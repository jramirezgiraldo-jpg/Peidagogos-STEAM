$pdfPath = "d:\Peidagogos_Local\DESCRIPCION_TECNICA_PEIDAGOGOS_STEAM.pdf"

$streamContent = @"
BT
/F1 18 Tf
40 790 Td
(MEMORIA TECNICA Y DESCRIPCION FUNCIONAL) Tj
/F2 10 Tf
0 -20 Td
(Direccion Nacional de Derecho de Autor - Republica de Colombia) Tj
0 -14 Td
(Obra: PEIDAGOGOS STEAM  |  Autor y Titular: Juan Felipe Ramirez Giraldo - CC 9770462  |  Ano: 2026) Tj
0 -12 Td
(-------------------------------------------------------------------------------------------------------------------------) Tj
/F1 12 Tf
0 -22 Td
(1. OBJETO Y FINALIDAD DEL SOFTWARE) Tj
/F2 9 Tf
0 -14 Td
(PEIDAGOGOS STEAM es una plataforma integral EdTech para la ensenanza, gestion del aprendizaje adaptativo) Tj
0 -13 Td
(y evaluacion por competencias STEAM articulada con las mallas curriculares y Derechos Basicos de Aprendizaje (DBA)) Tj
0 -13 Td
(de Colombia. Incorpora motor pedagogico asistido por Inteligencia Artificial y mecanicas de gamificacion continua.) Tj
/F1 12 Tf
0 -22 Td
(2. ESPECIFICACION TECNICA Y ARQUITECTURA) Tj
/F2 9 Tf
0 -14 Td
(- Backend: Servidor RESTful Node.js / Express.js con control de sesiones, seguridad HTTP y persistencia JSON indexada.) Tj
0 -13 Td
(- Frontend: SPA responsiva en HTML5, CSS3 y JavaScript moderno con vistas adaptadas a movil, tablet y escritorio.) Tj
0 -13 Td
(- Motor IA: Asistente pedagogico server-side para generacion de guias didacticas contextualizadas y preguntas ICFES.) Tj
0 -13 Td
(- Seguridad: Encabezados de seguridad, trazabilidad de estudiantes y marcas de agua digitales de derechos de autor.) Tj
0 -13 Td
(- Alertas: Notificaciones transaccionales y de matricula automatizadas en tiempo real.) Tj
/F1 12 Tf
0 -22 Td
(3. MODULOS Y FUNCIONALIDADES PRINCIPALES) Tj
/F2 9 Tf
0 -14 Td
(- Modulo Aulas y Mallas DBA: Explorador interactivo de estandares curriculares por periodos y semanas academicas.) Tj
0 -13 Td
(- Modulo Guias de Aprendizaje Continuo: Generador y persistencia de guias interactivas por semana y estudiante.) Tj
0 -13 Td
(- Modulo Gamificacion (XP): Acumulacion de experiencia, rangos jerarquicos, logros, sanciones y Salon de la Fama.) Tj
0 -13 Td
(- Modulo Multirrol: Paneles para Docentes, Tutores Home School, Estudiantes de Validacion y Administrador General.) Tj
0 -13 Td
(- Modulo Proyector: Interfaz interactiva de alta resolucion para transmision en salas de clase y tableros digitales.) Tj
/F1 12 Tf
0 -22 Td
(4. ESTRUCTURA DEL CODIGO FUENTE (PAQUETE DE REGISTRO)) Tj
/F2 9 Tf
0 -14 Td
(- server.js (Servidor Backend y APIs) | app.js (Logica de Cliente y Gamificacion) | login.html (Interfaz SPA)) Tj
0 -13 Td
(- diagnostico_nocturno.js (Modulo de Evaluacion Diagnostica) | proyector.html (Panel de Proyeccion en Aula)) Tj
ET
"@

$streamLen = [System.Text.Encoding]::ASCII.GetByteCount($streamContent)

$obj1 = "1 0 obj`r`n<</Type/Catalog/Pages 2 0 R>>`r`nendobj`r`n"
$obj2 = "2 0 obj`r`n<</Type/Pages/Kids[3 0 R]/Count 1>>`r`nendobj`r`n"
$obj3 = "3 0 obj`r`n<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 842]/Contents 4 0 R/Resources<</Font<</F1 5 0 R/F2 6 0 R>>>>>>`r`nendobj`r`n"
$obj4 = "4 0 obj`r`n<</Length $streamLen>>`r`nstream`r`n$streamContent`r`nendstream`r`nendobj`r`n"
$obj5 = "5 0 obj`r`n<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold>>`r`nendobj`r`n"
$obj6 = "6 0 obj`r`n<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>`r`nendobj`r`n"

$pdfHeader = "%PDF-1.4`r`n"

$body = ""
$xref = [System.Collections.Generic.List[string]]::new()
$xref.Add("xref")
$xref.Add("0 7")
$xref.Add("0000000000 65535 f `r`n")

$offset = [System.Text.Encoding]::ASCII.GetByteCount($pdfHeader)

$objs = @($obj1, $obj2, $obj3, $obj4, $obj5, $obj6)
foreach ($o in $objs) {
    $strOffset = ("{0:D10}" -f $offset)
    $xref.Add("$strOffset 00000 n `r`n")
    $body += $o
    $offset += [System.Text.Encoding]::ASCII.GetByteCount($o)
}

$xrefStr = ($xref -join "")
$trailer = "trailer`r`n<</Size 7/Root 1 0 R>>`r`nstartxref`r`n$offset`r`n%%EOF`r`n"

$fullPdf = $pdfHeader + $body + $xrefStr + $trailer
[System.IO.File]::WriteAllText($pdfPath, $fullPdf, [System.Text.Encoding]::ASCII)

Get-Item $pdfPath | Select-Object Name, Length, LastWriteTime
