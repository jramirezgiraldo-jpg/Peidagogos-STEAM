const fs = require('fs');

const appContent = fs.readFileSync('app.js', 'utf8');

// Extraer la función perteneceAlGrupo
const funcMatch = appContent.match(/window\.perteneceAlGrupo\s*=\s*function[\s\S]*?\n\};/);
if (!funcMatch) {
    console.error("No se encontró perteneceAlGrupo");
    process.exit(1);
}

const window = {};
eval(funcMatch[0]);
const perteneceAlGrupo = window.perteneceAlGrupo;

const usuarios = JSON.parse(fs.readFileSync('usuarios.json', 'utf8'));

const gruposProbar = [
    '6A', '6B', '7A', '7B', '7C', '8A', '8B', '9A', '10A', '10D', 'PENS',
    'Ciclo I (1°, 2°, 3°)', 'Ciclo II (4°, 5°)', 'Ciclo III (6°, 7°)', 'Ciclo IV (8°, 9°)', 'Ciclo V (10°)', 'Ciclo VI (11°)',
    'Ciclo I', 'Ciclo II', 'Ciclo III', 'Ciclo IV', 'Ciclo V', 'Ciclo VI',
    'HS-1', 'HS-2', 'HS-3', 'HS-4', 'HS-5', 'HS-6', 'HS-7', 'HS-8', 'HS-9', 'HS-10', 'HS-11'
];

console.log("=== RESULTADOS DE PERTENECE AL GRUPO ===");
gruposProbar.forEach(g => {
    const filtrados = usuarios.filter(u => perteneceAlGrupo(u, g));
    if (filtrados.length > 0) {
        console.log(`Grupo [${g}]: ${filtrados.length} estudiantes encontrados ->`);
        filtrados.forEach(f => {
            console.log(`   - Doc: ${f.documento}, Nombre: ${f.nombre} ${f.apellidos}, Grado: ${f.grado}, Grupo: ${f.grupo}`);
        });
    }
});
