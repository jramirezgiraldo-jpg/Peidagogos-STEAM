$zipPath = Join-Path $env:TEMP "mingit.zip"
$targetDir = Join-Path $env:USERPROFILE "mingit"

if (-not (Test-Path "$targetDir\cmd\git.exe")) {
    Write-Host "Downloading MinGit..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $url = "https://github.com/git-for-windows/git/releases/download/v2.44.0.windows.1/MinGit-2.44.0-64-bit.zip"
    Invoke-WebRequest -Uri $url -OutFile $zipPath
    Write-Host "Extracting MinGit to $targetDir..."
    Expand-Archive -Path $zipPath -DestinationPath $targetDir -Force
}

$gitExe = "$targetDir\cmd\git.exe"
if (Test-Path $gitExe) {
    Write-Host "SUCCESS: Git installed at $gitExe"
    & $gitExe --version
} else {
    Write-Host "ERROR: Git installation failed."
}
