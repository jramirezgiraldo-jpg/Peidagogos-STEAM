import os
import sys

files = [
    r"C:\Users\Juan Felipe\Documents\DBA C naturales.pdf",
    r"C:\Users\Juan Felipe\Documents\DBA C sociales.pdf",
    r"C:\Users\Juan Felipe\Documents\DBA lenguaje.pdf",
    r"C:\Users\Juan Felipe\Documents\DBA matematicas.pdf"
]

print("=== CHECKING DBA FILES ===")
for f in files:
    if os.path.exists(f):
        size_mb = os.path.getsize(f) / (1024 * 1024)
        print(f"FOUND: {f} ({size_mb:.2f} MB)")
    else:
        print(f"NOT FOUND: {f}")
