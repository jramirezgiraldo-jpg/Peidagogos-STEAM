const fs = require('fs');
const code = fs.readFileSync('d:/Peidagogos_Local/app.js', 'utf8');

// Check line by line for unmatched backticks
const lines = code.split('\n');
let inTemplate = false;
let templateStartLine = -1;
let openBraces = 0;

for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let j = 0;
    while (j < line.length) {
        if (line[j] === '\\') {
            j += 2;
            continue;
        }
        if (line[j] === '`') {
            inTemplate = !inTemplate;
            if (inTemplate) templateStartLine = i + 1;
        }
        j++;
    }
}

console.log("In template at EOF:", inTemplate, "started at line:", templateStartLine);
