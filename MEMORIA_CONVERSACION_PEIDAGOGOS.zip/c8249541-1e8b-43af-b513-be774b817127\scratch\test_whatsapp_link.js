const fs = require('fs');
const vm = require('vm');

global.window = global;
global.window.addEventListener = function() {};
global.window.removeEventListener = function() {};
global.window.location = { reload() {}, href: '', search: '' };
let lastOpenedUrl = '';
global.window.open = function(url, target) {
    lastOpenedUrl = url;
};

global.localStorage = {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    clear() { this._data = {}; }
};
global.document = {
    getElementById(id) { 
        if (id === 'peidabot-categoria-select') return { value: 'bug' };
        if (id === 'peidabot-mensaje-input') return { value: 'Prueba de anomalia tecnica en grado 7', focus() {} };
        if (id === 'peidabot-docente-input') return { value: 'Prof. Camilo - IE Montenegro' };
        if (id === 'peidabot-confirmacion-msg') return { style: {} };
        if (id === 'peidabot-form-container') return { style: {} };
        return null; 
    },
    querySelectorAll(sel) { return []; },
    addEventListener(evt, fn) {},
    removeEventListener(evt, fn) {},
    createElement(tag) { return { style: {}, appendChild() {}, innerHTML: '' }; }
};

// Mock fetch to prevent network errors in node test
global.fetch = async function() { return { ok: true, json: async () => [] }; };

const appCode = fs.readFileSync('d:/Peidagogos_Local/app.js', 'utf8');
vm.runInThisContext(appCode);

console.log('--- TEST: Validación de Envío de Mensajes a WhatsApp Oficial ---');
const numeroOficial = window.obtenerNumeroWhatsAppAdmin();
console.log('Número configurado:', numeroOficial);

// 1. Prueba de reporte PeidaBot
window.enviarReporteFeedback('whatsapp');
console.log('URL PeidaBot generada:', lastOpenedUrl);

if (lastOpenedUrl.startsWith('https://wa.me/573005590679?text=')) {
    console.log('✅ TEST 1 PASÓ: El reporte de PeidaBot se dirige a https://wa.me/573005590679');
} else {
    console.error('❌ TEST 1 FALLÓ');
}

// 2. Prueba de Resumen Diario WhatsApp
window.enviarResumenDiarioWhatsApp();
console.log('URL Resumen Diario generada:', lastOpenedUrl);

if (lastOpenedUrl.startsWith('https://wa.me/573005590679?text=')) {
    console.log('✅ TEST 2 PASÓ: El Resumen Diario se dirige a https://wa.me/573005590679');
} else {
    console.error('❌ TEST 2 FALLÓ');
}

console.log('--- TODOS LOS TESTS DE WHATSAPP PASARON SATISFACTORIAMENTE ---');
process.exit(0);
