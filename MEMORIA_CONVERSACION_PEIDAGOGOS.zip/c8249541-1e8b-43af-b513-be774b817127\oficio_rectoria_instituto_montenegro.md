# OFICIO FORMAL DE PUESTA A DISPOSICIÓN INSTITUCIONAL Y TÉRMINOS DE USO PILOTO

**Montenegro, Quindío, 18 de agosto de 2026**

**Señor:**  
**LIC. JORGE ELIÉCER**  
Rector  
**INSTITUCIÓN EDUCATIVA INSTITUTO MONTENEGRO**  
Montenegro, Quindío  

---

**ASUNTO:** Puesta a disposición solidaria de la plataforma tecnológica **"Peidagogos STEAM"** para la atención pedagógica post-emergencia sísmica y formalización de Términos de Uso en Fase Piloto Institucional.

---

**Respetado Señor Rector:**

Por medio de la presente comunicación, en mi calidad de docente de la institución y desarrollador de software, me dirijo a usted con el propósito de poner a disposición institucional y comunitaria, de manera solidaria y totalmente gratuita, la plataforma educativa interactiva **PEIDAGOGOS STEAM**.

Ante la contingencia y afectaciones derivadas del reciente evento sísmico en nuestro municipio y departamento, he integrado en la plataforma un módulo transversal de **"Primeros Auxilios Emocionales Post-Terremoto"** y contención socioemocional, junto con herramientas digitales para la continuidad del aprendizaje, la gestión de guías quincenales, proyección de clases y evaluación formativa orientada a los estándares oficiales del Ministerio de Educación Nacional (MEN).

---

### 1. TITULARIDAD Y REGISTRO ANTE LA DIRECCIÓN NACIONAL DE DERECHO DE AUTOR (DNDA)

Me permito informarle que la plataforma tecnológica **Peidagogos STEAM** cuenta con solicitud formal de registro de soporte lógico radicada ante la **Dirección Nacional de Derecho de Autor (DNDA)** de la República de Colombia bajo el **Número de Radicado 1-2026-000055** en la categoría **Software** (con fecha de radicación *12 de agosto de 2026 a las 03:37 PM*), a nombre del suscrito, **Juan Felipe Ramírez Giraldo**, en concordancia con la Ley 23 de 1982, la Decisión Andina 351 de 1993 y las directrices de la OMPI.

---

### 2. DELIMITACIÓN Y RECONOCIMIENTO DE REFERENTES CURRICULARES OFICIALES

Para total claridad institucional y jurídica, se hace constar expresamente que:

1. **Los Derechos Básicos de Aprendizaje (DBA), Matrices de Aprendizaje, Lineamientos Curriculares y Estándares Básicos de Competencias (EBC)** son documentos oficiales y propiedad exclusiva del **Ministerio de Educación Nacional (MEN)**, los cuales se incorporan en la plataforma como referentes pedagógicos de libre consulta formativa según el artículo 41 de la Ley 23 de 1982.
2. **Los planes de área, mallas y documentos institucionales** aportados por los docentes y la IE Instituto Montenegro son de titularidad de la comunidad académica institucional.
3. **Toda la ingeniería de software, arquitectura tecnológica, algoritmos de aprendizaje de documentos, motores de actividades interactivas, interfaces gráficas (UX/UI), simuladores y código fuente** constituyen la creación y propiedad intelectual exclusiva del suscrito autor.

---

### 3. TÉRMINOS Y CONDICIONES DE LA LICENCIA DE USO PILOTO INSTITUCIONAL

El uso de la plataforma por parte de directivos, docentes y estudiantes de la IE Instituto Montenegro se rige bajo los siguientes términos:

- **Gratuidad y Finalidad Solidaria:** El acceso para todos los docentes y estudiantes de la institución es completamente gratuito ($0 COP) durante la presente fase de contingencia y evaluación académica.
- **Licencia Académica Intransferible:** La autorización concedida a la institución es de uso personal, pedagógico e institucional, sin transferencia de derechos patrimoniales sobre el software.
- **Prohibición de Reproducción o Comercialización:** Queda prohibida la copia, descompilación, extracción masiva de código o explotación comercial no autorizada de la plataforma por parte de terceros.
- **Retroalimentación y Mejora Continua:** Las observaciones, sugerencias o reportes pedagógicos que realicen los docentes a través del asistente virtual (*PeidaBot*) serán recibidos de forma voluntaria y utilizados exclusivamente para la optimización técnica y pedagógica continua de la herramienta en beneficio de la comunidad.

---

### 4. SOLICITUD Y DISPOSICIÓN

Agradezco de antemano su receptividad y quedo a su entera disposición para coordinar una breve socialización con el equipo docente, presentar las funcionalidades de apoyo en aula y facilitar los accesos institucionales para el beneficio integral de nuestros estudiantes.

Cordialmente,

<br><br>

____________________________________________  
**JUAN FELIPE RAMÍREZ GIRALDO**  
Docente de la IE Instituto Montenegro  
Desarrollador y Titular de la Plataforma Peidagogos STEAM  
**Registro DNDA Radicado N.° 1-2026-000055 (Software)**  
*Montenegro, Quindío*
