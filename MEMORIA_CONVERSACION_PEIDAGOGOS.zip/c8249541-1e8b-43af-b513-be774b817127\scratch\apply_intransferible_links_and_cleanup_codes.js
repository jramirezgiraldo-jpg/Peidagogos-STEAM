const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

loginHtml = loginHtml.replace(/\r\n/g, '\n');
appJs = appJs.replace(/\r\n/g, '\n');

console.log('Iniciando: 1. Remover campo de código institucional, 2. Opción de Nueva IE dentro de dropdowns, 3. Generador de Enlaces y QR Intransferibles para Docentes...');

// =========================================================
// 1. MODIFICAR LOGIN.HTML: REMOVER CÓDIGO Y INTEGRAR NUEVA IE EN DROPDOWNS
// =========================================================

// A. Remover botón externo de nueva IE y poner la opción dentro del select
const targetDocenteIEBloque = `<div id="campo-docente-asignatura" style="display: none; flex-direction: column; gap: 10px; background: #F5F3FF; padding: 16px; border: 1.5px solid #DDD6FE; border-radius: 12px;">
            <label style="font-size: 0.88rem; font-weight: 800; color: #5B21B6; display: flex; align-items: center; justify-content: space-between; margin: 0;">
                <span>🏛️ Institución Educativa a la que Perteneces:</span>
            </label>
            <div style="display: flex; gap: 8px;">
                <select id="reg-docente-ie-select" style="flex: 1; padding: 10px; border: 1.5px solid #8B5CF6; border-radius: 8px; font-weight: bold; background-color: white; font-size: 0.9rem;">
                    <!-- Se llena dinámicamente -->
                </select>
                <button type="button" onclick="window.abrirModalCrearIE('docente')" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 14px; border-radius: 8px; font-weight: bold; font-size: 0.82rem; cursor: pointer; white-space: nowrap;">
                    ➕ Nueva IE
                </button>
            </div>
            <p style="margin: 0; color: #6D28D9; font-size: 0.8rem; line-height: 1.4;">
                ℹ️ <em>Tus materias y grados a cargo los configurarás y personalizarás con total comodidad directamente desde tu Panel Docente.</em>
            </p>
        </div>`;

const replacementDocenteIEBloque = `<div id="campo-docente-asignatura" style="display: none; flex-direction: column; gap: 10px; background: #F5F3FF; padding: 16px; border: 1.5px solid #DDD6FE; border-radius: 12px;">
            <label style="font-size: 0.88rem; font-weight: 800; color: #5B21B6; display: block; margin: 0;">
                <span>🏛️ Institución Educativa a la que Perteneces:</span>
            </label>
            <select id="reg-docente-ie-select" onchange="if(this.value==='__CREAR_NUEVA_IE__'){ window.abrirModalCrearIE('docente'); this.value=''; }" style="width: 100%; padding: 12px; border: 1.5px solid #8B5CF6; border-radius: 8px; font-weight: bold; background-color: white; font-size: 0.92rem; box-sizing: border-box;">
                <option value="">Selecciona tu Colegio o Institución...</option>
                <option value="IE Instituto Montenegro">🏫 IE Instituto Montenegro (Montenegro, Quindío)</option>
                <option value="__CREAR_NUEVA_IE__" style="color: #2563EB; font-weight: 900; background: #EFF6FF;">➕ Registrar / Crear Nueva Institución Educativa...</option>
            </select>
            <p style="margin: 0; color: #6D28D9; font-size: 0.8rem; line-height: 1.4;">
                ℹ️ <em>Tus materias y grados a cargo los configurarás con total comodidad directamente desde tu Panel Docente.</em>
            </p>
        </div>`;

if (loginHtml.includes(targetDocenteIEBloque)) {
    loginHtml = loginHtml.replace(targetDocenteIEBloque, replacementDocenteIEBloque);
    console.log('✅ Dropdown de IE docente actualizado con opción de Crear Nueva IE integrada.');
}

// B. Remover completamente el bloque #campo-codigo-institucional
const targetCampoCodigo = `<div id="campo-codigo-institucional" style="display: none; flex-direction: column; gap: 6px; background: #EFF6FF; padding: 12px; border: 1.5px solid #93C5FD; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
                <label id="lbl-codigo-institucional" style="font-size: 0.85rem; font-weight: bold; color: #1E3A8A; display: flex; align-items: center; gap: 6px; margin: 0;">
                    <span>🔑</span> Código Institucional / Verificación Docente:
                </label>
                <button type="button" onclick="iniciarEscaneoQRRegistro()" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 5px 12px; border-radius: 6px; font-weight: bold; font-size: 0.8rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(37,99,235,0.3);">
                    <span>📷</span> Escanear QR Proyectado
                </button>
            </div>
            <div style="display: flex; gap: 8px;">
                <input type="password" id="reg-codigo-institucional" placeholder="Ingresa el código oficial (ieinstituto2026)" style="flex: 1; padding: 10px 12px; border: 1.5px solid #3B82F6; border-radius: 6px; font-weight: bold; background-color: white; outline: none; font-size: 0.95rem;">
                <button type="button" onclick="const p = document.getElementById('reg-codigo-institucional'); p.type = (p.type === 'password' ? 'text' : 'password');" style="background: #E2E8F0; border: 1px solid #CBD5E1; border-radius: 6px; padding: 0 12px; cursor: pointer; font-size: 0.9rem;" title="Mostrar/Ocultar">👁️</button>
            </div>
            <span id="qr-feedback-status" style="font-size: 0.8rem; color: #475569;">Escribe el código oficial suministrado o escanea el QR proyectado.</span>
        </div>`;

if (loginHtml.includes(targetCampoCodigo)) {
    loginHtml = loginHtml.replace(targetCampoCodigo, '<!-- Campo de código retirado a favor de enlaces intransferibles y links directos -->');
    console.log('✅ Bloque de código institucional eliminado de login.html.');
}

// C. AGREGAR PESTAÑA Y VISTA DE GENERADOR DE ENLACES INTRANSFERIBLES EN EL PANEL ADMIN
const targetAdminTabs = `<div style="display: flex; background: #F3F4F6; border-bottom: 1px solid #E5E7EB; flex-wrap: wrap;">
                <button class="admin-tab-btn active" data-tab="grupos" style="padding: 15px 30px; border: none; background: white; font-weight: bold; cursor: pointer; border-bottom: 3px solid #3B82F6;">Instituciones</button>
                <button class="admin-tab-btn" data-tab="docentes" style="padding: 15px 30px; border: none; background: transparent; font-weight: bold; cursor: pointer; color: #6B7280;">Lista Docentes</button>`;

const replacementAdminTabs = `<div style="display: flex; background: #F3F4F6; border-bottom: 1px solid #E5E7EB; flex-wrap: wrap;">
                <button class="admin-tab-btn active" data-tab="grupos" style="padding: 15px 24px; border: none; background: white; font-weight: bold; cursor: pointer; border-bottom: 3px solid #3B82F6;">Instituciones</button>
                <button class="admin-tab-btn" data-tab="docentes" style="padding: 15px 24px; border: none; background: transparent; font-weight: bold; cursor: pointer; color: #6B7280;">Lista Docentes</button>
                <button class="admin-tab-btn" data-tab="invitaciones" style="padding: 15px 24px; border: none; background: transparent; font-weight: 900; cursor: pointer; color: #7C3AED; display: flex; align-items: center; gap: 6px;">
                    <span>🔑</span> Generador Links & QR Docentes
                </button>`;

if (loginHtml.includes(targetAdminTabs)) {
    loginHtml = loginHtml.replace(targetAdminTabs, replacementAdminTabs);
    console.log('✅ Pestaña de Generador Links & QR Docentes inyectada en el panel Admin.');
}

// D. AGREGAR VISTA #admin-view-invitaciones EN EL PANEL ADMIN
const targetAdminDocentesView = `<div id="admin-view-docentes" class="admin-view" style="display: none; padding: 20px;">`;

const vistaInvitacionesAdminHtml = `
            <!-- VISTA ADMIN: GENERADOR DE ENLACES Y QR INTRANSFERIBLES PARA DOCENTES -->
            <div id="admin-view-invitaciones" class="admin-view" style="display: none; padding: 28px;">
                <div style="background: white; border-radius: 16px; border: 1.5px solid #E2E8F0; padding: 26px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); margin-bottom: 25px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; flex-wrap: wrap; gap: 10px;">
                        <div>
                            <h3 style="margin: 0; font-size: 1.45rem; font-weight: 900; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                                <span>🔑</span> Generador de Enlaces y Códigos QR Intransferibles para Docentes
                            </h3>
                            <p style="margin: 4px 0 0 0; color: #64748B; font-size: 0.92rem;">
                                Genera invitaciones seguras con token intransferible. El docente se registra o ingresa directamente con solo escanear el QR o abrir el enlace, sin códigos ni trámites.
                            </p>
                        </div>
                        <span style="background: #F3E8FF; color: #7E22CE; padding: 6px 14px; border-radius: 20px; font-weight: 900; font-size: 0.85rem;">
                            🔒 Acceso Blindado DNDA 1-2026-000055
                        </span>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 16px; background: #F8FAFC; padding: 20px; border-radius: 14px; border: 1px solid #CBD5E1; margin-bottom: 20px;">
                        <div>
                            <label style="display: block; font-weight: 800; color: #1E293B; font-size: 0.88rem; margin-bottom: 5px;">
                                🏛️ Institución Educativa:
                            </label>
                            <select id="admin-inv-ie-select" style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-weight: 700; font-size: 0.9rem; background: white;">
                                <option value="IE Instituto Montenegro">IE Instituto Montenegro (Montenegro, Quindío)</option>
                                <option value="Colegio San José">Colegio San José</option>
                                <option value="Instituto Técnico Industrial">Instituto Técnico Industrial</option>
                            </select>
                        </div>

                        <div>
                            <label style="display: block; font-weight: 800; color: #1E293B; font-size: 0.88rem; margin-bottom: 5px;">
                                👨‍🏫 Nombre del Docente Invitado:
                            </label>
                            <input type="text" id="admin-inv-nombre-input" placeholder="Ej: Lic. Jorge Eliécer" style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-weight: 700; font-size: 0.9rem; box-sizing: border-box;">
                        </div>

                        <div>
                            <label style="display: block; font-weight: 800; color: #1E293B; font-size: 0.88rem; margin-bottom: 5px;">
                                🆔 Cédula / Documento (Opcional):
                            </label>
                            <input type="text" id="admin-inv-doc-input" placeholder="Ej: 109772671" style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-weight: 700; font-size: 0.9rem; box-sizing: border-box;">
                        </div>

                        <div>
                            <label style="display: block; font-weight: 800; color: #1E293B; font-size: 0.88rem; margin-bottom: 5px;">
                                📚 Materias / Área:
                            </label>
                            <input type="text" id="admin-inv-materia-input" placeholder="Ej: Ciencias Naturales, Física" style="width: 100%; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-weight: 700; font-size: 0.9rem; box-sizing: border-box;">
                        </div>
                    </div>

                    <div style="display: flex; justify-content: flex-end; gap: 12px;">
                        <button onclick="window.generarInvitacionDocenteIntransferible()" style="background: linear-gradient(135deg, #7C3AED, #6D28D9); color: white; border: none; padding: 12px 28px; border-radius: 10px; font-weight: 900; font-size: 1rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(124,58,237,0.35);">
                            <span>🚀</span> Generar Enlace Único y Código QR
                        </button>
                    </div>

                    <!-- Cuadro de Resultado de Invitación Generada -->
                    <div id="admin-invitacion-resultado-box" style="display: none; margin-top: 24px; background: #FAF5FF; border: 2px solid #C084FC; border-radius: 16px; padding: 24px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
                            <div>
                                <span style="background: #7C3AED; color: white; font-size: 0.75rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Invitación Generada</span>
                                <h4 id="admin-inv-resultado-docente-txt" style="margin: 6px 0 0 0; color: #1E293B; font-size: 1.3rem; font-weight: 900;">Docente</h4>
                            </div>
                            <span id="admin-inv-resultado-token-txt" style="font-family: monospace; font-weight: 900; background: white; padding: 6px 12px; border-radius: 8px; border: 1px solid #DDD6FE; color: #6D28D9; font-size: 0.9rem;">TOKEN</span>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 200px; gap: 20px; align-items: center;">
                            <div>
                                <label style="display: block; font-weight: 800; color: #475569; font-size: 0.85rem; margin-bottom: 4px;">Enlace Intransferible de Registro:</label>
                                <div style="display: flex; gap: 8px; margin-bottom: 14px;">
                                    <input type="text" id="admin-inv-url-input" readonly style="flex: 1; padding: 10px 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-size: 0.85rem; font-weight: 700; color: #1E293B; background: white;">
                                    <button onclick="window.copiarEnlaceInvitacionAdmin()" style="background: #2563EB; color: white; border: none; padding: 10px 16px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; white-space: nowrap;">
                                        📋 Copiar
                                    </button>
                                </div>

                                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                                    <button onclick="window.compartirInvitacionDocenteWhatsApp()" style="background: #10B981; color: white; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 900; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(16,185,129,0.25);">
                                        <span>📲</span> Enviar por WhatsApp
                                    </button>
                                    <button onclick="window.abrirVistaPreviaQRDocente()" style="background: #4F46E5; color: white; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 900; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(79,70,229,0.25);">
                                        <span>📽️</span> Proyectar QR en Pantalla Completa
                                    </button>
                                </div>
                            </div>

                            <!-- Contenedor del Código QR -->
                            <div style="background: white; border: 1.5px solid #DDD6FE; border-radius: 12px; padding: 10px; text-align: center;">
                                <img id="admin-inv-qr-img" src="" alt="QR Docente" style="width: 160px; height: 160px; object-fit: contain; margin: 0 auto; display: block;">
                                <span style="font-size: 0.72rem; font-weight: 800; color: #6D28D9; margin-top: 4px; display: block;">Escanea para Acceso Docente</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabla de Invitaciones Generadas -->
                <div style="background: white; border-radius: 16px; border: 1.5px solid #E2E8F0; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);">
                    <h4 style="margin: 0 0 16px 0; font-size: 1.2rem; font-weight: 900; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                        <span>📋</span> Historial de Invitaciones Intransferibles Generadas
                    </h4>
                    <div style="overflow-x: auto;">
                        <table style="width: 100%; border-collapse: collapse; text-align: left;">
                            <thead>
                                <tr style="border-bottom: 2px solid #E2E8F0; background: #F8FAFC;">
                                    <th style="padding: 12px 10px; font-weight: 800; color: #475569;">Fecha</th>
                                    <th style="padding: 12px 10px; font-weight: 800; color: #475569;">Docente</th>
                                    <th style="padding: 12px 10px; font-weight: 800; color: #475569;">Institución</th>
                                    <th style="padding: 12px 10px; font-weight: 800; color: #475569;">Token Intransferible</th>
                                    <th style="padding: 12px 10px; font-weight: 800; color: #475569;">Estado</th>
                                    <th style="padding: 12px 10px; text-align: center; font-weight: 800; color: #475569;">Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="tbody-admin-invitaciones-docentes">
                                <!-- Llenado por JS -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
`;

if (loginHtml.includes(targetAdminDocentesView)) {
    loginHtml = loginHtml.replace(targetAdminDocentesView, vistaInvitacionesAdminHtml + '\n' + targetAdminDocentesView);
    console.log('✅ Vista de Generador de Invitaciones Docentes inyectada en login.html');
}

// Actualizar versión de scripts a v57
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v57');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v57');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v57');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 2. ACTUALIZAR APP.JS CON GESTIÓN DE INVITACIONES Y TOKENS DOCENTES
// =========================================================

const logicaInvitacionesAdminJs = `
// =========================================================
// MÓDULO DE INVITACIONES Y TOKENS INTRANSFERIBLES PARA DOCENTES
// =========================================================
window.invitacionDocenteActiva = null;

window.generarInvitacionDocenteIntransferible = function() {
    const selIE = document.getElementById('admin-inv-ie-select');
    const inNom = document.getElementById('admin-inv-nombre-input');
    const inDoc = document.getElementById('admin-inv-doc-input');
    const inMat = document.getElementById('admin-inv-materia-input');

    const ie = selIE ? selIE.value : 'IE Instituto Montenegro';
    const nombre = inNom ? inNom.value.trim() : '';
    const documento = inDoc ? inDoc.value.trim() : '';
    const materia = inMat ? inMat.value.trim() : 'Ciencias Naturales y Educación Ambiental';

    if (!nombre) {
        alert("⚠️ Por favor ingresa el nombre del docente a invitar.");
        if (inNom) inNom.focus();
        return;
    }

    // Generar token único intransferible
    const token = 'TK-DOC-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    const baseUrl = window.location.origin + window.location.pathname;
    const urlFinal = \`\${baseUrl}?token_docente=\${token}&ie=\${encodeURIComponent(ie)}&nombre_doc=\${encodeURIComponent(nombre)}&doc=\${encodeURIComponent(documento)}&materia=\${encodeURIComponent(materia)}&rol=docente\`;
    const qrUrl = \`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=\${encodeURIComponent(urlFinal)}\`;

    const nuevaInvitacion = {
        token: token,
        nombre: nombre,
        documento: documento,
        institucion: ie,
        materia: materia,
        url: urlFinal,
        qr: qrUrl,
        fecha: new Date().toLocaleString('es-CO'),
        usado: false
    };

    // Guardar en base de datos de invitaciones
    let invList = JSON.parse(localStorage.getItem('invitaciones_docentes_db') || '[]');
    invList.unshift(nuevaInvitacion);
    localStorage.setItem('invitaciones_docentes_db', JSON.stringify(invList));

    window.invitacionDocenteActiva = nuevaInvitacion;

    // Mostrar en UI
    const resBox = document.getElementById('admin-invitacion-resultado-box');
    const txtDoc = document.getElementById('admin-inv-resultado-docente-txt');
    const txtTok = document.getElementById('admin-inv-resultado-token-txt');
    const inUrl = document.getElementById('admin-inv-url-input');
    const imgQR = document.getElementById('admin-inv-qr-img');

    if (txtDoc) txtDoc.innerText = \`Profesor(a) \${nombre} • \${ie}\`;
    if (txtTok) txtTok.innerText = token;
    if (inUrl) inUrl.value = urlFinal;
    if (imgQR) imgQR.src = qrUrl;
    if (resBox) resBox.style.display = 'block';

    window.renderizarTablaInvitacionesDocentesAdmin();
};

window.renderizarTablaInvitacionesDocentesAdmin = function() {
    const tbody = document.getElementById('tbody-admin-invitaciones-docentes');
    if (!tbody) return;

    const invList = JSON.parse(localStorage.getItem('invitaciones_docentes_db') || '[]');
    if (invList.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 25px; color: #64748B;">No hay invitaciones generadas aún.</td></tr>';
        return;
    }

    tbody.innerHTML = invList.map((inv, idx) => {
        const badgeEstado = inv.usado 
            ? '<span style="background: #ECFDF5; color: #047857; padding: 4px 10px; border-radius: 12px; font-weight: 800; font-size: 0.78rem;">✅ Utilizado</span>'
            : '<span style="background: #FEF3C7; color: #B45309; padding: 4px 10px; border-radius: 12px; font-weight: 800; font-size: 0.78rem;">⏳ Pendiente</span>';

        return \`
            <tr style="border-bottom: 1px solid #F1F5F9;">
                <td style="padding: 12px 10px; font-size: 0.85rem; color: #64748B;">\${inv.fecha}</td>
                <td style="padding: 12px 10px; font-weight: 800; color: #1E293B;">\${inv.nombre}</td>
                <td style="padding: 12px 10px; font-size: 0.85rem; color: #1E40AF;">\${inv.institucion}</td>
                <td style="padding: 12px 10px; font-family: monospace; font-weight: 800; color: #7C3AED;">\${inv.token}</td>
                <td style="padding: 12px 10px;">\${badgeEstado}</td>
                <td style="padding: 12px 10px; text-align: center;">
                    <div style="display: flex; gap: 6px; justify-content: center;">
                        <button onclick="navigator.clipboard.writeText('\${inv.url}'); alert('✅ Enlace copiado al portapapeles');" style="background: #2563EB; color: white; border: none; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; cursor: pointer;">
                            📋 Copiar Link
                        </button>
                        <button onclick="const t = encodeURIComponent('¡Hola Profesor(a) \${inv.nombre}! 👋\\\\n\\\\nLe compartimos su enlace oficial intransferible de acceso docente para Peidagogos STEAM:\\\\n\\\\n👉 \${inv.url}'); window.open('https://api.whatsapp.com/send?text='+t, '_blank');" style="background: #10B981; color: white; border: none; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; cursor: pointer;">
                            📲 WhatsApp
                        </button>
                    </div>
                </td>
            </tr>
        \`;
    }).join('');
};

window.copiarEnlaceInvitacionAdmin = function() {
    const inUrl = document.getElementById('admin-inv-url-input');
    if (!inUrl) return;
    inUrl.select();
    navigator.clipboard.writeText(inUrl.value).then(() => {
        alert("✅ Enlace intransferible copiado con éxito.");
    });
};

window.compartirInvitacionDocenteWhatsApp = function() {
    if (!window.invitacionDocenteActiva) return;
    const inv = window.invitacionDocenteActiva;
    const texto = \`¡Hola Profesor(a) *\${inv.nombre}*! 👋\\n\\nLe extendemos la invitación oficial para ingresar a la plataforma *Peidagogos STEAM* de la *\${inv.institucion}*.\\n\\n🔑 *Su enlace intransferible de acceso docente es:*\\n👉 \${inv.url}\\n\\n*(Al abrir este enlace ingresará directamente a su Panel Docente sin necesidad de códigos de verificación)*\`;
    window.open(\`https://api.whatsapp.com/send?text=\${encodeURIComponent(texto)}\`, '_blank');
};

window.abrirVistaPreviaQRDocente = function() {
    if (!window.invitacionDocenteActiva) return;
    const inv = window.invitacionDocenteActiva;
    const w = window.open('', '_blank');
    w.document.write(\`
        <html>
        <head><title>QR Docente - \${inv.nombre}</title></head>
        <body style="font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #0F172A; color: white; text-align: center; padding: 20px;">
            <img src="\${inv.qr}" style="width: 380px; height: 380px; background: white; padding: 20px; border-radius: 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
            <h1 style="margin: 24px 0 6px 0; font-size: 2.2rem;">Acceso Docente Intransferible</h1>
            <p style="font-size: 1.4rem; color: #94A3B8; margin: 0;">Profesor(a) \${inv.nombre} • \${inv.institucion}</p>
            <p style="font-size: 1rem; color: #38BDF8; font-family: monospace; margin-top: 10px;">Token: \${inv.token}</p>
        </body>
        </html>
    \`);
};

// =========================================================
// PROCESAMIENTO AUTOMÁTICO DE TOKEN INTRANSFERIBLE DOCENTE
// =========================================================
window.procesarTokenDocenteDesdeUrl = function() {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token_docente');
    const nom = params.get('nombre_doc');
    const doc = params.get('doc');
    const ie = params.get('ie');
    const materia = params.get('materia');

    if (token) {
        console.log("🔑 [TOKEN DOCENTE DETECTADO]:", { token, nom, ie });

        // Marcar token como utilizado
        try {
            let invList = JSON.parse(localStorage.getItem('invitaciones_docentes_db') || '[]');
            const idx = invList.findIndex(i => i.token === token);
            if (idx >= 0) {
                invList[idx].usado = true;
                localStorage.setItem('invitaciones_docentes_db', JSON.stringify(invList));
            }
        } catch(e) {}

        const docFinal = doc || ('doc_' + token.toLowerCase().replace(/[^a-z0-9]/g, ''));
        const nomFinal = nom ? decodeURIComponent(nom) : 'Docente Invitado';
        const ieFinal = ie ? decodeURIComponent(ie) : 'IE Instituto Montenegro';
        const matFinal = materia ? decodeURIComponent(materia) : 'Ciencias Naturales y Educación Ambiental';

        // Crear/Actualizar perfil docente en base de datos
        const payloadDocente = {
            documento: docFinal,
            cedula: docFinal,
            usuario: docFinal,
            nombre: nomFinal,
            nombres: nomFinal,
            apellidos: '',
            nombre_completo: nomFinal,
            edad: '35',
            genero: 'otro',
            rol: 'docente',
            tipo: 'docente_regular',
            institucion: ieFinal,
            asignatura: matFinal,
            materias: [matFinal],
            grados: ['6', '7', '8', '9', '10', '11'],
            pago_realizado: true,
            pago_activo: true,
            fecha_registro: new Date().toISOString()
        };

        try {
            let dList = JSON.parse(localStorage.getItem('docentes_db') || '[]');
            const dIdx = dList.findIndex(d => String(d.documento || '').toLowerCase() === String(docFinal).toLowerCase());
            if (dIdx >= 0) dList[dIdx] = { ...dList[dIdx], ...payloadDocente };
            else dList.push(payloadDocente);
            localStorage.setItem('docentes_db', JSON.stringify(dList));
        } catch(e) {}

        const sessionData = {
            status: 'success',
            usuario: docFinal,
            nombre: nomFinal,
            rol: 'docente',
            institucion: ieFinal,
            pago_activo: true,
            pago_realizado: true,
            usuarioObj: payloadDocente
        };
        sessionStorage.setItem('peidagogos_auth', JSON.stringify(sessionData));
        localStorage.setItem('usuario_sesion', JSON.stringify(sessionData));
        localStorage.setItem('usuario_actual', JSON.stringify(sessionData));
        window.usuario_actual = docFinal;
        window.rol_actual = 'docente';

        // Enviar notificación a Telegram
        if (window.enviarAlertaTelegram) {
            window.enviarAlertaTelegram(\`🔑 *DOCENTE INGRESÓ POR TOKEN INTRANSFERIBLE*\\n\\n👤 *Docente:* \${nomFinal}\\n🏷️ *Token:* \${token}\\n🏫 *Institución:* \${ieFinal}\\n📚 *Materia:* \${matFinal}\\n📅 *Fecha:* \${new Date().toLocaleString('es-CO')}\`);
        }

        // Ingresar al panel docente
        if (typeof mostrarVista === 'function') mostrarVista('docente-dashboard-container');
        const docView = document.getElementById('docente-dashboard-container');
        if (docView) docView.style.display = 'block';
        const dHeader = document.getElementById('docente-nombre-header');
        if (dHeader) dHeader.innerText = nomFinal;
        const dSub = document.getElementById('docente-institucion-subhead');
        if (dSub) dSub.innerText = \`🏛️ \${ieFinal}\`;

        if (typeof window.cargarEstudiantesDocente === 'function') {
            window.cargarEstudiantesDocente(docFinal);
        }

        alert(\`✅ ¡Bienvenido(a) Profesor(a) \${nomFinal}!\\n\\nHas ingresado de forma segura mediante tu Enlace Intransferible (\${token}) a la plataforma Peidagogos STEAM.\\n\\nTu Panel Docente para la \${ieFinal} está listo.\`);
    }
};

window.addEventListener('DOMContentLoaded', () => {
    setTimeout(window.procesarTokenDocenteDesdeUrl, 250);
});
`;

appJs += '\n' + logicaInvitacionesAdminJs;

// Actualizar window.cambiarTabAdmin para soportar 'invitaciones'
const targetCambiarTabAdmin = `else if (tabName === 'feedback') {
        const vFeedback = document.getElementById('admin-view-feedback');
        if (vFeedback) vFeedback.style.display = 'block';
        if (typeof window.renderizarBuzonAdmin === 'function') window.renderizarBuzonAdmin();
    }`;

const replacementCambiarTabAdmin = `else if (tabName === 'feedback') {
        const vFeedback = document.getElementById('admin-view-feedback');
        if (vFeedback) vFeedback.style.display = 'block';
        if (typeof window.renderizarBuzonAdmin === 'function') window.renderizarBuzonAdmin();
    } else if (tabName === 'invitaciones') {
        const vInv = document.getElementById('admin-view-invitaciones');
        if (vInv) vInv.style.display = 'block';
        if (typeof window.renderizarTablaInvitacionesDocentesAdmin === 'function') window.renderizarTablaInvitacionesDocentesAdmin();
    }`;

if (appJs.includes(targetCambiarTabAdmin)) {
    appJs = appJs.replace(targetCambiarTabAdmin, replacementCambiarTabAdmin);
    console.log('✅ cambiarTabAdmin actualizado con soporte para pestaña invitaciones.');
}

// Remover cualquier validación residual de código institucional en ejecutarRegistroEstudiante
const targetNormCodCheck = `if (!window.matriculaContingenciaActiva && normCod !== "ieinstituto2026" && normCod !== "instituto2026") {`;
const replacementNormCodCheck = `if (false) {`;

if (appJs.includes(targetNormCodCheck)) {
    appJs = appJs.replace(targetNormCodCheck, replacementNormCodCheck);
    console.log('✅ Verificación residual de código en registro desactivada.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
