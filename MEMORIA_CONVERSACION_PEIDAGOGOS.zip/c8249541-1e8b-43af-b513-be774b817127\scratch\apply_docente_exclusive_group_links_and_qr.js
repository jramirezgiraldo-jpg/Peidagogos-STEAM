const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

loginHtml = loginHtml.replace(/\r\n/g, '\n');
appJs = appJs.replace(/\r\n/g, '\n');

console.log('Iniciando: Enlaces y QR exclusivos de aula para docentes sin códigos...');

// 1. ACTUALIZAR MODAL DE ENLACE Y QR DE AULA EN LOGIN.HTML
const targetModalLinkHtml = `<div id="modal-link-contingencia-grupo" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.75); backdrop-filter: blur(4px); z-index: 100001; justify-content: center; align-items: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 580px; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); border: 1px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column;">
            
            <div style="background: linear-gradient(135deg, #2563EB, #1D4ED8); padding: 22px 26px; color: white; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 1.8rem;">🔗</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.35rem; font-weight: 900; color: white;">Enlace de Matrícula Directa</h3>
                        <p style="margin: 3px 0 0 0; font-size: 0.85rem; opacity: 0.95;">Listo para pegar en WhatsApp o Redes Sociales</p>
                    </div>
                </div>
                <button onclick="document.getElementById('modal-link-contingencia-grupo').style.display='none'" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; justify-content: center;">✕</button>
            </div>

            <div style="padding: 26px; display: flex; flex-direction: column; gap: 18px;">
                
                <div>
                    <span style="font-size: 0.82rem; font-weight: 800; color: #64748B; text-transform: uppercase;">AULA ASIGNADA</span>
                    <h3 id="modal-link-grupo-titulo" style="margin: 4px 0 10px 0; color: #0F172A; font-size: 1.35rem; font-weight: 900;">Grupo 7C</h3>
                    
                    <div style="background: #F1F5F9; border: 1.5px solid #CBD5E1; border-radius: 12px; padding: 12px; display: flex; align-items: center; gap: 10px;">
                        <input type="text" id="modal-link-input-url" readonly style="flex: 1; background: transparent; border: none; font-size: 0.88rem; font-weight: 700; color: #1E293B; outline: none;">
                        <button onclick="window.copiarLinkContingenciaDesdeModal()" style="background: #2563EB; color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; white-space: nowrap;">
                            📋 Copiar Link
                        </button>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="window.compartirLinkContingenciaWhatsApp()" style="flex: 1; background: #10B981; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(16,185,129,0.3);">
                        <span>📲</span> Compartir en WhatsApp
                    </button>
                    <button onclick="window.copiarMensajeCompletoRedes()" style="flex: 1; background: #4F46E5; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(79,70,229,0.3);">
                        <span>📝</span> Copiar Mensaje Completo
                    </button>
                </div>

                <div id="modal-link-copiado-feedback" style="display: none; background: #ECFDF5; border: 1px solid #86EFAC; color: #065F46; padding: 10px; border-radius: 8px; text-align: center; font-weight: 800; font-size: 0.88rem;">
                    ✅ ¡Enlace copiado al portapapeles! Pégalo en tu grupo de WhatsApp o red social.
                </div>

            </div>
        </div>
    </div>`;

const replacementModalLinkHtml = `<div id="modal-link-contingencia-grupo" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.8); backdrop-filter: blur(6px); z-index: 100001; justify-content: center; align-items: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 640px; border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.3); border: 1.5px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column;">
            
            <div style="background: linear-gradient(135deg, #1E40AF, #3B82F6); padding: 22px 28px; color: white; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 14px;">
                    <span style="font-size: 2.2rem;">🔗</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.45rem; font-weight: 900; color: white;">Enlace y QR Exclusivo del Aula</h3>
                        <p style="margin: 3px 0 0 0; font-size: 0.88rem; opacity: 0.95;">Matrícula instantánea para tus estudiantes sin códigos de verificación</p>
                    </div>
                </div>
                <button onclick="document.getElementById('modal-link-contingencia-grupo').style.display='none'" style="background: rgba(255,255,255,0.25); border: none; color: white; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; font-weight: 900; font-size: 1.2rem; display: flex; align-items: center; justify-content: center;">✕</button>
            </div>

            <div style="padding: 28px; display: flex; flex-direction: column; gap: 20px; max-height: 80vh; overflow-y: auto;">
                
                <!-- Identificación del Aula -->
                <div style="background: #F8FAFC; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 18px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                    <div>
                        <span style="font-size: 0.75rem; font-weight: 900; color: #64748B; text-transform: uppercase; letter-spacing: 0.5px;">AULA EXCLUSIVA</span>
                        <h3 id="modal-link-grupo-titulo" style="margin: 2px 0 0 0; color: #0F172A; font-size: 1.45rem; font-weight: 900;">Grupo 7C</h3>
                        <div id="modal-link-grupo-subtitulo" style="font-size: 0.88rem; color: #475569; font-weight: 700; margin-top: 2px;">IE Instituto Montenegro</div>
                    </div>
                    <span style="background: #ECFDF5; color: #047857; border: 1.5px solid #A7F3D0; padding: 6px 14px; border-radius: 20px; font-weight: 900; font-size: 0.82rem;">
                        ⚡ Matrícula Sin Códigos
                    </span>
                </div>

                <!-- Contenedor Central: URL + Código QR Dinámico -->
                <div style="display: grid; grid-template-columns: 1fr 180px; gap: 20px; align-items: center;">
                    <div>
                        <label style="display: block; font-weight: 800; color: #1E293B; font-size: 0.88rem; margin-bottom: 6px;">
                            📋 Enlace Web para Redes Sociales:
                        </label>
                        <div style="background: #F1F5F9; border: 1.5px solid #CBD5E1; border-radius: 12px; padding: 10px 12px; display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                            <input type="text" id="modal-link-input-url" readonly style="flex: 1; background: transparent; border: none; font-size: 0.82rem; font-weight: 700; color: #1E293B; outline: none;">
                            <button onclick="window.copiarLinkContingenciaDesdeModal()" style="background: #2563EB; color: white; border: none; padding: 8px 14px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; white-space: nowrap;">
                                Copiar
                            </button>
                        </div>
                        <p style="margin: 0; color: #64748B; font-size: 0.8rem; line-height: 1.45;">
                            💡 <em>Copia este link y pégalo en el grupo de WhatsApp de tu aula o de padres. Al abrirlo, el estudiante solo escribe sus datos básicos y entra directamente a tu planilla.</em>
                        </p>
                    </div>

                    <!-- Visualizador del Código QR del Aula -->
                    <div style="background: #FAF5FF; border: 2px solid #DDD6FE; border-radius: 16px; padding: 10px; text-align: center;">
                        <img id="modal-link-grupo-qr-img" src="" alt="QR Aula" style="width: 150px; height: 150px; object-fit: contain; margin: 0 auto; display: block; background: white; border-radius: 10px; padding: 4px;">
                        <span style="font-size: 0.72rem; font-weight: 800; color: #6D28D9; margin-top: 4px; display: block;">Escanear con Celular</span>
                    </div>
                </div>

                <!-- Botones de Acción Inmediata -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
                    <button onclick="window.compartirLinkContingenciaWhatsApp()" style="background: #10B981; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(16,185,129,0.3);">
                        <span>📲</span> Enviar a WhatsApp
                    </button>
                    <button onclick="window.proyectarQRAulaPantallaCompleta()" style="background: #4F46E5; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(79,70,229,0.3);">
                        <span>📽️</span> Proyectar QR en Aula
                    </button>
                    <button onclick="window.copiarMensajeCompletoRedes()" style="background: #0284C7; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(2,132,199,0.3);">
                        <span>📝</span> Copiar Mensaje
                    </button>
                </div>

                <div id="modal-link-copiado-feedback" style="display: none; background: #ECFDF5; border: 1px solid #86EFAC; color: #065F46; padding: 12px; border-radius: 10px; text-align: center; font-weight: 800; font-size: 0.9rem;">
                    ✅ ¡Enlace copiado al portapapeles! Pégalo en tu grupo de WhatsApp o red social.
                </div>

            </div>
        </div>
    </div>`;

if (loginHtml.includes(targetModalLinkHtml)) {
    loginHtml = loginHtml.replace(targetModalLinkHtml, replacementModalLinkHtml);
    console.log('✅ Modal de enlace y QR exclusivo de aula actualizado con QR dinámico y proyección.');
}

// Actualizar versión de scripts a v58
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v58');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v58');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v58');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 2. ACTUALIZAR APP.JS CON FUNCIONES DE QR DINÁMICO DEL AULA Y PROYECCIÓN
// =========================================================

const updateAppJsModalLogic = `
// =========================================================
// ACTUALIZACIÓN DE MODAL DE ENLACE Y QR EXCLUSIVO DE AULA
// =========================================================
window.abrirModalLinkContingenciaGrupo = function(nombreGrupo, grado, materia) {
    const modal = document.getElementById('modal-link-contingencia-grupo');
    if (!modal) return;

    let authSes = {};
    try {
        authSes = JSON.parse(sessionStorage.getItem('peidagogos_auth') || localStorage.getItem('usuario_actual') || '{}');
    } catch(e) {}

    const docId = String(window.usuario_actual || authSes.documento || authSes.usuario || 'docente').trim();
    const docNom = (document.getElementById('docente-nombre-header') ? document.getElementById('docente-nombre-header').innerText : (authSes.nombre || 'Docente')).trim();
    const docIE = (authSes.institucion || 'IE Instituto Montenegro').trim();

    // Generar token exclusivo de aula
    const tokenAula = 'AULA-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    const baseUrl = window.location.origin + window.location.pathname;
    const linkFinal = \`\${baseUrl}?token_aula=\${tokenAula}&reg=directo&docente=\${encodeURIComponent(docId)}&nombre_doc=\${encodeURIComponent(docNom)}&ie=\${encodeURIComponent(docIE)}&grupo=\${encodeURIComponent(nombreGrupo)}&grado=\${encodeURIComponent(grado || '')}&materia=\${encodeURIComponent(materia || '')}\`;
    const qrUrl = \`https://api.qrserver.com/v1/create-qr-code/?size=280x280&data=\${encodeURIComponent(linkFinal)}\`;

    window.grupoLinkActivo = {
        nombre: nombreGrupo,
        grado: grado,
        materia: materia,
        docente: docNom,
        ie: docIE,
        token: tokenAula,
        url: linkFinal,
        qr: qrUrl
    };

    const inUrl = document.getElementById('modal-link-input-url');
    const titGrupo = document.getElementById('modal-link-grupo-titulo');
    const subGrupo = document.getElementById('modal-link-grupo-subtitulo');
    const imgQR = document.getElementById('modal-link-grupo-qr-img');
    const fbCopiado = document.getElementById('modal-link-copiado-feedback');

    if (inUrl) inUrl.value = linkFinal;
    if (titGrupo) titGrupo.innerText = \`Grupo \${nombreGrupo}\`;
    if (subGrupo) subGrupo.innerText = \`👨‍🏫 \${docNom} • 🏛️ \${docIE}\`;
    if (imgQR) imgQR.src = qrUrl;
    if (fbCopiado) fbCopiado.style.display = 'none';

    modal.style.display = 'flex';
};

window.proyectarQRAulaPantallaCompleta = function() {
    if (!window.grupoLinkActivo) return;
    const g = window.grupoLinkActivo;
    const w = window.open('', '_blank');
    w.document.write(\`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Matrícula Directa - Grupo \${g.nombre}</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    margin: 0;
                    padding: 30px 20px;
                    font-family: 'Inter', system-ui, -apple-system, sans-serif;
                    background: #0F172A;
                    color: white;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    box-sizing: border-box;
                    text-align: center;
                }
                .card {
                    background: white;
                    color: #0F172A;
                    padding: 35px 40px;
                    border-radius: 28px;
                    box-shadow: 0 25px 60px rgba(0,0,0,0.6);
                    max-width: 520px;
                    width: 100%;
                }
                .qr-box {
                    background: #F8FAFC;
                    border: 2px solid #E2E8F0;
                    border-radius: 20px;
                    padding: 16px;
                    display: inline-block;
                    margin: 20px 0;
                }
                .btn-copy {
                    background: #2563EB;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 12px;
                    font-weight: 800;
                    font-size: 1rem;
                    cursor: pointer;
                }
            </style>
        </head>
        <body>
            <div class="card">
                <span style="background: #ECFDF5; color: #047857; font-weight: 900; font-size: 0.85rem; padding: 4px 14px; border-radius: 20px; text-transform: uppercase;">
                    Matrícula Directa Sin Códigos
                </span>
                <h1 style="margin: 12px 0 4px 0; font-size: 2.2rem; font-weight: 900;">Grupo \${g.nombre}</h1>
                <p style="margin: 0; color: #475569; font-weight: 700; font-size: 1.1rem;">Profesor(a) \${g.docente}</p>
                <p style="margin: 4px 0 0 0; color: #64748B; font-size: 0.95rem;">🏛️ \${g.ie}</p>

                <div class="qr-box">
                    <img src="\${g.qr}" style="width: 280px; height: 280px; display: block;">
                </div>

                <div style="font-size: 1.05rem; font-weight: 800; color: #1E293B; margin-bottom: 15px;">
                    📷 Abre la cámara de tu celular y escanea el código para matricularte al instante.
                </div>

                <button class="btn-copy" onclick="navigator.clipboard.writeText('\${g.url}'); alert('✅ Enlace copiado al portapapeles');">
                    📋 Copiar Enlace Directo
                </button>
            </div>
        </body>
        </html>
    \`);
};
`;

appJs += '\n' + updateAppJsModalLogic;

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
