const fs = require('fs');
const path = require('path');

const files = [
    "C:\\Users\\Juan Felipe\\Documents\\DBA C naturales.pdf",
    "C:\\Users\\Juan Felipe\\Documents\\DBA C sociales.pdf",
    "C:\\Users\\Juan Felipe\\Documents\\DBA lenguaje.pdf",
    "C:\\Users\\Juan Felipe\\Documents\\DBA matematicas.pdf"
];

console.log("=== VERIFICANDO ARCHIVOS DBA ===");
files.forEach(f => {
    if (fs.existsSync(f)) {
        const stats = fs.statSync(f);
        console.log(`✅ ENCONTRADO: ${f} (${(stats.size / 1024 / 1024).toFixed(2)} MB)`);
    } else {
        console.log(`❌ NO ENCONTRADO: ${f}`);
    }
});
