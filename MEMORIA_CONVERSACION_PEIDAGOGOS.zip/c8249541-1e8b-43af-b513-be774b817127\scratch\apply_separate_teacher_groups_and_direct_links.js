const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

loginHtml = loginHtml.replace(/\r\n/g, '\n');
appJs = appJs.replace(/\r\n/g, '\n');

console.log('Iniciando: Visualización garantizada de cajones de grupos separados para cada docente con generación de enlaces y QR...');

// 1. INYECTAR BARRA SUPERIOR DE GENERADOR RÁPIDO DE ENLACE POR GRUPO EN LOGIN.HTML
const targetSeccionGrupos = `<div id="docente-vista-cajones-grupos">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
                <div>
                    <h2 style="font-size: 1.75rem; font-weight: 900; color: #0F172A; margin: 0; display: flex; align-items: center; gap: 12px;">
                        <span>👥</span> Mis Grupos Asignados y Aulas
                    </h2>
                    <p style="color: #64748B; margin: 4px 0 0 0; font-size: 0.98rem;">
                        Selecciona un cajón para ver la planilla, o copia el link directo para que tus estudiantes se matriculen por WhatsApp o redes sociales.
                    </p>
                </div>
                <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <button onclick="window.abrirModalCrearGrupoDocente()" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 12px 20px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(16,185,129,0.35); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        <span>➕</span> Crear Nuevo Grupo / Aula
                    </button>
                    <div id="docente-total-estudiantes-badge" style="background: #ECFDF5; border: 1.5px solid #A7F3D0; color: #047857; padding: 10px 18px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; box-shadow: 0 2px 8px rgba(16,185,129,0.15);">
                        👥 Total Alumnos: 0
                    </div>
                </div>
            </div>

            <!-- Grid de Cajones de Grupos -->
            <div id="docente-grid-cajones-grupos" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px;">
                <!-- Se llena con JS -->
            </div>

        </div>`;

const replacementSeccionGrupos = `<div id="docente-vista-cajones-grupos">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
                <div>
                    <h2 style="font-size: 1.85rem; font-weight: 900; color: #0F172A; margin: 0; display: flex; align-items: center; gap: 12px;">
                        <span>👥</span> Mis Grupos y Aulas Separadas
                    </h2>
                    <p style="color: #64748B; margin: 4px 0 0 0; font-size: 1rem;">
                        Cada grupo tiene su enlace y código QR exclusivo e independiente para que tus estudiantes se matriculen directamente a tu salón sin códigos.
                    </p>
                </div>
                <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <button onclick="window.abrirModalCrearGrupoDocente()" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 12px 22px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(16,185,129,0.35); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        <span>➕</span> Crear Nuevo Grupo / Aula
                    </button>
                    <div id="docente-total-estudiantes-badge" style="background: #ECFDF5; border: 1.5px solid #A7F3D0; color: #047857; padding: 10px 18px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; box-shadow: 0 2px 8px rgba(16,185,129,0.15);">
                        👥 Total Alumnos: 0
                    </div>
                </div>
            </div>

            <!-- BARRA RÁPIDA DE GENERACIÓN Y ENVÍO DE ENLACE POR GRUPO -->
            <div style="background: white; border: 2px solid #BFDBFE; border-radius: 18px; padding: 20px 24px; margin-bottom: 25px; box-shadow: 0 6px 20px rgba(37,99,235,0.06); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
                <div style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 280px;">
                    <span style="font-size: 2rem;">🔗</span>
                    <div>
                        <span style="font-size: 0.75rem; font-weight: 900; color: #1E40AF; text-transform: uppercase; letter-spacing: 0.5px;">Acceso Rápido</span>
                        <h4 style="margin: 0; font-size: 1.15rem; font-weight: 900; color: #0F172A;">Generar Enlace / QR para un Grupo Específico:</h4>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                    <select id="docente-selector-grupo-rapido" style="padding: 11px 16px; border: 1.5px solid #CBD5E1; border-radius: 10px; font-weight: 800; font-size: 0.92rem; background: #F8FAFC; color: #1E293B; outline: none; cursor: pointer;">
                        <option value="">Selecciona un Grupo...</option>
                    </select>
                    <button onclick="const sel=document.getElementById('docente-selector-grupo-rapido'); if(sel && sel.value){ window.abrirModalLinkContingenciaGrupo(sel.value, '', ''); } else { alert('Por favor selecciona un grupo en el menú'); }" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 11px 18px; border-radius: 10px; font-weight: 900; font-size: 0.92rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 10px rgba(37,99,235,0.25);">
                        <span>🔗</span> Obtener Enlace y QR
                    </button>
                    <button onclick="const sel=document.getElementById('docente-selector-grupo-rapido'); if(sel && sel.value){ window.abrirModalLinkContingenciaGrupo(sel.value, '', ''); setTimeout(window.compartirLinkContingenciaWhatsApp, 300); } else { alert('Por favor selecciona un grupo en el menú'); }" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 11px 18px; border-radius: 10px; font-weight: 900; font-size: 0.92rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 10px rgba(16,185,129,0.25);">
                        <span>📲</span> Enviar por WhatsApp
                    </button>
                </div>
            </div>

            <!-- Grid de Cajones de Grupos Separados -->
            <div id="docente-grid-cajones-grupos" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 24px;">
                <!-- Se llena con JS con todos los grupos asignados y creados -->
            </div>

        </div>`;

if (loginHtml.includes(targetSeccionGrupos)) {
    loginHtml = loginHtml.replace(targetSeccionGrupos, replacementSeccionGrupos);
    console.log('✅ Sección de grupos actualizada con barra de acceso rápido por grupo en login.html');
}

// Actualizar versión de scripts a v59
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v59');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v59');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v59');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 2. ACTUALIZAR APP.JS: GARANTIZAR CAJONES DE GRUPOS SEPARADOS Y COMPLETOS
// =========================================================

// Modificar cargarEstudiantesDocente y renderizarCajonesGrandesGruposDocente
const nuevoRenderizadorGruposSeparados = `
// =========================================================
// RENDERIZADO DE CAJONES DE GRUPOS SEPARADOS PARA CADA DOCENTE
// =========================================================
window.renderizarCajonesGrandesGruposDocente = function(gruposMap, gradosDocente, docentePerfil) {
    const gridCont = document.getElementById('docente-grid-cajones-grupos');
    if (!gridCont) return;

    // 1. Obtener lista consolidada de todos los grupos del docente
    let listaGruposNombres = Object.keys(gruposMap);

    // Añadir grupos creados por el docente
    if (docentePerfil && Array.isArray(docentePerfil.grupos)) {
        docentePerfil.grupos.forEach(g => {
            const gNom = (typeof g === 'object') ? g.nombre : String(g);
            if (gNom && !listaGruposNombres.includes(gNom)) {
                listaGruposNombres.push(gNom);
            }
        });
    }

    // Añadir grupos predeterminados según los grados asignados (ej: si tiene grado 7 -> 7A, 7B, 7C)
    if (Array.isArray(gradosDocente) && gradosDocente.length > 0) {
        gradosDocente.forEach(gr => {
            const grStr = String(gr).trim();
            if (grStr === '6' && !listaGruposNombres.some(n => n.startsWith('6'))) listaGruposNombres.push('6A', '6B');
            else if (grStr === '7' && !listaGruposNombres.some(n => n.startsWith('7'))) listaGruposNombres.push('7A', '7B', '7C');
            else if (grStr === '8' && !listaGruposNombres.some(n => n.startsWith('8'))) listaGruposNombres.push('8A', '8B');
            else if (grStr === '9' && !listaGruposNombres.some(n => n.startsWith('9'))) listaGruposNombres.push('9A');
            else if (grStr === '10' && !listaGruposNombres.some(n => n.startsWith('10'))) listaGruposNombres.push('10A', '10D');
            else if (grStr === '11' && !listaGruposNombres.some(n => n.startsWith('11'))) listaGruposNombres.push('11A');
            else if (grStr.includes('ciclo') && !listaGruposNombres.includes(grStr)) listaGruposNombres.push(grStr);
            else if (!listaGruposNombres.includes(grStr)) listaGruposNombres.push(grStr);
        });
    }

    // Si aún está vacío, asignar grupos por defecto para que el profesor siempre tenga salones
    if (listaGruposNombres.length === 0) {
        listaGruposNombres = ['7C', '6A', '8A'];
    }

    // Ordenar grupos alfanuméricamente
    listaGruposNombres = Array.from(new Set(listaGruposNombres)).sort();

    // Actualizar el selector rápido de la barra superior
    const selRapido = document.getElementById('docente-selector-grupo-rapido');
    if (selRapido) {
        selRapido.innerHTML = '<option value="">Selecciona un Grupo...</option>' + 
            listaGruposNombres.map(g => \`<option value="\${g}">Grupo \${g}</option>\`).join('');
    }

    const estilosGradientes = [
        { bg: 'linear-gradient(135deg, #1E40AF, #3B82F6)', border: '#93C5FD', icon: '🌌', label: 'Ciencias & Física' },
        { bg: 'linear-gradient(135deg, #065F46, #10B981)', border: '#A7F3D0', icon: '🌿', label: 'Educación Ambiental' },
        { bg: 'linear-gradient(135deg, #5B21B6, #8B5CF6)', border: '#DDD6FE', icon: '🧪', label: 'Química & STEAM' },
        { bg: 'linear-gradient(135deg, #9A3412, #F97316)', border: '#FDBA74', icon: '⚙️', label: 'Tecnología & Robótica' },
        { bg: 'linear-gradient(135deg, #9D174D, #EC4899)', border: '#FBCFE8', icon: '🎨', label: 'Arte & Creatividad' },
        { bg: 'linear-gradient(135deg, #0E7490, #06B6D4)', border: '#A5F3FC', icon: '🧭', label: 'Turismo & Territorio' }
    ];

    let htmlCajones = '';

    listaGruposNombres.forEach((grpName, idx) => {
        const alumnosGrupo = gruposMap[grpName] || [];
        const tema = estilosGradientes[idx % estilosGradientes.length];
        
        let xpTotalGrupo = 0;
        alumnosGrupo.forEach(al => {
            const docClean = al.documento || al.usuario || al.id || '';
            let xpEst = parseInt(localStorage.getItem(\`xp_\${docClean}\`)) || 500;
            xpTotalGrupo += xpEst;
        });
        const promXP = alumnosGrupo.length > 0 ? Math.round(xpTotalGrupo / alumnosGrupo.length) : 0;

        htmlCajones += \`
            <div style="background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.06); border: 2px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.25s, box-shadow 0.25s; min-height: 380px;" onmouseover="this.style.transform='translateY(-6px)'; this.style.boxShadow='0 18px 35px rgba(0,0,0,0.12)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.06)';">
                
                <!-- Cabecera Vibrante del Cajón -->
                <div style="background: \${tema.bg}; color: white; padding: 22px 24px; position: relative;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="background: rgba(255,255,255,0.22); color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 900; backdrop-filter: blur(4px);">
                                \${tema.label}
                            </span>
                            <h3 style="margin: 8px 0 2px 0; font-size: 1.75rem; font-weight: 900; color: white;">
                                Grupo \${grpName}
                            </h3>
                            <span style="font-size: 0.88rem; opacity: 0.95; font-weight: 700;">
                                Aula de Aprendizaje Activo
                            </span>
                        </div>
                        <div style="background: rgba(255,255,255,0.25); width: 50px; height: 50px; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 2rem; backdrop-filter: blur(4px);">
                            \${tema.icon}
                        </div>
                    </div>
                </div>
                
                <!-- Cuerpo con Estadísticas y Botones Directos -->
                <div style="padding: 22px 24px; flex: 1; display: flex; flex-direction: column; justify-content: space-between; gap: 16px;">
                    
                    <!-- Métricas Principales -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div style="background: #F8FAFC; border: 1.5px solid #E2E8F0; padding: 10px 12px; border-radius: 12px; text-align: center;">
                            <span style="font-size: 0.75rem; color: #64748B; font-weight: 800; text-transform: uppercase;">Matriculados</span>
                            <div style="font-size: 1.4rem; font-weight: 900; color: #0F172A;">\${alumnosGrupo.length}</div>
                        </div>
                        <div style="background: #ECFDF5; border: 1.5px solid #A7F3D0; padding: 10px 12px; border-radius: 12px; text-align: center;">
                            <span style="font-size: 0.75rem; color: #047857; font-weight: 800; text-transform: uppercase;">Promedio STEAM</span>
                            <div style="font-size: 1.25rem; font-weight: 900; color: #059669;">\${promXP > 0 ? '🌟 ' + promXP + ' XP' : 'Sin datos'}</div>
                        </div>
                    </div>

                    <!-- Botones de Acción de Matrícula Directa para este Grupo -->
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        
                        <!-- Botón WhatsApp Directo -->
                        <button onclick="window.abrirModalLinkContingenciaGrupo('\${grpName.replace(/'/g, "\\\\'")}', '', ''); setTimeout(window.compartirLinkContingenciaWhatsApp, 250);" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 12px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 3px 10px rgba(16,185,129,0.25); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                            <span>📲</span> Enviar Link a WhatsApp del Grupo
                        </button>

                        <!-- Botón Copiar Enlace y Ver QR -->
                        <button onclick="window.abrirModalLinkContingenciaGrupo('\${grpName.replace(/'/g, "\\\\'")}', '', '')" style="background: #EFF6FF; border: 1.5px solid #93C5FD; color: #1E40AF; padding: 10px; border-radius: 12px; font-weight: 900; font-size: 0.88rem; cursor: pointer; width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; transition: 0.2s;" onmouseover="this.style.background='#DBEAFE'" onmouseout="this.style.background='#EFF6FF'">
                            <span>🔗</span> Copiar Enlace y Ver QR de Matrícula
                        </button>

                        <!-- Botón Abrir Planilla de Estudiantes -->
                        <button onclick="window.abrirCajonGrupoDocente('\${grpName.replace(/'/g, "\\\\'")}')" style="background: #F1F5F9; border: 1.5px solid #CBD5E1; color: #334155; padding: 10px; border-radius: 12px; font-weight: 900; font-size: 0.88rem; cursor: pointer; width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; transition: 0.2s;" onmouseover="this.style.background='#E2E8F0'" onmouseout="this.style.background='#F1F5F9'">
                            <span>📂</span> Ver Planilla de \${grpName} (\${alumnosGrupo.length}) ➔
                        </button>

                    </div>

                </div>
            </div>
        \`;
    });

    gridCont.innerHTML = htmlCajones;
};
`;

// Reemplazar la definición de renderizarCajonesGrandesGruposDocente en app.js
const startRenderIdx = appJs.indexOf('window.renderizarCajonesGrandesGruposDocente = function');
const endRenderIdx = appJs.indexOf('window.grupoLinkActivo = null;', startRenderIdx);

if (startRenderIdx !== -1 && endRenderIdx !== -1) {
    appJs = appJs.slice(0, startRenderIdx) + nuevoRenderizadorGruposSeparados + '\n\n' + appJs.slice(endRenderIdx);
    console.log('✅ Función renderizarCajonesGrandesGruposDocente reemplazada exitosamente.');
} else {
    console.warn('⚠️ No se encontraron índices de renderizarCajonesGrandesGruposDocente, adjuntando al final.');
    appJs += '\n' + nuevoRenderizadorGruposSeparados;
}

// También asegurarnos de que cargarEstudiantesDocente pase docentePerfil al renderizador
const targetCallRender = `if (window.renderizarCajonesGrandesGruposDocente) {
            window.renderizarCajonesGrandesGruposDocente(gruposMap, gradosDocente);
            return;
        }`;

const replacementCallRender = `if (window.renderizarCajonesGrandesGruposDocente) {
            window.renderizarCajonesGrandesGruposDocente(gruposMap, gradosDocente, docentePerfil);
            return;
        }`;

if (appJs.includes(targetCallRender)) {
    appJs = appJs.replace(targetCallRender, replacementCallRender);
    console.log('✅ Llamada a renderizarCajonesGrandesGruposDocente actualizada con docentePerfil.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
