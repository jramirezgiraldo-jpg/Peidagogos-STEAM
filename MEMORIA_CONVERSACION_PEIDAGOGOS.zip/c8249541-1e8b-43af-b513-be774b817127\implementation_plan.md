# Plan de Implementación: Asignación Docente Avanzada, Creador de Asignaturas con Aprendizaje de Documentos y Matrícula Automatizada

Este plan describe la arquitectura y desarrollo técnico para implementar el sistema integral de gestión curricular docente, creación de asignaturas personalizadas a partir de documentos de referencia, generación automática de mallas DBA y matriculación inteligente vinculada a docentes.

---

## 1. Objetivos del Requerimiento

1. **Menú de Matrícula/Registro Docente Ampliado**:
   - Selección de Institución Educativa (IE).
   - Selección múltiple de las **materias que orienta** (Ciencias, Matemáticas, Robótica, etc.).
   - Selección múltiple de los **grados o ciclos bajo su cargo** (ej: 6°, 7°, 8°, 9°, 10°, 11°, Ciclos I al VI).
2. **Módulo "Crear Nueva Asignatura" con Aprendizaje de Documentos**:
   - Formulario en el Panel Docente (y en el Registro) para crear asignaturas no listadas.
   - Campos: Nombre de la Asignatura, Grados destino, Icono/Color temático, Descripción general / Meta anual.
   - **Carga de Documentos de Referencia** (Archivos PDF, Word, TXT, Mallas o Estándares curriculares).
   - **Motor de Aprendizaje y Extracción Curricular**: Procesa el texto del documento para extraer automáticamente los DBAs y la distribución de temas por Periodos (1 a 4) y Semanas (1 a 8).
   - **Generación Automática de Malla Curricular**: Se integra de forma transparente en el visualizador oficial de Mallas DBA para que estudiantes, docentes y tutores la consulten con la misma calidad visual que las materias estándar.
   - **Generación de Guías Semanales**: El generador de guías adapta los temas extraídos del documento respetando el formato interactivo Peidagogos STEAM (Saberes previos, texto inductivo/deductivo, simuladores, ICFES y cierre gamificado).
3. **Matriculación Automatizada Inteligente del Estudiante**:
   - Al seleccionar la **IE** y el **Grado/Ciclo** en la matrícula o auto-registro del estudiante:
     - El sistema consulta automáticamente los docentes registrados en esa IE para ese grado.
     - Asigna automáticamente el paquete de materias curriculares e inscribe la materia personalizada si existe.
     - Vincula y muestra el **Docente Titular** directamente en cada tarjeta de materia del aula virtual del estudiante (`👨‍🏫 Orientador: Prof. Nombre Apellido`).

---

## 2. Diagrama de Arquitectura y Flujo de Datos

```mermaid
graph TD
    A[Docente se Registra / Configura Perfil] --> B[Selecciona IE, Grados a Cargo y Materias]
    B --> C{¿La Materia no existe?}
    C -- Sí --> D[Crear Nueva Asignatura + Adjuntar Documentos PDF/Word/TXT]
    D --> E[Motor de Extracción y Aprendizaje Curricular]
    E --> F1[Genera Malla Curricular DBA 4 Periodos x 8 Semanas]
    E --> F2[Habilita Guías Didácticas Semanales Personalizadas]
    C -- No --> G[Guarda Perfil en docentes_db y catalogo_asignaturas]
    F1 --> G
    
    H[Estudiante se Matricula] --> I[Selecciona IE y Grado]
    I --> J[Algoritmo de Enrutamiento Curricular Inteligente]
    G --> J
    J --> K[Estudiante queda Matriculado con sus Materias y Docentes Titulares Asignados]
```

---

## 3. Componentes Específicos a Implementar

### A. Formulario de Matrícula Docente (`login.html` & `app.js`)
- En el formulario de registro (`reg-ie === 'DocenteRegular'`), agregar:
  - Selector de Institución Educativa (`reg-docente-ie-select`): IE Instituto Montenegro, Colegio Ramón Messa, Home School, Validación o Nueva IE.
  - Selector de Materias (con opción de multi-selección y botón rápido `➕ Crear Asignatura`).
  - Selector múltiple de Grados a cargo (checkboxes interactivos: Primaria 1°-5°, Secundaria 6°-9°, Media 10°-11°, Ciclos I-VI).

### B. Modal / Vista "Crear Asignatura y Aprender de Documentos" (`login.html` & `app.js`)
- Botón en el Panel Docente: `➕ Crear Nueva Asignatura (con IA / Documentos)`.
- Interfaz con:
  - Input: Nombre de la asignatura (ej: *Robótica STEAM, Emprendimiento, Filosofía Contemporánea*).
  - Selector de Grados a los que aplica.
  - Textarea: Descripción y Enfoque pedagógico.
  - **Dropzone / Input File**: Soporte para adjuntar archivos (`.pdf`, `.docx`, `.txt`, `.json`, `.csv`) o pegar texto curricular directamente.
  - **Extractor y Constructor Curricular**: Extrae términos clave, objetivos y los distribuye en 4 periodos académicos con tópicos quincenales (Semana 1 a 8) y 4 DBAs estructurados.
  - Botón: `⚡ Aprender del Documento y Crear Malla Curricular`.

### C. Integración en el Explorador de Mallas DBA
- Modificar `generarHTMLDetalleMallaDBA` y `renderizarMallaDocenteColegio` / `renderizarMallaEstudianteDBA` para:
  - Cargar las materias estándar (`Naturales`, `Matematicas`, `Lenguaje`, `Sociales`) MÁS todas las **materias personalizadas creadas por los docentes**.
  - Renderizar pestañas/pills dinámicas con los iconos y colores de las nuevas asignaturas.

### D. Integración en el Generador de Guías Semanales
- Modificar `actualizarPlaneacionEstudiante` y `generarContenidoGuia` para reconocer la malla curricular de la nueva materia creada, permitiendo generar guías de la Semana 1 a la 8 con sus temas, saberes previos e interactivos.

### E. Matriculación Automatizada Estudiante - Docente
- Actualizar `window.ejecutarRegistroEstudiante` e `inicializarPanelEstudiante`:
  - Al matricular a un estudiante en una IE y Grado (ej. Grado 7° en Instituto Montenegro), el sistema busca en `docentes_db` qué docentes orientan ese grado y les asocia automáticamente sus materias.
  - En la vista del estudiante (`#student-subjects-grid`), cada tarjeta indicará: `👨‍🏫 Orientador: [Nombre del Docente]`.

---

## 4. Archivos a Modificar

1. **[`d:\Peidagogos_Local\login.html`](file:///d:/Peidagogos_Local/login.html)**:
   - Ampliar el formulario de registro docente con selector de IE, multi-selección de grados a cargo y selector de materias.
   - Agregar botón `➕ Crear Asignatura` en el header y herramientas del Panel Docente.
   - Agregar modal para creación de asignaturas con cargador de documentos de referencia.
2. **[`d:\Peidagogos_Local\app.js`](file:///d:/Peidagogos_Local/app.js)**:
   - Implementar `window.procesarDocumentosAsignaturaDocente()`.
   - Implementar `window.guardarNuevaAsignaturaPersonalizada()`.
   - Modificar `window.generarHTMLDetalleMallaDBA()` para renderizar mallas dinámicas.
   - Modificar `window.ejecutarRegistroEstudiante()` para la asignación automática por IE y Grado.
   - Actualizar el grid de asignaturas en `inicializarPanelEstudiante()` con los nombres de los docentes titulares.

---

## 5. Plan de Verificación

- **Prueba 1: Registro y Configuración Docente**:
  - Registrar un docente asignándole IE Instituto Montenegro, Grados 7° y 8°, y materias Física y Robótica.
- **Prueba 2: Creación de Asignatura con Archivo de Referencia**:
  - Crear una materia personalizada (ej. "Robótica STEAM") adjuntando un documento de referencia o texto curricular.
  - Comprobar que se generan los 4 periodos, 8 semanas y los DBAs.
- **Prueba 3: Explorador de Malla Curricular**:
  - Verificar que la nueva materia aparece en el menú de mallas tanto para el docente como para los estudiantes de ese grado.
- **Prueba 4: Guías Didácticas**:
  - Ingresar a la materia personalizada y verificar que se genera la guía interactiva con el formato de Peidagogos STEAM.
- **Prueba 5: Matrícula Automática de Estudiante**:
  - Matricular a un nuevo estudiante en Grado 7° de la misma IE y verificar que hereda automáticamente las materias y se visualiza su docente asignado.
- **Compilación**:
  - Validar sintaxis con `node -c app.js` (0 errores).
