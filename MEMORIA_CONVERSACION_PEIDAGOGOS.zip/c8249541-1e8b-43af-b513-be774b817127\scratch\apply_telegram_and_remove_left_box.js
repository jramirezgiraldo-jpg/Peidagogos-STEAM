const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

console.log('Iniciando: 1. Remover recuadro de matricular docente, 2. Integrar Telegram @jramirezgiraldo...');

// 1. Quitar recuadro de matricular estudiante del dashboard docente en login.html
const targetDocenteGrid = `    <div style="padding: 40px 30px; max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
        <!-- Formulario Matrícula Estudiante -->
        <div style="background: white; padding: 30px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">
            <h3 style="font-weight: 800; margin-bottom: 20px; color: #111827; display: flex; align-items: center; gap: 8px;">
                <span>➕</span> Matricular Estudiante
            </h3>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <input type="number" id="docente-reg-doc" placeholder="Documento" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <input type="text" id="docente-reg-nom" placeholder="Nombres" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <input type="text" id="docente-reg-ape" placeholder="Apellidos" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <input type="number" id="docente-reg-edad" placeholder="Edad" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <select id="docente-reg-gen" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                    <option value="">Género...</option><option value="F">Femenino</option><option value="M">Masculino</option>
                </select>
                <select id="docente-reg-grado" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;" onchange="cargarAsignaturasDocente(this.value)">
                    <option value="">Grado...</option><option value="6">6°</option><option value="7">7°</option><option value="8">8°</option><option value="9">9°</option><option value="10">10°</option><option value="11">11°</option>
                    <option value="Ciclo I (1°, 2°, 3°)">Ciclo I (1°, 2°, 3°)</option>
                    <option value="Ciclo II (4°, 5°)">Ciclo II (4°, 5°)</option>
                    <option value="Ciclo III (6°, 7°)">Ciclo III (6°, 7°)</option>
                    <option value="Ciclo IV (8°, 9°)">Ciclo IV (8°, 9°)</option>
                    <option value="Ciclo V (10°)">Ciclo V (10°)</option>
                    <option value="Ciclo VI (11°)">Ciclo VI (11°)</option>
                </select>
                <div>
                    <strong>Materias a cursar:</strong>
                    <div id="materias-checkboxes-container" style="display: flex; flex-direction: column; gap: 5px; margin-top: 10px;">
                        <span style="color: #6B7280; font-size: 0.9rem;">Selecciona un grado primero.</span>
                    </div>
                </div>
                <button id="btn-docente-matricular" style="background-color: #10B981; color: white; padding: 12px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Matricular</button>
            </div>
        </div>

        <!-- Lista Estudiantes -->
        <div style="background: white; padding: 30px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">`;

const replacementDocenteGrid = `    <div style="padding: 30px 30px; max-width: 1350px; margin: 0 auto;">
        <!-- Lista Estudiantes (Ancho Completo) -->
        <div style="background: white; padding: 35px 30px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">`;

loginHtml = loginHtml.replace(/\r\n/g, '\n');
const targetDocenteGridNorm = targetDocenteGrid.replace(/\r\n/g, '\n');

if (loginHtml.includes(targetDocenteGridNorm)) {
    loginHtml = loginHtml.replace(targetDocenteGridNorm, replacementDocenteGrid);
    console.log('✅ Recuadro de matricular estudiante eliminado del panel docente. Ahora toma 100% de ancho.');
} else {
    console.warn('⚠️ No se encontró targetDocenteGrid exacto.');
}

// 2. Actualizar botones de PeidaBot en login.html para priorizar Telegram
const targetPeidabotButtons = `<div style="display: flex; gap: 8px; margin-top: 4px;">
                    <button type="button" onclick="window.enviarReporteFeedback('plataforma')" style="flex: 1; background: #2563EB; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 3px 8px rgba(37,99,235,0.25);">
                        <span>💾</span> Guardar en Buzón
                    </button>
                    <button type="button" onclick="window.enviarReporteFeedback('whatsapp')" style="flex: 1; background: #10B981; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 3px 8px rgba(16,185,129,0.25);">
                        <span>📲</span> Enviar por WhatsApp
                    </button>
                </div>`;

const replacementPeidabotButtons = `<div style="display: flex; gap: 8px; margin-top: 4px;">
                    <button type="button" onclick="window.enviarReporteFeedback('plataforma')" style="flex: 1; background: #2563EB; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 3px 8px rgba(37,99,235,0.25);">
                        <span>💾</span> Guardar en Buzón
                    </button>
                    <button type="button" onclick="window.enviarReporteFeedback('telegram')" style="flex: 1; background: #0284C7; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 3px 8px rgba(2,132,199,0.25);" title="Notificar al chatbot oficial de Telegram del Administrador">
                        <span>📱</span> Enviar a Telegram
                    </button>
                </div>`;

const targetPeidabotButtonsNorm = targetPeidabotButtons.replace(/\r\n/g, '\n');
if (loginHtml.includes(targetPeidabotButtonsNorm)) {
    loginHtml = loginHtml.replace(targetPeidabotButtonsNorm, replacementPeidabotButtons);
    console.log('✅ Botón de Telegram integrado en PeidaBot.');
}

// 3. Actualizar versión de scripts a v50
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v50');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v50');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v50');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 4. ACTUALIZAR APP.JS CON NOTIFICACIONES TELEGRAM OFICIALES
// =========================================================
appJs = appJs.replace(/\r\n/g, '\n');

// A. Función Global window.enviarAlertaTelegram
const funcionTelegramJs = `
// =========================================================
// MÓDULO OFICIAL DE NOTIFICACIONES TELEGRAM (@jramirezgiraldo)
// =========================================================
window.enviarAlertaTelegram = function(mensaje) {
    const telegramUser = '@jramirezgiraldo';
    if (!telegramUser) return;
    const url = \`https://api.callmebot.com/text.php?user=\${encodeURIComponent(telegramUser)}&text=\${encodeURIComponent(mensaje)}\`;
    
    try {
        const img = new Image();
        img.src = url;
    } catch(e) {}

    try {
        fetch(url, { mode: 'no-cors' }).catch(() => {});
    } catch(e) {}

    console.log('📱 [TELEGRAM] Notificación enviada a @jramirezgiraldo:', mensaje);
};
`;

if (!appJs.includes('window.enviarAlertaTelegram = function')) {
    appJs += '\n' + funcionTelegramJs;
    console.log('✅ window.enviarAlertaTelegram agregado a app.js');
}

// B. Disparar Telegram en Registro de Docente
const targetRegDocAlert = `alert(\`✅ ¡Inscripción de Docente Regular Exitosa!\\n\\nBienvenido(a) Profesor(a) \${nom} \${ap}.\\n\\nHas ingresado a tu Panel Docente. Desde aquí puedes proyectar la clase, consultar el Leaderboard en vivo, evaluar con rúbricas formativas y utilizar la Caja de Herramientas STEAM.\`);`;

const replacementRegDocAlert = `if (window.enviarAlertaTelegram) {
                window.enviarAlertaTelegram(\`👨‍🏫 *NUEVO DOCENTE REGISTRADO EN PEIDAGOGOS STEAM*\\n\\n👤 *Profesor(a):* \${nom} \${ap}\\n🆔 *Cédula:* \${doc}\\n🏫 *Institución:* \${ieDocenteSeleccionada}\\n📚 *Materias:* \${asigDoc}\\n🎯 *Grados:* \${graDoc}\\n📅 *Fecha:* \${new Date().toLocaleString('es-CO')}\`);
            }

            alert(\`✅ ¡Inscripción de Docente Regular Exitosa!\\n\\nBienvenido(a) Profesor(a) \${nom} \${ap}.\\n\\nHas ingresado a tu Panel Docente. Desde aquí puedes proyectar la clase, consultar el Leaderboard en vivo, evaluar con rúbricas formativas y utilizar la Caja de Herramientas STEAM.\`);`;

if (appJs.includes(targetRegDocAlert)) {
    appJs = appJs.replace(targetRegDocAlert, replacementRegDocAlert);
    console.log('✅ Notificación Telegram enlazada a Registro Docente.');
}

// C. Disparar Telegram en Registro de Estudiante
const targetRegEstSuccess = `localStorage.setItem('usuario_sesion', JSON.stringify(sessionData));`;

const replacementRegEstSuccess = `localStorage.setItem('usuario_sesion', JSON.stringify(sessionData));

        if (window.enviarAlertaTelegram) {
            window.enviarAlertaTelegram(\`🎓 *NUEVA MATRÍCULA DE ESTUDIANTE EN PEIDAGOGOS STEAM*\\n\\n👤 *Estudiante:* \${nom} \${ap}\\n🆔 *Documento:* \${tipoDoc} \${doc}\\n📚 *Grado / Grupo:* \${gradoFinal} (\${grupoFinal})\\n🏫 *Institución:* \${ie}\\n📅 *Fecha:* \${new Date().toLocaleString('es-CO')}\`);
        }`;

if (appJs.includes(targetRegEstSuccess)) {
    appJs = appJs.replace(targetRegEstSuccess, replacementRegEstSuccess);
    console.log('✅ Notificación Telegram enlazada a Registro Estudiante.');
}

// D. Disparar Telegram en PeidaBot Feedback
const targetGuardarFeedback = `window.guardarItemBuzonFeedback(nuevoItem);`;

const replacementGuardarFeedback = `window.guardarItemBuzonFeedback(nuevoItem);

    if (window.enviarAlertaTelegram) {
        window.enviarAlertaTelegram(\`🤖 *NUEVO REPORTE PEIDABOT DOCENTE (\${nuevoItem.id})*\\n\\n🏷️ *Tipo:* \${nuevoItem.categoriaTexto}\\n👤 *Emisor:* \${nuevoItem.docente}\\n📝 *Mensaje:* \${nuevoItem.mensaje}\\n📅 *Fecha:* \${nuevoItem.fecha}\`);
    }`;

if (appJs.includes(targetGuardarFeedback)) {
    appJs = appJs.replace(targetGuardarFeedback, replacementGuardarFeedback);
    console.log('✅ Notificación Telegram enlazada a PeidaBot Feedback.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis completa con VM
try {
    new vm.Script(appJs);
    console.log('✨ Validación de sintaxis VM en app.js: CORRECTO (0 errores).');
} catch(err) {
    console.error('❌ Error de sintaxis en app.js:', err);
}
