const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

loginHtml = loginHtml.replace(/\r\n/g, '\n');
appJs = appJs.replace(/\r\n/g, '\n');

console.log('Iniciando implementación de Creación de Grupos y Links de Matrícula de Contingencia para Redes...');

// 1. INYECTAR BOTÓN DE CREAR GRUPO EN LA CABECERA DE MIS GRUPOS EN LOGIN.HTML
const targetCabeceraGrupos = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 22px; flex-wrap: wrap; gap: 12px;">
                <div>
                    <h2 style="font-size: 1.65rem; font-weight: 900; color: #111827; margin: 0; display: flex; align-items: center; gap: 10px;">
                        <span>👥</span> Mis Grupos Asignados
                    </h2>
                    <p style="color: #64748B; margin: 4px 0 0 0; font-size: 0.95rem;">
                        Selecciona un cajón para ingresar a la planilla de estudiantes matriculados en cada grupo.
                    </p>
                </div>
                <div id="docente-total-estudiantes-badge" style="background: #ECFDF5; border: 1px solid #A7F3D0; color: #047857; padding: 8px 16px; border-radius: 20px; font-weight: 800; font-size: 0.9rem; box-shadow: 0 2px 6px rgba(16,185,129,0.15);">
                    👥 Total Alumnos: 0
                </div>
            </div>`;

const replacementCabeceraGrupos = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
                <div>
                    <h2 style="font-size: 1.75rem; font-weight: 900; color: #0F172A; margin: 0; display: flex; align-items: center; gap: 12px;">
                        <span>👥</span> Mis Grupos Asignados y Aulas
                    </h2>
                    <p style="color: #64748B; margin: 4px 0 0 0; font-size: 0.98rem;">
                        Selecciona un cajón para ver la planilla, o copia el link directo para que tus estudiantes se matriculen por WhatsApp o redes sociales.
                    </p>
                </div>
                <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <button onclick="window.abrirModalCrearGrupoDocente()" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 12px 20px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(16,185,129,0.35); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        <span>➕</span> Crear Nuevo Grupo / Aula
                    </button>
                    <div id="docente-total-estudiantes-badge" style="background: #ECFDF5; border: 1.5px solid #A7F3D0; color: #047857; padding: 10px 18px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; box-shadow: 0 2px 8px rgba(16,185,129,0.15);">
                        👥 Total Alumnos: 0
                    </div>
                </div>
            </div>`;

if (loginHtml.includes(targetCabeceraGrupos)) {
    loginHtml = loginHtml.replace(targetCabeceraGrupos, replacementCabeceraGrupos);
    console.log('✅ Botón de Crear Grupo agregado a la cabecera de grupos en login.html');
} else {
    console.warn('⚠️ No se encontró targetCabeceraGrupos.');
}

// 2. INYECTAR MODAL DE CREACIÓN DE GRUPO Y GENERADOR DE ENLACE DE CONTINGENCIA EN LOGIN.HTML
const modalCrearGrupoHtml = `
    <!-- MODAL PARA CREAR NUEVO GRUPO Y GENERAR ENLACE DE CONTINGENCIA REDES -->
    <div id="modal-crear-grupo-docente" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.75); backdrop-filter: blur(4px); z-index: 100000; justify-content: center; align-items: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 580px; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); border: 1px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column;">
            
            <div style="background: linear-gradient(135deg, #059669, #10B981); padding: 22px 26px; color: white; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 1.8rem;">👥</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.35rem; font-weight: 900; color: white;">Crear Nuevo Grupo / Aula</h3>
                        <p style="margin: 3px 0 0 0; font-size: 0.85rem; opacity: 0.95;">Genera un enlace de contingencia sin códigos para tus redes sociales</p>
                    </div>
                </div>
                <button onclick="window.cerrarModalCrearGrupoDocente()" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; justify-content: center;">✕</button>
            </div>

            <div style="padding: 26px; display: flex; flex-direction: column; gap: 16px;">
                
                <div>
                    <label style="display: block; font-weight: 800; color: #1E293B; margin-bottom: 6px; font-size: 0.92rem;">
                        🏷️ Nombre o Código del Grupo / Aula:
                    </label>
                    <input type="text" id="nuevo-grupo-nombre-input" placeholder="Ej: 7C, 8A, 10-1, Física 9, Robótica" style="width: 100%; padding: 12px 14px; border: 1.5px solid #CBD5E1; border-radius: 10px; font-weight: 800; font-size: 1rem; box-sizing: border-box; color: #0F172A;">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <label style="display: block; font-weight: 800; color: #1E293B; margin-bottom: 6px; font-size: 0.88rem;">
                            🎓 Grado o Ciclo Base:
                        </label>
                        <select id="nuevo-grupo-grado-select" style="width: 100%; padding: 12px; border: 1.5px solid #CBD5E1; border-radius: 10px; font-weight: 700; font-size: 0.9rem; background: white; box-sizing: border-box;">
                            <option value="6">6° de Secundaria</option>
                            <option value="7">7° de Secundaria</option>
                            <option value="8">8° de Secundaria</option>
                            <option value="9">9° de Secundaria</option>
                            <option value="10">10° Media</option>
                            <option value="11">11° Media</option>
                            <option value="1">1° Primaria</option>
                            <option value="2">2° Primaria</option>
                            <option value="3">3° Primaria</option>
                            <option value="4">4° Primaria</option>
                            <option value="5">5° Primaria</option>
                            <option value="Ciclo I">Ciclo I (1°,2°,3°)</option>
                            <option value="Ciclo II">Ciclo II (4°,5°)</option>
                            <option value="Ciclo III">Ciclo III (6°,7°)</option>
                            <option value="Ciclo IV">Ciclo IV (8°,9°)</option>
                            <option value="Ciclo V">Ciclo V (10°)</option>
                            <option value="Ciclo VI">Ciclo VI (11°)</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-weight: 800; color: #1E293B; margin-bottom: 6px; font-size: 0.88rem;">
                            📚 Asignatura Principal:
                        </label>
                        <select id="nuevo-grupo-materia-select" style="width: 100%; padding: 12px; border: 1.5px solid #CBD5E1; border-radius: 10px; font-weight: 700; font-size: 0.9rem; background: white; box-sizing: border-box;">
                            <option value="Física">Física</option>
                            <option value="Ciencias Naturales y Educación Ambiental">Ciencias Naturales</option>
                            <option value="Química">Química</option>
                            <option value="Matemáticas">Matemáticas</option>
                            <option value="Lengua Castellana">Lengua Castellana</option>
                            <option value="Tecnología e Informática">Tecnología e Informática</option>
                            <option value="Educación Artística">Educación Artística</option>
                            <option value="Ética y Valores Humanos">Ética y Valores</option>
                            <option value="Turismo y Patrimonio">Turismo</option>
                            <option value="Auxilios Emocionales">Auxilios Emocionales</option>
                        </select>
                    </div>
                </div>

                <!-- Explicación de Contingencia -->
                <div style="background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 12px; padding: 14px; color: #166534; font-size: 0.86rem; line-height: 1.45;">
                    <strong>🚀 Matrícula de Contingencia Sin Fricción:</strong>
                    Al crear este grupo se generará un enlace web que podrás pegar directamente en grupos de <strong>WhatsApp, Facebook, Telegram o Teams</strong>. Cuando tus estudiantes abran el link, <strong>no necesitarán ingresar ningún código de verificación</strong> y quedarán matriculados de inmediato en este salón bajo tu perfil docente.
                </div>

            </div>

            <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 16px 26px; display: flex; justify-content: space-between; align-items: center;">
                <button onclick="window.cerrarModalCrearGrupoDocente()" style="background: transparent; color: #64748B; border: none; font-weight: 700; cursor: pointer; font-size: 0.9rem;">
                    Cancelar
                </button>
                <button onclick="window.guardarNuevoGrupoDocente()" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 12px 24px; border-radius: 10px; font-weight: 900; font-size: 0.95rem; cursor: pointer; box-shadow: 0 4px 12px rgba(16,185,129,0.3);">
                    🚀 Crear Grupo y Obtener Link
                </button>
            </div>

        </div>
    </div>

    <!-- MODAL DE ENLACE DE CONTINGENCIA GENERADO PARA COMPARTIR -->
    <div id="modal-link-contingencia-grupo" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.75); backdrop-filter: blur(4px); z-index: 100001; justify-content: center; align-items: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 580px; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); border: 1px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column;">
            
            <div style="background: linear-gradient(135deg, #2563EB, #1D4ED8); padding: 22px 26px; color: white; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 1.8rem;">🔗</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.35rem; font-weight: 900; color: white;">Enlace de Matrícula Directa</h3>
                        <p style="margin: 3px 0 0 0; font-size: 0.85rem; opacity: 0.95;">Listo para pegar en WhatsApp o Redes Sociales</p>
                    </div>
                </div>
                <button onclick="document.getElementById('modal-link-contingencia-grupo').style.display='none'" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; justify-content: center;">✕</button>
            </div>

            <div style="padding: 26px; display: flex; flex-direction: column; gap: 18px;">
                
                <div>
                    <span style="font-size: 0.82rem; font-weight: 800; color: #64748B; text-transform: uppercase;">AULA ASIGNADA</span>
                    <h3 id="modal-link-grupo-titulo" style="margin: 4px 0 10px 0; color: #0F172A; font-size: 1.35rem; font-weight: 900;">Grupo 7C</h3>
                    
                    <div style="background: #F1F5F9; border: 1.5px solid #CBD5E1; border-radius: 12px; padding: 12px; display: flex; align-items: center; gap: 10px;">
                        <input type="text" id="modal-link-input-url" readonly style="flex: 1; background: transparent; border: none; font-size: 0.88rem; font-weight: 700; color: #1E293B; outline: none;">
                        <button onclick="window.copiarLinkContingenciaDesdeModal()" style="background: #2563EB; color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; white-space: nowrap;">
                            📋 Copiar Link
                        </button>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="window.compartirLinkContingenciaWhatsApp()" style="flex: 1; background: #10B981; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(16,185,129,0.3);">
                        <span>📲</span> Compartir en WhatsApp
                    </button>
                    <button onclick="window.copiarMensajeCompletoRedes()" style="flex: 1; background: #4F46E5; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(79,70,229,0.3);">
                        <span>📝</span> Copiar Mensaje Completo
                    </button>
                </div>

                <div id="modal-link-copiado-feedback" style="display: none; background: #ECFDF5; border: 1px solid #86EFAC; color: #065F46; padding: 10px; border-radius: 8px; text-align: center; font-weight: 800; font-size: 0.88rem;">
                    ✅ ¡Enlace copiado al portapapeles! Pégalo en tu grupo de WhatsApp o red social.
                </div>

            </div>
        </div>
    </div>
`;

if (!loginHtml.includes('modal-crear-grupo-docente')) {
    const endBodyIdx = loginHtml.lastIndexOf('</body>');
    if (endBodyIdx !== -1) {
        loginHtml = loginHtml.slice(0, endBodyIdx) + modalCrearGrupoHtml + '\n' + loginHtml.slice(endBodyIdx);
        console.log('✅ Modales de Creación de Grupos y Enlace Directo inyectados en login.html');
    }
}

// 3. ACTUALIZAR VERSIÓN DE SCRIPTS A V55
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v55');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v55');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v55');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 4. ACTUALIZAR APP.JS CON LÓGICA DE GRUPOS Y AUTO-MATRÍCULA DIRECTA
// =========================================================

const logicaContingenciaJs = `
// =========================================================
// MÓDULO DE CREACIÓN DE GRUPOS Y MATRÍCULA DIRECTA DE CONTINGENCIA
// =========================================================
window.grupoLinkActivo = null;

window.abrirModalCrearGrupoDocente = function() {
    const modal = document.getElementById('modal-crear-grupo-docente');
    if (!modal) return;
    modal.style.display = 'flex';
    const inNom = document.getElementById('nuevo-grupo-nombre-input');
    if (inNom) {
        inNom.value = '';
        inNom.focus();
    }
};

window.cerrarModalCrearGrupoDocente = function() {
    const modal = document.getElementById('modal-crear-grupo-docente');
    if (modal) modal.style.display = 'none';
};

window.guardarNuevoGrupoDocente = function() {
    const inNom = document.getElementById('nuevo-grupo-nombre-input');
    const selGra = document.getElementById('nuevo-grupo-grado-select');
    const selMat = document.getElementById('nuevo-grupo-materia-select');

    const nombreGrupo = inNom ? inNom.value.trim() : '';
    const grado = selGra ? selGra.value : '7';
    const materia = selMat ? selMat.value : 'Ciencias Naturales';

    if (!nombreGrupo) {
        alert("⚠️ Por favor ingresa el nombre o código del grupo (ej: 7C, 8A, Física 9).");
        if (inNom) inNom.focus();
        return;
    }

    try {
        let dList = JSON.parse(localStorage.getItem('docentes_db') || '[]');
        const authSes = JSON.parse(sessionStorage.getItem('peidagogos_auth') || localStorage.getItem('usuario_actual') || '{}');
        const docKey = String(window.usuario_actual || authSes.documento || authSes.usuario || '').trim().toLowerCase();

        let docItem = dList.find(d => {
            const dDoc = String(d.documento || d.cedula || d.usuario || '').trim().toLowerCase();
            return dDoc === docKey;
        });

        if (!docItem) {
            docItem = {
                documento: docKey || 'docente',
                nombre: (document.getElementById('docente-nombre-header') ? document.getElementById('docente-nombre-header').innerText : 'Docente'),
                institucion: 'IE Instituto Montenegro',
                grados: [],
                grupos: []
            };
            dList.push(docItem);
        }

        if (!docItem.grados) docItem.grados = [];
        if (!docItem.grados.includes(grado) && !docItem.grados.includes(nombreGrupo)) {
            docItem.grados.push(nombreGrupo);
            if (!docItem.grados.includes(grado)) docItem.grados.push(grado);
        }

        if (!docItem.grupos) docItem.grupos = [];
        if (!docItem.grupos.some(g => g.nombre === nombreGrupo)) {
            docItem.grupos.push({ nombre: nombreGrupo, grado: grado, materia: materia, fecha: new Date().toISOString() });
        }

        localStorage.setItem('docentes_db', JSON.stringify(dList));

        // Actualizar sesión
        authSes.grados = docItem.grados;
        sessionStorage.setItem('peidagogos_auth', JSON.stringify(authSes));

        window.cerrarModalCrearGrupoDocente();

        // Recargar vista docente
        if (typeof window.cargarEstudiantesDocente === 'function') {
            window.cargarEstudiantesDocente(docKey);
        }

        // Abrir modal con el enlace listo para compartir
        window.abrirModalLinkContingenciaGrupo(nombreGrupo, grado, materia);

    } catch(e) {
        console.error("Error creando grupo docente:", e);
    }
};

window.abrirModalLinkContingenciaGrupo = function(nombreGrupo, grado, materia) {
    const modal = document.getElementById('modal-link-contingencia-grupo');
    if (!modal) return;

    let authSes = {};
    try {
        authSes = JSON.parse(sessionStorage.getItem('peidagogos_auth') || localStorage.getItem('usuario_actual') || '{}');
    } catch(e) {}

    const docId = String(window.usuario_actual || authSes.documento || authSes.usuario || 'docente').trim();
    const docNom = (document.getElementById('docente-nombre-header') ? document.getElementById('docente-nombre-header').innerText : (authSes.nombre || 'Docente')).trim();
    const docIE = (authSes.institucion || 'IE Instituto Montenegro').trim();

    const baseUrl = window.location.origin + window.location.pathname;
    const linkFinal = \`\${baseUrl}?reg=directo&docente=\${encodeURIComponent(docId)}&nombre_doc=\${encodeURIComponent(docNom)}&ie=\${encodeURIComponent(docIE)}&grupo=\${encodeURIComponent(nombreGrupo)}&grado=\${encodeURIComponent(grado || '')}&materia=\${encodeURIComponent(materia || '')}\`;

    window.grupoLinkActivo = {
        nombre: nombreGrupo,
        grado: grado,
        materia: materia,
        docente: docNom,
        ie: docIE,
        url: linkFinal
    };

    const inUrl = document.getElementById('modal-link-input-url');
    const titGrupo = document.getElementById('modal-link-grupo-titulo');
    const fbCopiado = document.getElementById('modal-link-copiado-feedback');

    if (inUrl) inUrl.value = linkFinal;
    if (titGrupo) titGrupo.innerText = \`Grupo \${nombreGrupo} • \${docIE}\`;
    if (fbCopiado) fbCopiado.style.display = 'none';

    modal.style.display = 'flex';
};

window.copiarLinkContingenciaDesdeModal = function() {
    const inUrl = document.getElementById('modal-link-input-url');
    if (!inUrl) return;
    inUrl.select();
    navigator.clipboard.writeText(inUrl.value).then(() => {
        const fb = document.getElementById('modal-link-copiado-feedback');
        if (fb) {
            fb.style.display = 'block';
            setTimeout(() => { fb.style.display = 'none'; }, 4000);
        }
    });
};

window.compartirLinkContingenciaWhatsApp = function() {
    if (!window.grupoLinkActivo) return;
    const g = window.grupoLinkActivo;
    const texto = \`¡Hola a todos! 👋\\n\\nSoy el(la) Profesor(a) *\${g.docente}* de la *\${g.ie}*.\\n\\n📚 Les comparto el enlace oficial de matrícula para el aula *\${g.nombre}* en la plataforma *Peidagogos STEAM*:\\n\\n👉 \${g.url}\\n\\n*(Solo abre el enlace, escribe tus datos básicos y listo. ¡No necesitas ningún código de verificación!)*\`;
    const waUrl = \`https://api.whatsapp.com/send?text=\${encodeURIComponent(texto)}\`;
    window.open(waUrl, '_blank');
};

window.copiarMensajeCompletoRedes = function() {
    if (!window.grupoLinkActivo) return;
    const g = window.grupoLinkActivo;
    const texto = \`¡Hola a todos! 👋\\n\\nSoy el(la) Profesor(a) \${g.docente} de la \${g.ie}.\\n\\n📚 Les comparto el enlace oficial de matrícula para el aula \${g.nombre} en la plataforma Peidagogos STEAM:\\n\\n👉 \${g.url}\\n\\n(Solo abre el enlace, escribe tus datos básicos y listo. ¡No necesitas ningún código de verificación!)\`;
    navigator.clipboard.writeText(texto).then(() => {
        alert("✅ ¡Mensaje completo copiado con éxito!\\n\\nPégalo directamente en tu grupo de WhatsApp, Facebook, Telegram o correo electrónico.");
    });
};

// =========================================================
// AUTO-DETECCIÓN Y PROCESAMIENTO DE LINK DIRECTO DE MATRÍCULA
// =========================================================
window.verificarParametrosMatriculaDirecta = function() {
    const params = new URLSearchParams(window.location.search);
    const regDirecto = params.get('reg');
    const docId = params.get('docente');
    const docNom = params.get('nombre_doc') || 'Docente Orientador';
    const ieParam = params.get('ie');
    const grupoParam = params.get('grupo');
    const gradoParam = params.get('grado');
    const materiaParam = params.get('materia');

    if (regDirecto === 'directo' || docId) {
        console.log("🚀 [CONTINGENCIA] Matrícula directa por enlace de redes activada:", { docId, docNom, grupoParam, ieParam });

        // Cambiar a la vista de matrícula
        if (typeof mostrarVista === 'function') {
            mostrarVista('register-screen-container');
        }

        window.matriculaContingenciaActiva = {
            docenteId: docId,
            docenteNombre: decodeURIComponent(docNom),
            institucion: ieParam ? decodeURIComponent(ieParam) : 'IE Instituto Montenegro',
            grupo: grupoParam ? decodeURIComponent(grupoParam) : '',
            grado: gradoParam ? decodeURIComponent(gradoParam) : '',
            materia: materiaParam ? decodeURIComponent(materiaParam) : ''
        };

        // Prellenar campos
        const selRol = document.getElementById('reg-rol');
        if (selRol) {
            selRol.value = 'estudiante_regular';
            if (typeof toggleCamposRegistroPorRol === 'function') toggleCamposRegistroPorRol();
        }

        const selIE = document.getElementById('reg-ie');
        if (selIE) {
            selIE.value = 'InstitutoMontenegro';
            if (typeof toggleIEOptions === 'function') toggleIEOptions();
        }

        const selGrado = document.getElementById('reg-grado');
        if (selGrado && gradoParam) selGrado.value = decodeURIComponent(gradoParam);

        const selGrupo = document.getElementById('registro-grupo');
        if (selGrupo && grupoParam) selGrupo.value = decodeURIComponent(grupoParam);

        // Ocultar campo de código institucional porque este link viene pre-autorizado por el docente
        const codBox = document.getElementById('campo-codigo-institucional');
        if (codBox) codBox.style.display = 'none';

        // Inyectar Banner de Bienvenida de Contingencia en la parte superior del formulario
        const regCard = document.querySelector('#register-screen-container > div');
        if (regCard && !document.getElementById('banner-contingencia-matricula')) {
            const banner = document.createElement('div');
            banner.id = 'banner-contingencia-matricula';
            banner.style.background = 'linear-gradient(135deg, #ECFDF5, #D1FAE5)';
            banner.style.border = '2px solid #10B981';
            banner.style.borderRadius = '14px';
            banner.style.padding = '14px 18px';
            banner.style.marginBottom = '12px';
            banner.style.color = '#065F46';
            banner.innerHTML = \`
                <div style="font-weight: 900; font-size: 1.05rem; display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                    <span>✨</span> Matrícula Directa de Contingencia
                </div>
                <div style="font-size: 0.88rem; line-height: 1.4;">
                    Te estás matriculando en el <strong>Grupo \${decodeURIComponent(grupoParam || 'General')}</strong> con el(la) Profesor(a) <strong>\${decodeURIComponent(docNom)}</strong> (\${decodeURIComponent(ieParam || 'IE Instituto Montenegro')}).
                </div>
                <div style="font-size: 0.8rem; margin-top: 6px; font-weight: 800; color: #047857;">
                    ⚡ Acceso inmediato sin códigos de verificación. Solo completa tus datos personales.
                </div>
            \`;
            regCard.insertBefore(banner, regCard.children[1]);
        }
    }
};

window.addEventListener('DOMContentLoaded', () => {
    setTimeout(window.verificarParametrosMatriculaDirecta, 200);
});
`;

appJs += '\n' + logicaContingenciaJs;

// Actualizar renderizarCajonesGrandesGruposDocente para agregar el botón de copiar Link de Redes en cada Cajón
const targetBotonCajon = `<button onclick="window.abrirCajonGrupoDocente('\${grpName.replace(/'/g, "\\\\'")}')" style="background: \${tema.bg}; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; cursor: pointer; width: 100%; font-size: 1rem; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.15); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        <span>📂</span> Abrir Planilla de \${grpName} <span>➔</span>
                    </button>`;

const replacementBotonCajon = `<button onclick="window.abrirCajonGrupoDocente('\${grpName.replace(/'/g, "\\\\'")}')" style="background: \${tema.bg}; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; cursor: pointer; width: 100%; font-size: 1rem; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.15); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        <span>📂</span> Abrir Planilla de \${grpName} <span>➔</span>
                    </button>

                    <!-- Botón de Link Rápido de Redes / WhatsApp -->
                    <button onclick="window.abrirModalLinkContingenciaGrupo('\${grpName.replace(/'/g, "\\\\'")}', '', '')" style="background: #F8FAFC; border: 1.5px solid #CBD5E1; color: #1E293B; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; margin-top: 8px; transition: 0.2s;" onmouseover="this.style.background='#E2E8F0'" onmouseout="this.style.background='#F8FAFC'">
                        <span>🔗</span> Link Matrícula (WhatsApp / Redes)
                    </button>`;

if (appJs.includes(targetBotonCajon)) {
    appJs = appJs.replace(targetBotonCajon, replacementBotonCajon);
    console.log('✅ Botón de Link de Redes Sociales agregado a cada cajón de grupo.');
}

// Actualizar en ejecutarRegistroEstudiante para omitir código cuando matriculaContingenciaActiva está presente
const targetRegCodigoCheck = `if (normCod !== "ieinstituto2026" && normCod !== "instituto2026") {`;

const replacementRegCodigoCheck = `if (!window.matriculaContingenciaActiva && normCod !== "ieinstituto2026" && normCod !== "instituto2026") {`;

if (appJs.includes(targetRegCodigoCheck)) {
    appJs = appJs.replace(targetRegCodigoCheck, replacementRegCodigoCheck);
    console.log('✅ Validación de código ajustada para omitirse automáticamente en matrícula de contingencia.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
