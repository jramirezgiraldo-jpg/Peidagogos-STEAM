const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Función para empaquetar un archivo .docx (Office Open XML ZIP)
function createDocx(outputPath, title, contentXml) {
    const files = {};

    // 1. [Content_Types].xml
    files['[Content_Types].xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>
</Types>`;

    // 2. _rels/.rels
    files['_rels/.rels'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

    // 3. word/_rels/document.xml.rels
    files['word/_rels/document.xml.rels'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>
</Relationships>`;

    // 4. word/settings.xml
    files['word/settings.xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:defaultTabStop w:val="720"/>
</w:settings>`;

    // 5. word/styles.xml
    files['word/styles.xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>
        <w:sz w:val="22"/>
        <w:szCs w:val="22"/>
        <w:lang w:val="es-CO"/>
      </w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:qFormat/>
  </w:style>
</w:styles>`;

    // 6. word/document.xml
    files['word/document.xml'] = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
${contentXml}
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>`;

    // Build ZIP buffer
    const zipBuffer = buildSimpleZip(files);
    fs.writeFileSync(outputPath, zipBuffer);
    console.log(`✅ Archivo .docx creado exitosamente en: ${outputPath} (${zipBuffer.length} bytes)`);
}

// Implementación ligera de empaquetador ZIP estándar en Node.js
function buildSimpleZip(filesMap) {
    const localHeaders = [];
    const centralEntries = [];
    let offset = 0;

    for (const [filename, contentStr] of Object.entries(filesMap)) {
        const fileData = Buffer.from(contentStr, 'utf8');
        const compressedData = zlib.deflateRawSync(fileData);
        const crc = crc32(fileData);
        const fileNameBuf = Buffer.from(filename, 'utf8');

        // Local file header (30 bytes + name + compressedData)
        const localHeader = Buffer.alloc(30);
        localHeader.writeUInt32LE(0x04034b50, 0); // signature
        localHeader.writeUInt16LE(20, 4);         // version needed (2.0)
        localHeader.writeUInt16LE(0, 6);          // flags
        localHeader.writeUInt16LE(8, 8);          // compression method: 8 (deflate)
        localHeader.writeUInt16LE(0, 10);         // mod time
        localHeader.writeUInt16LE(0, 12);         // mod date
        localHeader.writeUInt32LE(crc, 14);       // crc32
        localHeader.writeUInt32LE(compressedData.length, 18); // compressed size
        localHeader.writeUInt32LE(fileData.length, 22);       // uncompressed size
        localHeader.writeUInt16LE(fileNameBuf.length, 26);    // filename length
        localHeader.writeUInt16LE(0, 28);                     // extra length

        const localBlock = Buffer.concat([localHeader, fileNameBuf, compressedData]);
        localHeaders.push(localBlock);

        // Central directory entry (46 bytes + name)
        const centralHeader = Buffer.alloc(46);
        centralHeader.writeUInt32LE(0x02014b50, 0); // signature
        centralHeader.writeUInt16LE(20, 4);          // version made by
        centralHeader.writeUInt16LE(20, 6);          // version needed
        centralHeader.writeUInt16LE(0, 8);           // flags
        centralHeader.writeUInt16LE(8, 10);          // compression method: 8
        centralHeader.writeUInt16LE(0, 12);          // mod time
        centralHeader.writeUInt16LE(0, 14);          // mod date
        centralHeader.writeUInt32LE(crc, 16);        // crc32
        centralHeader.writeUInt32LE(compressedData.length, 20); // compressed size
        centralHeader.writeUInt32LE(fileData.length, 24);       // uncompressed size
        centralHeader.writeUInt16LE(fileNameBuf.length, 28);    // filename length
        centralHeader.writeUInt16LE(0, 30);          // extra field length
        centralHeader.writeUInt16LE(0, 32);          // file comment length
        centralHeader.writeUInt16LE(0, 34);          // disk number start
        centralHeader.writeUInt16LE(0, 36);          // internal file attributes
        centralHeader.writeUInt32LE(0, 38);          // external file attributes
        centralHeader.writeUInt32LE(offset, 42);     // relative offset of local header

        centralEntries.push(Buffer.concat([centralHeader, fileNameBuf]));
        offset += localBlock.length;
    }

    const centralDirBuffer = Buffer.concat(centralEntries);
    const localHeadersBuffer = Buffer.concat(localHeaders);

    // End of central directory record (22 bytes)
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0); // signature
    eocd.writeUInt16LE(0, 4);          // number of this disk
    eocd.writeUInt16LE(0, 6);          // disk where central directory starts
    eocd.writeUInt16LE(Object.keys(filesMap).length, 8);  // number of central directory records on this disk
    eocd.writeUInt16LE(Object.keys(filesMap).length, 10); // total number of central directory records
    eocd.writeUInt32LE(centralDirBuffer.length, 12);      // size of central directory
    eocd.writeUInt32LE(localHeadersBuffer.length, 16);    // offset of start of central directory
    eocd.writeUInt16LE(0, 20);         // comment length

    return Buffer.concat([localHeadersBuffer, centralDirBuffer, eocd]);
}

// CRC32 Helper
function crc32(buf) {
    let table = crc32.table;
    if (!table) {
        table = crc32.table = new Uint32Array(256);
        for (let i = 0; i < 256; i++) {
            let c = i;
            for (let k = 0; k < 8; k++) {
                c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
            }
            table[i] = c;
        }
    }
    let crc = 0 ^ (-1);
    for (let i = 0; i < buf.length; i++) {
        crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xFF];
    }
    return (crc ^ (-1)) >>> 0;
}

// Helper para párrafos en WordprocessingML
function p(text, options = {}) {
    const { bold, italic, size = 22, color = '000000', align = 'left', spacingAfter = 120, spacingBefore = 0 } = options;
    const jcXml = align !== 'left' ? `<w:jc w:val="${align}"/>` : '';
    const rPrXml = `
      <w:rPr>
        ${bold ? '<w:b/>' : ''}
        ${italic ? '<w:i/>' : ''}
        <w:sz w:val="${size}"/>
        <w:szCs w:val="${size}"/>
        <w:color w:val="${color}"/>
      </w:rPr>`;
    
    return `    <w:p>
      <w:pPr>
        ${jcXml}
        <w:spacing w:before="${spacingBefore}" w:after="${spacingAfter}" w:line="276" w:lineRule="auto"/>
      </w:pPr>
      <w:r>
        ${rPrXml}
        <w:t xml:space="preserve">${escapeXml(text)}</w:t>
      </w:r>
    </w:p>`;
}

function escapeXml(unsafe) {
    return unsafe.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
        }
    });
}

// Generación del documento Word
const fechaHoy = "18 de agosto de 2026";
let docXml = '';

// Encabezado
docXml += p("Montenegro, Quindío, " + fechaHoy, { align: 'right', size: 20, color: '555555', spacingAfter: 200 });

docXml += p("Señor:", { bold: true, size: 22, spacingAfter: 40 });
docXml += p("LIC. JORGE ELIÉCER", { bold: true, size: 24, spacingAfter: 40 });
docXml += p("Rector", { bold: true, size: 22, spacingAfter: 40 });
docXml += p("INSTITUCIÓN EDUCATIVA INSTITUTO MONTENEGRO", { bold: true, size: 22, color: '1E3A8A', spacingAfter: 40 });
docXml += p("Montenegro, Quindío", { size: 22, spacingAfter: 240 });

docXml += p("ASUNTO: Puesta a disposición solidaria de la plataforma tecnológica 'Peidagogos STEAM' para la atención pedagógica post-emergencia sísmica y formalización de Términos de Uso en Fase Piloto Institucional.", { bold: true, size: 22, color: '0F172A', spacingAfter: 240 });

docXml += p("Respetado Señor Rector:", { size: 22, spacingAfter: 140 });

docXml += p("Por medio de la presente comunicación, en mi calidad de docente de la institución y desarrollador de software, me dirijo a usted con el propósito de poner a disposición institucional y comunitaria, de manera solidaria y totalmente gratuita, la plataforma educativa interactiva PEIDAGOGOS STEAM.", { size: 22, align: 'both', spacingAfter: 140 });

docXml += p("Ante la contingencia y afectaciones derivadas del reciente evento sísmico en nuestro municipio y departamento, he integrado en la plataforma un módulo transversal de 'Primeros Auxilios Emocionales Post-Terremoto' y contención socioemocional, junto con herramientas digitales para la continuidad del aprendizaje, la gestión de guías quincenales, proyección de clases y evaluación formativa orientada a los estándares oficiales del Ministerio de Educación Nacional (MEN).", { size: 22, align: 'both', spacingAfter: 140 });

docXml += p("1. TITULARIDAD Y REGISTRO ANTE LA DIRECCIÓN NACIONAL DE DERECHO DE AUTOR (DNDA)", { bold: true, size: 22, color: '1E3A8A', spacingBefore: 180, spacingAfter: 80 });

docXml += p("Me permito informarle que la plataforma tecnológica Peidagogos STEAM cuenta con solicitud formal de registro de soporte lógico radicada ante la Dirección Nacional de Derecho de Autor (DNDA) de la República de Colombia bajo el Número de Radicado 1-2026-000055 en la categoría Software (con fecha de radicación 12 de agosto de 2026 a las 03:37 PM), a nombre del suscrito, Juan Felipe Ramírez Giraldo, en concordancia con la Ley 23 de 1982, la Decisión Andina 351 de 1993 y las directrices de la OMPI.", { size: 22, align: 'both', spacingAfter: 140 });

docXml += p("2. DELIMITACIÓN Y RECONOCIMIENTO DE REFERENTES CURRICULARES OFICIALES", { bold: true, size: 22, color: '1E3A8A', spacingBefore: 180, spacingAfter: 80 });

docXml += p("Para total claridad institucional y jurídica, se hace constar expresamente que:", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("a) Los Derechos Básicos de Aprendizaje (DBA), Matrices de Aprendizaje, Lineamientos Curriculares y Estándares Básicos de Competencias (EBC) son documentos oficiales y propiedad exclusiva del Ministerio de Educación Nacional (MEN), los cuales se incorporan en la plataforma como referentes pedagógicos de libre consulta formativa según el artículo 41 de la Ley 23 de 1982.", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("b) Los planes de área, mallas y documentos institucionales aportados por los docentes y la IE Instituto Montenegro son de titularidad de la comunidad académica institucional.", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("c) Toda la ingeniería de software, arquitectura tecnológica, algoritmos de aprendizaje de documentos, motores de actividades interactivas, interfaces gráficas (UX/UI), simuladores y código fuente constituyen la creación y propiedad intelectual exclusiva del suscrito autor.", { size: 22, align: 'both', spacingAfter: 140 });

docXml += p("3. TÉRMINOS Y CONDICIONES DE LA LICENCIA DE USO PILOTO INSTITUCIONAL", { bold: true, size: 22, color: '1E3A8A', spacingBefore: 180, spacingAfter: 80 });

docXml += p("El uso de la plataforma por parte de directivos, docentes y estudiantes de la IE Instituto Montenegro se rige bajo los siguientes términos:", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("• Gratuidad y Finalidad Solidaria: El acceso para todos los docentes y estudiantes de la institución es completamente gratuito ($0 COP) durante la presente fase de contingencia y evaluación académica.", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("• Licencia Académica Intransferible: La autorización concedida a la institución es de uso personal, pedagógico e institucional, sin transferencia de derechos patrimoniales sobre el software.", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("• Prohibición de Reproducción o Comercialización: Queda prohibida la copia, decompilación, extracción masiva de código o explotación comercial no autorizada de la plataforma por parte de terceros.", { size: 22, align: 'both', spacingAfter: 80 });
docXml += p("• Retroalimentación y Mejora Continua: Las observaciones, sugerencias o aportes pedagógicos que realicen los docentes a través del asistente virtual (PeidaBot) serán recibidos de forma voluntaria y utilizados exclusivamente para la optimización técnica y pedagógica continua de la herramienta en beneficio de la comunidad.", { size: 22, align: 'both', spacingAfter: 140 });

docXml += p("4. SOLICITUD Y DISPOSICIÓN", { bold: true, size: 22, color: '1E3A8A', spacingBefore: 180, spacingAfter: 80 });

docXml += p("Agradezco de antemano su receptividad y quedo a su entera disposición para coordinar una breve socialización con el equipo docente, presentar las funcionalidades de apoyo en aula y facilitar los accesos institucionales para el beneficio integral de nuestros estudiantes.", { size: 22, align: 'both', spacingAfter: 240 });

docXml += p("Cordialmente,", { size: 22, spacingAfter: 300 });

docXml += p("____________________________________________", { size: 22, color: '64748B', spacingAfter: 40 });
docXml += p("JUAN FELIPE RAMÍREZ GIRALDO", { bold: true, size: 22, color: '0F172A', spacingAfter: 30 });
docXml += p("Docente de la IE Instituto Montenegro", { size: 20, color: '334155', spacingAfter: 30 });
docXml += p("Desarrollador y Titular de la Plataforma Peidagogos STEAM", { size: 20, color: '334155', spacingAfter: 30 });
docXml += p("Registro DNDA Radicado N.° 1-2026-000055 (Software)", { bold: true, size: 20, color: '1E3A8A', spacingAfter: 30 });
docXml += p("Email institucional / Celular de contacto", { size: 20, color: '64748B', spacingAfter: 60 });

const outPath = 'd:/Peidagogos_Local/Oficio_Rectoria_Instituto_Montenegro_Peidagogos_STEAM.docx';
createDocx(outPath, "Oficio Rectoria Instituto Montenegro - Peidagogos STEAM", docXml);
