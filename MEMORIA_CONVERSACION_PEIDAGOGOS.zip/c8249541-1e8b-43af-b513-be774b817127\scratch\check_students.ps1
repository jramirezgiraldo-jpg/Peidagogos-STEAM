[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$wc = New-Object System.Net.WebClient
$json = $wc.DownloadString("https://peidagogosteam.com/api/estudiantes")
$users = $json | ConvertFrom-Json
Write-Host "Total students in live API: $($users.Count)"
$groups = $users | Group-Object -Property grupo
foreach ($g in $groups) {
    Write-Host "Grupo '$($g.Name)': $($g.Count) estudiantes"
}

Write-Host "`nSample students:"
foreach ($u in $users | Select-Object -First 5) {
    Write-Host "Doc: $($u.documento), Nombre: $($u.nombre) $($u.apellidos), Grado: $($u.grado), Grupo: $($u.grupo)"
}
