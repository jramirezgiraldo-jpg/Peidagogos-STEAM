# Comprobación básica de llaves y estructura
$app = Get-Content -Path "d:\Peidagogos_Local\app.js" -Raw
$login = Get-Content -Path "d:\Peidagogos_Local\login.html" -Raw

Write-Host "app.js length:" $app.Length
Write-Host "login.html length:" $login.Length

# Comprobación de funciones y mallas clave
$checks = @(
    "mallaMatematicas",
    "mallaNaturales",
    "mallaCastellano",
    "mallaSociales",
    "cambiarTabTutor",
    "seleccionarMateriaTutorMalla",
    "abrirMallaTutorDesdeEstudiante",
    "renderizarMallaTutorHomeSchool",
    "vista-tutor-mallas",
    "btn-tab-tutor-mallas"
)

foreach ($c in $checks) {
    if ($app.Contains($c) -or $login.Contains($c)) {
        Write-Host "OK: $c presente"
    } else {
        Write-Host "MISSING: $c"
    }
}
