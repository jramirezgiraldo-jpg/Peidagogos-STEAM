const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

console.log('Iniciando: 1. Simplificar registro docente, 2. Limpiar header docente, 3. Agregar Gestor de Materias/Grados en Panel Docente...');

// 1. SIMPLIFICAR EL FORMULARIO DE REGISTRO DOCENTE EN LOGIN.HTML
// Solo dejar Institución Educativa (y remover los checkboxes de materias/grados del registro inicial)
const targetCampoDocente = `<div id="campo-docente-asignatura" style="display: none; flex-direction: column; gap: 12px; background: #F5F3FF; padding: 16px; border: 1.5px solid #DDD6FE; border-radius: 12px;">
            <div>
                <label style="font-size: 0.85rem; font-weight: bold; color: #5B21B6; display: flex; align-items: center; justify-content: space-between; margin-bottom: 5px;">
                    <span>🏛️ Institución Educativa a la que Perteneces:</span>
                </label>
                <div style="display: flex; gap: 8px;">
                    <select id="reg-docente-ie-select" style="flex: 1; padding: 10px; border: 1.5px solid #8B5CF6; border-radius: 8px; font-weight: bold; background-color: white; font-size: 0.9rem;">
                        <!-- Se llena dinámicamente -->
                    </select>
                    <button type="button" onclick="window.abrirModalCrearIE('docente')" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 12px; border-radius: 8px; font-weight: bold; font-size: 0.8rem; cursor: pointer; white-space: nowrap;">
                        ➕ Nueva IE
                    </button>
                </div>
            </div>

            <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                    <label style="font-size: 0.85rem; font-weight: bold; color: #5B21B6; display: flex; align-items: center; gap: 4px; margin: 0;">
                        <span>📚</span> Materias que Orientas (Selecciona una o más):
                    </label>
                    <button type="button" onclick="window.abrirModalCrearAsignaturaDocente('registro')" style="background: #7C3AED; color: white; border: none; padding: 4px 10px; border-radius: 6px; font-weight: 800; font-size: 0.75rem; cursor: pointer;">
                        ➕ Crear Asignatura (IA)
                    </button>
                </div>
                <div id="reg-docente-materias-pills" style="display: flex; gap: 6px; flex-wrap: wrap; max-height: 140px; overflow-y: auto; background: white; padding: 10px; border-radius: 8px; border: 1px solid #DDD6FE;">
                    <!-- Checkboxes dinámicos inyectados por JS -->
                </div>
            </div>

            <div>
                <label style="font-size: 0.85rem; font-weight: bold; color: #5B21B6; display: block; margin-bottom: 6px;">
                    <span>🎓</span> Grados o Ciclos bajo tu cargo (Selección múltiple):
                </label>
                <div id="reg-docente-grados-pills" style="display: flex; gap: 6px; flex-wrap: wrap; background: white; padding: 10px; border-radius: 8px; border: 1px solid #DDD6FE;">
                    <!-- Checkboxes dinámicos inyectados por JS -->
                </div>
            </div>
        </div>`;

const replacementCampoDocente = `<div id="campo-docente-asignatura" style="display: none; flex-direction: column; gap: 10px; background: #F5F3FF; padding: 16px; border: 1.5px solid #DDD6FE; border-radius: 12px;">
            <label style="font-size: 0.88rem; font-weight: 800; color: #5B21B6; display: flex; align-items: center; justify-content: space-between; margin: 0;">
                <span>🏛️ Institución Educativa a la que Perteneces:</span>
            </label>
            <div style="display: flex; gap: 8px;">
                <select id="reg-docente-ie-select" style="flex: 1; padding: 10px; border: 1.5px solid #8B5CF6; border-radius: 8px; font-weight: bold; background-color: white; font-size: 0.9rem;">
                    <!-- Se llena dinámicamente -->
                </select>
                <button type="button" onclick="window.abrirModalCrearIE('docente')" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 14px; border-radius: 8px; font-weight: bold; font-size: 0.82rem; cursor: pointer; white-space: nowrap;">
                    ➕ Nueva IE
                </button>
            </div>
            <p style="margin: 0; color: #6D28D9; font-size: 0.8rem; line-height: 1.4;">
                ℹ️ <em>Tus materias y grados a cargo los configurarás y personalizarás con total comodidad directamente desde tu Panel Docente.</em>
            </p>
        </div>`;

loginHtml = loginHtml.replace(/\r\n/g, '\n');
const targetCampoDocenteNorm = targetCampoDocente.replace(/\r\n/g, '\n');

if (loginHtml.includes(targetCampoDocenteNorm)) {
    loginHtml = loginHtml.replace(targetCampoDocenteNorm, replacementCampoDocente);
    console.log('✅ Formulario de registro docente simplificado: solo datos personales e IE.');
} else {
    console.warn('⚠️ No se encontró targetCampoDocente.');
}

// 2. REDISEÑAR EL HEADER Y BARRA DE HERRAMIENTAS DEL PANEL DOCENTE EN LOGIN.HTML
const targetDocenteHeaderAndBar = `<header style="background: white; border-bottom: 1px solid #E5E7EB; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center;">
        <div style="font-weight: 900; font-size: 1.4rem; color: #111827;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 55px; width: auto; object-fit: contain;">
        </div>
        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <button onclick="window.abrirClasePrimerosAuxiliosEmocionales('docente')" style="background: linear-gradient(135deg, #EF4444, #DC2626); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(239,68,68,0.25);" title="Proyectar o trabajar la clase interactiva de contención y primeros auxilios emocionales post-sismo">
                <span>❤️‍🩹</span> Auxilios Emocionales (Terremoto)
            </button>
            <button onclick="window.abrirModalCrearAsignaturaDocente('docente')" style="background: linear-gradient(135deg, #4F46E5, #7C3AED); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(79,70,229,0.25);" title="Crear nueva materia y generar Malla DBA con IA/documentos">
                <span>📚</span> Crear Asignatura (IA)
            </button>
            <button onclick="window.abrirCajaHerramientas('todas', 'docente')" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(236,72,153,0.3);">
                <span>🧰</span> Caja de Herramientas
            </button>
            <button onclick="window.abrirConfiguradorDiapositivas('docente')" style="background: linear-gradient(135deg, #7C3AED, #6D28D9); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(124,58,237,0.25);">
                <span>📽️</span> Diapositivas de la Semana
            </button>
            <button onclick="mostrarReferidos()" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(236,72,153,0.25);"><span>🎁</span> Invita y Gana</button>
            <a href="proyector-qr.html" target="_blank" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(37,99,235,0.25);"><span>📽️</span> Proyectar QR Matrícula</a>
            <a href="proyector.html" target="_blank" style="background: #10B981; color: white; border: none; padding: 8px 20px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px;"><i class="ph ph-projector-screen-chart" style="font-size: 1.2rem;"></i> Modo Proyector</a>
            <div style="background: #F3F4F6; padding: 8px 15px; border-radius: 20px; font-size: 0.9rem; font-weight: 700; color: #374151;">
                Panel Docente: <span id="docente-nombre-header">Docente</span>
            </div>
            <button onclick="location.reload()" style="background: #EF4444; color: white; border: none; padding: 8px 20px; border-radius: 8px; font-weight: bold; cursor: pointer;">Cerrar Sesi&oacute;n</button>
        </div>
    </header>

    <div style="padding: 30px 30px; max-width: 1350px; margin: 0 auto;">
        
        <!-- Barra de Botones Rápidos Docente -->
        <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 25px; flex-wrap: wrap;">
            <button onclick="window.abrirModalAuditorQA()" style="background: linear-gradient(135deg, #0EA5E9, #0284C7); color: white; border: none; padding: 10px 16px; border-radius: 10px; font-weight: 800; font-size: 0.9rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(14,165,233,0.35);" title="Verifica una a una todas las funciones de la plataforma y auto-corrige">
                <span>🩺</span> Agente Auditor QA
            </button>
            <button onclick="window.abrirCajaHerramientas('todas', 'docente')" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 10px 16px; border-radius: 10px; font-weight: 800; font-size: 0.9rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(236,72,153,0.35);" title="Abre el kit completo con las 42 herramientas y generadores de aula">
                <span>🧰</span> Caja de Herramientas (42)
            </button>
            <button onclick="window.abrirConfiguradorDiapositivas('docente')" style="background: linear-gradient(135deg, #7C3AED, #6D28D9); color: white; border: none; padding: 10px 16px; border-radius: 10px; font-weight: 800; font-size: 0.9rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(124,58,237,0.3);" title="Genera 10 diapositivas para introducir el tema de la semana">
                <span>📽️</span> 10 Diapositivas Semanales
            </button>
            <a href="proyector.html" target="_blank" style="background: linear-gradient(135deg, #059669, #10B981); color: white; border: none; padding: 10px 16px; border-radius: 10px; font-weight: 800; font-size: 0.9rem; text-decoration: none; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(16,185,129,0.3);" title="Modo interactivo para cuando los estudiantes no tienen computadores">
                <span>📽️</span> Modo Proyector (Sin Computadores)
            </a>
            <button onclick="window.abrirRankingDocenteNuevaPestana()" style="background: linear-gradient(135deg, #F59E0B, #D97706); color: white; border: none; padding: 10px 16px; border-radius: 10px; font-weight: 900; font-size: 0.9rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(245,158,11,0.35);" title="Abre la tabla de posiciones en una pestaña nueva para VideoBeam / Smart TV">
                <span>🏆</span> Proyectar Ránking en Pestaña Nueva
            </button>
        </div>`;

const replacementDocenteHeaderAndBar = `<header style="background: white; border-bottom: 1.5px solid #E2E8F0; padding: 14px 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
        <div style="display: flex; align-items: center; gap: 14px;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 48px; width: auto; object-fit: contain;">
            <div style="border-left: 2px solid #E2E8F0; padding-left: 14px;">
                <div style="font-weight: 900; font-size: 1.25rem; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <span>👨‍🏫</span> <span id="docente-nombre-header">Docente</span>
                </div>
                <div id="docente-institucion-subhead" style="font-size: 0.82rem; color: #64748B; font-weight: 600;">
                    🏛️ IE Instituto Montenegro • Sede Principal
                </div>
            </div>
        </div>

        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
            <button onclick="window.abrirClasePrimerosAuxiliosEmocionales('docente')" style="background: linear-gradient(135deg, #EF4444, #DC2626); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 0.85rem; box-shadow: 0 3px 8px rgba(239,68,68,0.25);" title="Clase de Primeros Auxilios Emocionales post-sismo">
                <span>❤️‍🩹</span> Auxilios Emocionales
            </button>
            <button onclick="mostrarReferidos()" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 0.85rem; box-shadow: 0 3px 8px rgba(236,72,153,0.25);">
                <span>🎁</span> Invita y Gana
            </button>
            <button onclick="location.reload()" style="background: #F1F5F9; color: #475569; border: 1px solid #CBD5E1; padding: 8px 16px; border-radius: 8px; font-weight: 800; cursor: pointer; font-size: 0.85rem;" onmouseover="this.style.background='#E2E8F0'" onmouseout="this.style.background='#F1F5F9'">
                <span>🚪</span> Cerrar Sesión
            </button>
        </div>
    </header>

    <div style="padding: 30px 30px; max-width: 1400px; margin: 0 auto;">
        
        <!-- BARRA PRINCIPAL DE GESTIÓN Y HERRAMIENTAS STEAM -->
        <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 18px 22px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            
            <!-- Grupo Izquierdo: Gestión Curricular y Asignaturas -->
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <span style="font-weight: 900; font-size: 0.92rem; color: #1E293B; display: flex; align-items: center; gap: 6px;">
                    <span>📚</span> Gestión de Materias:
                </span>
                <button onclick="window.abrirModalCrearAsignaturaDocente('docente')" style="background: linear-gradient(135deg, #7C3AED, #6D28D9); color: white; border: none; padding: 9px 16px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 10px rgba(124,58,237,0.25);" title="Crear nueva materia y generar Malla Curricular DBA con IA">
                    <span>✨</span> Crear Asignatura (IA)
                </button>
                <button onclick="window.abrirModalGestionMateriasGradosDocente()" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 9px 16px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 10px rgba(37,99,235,0.25);" title="Seleccionar qué materias dictas y qué grados tienes a cargo">
                    <span>⚙️</span> Mis Materias y Grados
                </button>
            </div>

            <!-- Grupo Derecho: Herramientas de Aula y Proyección -->
            <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <button onclick="window.abrirCajaHerramientas('todas', 'docente')" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(236,72,153,0.25);" title="Caja con las 42 herramientas interactivas STEAM">
                    <span>🧰</span> Caja STEAM (42)
                </button>
                <button onclick="window.abrirConfiguradorDiapositivas('docente')" style="background: #6366F1; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(99,102,241,0.25);" title="Generador de 10 Diapositivas Semanales">
                    <span>📽️</span> Diapositivas
                </button>
                <a href="proyector.html" target="_blank" style="background: #10B981; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; text-decoration: none; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(16,185,129,0.25);" title="Modo interactivo de aula sin computadores">
                    <span>📽️</span> Proyector
                </a>
                <button onclick="window.abrirRankingDocenteNuevaPestana()" style="background: #F59E0B; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 900; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(245,158,11,0.25);" title="Ránking en vivo para VideoBeam / Smart TV">
                    <span>🏆</span> Ránking
                </button>
                <button onclick="window.abrirModalAuditorQA()" style="background: #0284C7; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px;" title="Agente Auditor QA">
                    <span>🩺</span> QA
                </button>
            </div>
        </div>`;

const targetDocenteHeaderAndBarNorm = targetDocenteHeaderAndBar.replace(/\r\n/g, '\n');
if (loginHtml.includes(targetDocenteHeaderAndBarNorm)) {
    loginHtml = loginHtml.replace(targetDocenteHeaderAndBarNorm, replacementDocenteHeaderAndBar);
    console.log('✅ Header y barra de herramientas docente rediseñados y desduplicados.');
} else {
    console.warn('⚠️ No se encontró targetDocenteHeaderAndBar exacto.');
}

// 3. INYECTAR MODAL DE GESTIÓN DE MATERIAS Y GRADOS DEL DOCENTE EN LOGIN.HTML
const modalGestionMateriasHtml = `
    <!-- MODAL DE GESTIÓN DE MATERIAS Y GRADOS DEL DOCENTE -->
    <div id="modal-gestionar-materias-grados" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.7); backdrop-filter: blur(4px); z-index: 100000; justify-content: center; align-items: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 650px; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); border: 1px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column; max-height: 90vh;">
            
            <div style="background: linear-gradient(135deg, #1E40AF, #3B82F6); padding: 20px 24px; color: white; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.6rem;">⚙️</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.25rem; font-weight: 900; color: white;">Configuración de Materias y Grados</h3>
                        <p style="margin: 2px 0 0 0; font-size: 0.82rem; opacity: 0.9;">Selecciona qué asignaturas dictas y qué grupos tienes bajo tu cargo</p>
                    </div>
                </div>
                <button onclick="window.cerrarModalGestionMateriasGradosDocente()" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; justify-content: center;">✕</button>
            </div>

            <div style="padding: 24px; overflow-y: auto; flex: 1; display: flex; flex-direction: column; gap: 20px;">
                
                <!-- Sección 1: Materias Asignadas -->
                <div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <label style="font-weight: 900; color: #1E293B; font-size: 0.95rem; display: flex; align-items: center; gap: 6px;">
                            <span>📚</span> 1. Materias que Orientas:
                        </label>
                        <button type="button" onclick="window.abrirModalCrearAsignaturaDocente('docente'); window.cerrarModalGestionMateriasGradosDocente();" style="background: #7C3AED; color: white; border: none; padding: 4px 10px; border-radius: 6px; font-weight: 800; font-size: 0.78rem; cursor: pointer;">
                            ➕ Inscribir Materia Nueva (IA)
                        </button>
                    </div>
                    <p style="margin: 0 0 10px 0; color: #64748B; font-size: 0.82rem;">Marca las materias del catálogo que orientas en tu institución:</p>
                    <div id="gestor-materias-pills-container" style="display: flex; gap: 8px; flex-wrap: wrap; background: #F8FAFC; padding: 12px; border-radius: 12px; border: 1px solid #E2E8F0; max-height: 160px; overflow-y: auto;">
                        <!-- Se inyectan checkboxes dinámicos -->
                    </div>
                </div>

                <!-- Sección 2: Grados Asignados -->
                <div>
                    <label style="font-weight: 900; color: #1E293B; font-size: 0.95rem; display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                        <span>🎓</span> 2. Grados o Ciclos a tu Cargo:
                    </label>
                    <p style="margin: 0 0 10px 0; color: #64748B; font-size: 0.82rem;">Marca los grados de los cuales quieres ver estudiantes y cajones en tu panel:</p>
                    <div id="gestor-grados-pills-container" style="display: flex; gap: 8px; flex-wrap: wrap; background: #F8FAFC; padding: 12px; border-radius: 12px; border: 1px solid #E2E8F0;">
                        <!-- Se inyectan checkboxes de grados -->
                    </div>
                </div>

            </div>

            <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 16px 24px; display: flex; justify-content: space-between; align-items: center;">
                <button onclick="window.cerrarModalGestionMateriasGradosDocente()" style="background: transparent; color: #64748B; border: none; font-weight: 700; cursor: pointer; font-size: 0.9rem;">
                    Cancelar
                </button>
                <button onclick="window.guardarConfiguracionMateriasGradosDocente()" style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 10px 24px; border-radius: 10px; font-weight: 800; font-size: 0.95rem; cursor: pointer; box-shadow: 0 4px 12px rgba(16,185,129,0.3);">
                    💾 Guardar y Actualizar Grupos
                </button>
            </div>

        </div>
    </div>
`;

if (!loginHtml.includes('modal-gestionar-materias-grados')) {
    const endBodyIdx = loginHtml.lastIndexOf('</body>');
    if (endBodyIdx !== -1) {
        loginHtml = loginHtml.slice(0, endBodyIdx) + modalGestionMateriasHtml + '\n' + loginHtml.slice(endBodyIdx);
        console.log('✅ Modal de Gestión de Materias y Grados inyectado en login.html');
    }
}

// Actualizar version de scripts a v52
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v52');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v52');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v52');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 4. ACTUALIZAR APP.JS CON CAJONES EXPANDIDOS Y GESTOR DE MATERIAS
// =========================================================
appJs = appJs.replace(/\r\n/g, '\n');

const gestorMateriasGradosJs = `
// =========================================================
// GESTOR DE MATERIAS Y GRADOS DEL DOCENTE EN SU PANEL
// =========================================================
window.abrirModalGestionMateriasGradosDocente = function() {
    const modal = document.getElementById('modal-gestionar-materias-grados');
    if (!modal) return;
    modal.style.display = 'flex';

    // 1. Obtener perfil docente activo
    let docentePerfil = null;
    try {
        const dList = JSON.parse(localStorage.getItem('docentes_db') || '[]');
        const authSes = JSON.parse(sessionStorage.getItem('peidagogos_auth') || localStorage.getItem('usuario_actual') || '{}');
        const docKey = String(window.usuario_actual || authSes.documento || authSes.usuario || '').trim().toLowerCase();
        docentePerfil = dList.find(d => {
            const dDoc = String(d.documento || d.cedula || d.usuario || '').trim().toLowerCase();
            return dDoc === docKey;
        });
        if (!docentePerfil) docentePerfil = authSes;
    } catch(e) {}

    const materiasActivas = (docentePerfil && Array.isArray(docentePerfil.materias)) ? docentePerfil.materias : ['Física', 'Ciencias Naturales'];
    const gradosActivos = (docentePerfil && Array.isArray(docentePerfil.grados)) ? docentePerfil.grados : ['6', '7', '8', '9'];

    // 2. Renderizar catálogo de materias (Oficiales + Creadas por IA)
    const containerMaterias = document.getElementById('gestor-materias-pills-container');
    if (containerMaterias) {
        const catalogoBase = [
            'Física', 'Ciencias Naturales y Educación Ambiental', 'Química', 'Matemáticas',
            'Lengua Castellana', 'Ciencias Sociales', 'Tecnología e Informática',
            'Educación Artística', 'Ética y Valores Humanos', 'Turismo y Patrimonio',
            'Filosofía', 'Inglés', 'Auxilios Emocionales y Prevención del Riesgo'
        ];

        // Añadir materias creadas
        try {
            const materiasCreadas = JSON.parse(localStorage.getItem('asignaturas_creadas_db') || '[]');
            materiasCreadas.forEach(mc => {
                if (mc.nombre && !catalogoBase.includes(mc.nombre)) catalogoBase.push(mc.nombre);
            });
        } catch(e) {}

        containerMaterias.innerHTML = catalogoBase.map(m => {
            const isChecked = materiasActivas.some(ma => ma.toLowerCase() === m.toLowerCase()) ? 'checked' : '';
            return \`
                <label style="display: inline-flex; align-items: center; gap: 6px; background: white; border: 1.5px solid \${isChecked ? '#3B82F6' : '#CBD5E1'}; padding: 6px 12px; border-radius: 8px; font-size: 0.85rem; font-weight: 700; color: #1E293B; cursor: pointer;">
                    <input type="checkbox" name="gestor_docente_materia_chk" value="\${m}" \${isChecked} style="accent-color: #2563EB;">
                    \${m}
                </label>
            \`;
        }).join('');
    }

    // 3. Renderizar catálogo de Grados
    const containerGrados = document.getElementById('gestor-grados-pills-container');
    if (containerGrados) {
        const gradosLista = [
            { val: '1', txt: '1° Primaria' },
            { val: '2', txt: '2° Primaria' },
            { val: '3', txt: '3° Primaria' },
            { val: '4', txt: '4° Primaria' },
            { val: '5', txt: '5° Primaria' },
            { val: '6', txt: '6° Secundaria' },
            { val: '7', txt: '7° Secundaria' },
            { val: '8', txt: '8° Secundaria' },
            { val: '9', txt: '9° Secundaria' },
            { val: '10', txt: '10° Media' },
            { val: '11', txt: '11° Media' },
            { val: 'Ciclo I', txt: 'Ciclo I (1°,2°,3°)' },
            { val: 'Ciclo II', txt: 'Ciclo II (4°,5°)' },
            { val: 'Ciclo III', txt: 'Ciclo III (6°,7°)' },
            { val: 'Ciclo IV', txt: 'Ciclo IV (8°,9°)' },
            { val: 'Ciclo V', txt: 'Ciclo V (10°)' },
            { val: 'Ciclo VI', txt: 'Ciclo VI (11°)' }
        ];

        containerGrados.innerHTML = gradosLista.map(g => {
            const isChecked = gradosActivos.some(ga => String(ga).toLowerCase() === g.val.toLowerCase() || String(ga).toLowerCase() === g.txt.toLowerCase()) ? 'checked' : '';
            return \`
                <label style="display: inline-flex; align-items: center; gap: 6px; background: white; border: 1.5px solid \${isChecked ? '#10B981' : '#CBD5E1'}; padding: 6px 12px; border-radius: 8px; font-size: 0.85rem; font-weight: 700; color: #1E293B; cursor: pointer;">
                    <input type="checkbox" name="gestor_docente_grado_chk" value="\${g.val}" \${isChecked} style="accent-color: #10B981;">
                    \${g.txt}
                </label>
            \`;
        }).join('');
    }
};

window.cerrarModalGestionMateriasGradosDocente = function() {
    const modal = document.getElementById('modal-gestionar-materias-grados');
    if (modal) modal.style.display = 'none';
};

window.guardarConfiguracionMateriasGradosDocente = function() {
    const chkMaterias = document.querySelectorAll('input[name="gestor_docente_materia_chk"]:checked');
    const chkGrados = document.querySelectorAll('input[name="gestor_docente_grado_chk"]:checked');

    const materiasSel = Array.from(chkMaterias).map(c => c.value);
    const gradosSel = Array.from(chkGrados).map(c => c.value);

    if (materiasSel.length === 0) {
        alert("⚠️ Por favor selecciona al menos una materia que orientas.");
        return;
    }
    if (gradosSel.length === 0) {
        alert("⚠️ Por favor selecciona al menos un grado o ciclo a tu cargo.");
        return;
    }

    try {
        let dList = JSON.parse(localStorage.getItem('docentes_db') || '[]');
        const authSes = JSON.parse(sessionStorage.getItem('peidagogos_auth') || localStorage.getItem('usuario_actual') || '{}');
        const docKey = String(window.usuario_actual || authSes.documento || authSes.usuario || '').trim().toLowerCase();

        let docItem = dList.find(d => {
            const dDoc = String(d.documento || d.cedula || d.usuario || '').trim().toLowerCase();
            return dDoc === docKey;
        });

        if (!docItem) {
            docItem = {
                documento: docKey || 'docente',
                nombre: (document.getElementById('docente-nombre-header') ? document.getElementById('docente-nombre-header').innerText : 'Docente'),
                institucion: 'IE Instituto Montenegro'
            };
            dList.push(docItem);
        }

        docItem.materias = materiasSel;
        docItem.asignatura = materiasSel.join(', ');
        docItem.grados = gradosSel;
        docItem.grado = gradosSel.join(', ');

        localStorage.setItem('docentes_db', JSON.stringify(dList));

        // Actualizar sesión actual
        authSes.materias = materiasSel;
        authSes.grados = gradosSel;
        sessionStorage.setItem('peidagogos_auth', JSON.stringify(authSes));

        window.cerrarModalGestionMateriasGradosDocente();
        
        // Recargar cajones de grupos
        if (typeof window.cargarEstudiantesDocente === 'function') {
            window.cargarEstudiantesDocente(window.usuario_actual || docKey);
        }

        alert(\`✅ Configuración guardada con éxito:\n\n📚 \${materiasSel.length} Materias asignadas\n🎓 \${gradosSel.length} Grados a cargo\n\nTus cajones de grupos se han actualizado automáticamente.\`);
    } catch(e) {
        console.error("Error al guardar configuración docente:", e);
    }
};
`;

// Reemplazar la función de renderizado de cajones para que sean GRANDES y con EXPLICACIONES PEDAGÓGICAS
const reemplazoCajonesGrandesJs = `
// =========================================================
// RENDERIZADO DE CAJONES DE GRUPOS GRANDES Y DETALLADOS
// =========================================================
window.renderizarCajonesGrandesGruposDocente = function(gruposMap, gradosDocente) {
    const gridCont = document.getElementById('docente-grid-cajones-grupos');
    if (!gridCont) return;

    const nombresGrupos = Object.keys(gruposMap).sort();
    
    if (nombresGrupos.length === 0) {
        gridCont.innerHTML = \`
            <div style="grid-column: 1 / -1; background: white; border: 2px dashed #CBD5E1; border-radius: 20px; padding: 50px 25px; text-align: center;">
                <span style="font-size: 3.5rem;">🏫</span>
                <h3 style="color: #1E293B; margin: 15px 0 8px 0; font-weight: 900; font-size: 1.35rem;">Aún no tienes estudiantes matriculados en tus grupos</h3>
                <p style="color: #64748B; font-size: 0.95rem; margin: 0 auto 20px auto; max-width: 600px; line-height: 1.5;">
                    Los estudiantes matriculados en tu institución que coincidan con tus grados asignados aparecerán automáticamente en sus respectivos cajones. Puedes verificar o añadir más grados y materias con el botón <strong>⚙️ Mis Materias y Grados</strong>.
                </p>
                <button onclick="window.abrirModalGestionMateriasGradosDocente()" style="background: #2563EB; color: white; border: none; padding: 10px 20px; border-radius: 10px; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
                    <span>⚙️</span> Configurar Grados y Materias
                </button>
            </div>
        \`;
        return;
    }

    let htmlCajones = '';
    const estilosGradientes = [
        { bg: 'linear-gradient(135deg, #1E40AF, #3B82F6)', border: '#93C5FD', icon: '🌌', label: 'Ciencias & Física' },
        { bg: 'linear-gradient(135deg, #065F46, #10B981)', border: '#A7F3D0', icon: '🌿', label: 'Educación Ambiental' },
        { bg: 'linear-gradient(135deg, #5B21B6, #8B5CF6)', border: '#DDD6FE', icon: '🧪', label: 'Química & STEAM' },
        { bg: 'linear-gradient(135deg, #9A3412, #F97316)', border: '#FDBA74', icon: '⚙️', label: 'Tecnología & Robótica' },
        { bg: 'linear-gradient(135deg, #9D174D, #EC4899)', border: '#FBCFE8', icon: '🎨', label: 'Arte & Creatividad' },
        { bg: 'linear-gradient(135deg, #0E7490, #06B6D4)', border: '#A5F3FC', icon: '🧭', label: 'Turismo & Territorio' }
    ];

    nombresGrupos.forEach((grpName, idx) => {
        const alumnosGrupo = gruposMap[grpName];
        const tema = estilosGradientes[idx % estilosGradientes.length];
        
        let xpTotalGrupo = 0;
        alumnosGrupo.forEach(al => {
            const docClean = al.documento || al.usuario || al.id || '';
            let xpEst = parseInt(localStorage.getItem(\`xp_\${docClean}\`)) || 500;
            xpTotalGrupo += xpEst;
        });
        const promXP = Math.round(xpTotalGrupo / alumnosGrupo.length);

        htmlCajones += \`
            <div style="background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.06); border: 1.5px solid #E2E8F0; overflow: hidden; display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.25s, box-shadow 0.25s; min-height: 340px;" onmouseover="this.style.transform='translateY(-6px)'; this.style.boxShadow='0 18px 35px rgba(0,0,0,0.12)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.06)';">
                
                <!-- Cabecera Vibrante del Cajón -->
                <div style="background: \${tema.bg}; color: white; padding: 22px 24px; position: relative;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="background: rgba(255,255,255,0.22); color: white; padding: 3px 10px; border-radius: 20px; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 900; backdrop-filter: blur(4px);">
                                \${tema.label}
                            </span>
                            <h3 style="margin: 8px 0 2px 0; font-size: 1.65rem; font-weight: 900; color: white;">
                                Grupo \${grpName}
                            </h3>
                            <span style="font-size: 0.85rem; opacity: 0.92; font-weight: 600;">
                                Aula de Aprendizaje Activo
                            </span>
                        </div>
                        <div style="background: rgba(255,255,255,0.25); width: 48px; height: 48px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; backdrop-filter: blur(4px);">
                            \${tema.icon}
                        </div>
                    </div>
                </div>
                
                <!-- Cuerpo y Explicación Pedagógica del Contenido -->
                <div style="padding: 22px 24px; flex: 1; display: flex; flex-direction: column; justify-content: space-between; gap: 16px;">
                    
                    <!-- Métricas Principales -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; padding: 10px 12px; border-radius: 12px; text-align: center;">
                            <span style="font-size: 0.75rem; color: #64748B; font-weight: 800; text-transform: uppercase;">Estudiantes</span>
                            <div style="font-size: 1.3rem; font-weight: 900; color: #0F172A;">\${alumnosGrupo.length}</div>
                        </div>
                        <div style="background: #ECFDF5; border: 1px solid #A7F3D0; padding: 10px 12px; border-radius: 12px; text-align: center;">
                            <span style="font-size: 0.75rem; color: #047857; font-weight: 800; text-transform: uppercase;">Promedio STEAM</span>
                            <div style="font-size: 1.3rem; font-weight: 900; color: #059669;">🌟 \${promXP} XP</div>
                        </div>
                    </div>

                    <!-- Explicación de lo que encuentras en este Cajón -->
                    <div style="background: #F1F5F9; border-radius: 12px; padding: 12px 14px; font-size: 0.82rem; color: #334155; line-height: 1.45;">
                        <div style="font-weight: 900; color: #0F172A; margin-bottom: 4px; display: flex; align-items: center; gap: 4px;">
                            <span>📋</span> Contenido del Cajón:
                        </div>
                        <ul style="margin: 0; padding-left: 18px;">
                            <li><strong>Planilla en vivo:</strong> Seguimiento individual de avances formativos.</li>
                            <li><strong>Guías Resueltas:</strong> Solucionario oficial para el orientador.</li>
                            <li><strong>Malla Curricular DBA:</strong> Estándares y matriz MEN asociada.</li>
                            <li><strong>Evaluación Formativa:</strong> Bonificaciones (+10%) y sanciones.</li>
                        </ul>
                    </div>

                    <!-- Botón de Entrada Principal -->
                    <button onclick="window.abrirCajonGrupoDocente('\${grpName.replace(/'/g, "\\\\'")}')" style="background: \${tema.bg}; color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 900; cursor: pointer; width: 100%; font-size: 1rem; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.15); transition: 0.2s;" onmouseover="this.style.filter='brightness(1.1)'" onmouseout="this.style.filter='none'">
                        <span>📂</span> Abrir Planilla de \${grpName} <span>➔</span>
                    </button>

                </div>
            </div>
        \`;
    });
    gridCont.innerHTML = htmlCajones;
};
`;

appJs += '\n' + gestorMateriasGradosJs + '\n' + reemplazoCajonesGrandesJs;

// Actualizar en cargarEstudiantesDocente la llamada al nuevo renderizador
const targetRenderLlamada = `// 4. Renderizar Cajones de Grupos
        const gridCont = document.getElementById('docente-grid-cajones-grupos');
        const badgeTotal = document.getElementById('docente-total-estudiantes-badge');
        if (badgeTotal) badgeTotal.innerText = \`👥 Total Alumnos: \${misEstudiantes.length}\`;`;

const replacementRenderLlamada = `// 4. Renderizar Cajones de Grupos con Diseño Amplio y Explicaciones
        const badgeTotal = document.getElementById('docente-total-estudiantes-badge');
        if (badgeTotal) badgeTotal.innerText = \`👥 Total Alumnos: \${misEstudiantes.length}\`;
        
        if (window.renderizarCajonesGrandesGruposDocente) {
            window.renderizarCajonesGrandesGruposDocente(gruposMap, gradosDocente);
            return;
        }`;

if (appJs.includes(targetRenderLlamada)) {
    appJs = appJs.replace(targetRenderLlamada, replacementRenderLlamada);
    console.log('✅ cargarEstudiantesDocente enlazado al renderizador de cajones grandes.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis completa con VM
try {
    new vm.Script(appJs);
    console.log('✨ Validación de sintaxis VM en app.js: CORRECTO (0 errores).');
} catch(err) {
    console.error('❌ Error de sintaxis en app.js:', err);
}
