$files = @(
    "C:\Users\Juan Felipe\Documents\DBA C naturales.pdf",
    "C:\Users\Juan Felipe\Documents\DBA C sociales.pdf",
    "C:\Users\Juan Felipe\Documents\DBA lenguaje.pdf",
    "C:\Users\Juan Felipe\Documents\DBA matematicas.pdf"
)

foreach ($f in $files) {
    Write-Host "============================="
    Write-Host "FILE: $f"
    $bytes = [System.IO.File]::ReadAllBytes($f)
    $str = [System.Text.Encoding]::ASCII.GetString($bytes)
    
    # Buscar ocurrencias de Grado / DBA
    $matches = [regex]::Matches($str, "(Grado\s+[0-9]+|GRADO\s+[0-9]+|DERECHOS\s+B[AÁ]SICOS|DBA)")
    Write-Host "Total matches: $($matches.Count)"
    for ($i = 0; $i -lt [math]::Min(5, $matches.Count); $i++) {
        Write-Host "  Match: $($matches[$i].Value)"
    }
}
