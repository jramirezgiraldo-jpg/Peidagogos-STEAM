const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

console.log('Iniciando integración de PeidaBot y Buzón de Sugerencias Docentes...');

// 1. Actualizar términos legales en login.html para incluir Cláusula 4 (Feedback y Sugerencias)
const targetTerminosSec3 = `                <div>
                    <h4 style="margin: 0 0 6px 0; color: #0F172A; font-weight: 900; font-size: 1.05rem; display: flex; align-items: center; gap: 6px;">
                        <span>3.</span> Condiciones de la Licencia de Prueba y Prohibiciones
                    </h4>
                    <ul style="margin: 0; padding-left: 20px; color: #334155; display: flex; flex-direction: column; gap: 6px;">
                        <li>El acceso institucional otorgado a directivos, docentes y estudiantes constituye una licencia de uso personal y académico intransferible.</li>
                        <li>Queda expresamente prohibida la copia, reproducción no autorizada, ingeniería inversa, descompilación, extracción masiva de datos (web scraping), redistribución o explotación comercial del software sin el consentimiento expreso y por escrito del autor.</li>
                        <li>El uso de la plataforma no transfiere ningún derecho patrimonial ni moral sobre el soporte lógico ni sobre sus algoritmos.</li>
                    </ul>
                </div>`;

const replacementTerminosSec3 = `                <div>
                    <h4 style="margin: 0 0 6px 0; color: #0F172A; font-weight: 900; font-size: 1.05rem; display: flex; align-items: center; gap: 6px;">
                        <span>3.</span> Condiciones de la Licencia de Prueba y Prohibiciones
                    </h4>
                    <ul style="margin: 0; padding-left: 20px; color: #334155; display: flex; flex-direction: column; gap: 6px;">
                        <li>El acceso institucional otorgado a directivos, docentes y estudiantes constituye una licencia de uso personal y académico intransferible.</li>
                        <li>Queda expresamente prohibida la copia, reproducción no autorizada, ingeniería inversa, descompilación, extracción masiva de datos (web scraping), redistribución o explotación comercial del software sin el consentimiento expreso y por escrito del autor.</li>
                        <li>El uso de la plataforma no transfiere ningún derecho patrimonial ni moral sobre el soporte lógico ni sobre sus algoritmos.</li>
                    </ul>
                </div>

                <div style="background: #F8FAFC; border: 1.5px dashed #94A3B8; border-radius: 12px; padding: 14px 18px;">
                    <h4 style="margin: 0 0 6px 0; color: #0F172A; font-weight: 900; font-size: 1.02rem; display: flex; align-items: center; gap: 6px;">
                        <span>4.</span> Aportes, Sugerencias y Retroalimentación Docente (Feedback)
                    </h4>
                    <p style="margin: 0; color: #475569; font-size: 0.88rem;">
                        Las anomalías reportadas, sugerencias metodológicas, propuestas de mejora o comentarios que los docentes y directivos compartan voluntariamente mediante el asistente virtual (PeidaBot) o canales de soporte se consideran contribuciones libres de regalías para la optimización técnica continua de la plataforma. La implementación de tales sugerencias no genera derechos de autor, copropiedad ni contraprestación económica alguna a favor del usuario aportante, manteniéndose la titularidad íntegra y exclusiva en cabeza de Juan Felipe Ramírez Giraldo (DNDA Radicado 1-2026-000055).
                    </p>
                </div>`;

if (loginHtml.includes(targetTerminosSec3)) {
    loginHtml = loginHtml.replace(targetTerminosSec3, replacementTerminosSec3);
    console.log('✅ Cláusula 4 de Feedback añadida a los términos legales.');
}

// 2. Inyectar tercer tab en el panel de administrador
const targetAdminTabs = `<button class="admin-tab-btn active" data-tab="grupos" style="padding: 15px 30px; border: none; background: white; font-weight: bold; cursor: pointer; border-bottom: 3px solid #3B82F6;">Instituciones</button>
                <button class="admin-tab-btn" data-tab="docentes" style="padding: 15px 30px; border: none; background: transparent; font-weight: bold; cursor: pointer; color: #6B7280;">Lista Docentes</button>`;

const replacementAdminTabs = `<button class="admin-tab-btn active" data-tab="grupos" onclick="window.cambiarTabAdmin('grupos')" style="padding: 15px 30px; border: none; background: white; font-weight: bold; cursor: pointer; border-bottom: 3px solid #3B82F6;">Instituciones</button>
                <button class="admin-tab-btn" data-tab="docentes" onclick="window.cambiarTabAdmin('docentes')" style="padding: 15px 30px; border: none; background: transparent; font-weight: bold; cursor: pointer; color: #6B7280;">Lista Docentes</button>
                <button class="admin-tab-btn" data-tab="feedback" onclick="window.cambiarTabAdmin('feedback')" style="padding: 15px 30px; border: none; background: transparent; font-weight: bold; cursor: pointer; color: #6B7280; display: flex; align-items: center; gap: 8px;">
                    <span>📬</span> Buzón Sugerencias & Auditoría Docente 
                    <span id="admin-feedback-badge" style="background: #EF4444; color: white; border-radius: 10px; padding: 2px 8px; font-size: 0.75rem; font-weight: 900; display: none;">0</span>
                </button>`;

if (loginHtml.includes(targetAdminTabs)) {
    loginHtml = loginHtml.replace(targetAdminTabs, replacementAdminTabs);
    console.log('✅ Tabs de administrador actualizados con Buzón de Feedback.');
}

// 3. Inyectar vista del buzón de feedback en el contenedor del admin
const targetAdminEndContainer = `</div> <!-- fin dashboard-screen-container -->`;

const replacementAdminFeedbackView = `
            <!-- VISTA DE BUZÓN DE SUGERENCIAS Y AUDITORÍA DOCENTE (NUEVO) -->
            <div id="admin-view-feedback" class="admin-view" style="display: none; padding: 25px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <h3 style="margin: 0; font-size: 1.4rem; color: #0F172A; font-weight: 900; display: flex; align-items: center; gap: 10px;">
                            <span>📬</span> Buzón Central de Reportes y Sugerencias Docentes
                        </h3>
                        <p style="margin: 4px 0 0 0; color: #64748B; font-size: 0.9rem;">
                            Monitoreo diario de anomalías, propuestas de mejora pedagógica y dificultades reportadas por los profesores.
                        </p>
                    </div>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button onclick="window.enviarResumenDiarioWhatsApp()" style="background: #10B981; color: white; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 10px rgba(16,185,129,0.25);">
                            <span>📲</span> Enviar Resumen Diario a mi WhatsApp
                        </button>
                        <button onclick="window.exportarBuzonMarkdown()" style="background: #2563EB; color: white; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 10px rgba(37,99,235,0.25);">
                            <span>📥</span> Descargar Reporte (.md)
                        </button>
                    </div>
                </div>

                <!-- Métricas Rápidas -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
                    <div style="background: white; border: 1px solid #E2E8F0; padding: 15px; border-radius: 12px; border-left: 4px solid #3B82F6;">
                        <div style="font-size: 0.8rem; color: #64748B; font-weight: 700;">TOTAL REPORTES</div>
                        <div id="stat-fb-total" style="font-size: 1.8rem; font-weight: 900; color: #1E293B; margin-top: 4px;">0</div>
                    </div>
                    <div style="background: white; border: 1px solid #E2E8F0; padding: 15px; border-radius: 12px; border-left: 4px solid #EF4444;">
                        <div style="font-size: 0.8rem; color: #64748B; font-weight: 700;">ANOMALÍAS / ERRORES</div>
                        <div id="stat-fb-bugs" style="font-size: 1.8rem; font-weight: 900; color: #EF4444; margin-top: 4px;">0</div>
                    </div>
                    <div style="background: white; border: 1px solid #E2E8F0; padding: 15px; border-radius: 12px; border-left: 4px solid #10B981;">
                        <div style="font-size: 0.8rem; color: #64748B; font-weight: 700;">MEJORAS PEDAGÓGICAS</div>
                        <div id="stat-fb-ideas" style="font-size: 1.8rem; font-weight: 900; color: #10B981; margin-top: 4px;">0</div>
                    </div>
                    <div style="background: white; border: 1px solid #E2E8F0; padding: 15px; border-radius: 12px; border-left: 4px solid #F59E0B;">
                        <div style="font-size: 0.8rem; color: #64748B; font-weight: 700;">PENDIENTES DE APLICAR</div>
                        <div id="stat-fb-pending" style="font-size: 1.8rem; font-weight: 900; color: #F59E0B; margin-top: 4px;">0</div>
                    </div>
                </div>

                <!-- Tabla de Reportes -->
                <div style="background: white; border-radius: 14px; border: 1px solid #E2E8F0; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                    <div style="padding: 15px 20px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-weight: 800; color: #334155; font-size: 0.95rem;">Historial Detallado de Sugerencias y Auditoría</span>
                        <div style="display: flex; gap: 8px;">
                            <select id="filtro-fb-categoria" onchange="window.renderizarBuzonAdmin()" style="padding: 6px 12px; border-radius: 6px; border: 1px solid #CBD5E1; font-size: 0.85rem; font-weight: 600;">
                                <option value="todas">Todas las categorías</option>
                                <option value="bug">🐛 Errores / Bugs</option>
                                <option value="mejora">💡 Mejoras Pedagógicas</option>
                                <option value="dificultad">📚 Dificultades con Malla/Guía</option>
                                <option value="emocional">❤️‍🩹 Auxilios Emocionales</option>
                                <option value="otro">📝 Otros Aportes</option>
                            </select>
                        </div>
                    </div>
                    <div id="admin-fb-table-container" style="overflow-x: auto; padding: 10px;">
                        <!-- Renderizado dinámico desde app.js -->
                    </div>
                </div>
            </div>
</div> <!-- fin dashboard-screen-container -->`;

if (loginHtml.includes(targetAdminEndContainer)) {
    loginHtml = loginHtml.replace(targetAdminEndContainer, replacementAdminFeedbackView);
    console.log('✅ Vista de Buzón de Administrador insertada.');
}

// 4. Inyectar Widget Flotante de PeidaBot y Modal del Chatbot
const targetBeforeScripts = `    <!-- MODAL: TÉRMINOS LEGALES, LICENCIA PILOTO Y REGISTRO DNDA -->`;

const chatbotWidgetsHtml = `
    <!-- BOTÓN FLOTANTE CHATBOT PEIDABOT -->
    <div id="btn-flotante-peidabot-soporte" onclick="window.toggleChatbotSoporte()" style="position: fixed; bottom: 25px; right: 25px; z-index: 99999; background: linear-gradient(135deg, #2563EB, #7C3AED); color: white; padding: 12px 20px; border-radius: 30px; font-weight: 800; font-size: 0.92rem; box-shadow: 0 8px 25px rgba(37,99,235,0.4); cursor: pointer; display: flex; align-items: center; gap: 10px; transition: transform 0.2s, box-shadow 0.2s; border: 2px solid rgba(255,255,255,0.25);" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'" title="Abrir asistente de soporte y reporte de sugerencias para docentes">
        <span style="font-size: 1.3rem;">🤖</span>
        <span>PeidaBot: Soporte & Sugerencias</span>
        <span style="background: #10B981; width: 10px; height: 10px; border-radius: 50%; display: inline-block; box-shadow: 0 0 6px #10B981;"></span>
    </div>

    <!-- MODAL CHATBOT FLOTANTE DE SOPORTE Y RETROALIMENTACIÓN DOCENTE -->
    <div id="modal-chatbot-soporte-docente" style="display: none; position: fixed; bottom: 85px; right: 25px; z-index: 100000; width: 390px; max-width: calc(100vw - 30px); height: 580px; max-height: calc(100vh - 100px); background: white; border-radius: 20px; box-shadow: 0 20px 45px rgba(0,0,0,0.25); border: 1px solid #E2E8F0; flex-direction: column; overflow: hidden; font-family: Inter, sans-serif;">
        
        <!-- Header Chatbot -->
        <div style="background: linear-gradient(135deg, #1E3A8A, #3B82F6); color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <div style="background: rgba(255,255,255,0.2); width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.3rem;">
                    🤖
                </div>
                <div>
                    <h4 style="margin: 0; font-size: 1rem; font-weight: 800;">PeidaBot • Asistente</h4>
                    <div style="font-size: 0.75rem; color: #DBEAFE; display: flex; align-items: center; gap: 4px;">
                        <span style="width: 7px; height: 7px; background: #34D399; border-radius: 50%; display: inline-block;"></span> En línea para mejorar la app
                    </div>
                </div>
            </div>
            <button onclick="window.cerrarChatbotSoporte()" style="background: rgba(255,255,255,0.15); border: none; color: white; width: 30px; height: 30px; border-radius: 50%; cursor: pointer; font-size: 1rem; font-weight: bold;">✕</button>
        </div>

        <!-- Cuerpo de Conversación / Formulario -->
        <div id="peidabot-chat-body" style="flex: 1; padding: 18px; overflow-y: auto; display: flex; flex-direction: column; gap: 14px; background: #F8FAFC;">
            
            <!-- Mensaje de Bienvenida -->
            <div style="display: flex; gap: 8px; align-items: flex-start;">
                <span style="font-size: 1.3rem;">🤖</span>
                <div style="background: white; border: 1px solid #E2E8F0; padding: 12px 14px; border-radius: 0 14px 14px 14px; font-size: 0.86rem; color: #1E293B; line-height: 1.4; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
                    ¡Hola! Soy <strong>PeidaBot</strong>. Mi misión es recolectar tus comentarios para que el administrador <strong>Juan Felipe</strong> optimice la plataforma diariamente. ¿Qué deseas compartir hoy?
                </div>
            </div>

            <!-- Chips de Categorías Rápidas -->
            <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                <button type="button" class="peidabot-chip" onclick="window.seleccionarCategoriaChatbot('bug')" style="background: white; border: 1px solid #FCA5A5; color: #B91C1C; padding: 6px 10px; border-radius: 20px; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                    <span>🐛</span> Reportar Error
                </button>
                <button type="button" class="peidabot-chip" onclick="window.seleccionarCategoriaChatbot('mejora')" style="background: white; border: 1px solid #86EFAC; color: #15803D; padding: 6px 10px; border-radius: 20px; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                    <span>💡</span> Sugerir Mejora
                </button>
                <button type="button" class="peidabot-chip" onclick="window.seleccionarCategoriaChatbot('dificultad')" style="background: white; border: 1px solid #93C5FD; color: #1D4ED8; padding: 6px 10px; border-radius: 20px; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                    <span>📚</span> Dificultad Guías
                </button>
                <button type="button" class="peidabot-chip" onclick="window.seleccionarCategoriaChatbot('emocional')" style="background: white; border: 1px solid #FDE68A; color: #B45309; padding: 6px 10px; border-radius: 20px; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                    <span>❤️‍🩹</span> Auxilios Emocionales
                </button>
            </div>

            <!-- Formulario de Reporte -->
            <div id="peidabot-form-container" style="background: white; border: 1.5px solid #DBEAFE; border-radius: 12px; padding: 14px; display: flex; flex-direction: column; gap: 10px;">
                <div>
                    <label style="font-size: 0.78rem; font-weight: 800; color: #1E3A8A; display: block; margin-bottom: 3px;">Categoría seleccionada:</label>
                    <select id="peidabot-categoria-select" style="width: 100%; padding: 8px 10px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.82rem; font-weight: 600; background: #F8FAFC;">
                        <option value="bug">🐛 Anomalía / Error Técnico</option>
                        <option value="mejora">💡 Sugerencia de Mejora Pedagógica</option>
                        <option value="dificultad">📚 Dificultad con Guías o Mallas</option>
                        <option value="emocional">❤️‍🩹 Feedback Primeros Auxilios Emocionales</option>
                        <option value="otro">📝 Otra Consulta / Petición General</option>
                    </select>
                </div>

                <div>
                    <label style="font-size: 0.78rem; font-weight: 800; color: #1E3A8A; display: block; margin-bottom: 3px;">Detalle del reporte o sugerencia:</label>
                    <textarea id="peidabot-mensaje-input" rows="4" placeholder="Describe qué sucedió, qué te gustaría añadir o qué tema/materia necesita ajuste..." style="width: 100%; padding: 8px 10px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.82rem; box-sizing: border-box; font-family: Inter, sans-serif; resize: vertical;"></textarea>
                </div>

                <div>
                    <label style="font-size: 0.75rem; font-weight: 700; color: #64748B; display: block; margin-bottom: 2px;">Tu Nombre / Institución (Opcional):</label>
                    <input type="text" id="peidabot-docente-input" placeholder="Ej: Prof. Camilo - IE Montenegro" style="width: 100%; padding: 7px 10px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.8rem; box-sizing: border-box;">
                </div>

                <div style="display: flex; gap: 8px; margin-top: 4px;">
                    <button type="button" onclick="window.enviarReporteFeedback('plataforma')" style="flex: 1; background: #2563EB; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 3px 8px rgba(37,99,235,0.25);">
                        <span>💾</span> Guardar en Buzón
                    </button>
                    <button type="button" onclick="window.enviarReporteFeedback('whatsapp')" style="flex: 1; background: #10B981; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 0.82rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 3px 8px rgba(16,185,129,0.25);">
                        <span>📲</span> Enviar por WhatsApp
                    </button>
                </div>
            </div>

            <div id="peidabot-confirmacion-msg" style="display: none; background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 12px; padding: 14px; color: #065F46; font-size: 0.84rem; line-height: 1.4;">
                🎉 <strong>¡Reporte recibido con éxito!</strong><br>
                Tu sugerencia ha quedado archivada en la consola del administrador para la ronda de mejoras continuas.
            </div>

        </div>
    </div>
`;

if (loginHtml.includes(targetBeforeScripts)) {
    loginHtml = loginHtml.replace(targetBeforeScripts, chatbotWidgetsHtml + '\n' + targetBeforeScripts);
    console.log('✅ Botón flotante y Modal de PeidaBot inyectados en login.html.');
}

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 5. INYECTAR LÓGICA DE PEIDABOT Y BUZÓN EN APP.JS
// =========================================================
const modulosChatbotFeedbackJs = `
// =========================================================
// MÓDULO PEIDABOT: CHATBOT DE SOPORTE Y RETROALIMENTACIÓN DOCENTE
// =========================================================

window.toggleChatbotSoporte = function() {
    const modal = document.getElementById("modal-chatbot-soporte-docente");
    if (!modal) return;
    if (modal.style.display === "none" || !modal.style.display) {
        window.abrirChatbotSoporte();
    } else {
        window.cerrarChatbotSoporte();
    }
};

window.abrirChatbotSoporte = function(categoriaDefecto) {
    const modal = document.getElementById("modal-chatbot-soporte-docente");
    if (!modal) return;
    modal.style.display = "flex";

    if (categoriaDefecto) {
        window.seleccionarCategoriaChatbot(categoriaDefecto);
    }

    // Auto-identificar docente logueado
    try {
        const ses = JSON.parse(sessionStorage.getItem('peidagogos_auth') || localStorage.getItem('usuario_actual') || '{}');
        const inDoc = document.getElementById("peidabot-docente-input");
        if (inDoc && !inDoc.value.trim() && (ses.nombre || ses.nombre_completo)) {
            const nom = ses.nombre || ses.nombre_completo;
            const ie = ses.institucion || 'IE Instituto Montenegro';
            inDoc.value = \`Prof. \${nom} (\${ie})\`;
        }
    } catch(e) {}
};

window.cerrarChatbotSoporte = function() {
    const modal = document.getElementById("modal-chatbot-soporte-docente");
    if (modal) modal.style.display = "none";
};

window.seleccionarCategoriaChatbot = function(cat) {
    const sel = document.getElementById("peidabot-categoria-select");
    if (sel) {
        sel.value = cat;
        sel.style.borderColor = "#2563EB";
        setTimeout(() => { sel.style.borderColor = "#CBD5E1"; }, 1000);
    }
    const txtArea = document.getElementById("peidabot-mensaje-input");
    if (txtArea) txtArea.focus();
};

window.obtenerBuzonFeedback = function() {
    try {
        return JSON.parse(localStorage.getItem('buzon_docente_db') || '[]');
    } catch(e) {
        return [];
    }
};

window.guardarItemBuzonFeedback = function(item) {
    let list = window.obtenerBuzonFeedback();
    list.unshift(item);
    localStorage.setItem('buzon_docente_db', JSON.stringify(list));
    window.actualizarBadgeFeedbackAdmin();
    return item;
};

window.enviarReporteFeedback = function(metodo) {
    const inCat = document.getElementById("peidabot-categoria-select");
    const inTxt = document.getElementById("peidabot-mensaje-input");
    const inDoc = document.getElementById("peidabot-docente-input");

    if (!inTxt || !inTxt.value.trim()) {
        alert("Por favor describe el reporte o la sugerencia para poder procesarla.");
        if (inTxt) inTxt.focus();
        return;
    }

    const catVal = inCat ? inCat.value : "mejora";
    const catLabels = {
        bug: "🐛 Anomalía / Error Técnico",
        mejora: "💡 Sugerencia Pedagógica / Interfaz",
        dificultad: "📚 Dificultad con Guías o Mallas",
        emocional: "❤️‍🩹 Auxilios Emocionales",
        otro: "📝 Consulta General"
    };

    const nuevoItem = {
        id: 'FB-' + Date.now().toString(36).toUpperCase(),
        categoria: catVal,
        categoriaTexto: catLabels[catVal] || catVal,
        mensaje: inTxt.value.trim(),
        docente: (inDoc && inDoc.value.trim()) ? inDoc.value.trim() : "Docente Anónimo / Usuario",
        fecha: new Date().toLocaleString('es-CO'),
        fechaIso: new Date().toISOString(),
        estado: 'Pendiente' // 'Pendiente' | 'En Revisión' | 'Resuelto'
    };

    window.guardarItemBuzonFeedback(nuevoItem);

    if (metodo === 'whatsapp') {
        const textoWa = encodeURIComponent(\`*REPORTE PEIDAGOGOS STEAM (\${nuevoItem.id})*\\n\\n*Tipo:* \${nuevoItem.categoriaTexto}\\n*Emisor:* \${nuevoItem.docente}\\n*Fecha:* \${nuevoItem.fecha}\\n\\n*Detalle:*\\n\${nuevoItem.mensaje}\\n\\n_Enviado desde el Asistente PeidaBot_\`);
        window.open(\`https://wa.me/?text=\${textoWa}\`, '_blank');
    }

    // Mostrar feedback en el chatbot
    const confirmBox = document.getElementById("peidabot-confirmacion-msg");
    const formBox = document.getElementById("peidabot-form-container");
    if (confirmBox && formBox) {
        confirmBox.style.display = "block";
        formBox.style.display = "none";
        setTimeout(() => {
            confirmBox.style.display = "none";
            formBox.style.display = "flex";
            if (inTxt) inTxt.value = "";
            window.cerrarChatbotSoporte();
        }, 3000);
    }
};

window.actualizarBadgeFeedbackAdmin = function() {
    const badge = document.getElementById("admin-feedback-badge");
    if (!badge) return;
    const buzon = window.obtenerBuzonFeedback();
    const pendientes = buzon.filter(b => b.estado === 'Pendiente').length;
    if (pendientes > 0) {
        badge.innerText = pendientes;
        badge.style.display = "inline-block";
    } else {
        badge.style.display = "none";
    }
};

window.renderizarBuzonAdmin = function() {
    const cont = document.getElementById("admin-fb-table-container");
    if (!cont) return;

    const buzon = window.obtenerBuzonFeedback();
    const filtroCat = document.getElementById("filtro-fb-categoria") ? document.getElementById("filtro-fb-categoria").value : "todas";

    // Actualizar métricas
    const stTotal = document.getElementById("stat-fb-total");
    const stBugs = document.getElementById("stat-fb-bugs");
    const stIdeas = document.getElementById("stat-fb-ideas");
    const stPending = document.getElementById("stat-fb-pending");

    if (stTotal) stTotal.innerText = buzon.length;
    if (stBugs) stBugs.innerText = buzon.filter(b => b.categoria === 'bug').length;
    if (stIdeas) stIdeas.innerText = buzon.filter(b => b.categoria === 'mejora').length;
    if (stPending) stPending.innerText = buzon.filter(b => b.estado === 'Pendiente').length;

    let itemsFiltrados = buzon;
    if (filtroCat !== 'todas') {
        itemsFiltrados = buzon.filter(b => b.categoria === filtroCat);
    }

    if (itemsFiltrados.length === 0) {
        cont.innerHTML = \`
            <div style="text-align: center; padding: 40px 20px; color: #64748B;">
                <span style="font-size: 2.5rem;">📭</span>
                <h4 style="margin: 10px 0 4px 0; color: #334155;">No hay reportes ni sugerencias en esta categoría</h4>
                <p style="font-size: 0.85rem; margin: 0;">Los aportes enviados por los docentes a través de PeidaBot aparecerán aquí.</p>
            </div>
        \`;
        return;
    }

    let html = \`
        <table style="width: 100%; border-collapse: collapse; font-size: 0.86rem; text-align: left;">
            <thead>
                <tr style="background: #F1F5F9; color: #475569; border-bottom: 2px solid #CBD5E1;">
                    <th style="padding: 12px;">ID / Fecha</th>
                    <th style="padding: 12px;">Categoría</th>
                    <th style="padding: 12px;">Docente / Emisor</th>
                    <th style="padding: 12px; width: 40%;">Mensaje / Sugerencia</th>
                    <th style="padding: 12px;">Estado</th>
                    <th style="padding: 12px; text-align: center;">Acciones</th>
                </tr>
            </thead>
            <tbody>
    \`;

    itemsFiltrados.forEach(item => {
        const bgEstado = item.estado === 'Resuelto' ? '#DCFCE7' : (item.estado === 'En Revisión' ? '#FEF3C7' : '#FEE2E2');
        const colEstado = item.estado === 'Resuelto' ? '#15803D' : (item.estado === 'En Revisión' ? '#B45309' : '#B91C1C');

        html += \`
            <tr style="border-bottom: 1px solid #E2E8F0;">
                <td style="padding: 12px; font-weight: 700; color: #1E293B;">
                    <div>\${item.id}</div>
                    <div style="font-size: 0.75rem; color: #64748B; font-weight: 400;">\${item.fecha}</div>
                </td>
                <td style="padding: 12px;">
                    <span style="font-weight: 700; font-size: 0.8rem; color: #1E3A8A;">\${item.categoriaTexto}</span>
                </td>
                <td style="padding: 12px; color: #334155; font-weight: 600;">\${item.docente}</td>
                <td style="padding: 12px; color: #1E293B; line-height: 1.4;">\${item.mensaje}</td>
                <td style="padding: 12px;">
                    <span style="background: \${bgEstado}; color: \${colEstado}; padding: 3px 8px; border-radius: 6px; font-weight: 800; font-size: 0.75rem;">
                        \${item.estado}
                    </span>
                </td>
                <td style="padding: 12px; text-align: center;">
                    <div style="display: flex; gap: 6px; justify-content: center;">
                        <button onclick="window.cambiarEstadoFeedback('\${item.id}', 'Resuelto')" style="background: #10B981; color: white; border: none; padding: 5px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer;" title="Marcar como resuelto / aplicado">
                            ✓ Resuelto
                        </button>
                        <button onclick="window.cambiarEstadoFeedback('\${item.id}', 'En Revisión')" style="background: #F59E0B; color: white; border: none; padding: 5px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer;" title="Marcar en revisión">
                            ⏳ En Curso
                        </button>
                    </div>
                </td>
            </tr>
        \`;
    });

    html += \`</tbody></table>\`;
    cont.innerHTML = html;
};

window.cambiarEstadoFeedback = function(id, nuevoEstado) {
    let list = window.obtenerBuzonFeedback();
    const idx = list.findIndex(b => b.id === id);
    if (idx !== -1) {
        list[idx].estado = nuevoEstado;
        localStorage.setItem('buzon_docente_db', JSON.stringify(list));
        window.renderizarBuzonAdmin();
        window.actualizarBadgeFeedbackAdmin();
    }
};

window.enviarResumenDiarioWhatsApp = function() {
    const buzon = window.obtenerBuzonFeedback();
    if (buzon.length === 0) {
        alert("No hay reportes registrados para generar el resumen.");
        return;
    }

    const hoyStr = new Date().toLocaleDateString('es-CO');
    let msg = \`*RESUMEN DIARIO DE AUDITORÍA Y FEEDBACK DOCENTE (\${hoyStr})*\\n*Peidagogos STEAM*\\n\\n\`;

    buzon.forEach((b, i) => {
        msg += \`*\${i+1}. [\${b.categoriaTexto}] - \${b.docente}*\` +
               \`\\nEstado: \${b.estado}\` +
               \`\\nDetalle: \${b.mensaje}\\n\\n\`;
    });

    window.open(\`https://wa.me/?text=\${encodeURIComponent(msg)}\`, '_blank');
};

window.exportarBuzonMarkdown = function() {
    const buzon = window.obtenerBuzonFeedback();
    const hoyStr = new Date().toLocaleDateString('es-CO');
    let md = \`# Reporte Diario de Auditoría y Sugerencias Docentes\\n**Plataforma:** Peidagogos STEAM (DNDA Radicado 1-2026-000055)\\n**Fecha:** \${hoyStr}\\n\\n---\\n\\n\`;

    buzon.forEach((b, i) => {
        md += \`### \${i+1}. \${b.id} - \${b.categoriaTexto}\\n- **Emisor:** \${b.docente}\\n- **Fecha:** \${b.fecha}\\n- **Estado:** \${b.estado}\\n- **Detalle:** \${b.mensaje}\\n\\n\`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = \`Reporte_Feedback_Docente_\${Date.now()}.md\`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};
`;

// Insertar modulosChatbotFeedbackJs en app.js
appJs += '\n' + modulosChatbotFeedbackJs;

// Actualizar cambiarTabAdmin en app.js para soportar el tab de feedback
const targetCambiarTab = `window.cambiarTabAdmin = function(tabName) {`;
const targetCambiarTabBody = `window.cambiarTabAdmin = function(tabName) {
    document.querySelectorAll('.admin-tab-btn').forEach(btn => {
        if (btn.getAttribute('data-tab') === tabName) {
            btn.classList.add('active');
            btn.style.background = 'white';
            btn.style.borderBottom = '3px solid #3B82F6';
            btn.style.color = '#111827';
        } else {
            btn.classList.remove('active');
            btn.style.background = 'transparent';
            btn.style.borderBottom = 'none';
            btn.style.color = '#6B7280';
        }
    });

    const viewGrupos = document.getElementById('admin-view-grupos');
    const viewDocentes = document.getElementById('admin-view-docentes');
    const viewFeedback = document.getElementById('admin-view-feedback');

    if (viewGrupos) viewGrupos.style.display = tabName === 'grupos' ? 'block' : 'none';
    if (viewDocentes) viewDocentes.style.display = tabName === 'docentes' ? 'block' : 'none';
    if (viewFeedback) {
        viewFeedback.style.display = tabName === 'feedback' ? 'block' : 'none';
        if (tabName === 'feedback') window.renderizarBuzonAdmin();
    }
};`;

if (appJs.includes(targetCambiarTab)) {
    // Reemplazar la función existente
    const idxStart = appJs.indexOf(`window.cambiarTabAdmin = function(tabName) {`);
    const idxEnd = appJs.indexOf(`};`, idxStart) + 2;
    appJs = appJs.substring(0, idxStart) + targetCambiarTabBody + appJs.substring(idxEnd);
    console.log('✅ cambiarTabAdmin actualizado con soporte para tab de feedback.');
} else {
    appJs += '\n' + targetCambiarTabBody;
    console.log('✅ cambiarTabAdmin creado.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis completa con VM
try {
    new vm.Script(appJs);
    console.log('✨ Validación de sintaxis VM en app.js: CORRECTO (0 errores).');
} catch(err) {
    console.error('❌ Error de sintaxis en app.js:', err);
}
