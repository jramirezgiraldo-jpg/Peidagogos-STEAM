try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $wc = New-Object System.Net.WebClient
    $html = $wc.DownloadString("https://peidagogosteam.com/login.html")
    Write-Host "Length of live HTML: $($html.Length)"
    
    if ($html.Contains("v20260806_v17")) {
        Write-Host "✅ LIVE HTML has v17 version!"
    } elseif ($html.Contains("v20260806_v16")) {
        Write-Host "⚠️ LIVE HTML has v16 version (building...)"
    } else {
        Write-Host "❌ LIVE HTML has older version!"
    }
} catch {
    Write-Host "Error: $_"
}
