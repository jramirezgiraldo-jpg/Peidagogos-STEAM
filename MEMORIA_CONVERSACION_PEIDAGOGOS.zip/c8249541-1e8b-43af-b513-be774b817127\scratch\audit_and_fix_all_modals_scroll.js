const fs = require('fs');
const path = require('path');

const loginPath = 'd:/Peidagogos_Local/login.html';
const stylesPath = 'd:/Peidagogos_Local/css/styles.css';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let stylesCss = fs.existsSync(stylesPath) ? fs.readFileSync(stylesPath, 'utf8') : '';

console.log('=== AUDITORÍA COMPLETA DE SCROLL EN TODOS LOS MODALES Y PANTALLAS ===');

// 1. Auditar modales en login.html
const modalRegex = /<div\s+[^>]*id=["'](modal-[^"']+)["'][^>]*>/gi;
let match;
const modalesEncontrados = [];

while ((match = modalRegex.exec(loginHtml)) !== null) {
    modalesEncontrados.push(match[1]);
}

console.log(`Se encontraron ${modalesEncontrados.length} modales en login.html:`, modalesEncontrados);

// 2. Corregir modal-caja-herramientas específicamente
// En modal-caja-herramientas:
// El contenedor exterior debe tener overflow-y: auto y el contenedor interior flex con overflow-y: auto
const targetCajaHerramientas = `<div id="modal-caja-herramientas" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.88); backdrop-filter: blur(10px); align-items: center; justify-content: center; z-index: 100000; padding: 20px;">
        <div style="background: #F8FAFC; border-radius: 24px; padding: 26px 30px; max-width: 1200px; width: 100%; max-height: 92vh; display: flex; flex-direction: column; box-shadow: 0 25px 70px -15px rgba(0,0,0,0.5); text-align: left; overflow: hidden; border: 1px solid #CBD5E1;">`;

const replacementCajaHerramientas = `<div id="modal-caja-herramientas" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.88); backdrop-filter: blur(10px); align-items: center; justify-content: center; z-index: 100000; padding: 20px; overflow-y: auto;">
        <div style="background: #F8FAFC; border-radius: 24px; padding: 26px 30px; max-width: 1200px; width: 100%; max-height: 92vh; display: flex; flex-direction: column; box-shadow: 0 25px 70px -15px rgba(0,0,0,0.5); text-align: left; overflow-y: auto; -webkit-overflow-scrolling: touch; border: 1px solid #CBD5E1;">`;

if (loginHtml.includes(targetCajaHerramientas)) {
    loginHtml = loginHtml.replace(targetCajaHerramientas, replacementCajaHerramientas);
    console.log('✅ Corregido scroll en modal-caja-herramientas (overlay + inner container con overflow-y: auto).');
} else {
    console.log('Buscando modal-caja-herramientas con regex...');
    loginHtml = loginHtml.replace(/<div\s+id=["']modal-caja-herramientas["'][^>]*style=["']([^"']*)["']>/gi, (m, style) => {
        let newStyle = style;
        if (!newStyle.includes('overflow-y: auto')) {
            newStyle += '; overflow-y: auto !important;';
        }
        return `<div id="modal-caja-herramientas" style="${newStyle}">`;
    });
}

// 3. Revisar y asegurar scroll en todos los modales de login.html
modalesEncontrados.forEach(mId => {
    // Buscar el div del modal y su primer hijo
    const regModalBlock = new RegExp(`(<div\\s+[^>]*id=["']${mId}["'][^>]*style=["'])([^"']*)(["'][^>]*>\\s*<div\\s+[^>]*style=["'])([^"']*)(["'])`, 'gi');
    loginHtml = loginHtml.replace(regModalBlock, (full, p1, overlayStyle, p3, innerStyle, p5) => {
        let newOverlay = overlayStyle;
        let newInner = innerStyle;

        if (!newOverlay.includes('overflow-y')) {
            newOverlay += '; overflow-y: auto; -webkit-overflow-scrolling: touch;';
        }
        if (!newInner.includes('overflow-y') && !newInner.includes('overflow: auto')) {
            newInner = newInner.replace(/overflow:\s*hidden;?/gi, '');
            newInner += '; overflow-y: auto !important; max-height: 90vh; -webkit-overflow-scrolling: touch;';
        } else if (newInner.includes('overflow: hidden')) {
            newInner = newInner.replace(/overflow:\s*hidden;?/gi, 'overflow-y: auto !important; max-height: 90vh;');
        }

        return `${p1}${newOverlay}${p3}${newInner}${p5}`;
    });
});

// 4. Asegurar que todas las vistas principales tengan scroll vertical libre:
// #login-screen-container, #register-screen-container, #student-screen-container,
// #docente-dashboard-container, #tutor-dashboard-container, #dashboard-screen-container, #screen-plan-estudio
const vistasPrincipales = [
    'login-screen-container',
    'register-screen-container',
    'student-screen-container',
    'docente-dashboard-container',
    'tutor-dashboard-container',
    'dashboard-screen-container',
    'screen-plan-estudio',
    'screen-laboratorio',
    'screen-evaluacion',
    'screen-simulador'
];

vistasPrincipales.forEach(vId => {
    const regVista = new RegExp(`(<div\\s+[^>]*id=["']${vId}["'][^>]*style=["'])([^"']*)(["'])`, 'gi');
    loginHtml = loginHtml.replace(regVista, (full, p1, style, p3) => {
        let newStyle = style;
        if (newStyle.includes('overflow: hidden')) {
            newStyle = newStyle.replace(/overflow:\s*hidden;?/gi, 'overflow-y: auto !important;');
        }
        if (!newStyle.includes('overflow-y')) {
            newStyle += '; overflow-y: auto !important; min-height: 100vh;';
        }
        return `${p1}${newStyle}${p3}`;
    });
});

// 5. Inyectar regla CSS global para garantizar scroll en cualquier modal presente y futuro
const globalScrollCss = `
<style id="global-fix-scroll-modals">
    /* Garantizar que el body y html permitan scroll */
    html, body {
        overflow-x: hidden !important;
        overflow-y: auto !important;
        height: auto !important;
        min-height: 100vh !important;
        -webkit-overflow-scrolling: touch !important;
    }

    /* Todos los modales fijos con scroll garantizado */
    div[id^="modal-"], .modal-overlay, [id*="-modal"] {
        overflow-y: auto !important;
        -webkit-overflow-scrolling: touch !important;
        box-sizing: border-box !important;
    }

    /* El contenido interior de los modales nunca queda atrapado sin scroll */
    div[id^="modal-"] > div, .modal-card, .modal-content {
        max-height: 92vh !important;
        overflow-y: auto !important;
        -webkit-overflow-scrolling: touch !important;
        box-sizing: border-box !important;
    }

    /* Vistas de pantallas completas con scroll fluido */
    [id$="-screen-container"], [id$="-dashboard-container"], [id^="screen-"] {
        overflow-y: auto !important;
        -webkit-overflow-scrolling: touch !important;
        height: auto !important;
        min-height: 100vh !important;
    }
</style>
`;

if (!loginHtml.includes('global-fix-scroll-modals')) {
    loginHtml = loginHtml.replace('</head>', globalScrollCss + '\n</head>');
    console.log('✅ Inyectado bloque de estilos global-fix-scroll-modals en <head>.');
}

// 6. Actualizar versión de scripts para romper caché
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260819_v61');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260819_v61');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260819_v61');

fs.writeFileSync(loginPath, loginHtml, 'utf8');
console.log('✅ login.html actualizado y blindado contra problemas de scroll.');
