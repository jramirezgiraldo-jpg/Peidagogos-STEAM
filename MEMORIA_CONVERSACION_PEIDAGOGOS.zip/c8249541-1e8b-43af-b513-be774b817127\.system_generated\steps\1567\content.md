Title: Live Content

Description: Fetched live

Source: https://peidagogosteam.com/login.html

---

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="copyright" content="© 2026 Peidagogos STEAM. Todos los derechos reservados.">
    <meta name="author" content="Peidagogos STEAM - Educación y Tecnología">
    <meta name="robots" content="noarchive, noimageindex">
    <meta name="rights" content="Propiedad Intelectual y Derechos Reservados de Peidagogos STEAM">
    <title>Peidagogos STEAM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        window.MathJax = {
          tex: {
            inlineMath: [['$', '$'], ['\\(', '\\)']],
            displayMath: [['$$', '$$'], ['\\[', '\\]']]
          }
        };
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
    <style>
        .markdown-body {
            font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
            font-size: 16px;
            line-height: 1.5;
            word-wrap: break-word;
            color: #24292f;
        }
        .markdown-body h1, .markdown-body h2, .markdown-body h3 {
            border-bottom: 1px solid #hsla(210,18%,87%,1);
            padding-bottom: .3em;
            margin-top: 24px;
            margin-bottom: 16px;
            font-weight: 600;
            line-height: 1.25;
            color: #111827;
        }
        .markdown-body ul {
            padding-left: 2em;
            margin-top: 0;
            margin-bottom: 16px;
            list-style-type: disc;
        }
        .markdown-body p {
            margin-top: 0;
            margin-bottom: 16px;
        }
        .markdown-body strong {
            font-weight: 600;
            color: #1E3A8A;
        }

        /* Responsive Mobile Fixes */
        @media (max-width: 768px) {
            #login-screen-container {
                grid-template-columns: 1fr !important;
                min-height: 100vh;
                height: auto !important;
                overflow-y: auto !important;
            }
            #login-screen-container > div {
                padding: 30px 20px !important;
                border-left: none !important;
                border-bottom: 1px solid #e5e7eb;
            }
            #register-screen-container {
                height: auto !important;
                min-height: 100vh !important;
                padding: 20px 12px !important;
            }
            #register-screen-container > div {
                padding: 25px 18px !important;
            }
            
            /* Asegurar que ninguna vista oculta se muestre con display !important en mobile */
            #login-screen-container[style*="display: none"],
            #register-screen-container[style*="display: none"],
            #docente-dashboard-container[style*="display: none"],
            #dashboard-screen-container[style*="display: none"],
            #student-dashboard-container[style*="display: none"],
            #tutor-dashboard-container[style*="display: none"] {
                display: none !important;
            }
            
            /* Docente Dashboard */
            #docente-dashboard-container > div:nth-child(2) {
                grid-template-columns: 1fr !important;
                padding: 15px !important;
            }
            #docente-dashboard-container header {
                flex-direction: column !important;
                gap: 10px;
                padding: 15px !important;
            }
            
            /* Admin Dashboard */
            #dashboard-screen-container header {
                flex-direction: column !important;
                gap: 10px;
                padding: 15px !important;
            }
            #dashboard-screen-container .admin-tab-btn {
                flex: 1 1 100%;
            }
            #student-main-content > div > div:first-child {
                flex-direction: column !important;
                text-align: center;
            }
            
            /* Student Dashboard */
            #student-dashboard-container header {
                flex-direction: column !important;
                gap: 10px;
                padding: 15px !important;
            }
            #student-dashboard-container > div:nth-child(2) {
                flex-direction: column !important;
                text-align: center;
            }
            
            /* Tables */
            table {
                display: block !important;
                overflow-x: auto !important;
                white-space: nowrap !important;
                -webkit-overflow-scrolling: touch;
            }
            
            /* Quest / Misiones container in Student */
            #student-quest-container > div:nth-child(3) {
                grid-template-columns: 1fr !important;
            }
        }

        /* Estilos Menú Colgante Sanciones y Notificaciones */
        .item-sancion-btn:hover {
            background-color: #FEE2E2 !important;
            color: #991B1B !important;
        }
        @keyframes popInAlert {
            0% { transform: scale(0.85); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        @keyframes slideDownToast {
            0% { transform: translate(-50%, -40px); opacity: 0; }
            100% { transform: translate(-50%, 0); opacity: 1; }
        }
    </style>

</head>
<body>
    <div id="app-container">
        <!-- 1. LANDING & AUTH (SPLIT GRID 100vh) -->
        <div id="login-screen-container" style="display: grid; grid-template-columns: 1fr 1fr; min-height: 100vh; overflow-y: auto; background-color: #f8f9fa;">
    <div style="padding: 5% 10%; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
        <img src="logo-peidagogos.png" alt="Logo Peidagogos STEAM" style="max-width: 200px; height: auto; object-fit: contain; margin-bottom: 20px;">
        <h2 style="font-size: 2.2rem; font-weight: 800; color: #111827; margin: 0; line-height: 1.2;">Arquitectura del Aprendizaje</h2>
        <p style="font-size: 1rem; color: #6B7280; margin: 10px 0 30px 0;">Plataforma dise&ntilde;ada para la era digital.</p>
    </div>
    <div style="padding: 5% 15%; display: flex; flex-direction: column; justify-content: center; background-color: #ffffff; border-left: 1px solid #e5e7eb;">
        <h2 style="font-size: 2rem; font-weight: 800; color: #111827; margin: 0;">Portal de Acceso</h2>
        <p style="font-size: 1rem; color: #6B7280; margin: 10px 0 25px 0;">Selecciona tu vía de ingreso a la plataforma.</p>
        
        <form id="login-form" onsubmit="return false;" style="display: flex; flex-direction: column; gap: 15px; margin-bottom: 20px;">
            <div style="display: flex; flex-direction: column; gap: 5px; text-align: left;">
                <label for="login-role" style="font-weight: 800; color: #111827; font-size: 0.95rem;">Selecciona tu perfil de ingreso:</label>
                <select id="login-role" style="padding: 12px; border: 2px solid #3B82F6; border-radius: 8px; font-weight: bold; color: #111827; cursor: pointer; background-color: #F0F9FF;">
                    <option value="estudiante">👨‍🎓 Soy Estudiante</option>
                    <option value="homeschool_tutor">🏡 Soy Tutor Home School</option>
                    <option value="validacion">🎓 Soy Estudiante de Validación</option>
                    <option value="docente">👨‍🏫 Soy Docente de Colegio</option>
                    <option value="admin">⚙️ Soy Administrador</option>
                </select>
            </div>
            <input type="text" id="admin-user" placeholder="Número de Identificación" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
            <input type="password" id="admin-pass" placeholder="Contraseña" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
            <button type="submit" id="btn-login-core" style="background-color: #2563EB; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 6px rgba(37,99,235,0.25); transition: 0.2s;">Iniciar Sesión</button>
            <div id="login-error-msg" style="color: #e74c3c; font-size: 0.85rem; display: none;">Credenciales incorrectas.</div>
        </form>

        <!-- Botones de acceso directo rápido -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px;">
            <button type="button" onclick="accesoRapidoRol('homeschool_tutor')" style="background: #EFF6FF; border: 1px solid #93C5FD; color: #1D4ED8; padding: 10px 12px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 0.85rem; display: flex; align-items: center; justify-content: center; gap: 6px; transition: 0.2s;" onmouseover="this.style.background='#DBEAFE'" onmouseout="this.style.background='#EFF6FF'">
                🏡 Tutor Home School
            </button>
            <button type="button" onclick="accesoRapidoRol('validacion')" style="background: #FEF3C7; border: 1px solid #FCD34D; color: #92400E; padding: 10px 12px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 0.85rem; display: flex; align-items: center; justify-content: center; gap: 6px; transition: 0.2s;" onmouseover="this.style.background='#FDE68A'" onmouseout="this.style.background='#FEF3C7'">
                🎓 Validación
            </button>
        </div>

        <button id="btn-show-register" onclick="mostrarVista('register-screen-container')" style="background: #F3F4F6; color: #374151; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: center;">➕ Registrar Nuevo Estudiante / Matrícula</button>
    </div>
</div>

<div id="register-screen-container" style="display: none; min-height: 100vh; background-color: #f3f4f6; justify-content: center; align-items: flex-start; padding: 30px 15px; overflow-y: auto; box-sizing: border-box;">
    <div style="background: white; padding: 35px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); width: 100%; max-width: 520px; display: flex; flex-direction: column; gap: 15px; margin: auto;">
        <div style="text-align: center; margin-bottom: 5px;">
            <h2 style="font-size: 1.8rem; font-weight: 800; color: #111827; margin: 0;">Matrícula y Registro</h2>
            <p style="color: #6B7280; font-size: 0.9rem; margin-top: 5px;">Colegio Regular • Home School • Validación</p>
        </div>
        <div style="display: flex; gap: 10px;">
            <select id="reg-tipo-doc" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; width: 30%;">
                <option value="TI">TI</option>
                <option value="RC">RC</option>
                <option value="CC">CC</option>
                <option value="CE">CE</option>
            </select>
            <input type="text" id="reg-documento" placeholder="Número de documento" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; flex: 1; margin: 0;">
        </div>
        <input type="text" id="reg-apellidos" placeholder="Apellidos" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
        <input type="text" id="reg-nombre" placeholder="Nombres" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <input type="number" id="reg-edad" placeholder="Edad" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
            <select id="reg-genero" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
                <option value="">Género...</option><option value="F">Femenino</option><option value="M">Masculino</option><option value="otro">Otro</option>
            </select>
        </div>
        <select id="reg-ie" onchange="toggleIEOptions()" style="padding: 12px; border: 2px solid #3B82F6; border-radius: 8px; font-weight: bold; background-color: #F8FAFC;" required>
            <option value="">Institución / Modalidad...</option>
            <option value="InstitutoMontenegro">🏫 IE Instituto Montenegro</option>
            <option value="HomeSchool">🏡 Tutor Home School (Educación en Casa)</option>
            <option value="Validacion">🎓 Validación Bachillerato (Ciclos)</option>
        </select>

        <div id="campo-codigo-institucional" style="display: none; flex-direction: column; gap: 6px; background: #EFF6FF; padding: 12px; border: 1.5px solid #93C5FD; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
                <label style="font-size: 0.85rem; font-weight: bold; color: #1E3A8A; display: flex; align-items: center; gap: 6px; margin: 0;">
                    <span>🔑</span> Código Institucional (IE Instituto Montenegro - $0 COP):
                </label>
                <button type="button" onclick="iniciarEscaneoQRRegistro()" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 5px 12px; border-radius: 6px; font-weight: bold; font-size: 0.8rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(37,99,235,0.3);">
                    <span>📷</span> Escanear QR Proyectado
                </button>
            </div>
            <div style="display: flex; gap: 8px;">
                <input type="password" id="reg-codigo-institucional" placeholder="Ingresa el código oficial (ieinstituto2026)" style="flex: 1; padding: 10px 12px; border: 1.5px solid #3B82F6; border-radius: 6px; font-weight: bold; background-color: white; outline: none; font-size: 0.95rem;">
                <button type="button" onclick="const p = document.getElementById('reg-codigo-institucional'); p.type = (p.type === 'password' ? 'text' : 'password');" style="background: #E2E8F0; border: 1px solid #CBD5E1; border-radius: 6px; padding: 0 12px; cursor: pointer; font-size: 0.9rem;" title="Mostrar/Ocultar">👁️</button>
            </div>
            <span id="qr-feedback-status" style="font-size: 0.8rem; color: #475569;">Escribe el código o escanea el QR proyectado por el docente en el VideoBeam del salón.</span>
        </div>
        
        <select id="reg-grado" onchange="actualizarMaterias()" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; display: none;">
            <option value="">Grado / Ciclo a cursar...</option>
            <option value="1">1° de Primaria</option>
            <option value="2">2° de Primaria</option>
            <option value="3">3° de Primaria</option>
            <option value="4">4° de Primaria</option>
            <option value="5">5° de Primaria</option>
            <option value="6">6° de Secundaria</option>
            <option value="7">7° de Secundaria</option>
            <option value="8">8° de Secundaria</option>
            <option value="9">9° de Secundaria</option>
            <option value="10">10° Media</option>
            <option value="11">11° Media</option>
            <option value="Ciclo I">Ciclo I (1°, 2°, 3°)</option>
            <option value="Ciclo II">Ciclo II (4°, 5°)</option>
            <option value="Ciclo III">Ciclo III (6°, 7°)</option>
            <option value="Ciclo IV">Ciclo IV (8°, 9°)</option>
            <option value="Ciclo V">Ciclo V (10°)</option>
            <option value="Ciclo VI">Ciclo VI (11°)</option>
        </select>
        
        <select id="registro-grupo" onchange="actualizarMaterias()" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; display: none;">
            <option value="">Grupo / Ciclo...</option>
            <option value="6A">6A</option><option value="6B">6B</option>
            <option value="7A">7A</option><option value="7B">7B</option><option value="7C">7C</option>
            <option value="8A">8A</option><option value="8B">8B</option>
            <option value="9A">9A</option>
            <option value="10A">10A</option><option value="10D">10D</option>
            <option value="PENS">PENS</option>
            <option value="Ciclo I">Ciclo I (1°, 2°, 3°)</option>
            <option value="Ciclo II">Ciclo II (4°, 5°)</option>
            <option value="Ciclo III">Ciclo III (6°, 7°)</option>
            <option value="Ciclo IV">Ciclo IV (8°, 9°)</option>
            <option value="Ciclo V">Ciclo V (10°)</option>
            <option value="Ciclo VI">Ciclo VI (11°)</option>
        </select>
        
        <input type="hidden" id="registro-asignatura">
        <div id="materias-asignadas-view" style="padding: 12px; background: #f9fafb; border: 1px solid #d1d5db; border-radius: 8px; color: #6B7280; font-style: italic; font-size: 0.95rem;">Selecciona modalidad y curso para ver asignaturas</div>
        
        <div id="info-pago-modalidad" style="display: none; padding: 12px; border-radius: 8px; font-size: 0.9rem; font-weight: 600;"></div>

        <script>
            function accesoRapidoRol(rol) {
                const select = document.getElementById('login-role');
                if (select) {
                    select.value = rol;
                    select.dispatchEvent(new Event('change'));
                }
                const userInput = document.getElementById('admin-user');
                if (userInput) userInput.focus();
            }

            function toggleIEOptions() {
                const ie = document.getElementById("reg-ie").value;
                const gradoSelect = document.getElementById("reg-grado");
                const grupoSelect = document.getElementById("registro-grupo");
                const campoCodigo = document.getElementById("campo-codigo-institucional");
                const infoPago = document.getElementById("info-pago-modalidad");
                const materiasView = document.getElementById("materias-asignadas-view");
                const btnSubmit = document.getElementById("btn-submit-register");
                
                if (ie === "HomeSchool") {
                    if (campoCodigo) campoCodigo.style.display = "none";
                    if (gradoSelect) { gradoSelect.style.display = "none"; gradoSelect.value = ""; }
                    if (grupoSelect) { grupoSelect.style.display = "none"; grupoSelect.value = ""; }
                    if (materiasView) materiasView.style.display = "none";
                    if (btnSubmit) btnSubmit.innerText = "Registrarme como Tutor Home School";
                    if (infoPago) {
                        infoPago.style.display = "block";
                        infoPago.style.background = "#EFF6FF";
                        infoPago.style.color = "#1D4ED8";
                        infoPago.style.border = "1px solid #93C5FD";
                        infoPago.innerHTML = "🏡 <strong>Registro de Tutor / Padre Home School (Gratis):</strong> Te registrarás como tutor para matricular a tus estudiantes ($85.000 COP base), personalizar materias y gestionar el aprendizaje en casa según estándares DBA del MEN.<br><span style='font-size:0.8rem; color:#475569; display:block; margin-top:4px;'>⚠️ <em>Aviso: Esta plataforma es una herramienta pedagógica en casa y no constituye matrícula SIMAT automática a menos que se solicite el módulo certificado ($15.000 COP/mes).</em></span>";
                    }
                } else if (ie === "Validacion") {
                    if (campoCodigo) campoCodigo.style.display = "none";
                    if (gradoSelect) { gradoSelect.style.display = "block"; }
                    if (grupoSelect) { grupoSelect.style.display = "none"; grupoSelect.value = ""; }
                    if (materiasView) materiasView.style.display = "block";
                    if (btnSubmit) btnSubmit.innerText = "Continuar con la Matrícula";
                    if (infoPago) {
                        infoPago.style.display = "block";
                        infoPago.style.background = "#FEF3C7";
                        infoPago.style.color = "#92400E";
                        infoPago.style.border = "1px solid #FCD34D";
                        infoPago.innerHTML = "🎓 <strong>Modalidad Validación Bachillerato por Ciclos:</strong> Registro inicial gratis y observación de la Guía 1 de muestra. Tarifa de matrícula oficial para resolver guías y certificar: <strong>$85.000 COP</strong>.<br><span style='font-size:0.8rem; color:#78350F; display:block; margin-top:4px;'>⚠️ <em>Aviso: Esta plataforma desarrolla las competencias de los DBA del MEN. La vinculación oficial y boletín certificado en SIMAT con la IE Instituto Montenegro tiene un costo mensual de $15.000 COP.</em></span>";
                    }
                } else if (ie === "InstitutoMontenegro") {
                    if (campoCodigo) campoCodigo.style.display = "flex";
                    if (gradoSelect) { gradoSelect.style.display = "none"; gradoSelect.value = ""; }
                    if (grupoSelect) { grupoSelect.style.display = "block"; }
                    if (materiasView) materiasView.style.display = "block";
                    if (btnSubmit) btnSubmit.innerText = "Continuar con la Matrícula";
                    if (infoPago) {
                        infoPago.style.display = "block";
                        infoPago.style.background = "#F0FDF4";
                        infoPago.style.color = "#166534";
                        infoPago.style.border = "1px solid #86EFAC";
                        infoPago.innerHTML = "🏫 <strong>Comunidad Oficial IE Instituto Montenegro:</strong> Ingresa el código institucional suministrado por la institución para matricularte con acceso total e ilimitado.";
                    }
                } else {
                    if (campoCodigo) campoCodigo.style.display = "none";
                    if (gradoSelect) { gradoSelect.style.display = "none"; gradoSelect.value = ""; }
                    if (grupoSelect) { grupoSelect.style.display = "none"; grupoSelect.value = ""; }
                    if (materiasView) materiasView.style.display = "none";
                    if (btnSubmit) btnSubmit.innerText = "Continuar con la Matrícula";
                    if (infoPago) infoPago.style.display = "none";
                }
                actualizarMaterias();
            }

            function actualizarMaterias() {
                const ie = document.getElementById("reg-ie").value;
                const input = document.getElementById("registro-asignatura");
                const view = document.getElementById("materias-asignadas-view");
                
                let materias = null;
                const grado = document.getElementById("reg-grado").value;
                const grupo = document.getElementById("registro-grupo").value;
                
                // REGLA FUNDAMENTAL: Todos los ciclos (I al VI) cursan Ciencias Naturales
                if (ie === "HomeSchool") {
                    const mapaHome = {
                        "1": "Ciencias Naturales, Matemáticas, Lengua Castellana",
                        "2": "Ciencias Naturales, Matemáticas, Lengua Castellana",
                        "3": "Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética y Valores",
                        "4": "Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética y Valores",
                        "5": "Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética y Valores",
                        "6": "Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética y Valores",
                        "7": "Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Turismo, Educación Artística, Ética y Valores",
                        "8": "Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética y Valores",
                        "9": "Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética y Valores",
                        "10": "Matemáticas, Física, Química, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Filosofía y Ética",
                        "11": "Matemáticas, Física, Química, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Filosofía y Ética, Turismo"
                    };
                    materias = mapaHome[grado] || "Ciencias Naturales, Matemáticas, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología";
                } else if (ie === "Validacion" || (grado && grado.includes("Ciclo")) || (grupo && grupo.includes("Ciclo"))) {
                    const cicloVal = (grado && grado.includes("Ciclo")) ? grado : (grupo && grupo.includes("Ciclo") ? grupo : (grado || grupo || "Ciclo VI"));
                    const mapaCiclos = {
                        "Ciclo I": "Ciencias Naturales, Matemáticas, Lengua Castellana, Ciencias Sociales",
                        "Ciclo II": "Ciencias Naturales, Matemáticas, Lengua Castellana, Ciencias Sociales, Inglés",
                        "Ciclo III": "Ciencias Naturales, Matemáticas, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología",
                        "Ciclo IV": "Ciencias Naturales, Matemáticas, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología",
                        "Ciclo V": "Ciencias Naturales, Matemáticas, Física, Química, Lengua Castellana, Ciencias Sociales, Inglés, Filosofía y Ética",
                        "Ciclo VI": "Ciencias Naturales, Matemáticas, Física, Química, Lengua Castellana, Ciencias Sociales, Inglés, Filosofía y Ética"
                    };
                    materias = mapaCiclos[cicloVal] || "Ciencias Naturales, Matemáticas, Física, Química, Lengua Castellana, Ciencias Sociales, Inglés, Filosofía y Ética";
                } else if (ie === "InstitutoMontenegro") {
                    const mapaMontenegro = {
                        "6A": "Física, Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética",
                        "6B": "Física, Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética",
                        "7A": "Física, Turismo, Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética",
                        "7B": "Física, Turismo, Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística, Ética",
                        "7C": "Física, Ética, Turismo, Matemáticas, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Educación Artística",
                        "8A": "Artística, Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Ética",
                        "8B": "Artística, Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Ética",
                        "9A": "Artística, Matemáticas, Ciencias Naturales, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología, Ética",
                        "10A": "Ética, Matemáticas, Física, Química, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología",
                        "10D": "Ética, Matemáticas, Física, Química, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología",
                        "PENS": "Química, Turismo, Matemáticas, Física, Ciencias Naturales, Lengua Castellana, Ciencias Sociales, Inglés, Filosofía",
                        "Ciclo I": "Ciencias Naturales, Matemáticas, Lengua Castellana, Ciencias Sociales",
                        "Ciclo II": "Ciencias Naturales, Matemáticas, Lengua Castellana, Ciencias Sociales, Inglés",
                        "Ciclo III": "Ciencias Naturales, Matemáticas, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología",
                        "Ciclo IV": "Ciencias Naturales, Matemáticas, Física, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología",
                        "Ciclo V": "Ciencias Naturales, Matemáticas, Física, Química, Lengua Castellana, Ciencias Sociales, Inglés, Filosofía y Ética",
                        "Ciclo VI": "Ciencias Naturales, Matemáticas, Física, Química, Lengua Castellana, Ciencias Sociales, Inglés, Filosofía y Ética"
                    };
                    materias = mapaMontenegro[grupo] || "Ciencias Naturales, Matemáticas, Lengua Castellana, Ciencias Sociales, Inglés, Tecnología";
                }
                
                if (materias) {
                    input.value = materias;
                    view.innerHTML = "<strong>Materias asignadas:</strong> " + materias;
                    view.style.color = "#111827";
                    view.style.fontStyle = "normal";
                } else {
                    input.value = "";
                    view.innerHTML = "Sin asignaturas seleccionadas";
                    view.style.color = "#e74c3c";
                    view.style.fontStyle = "italic";
                }
            }
        </script>
        <button type="button" id="btn-submit-register" onclick="window.ejecutarRegistroEstudiante(event)" style="background-color: #10B981; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 10px rgba(16,185,129,0.3); font-size: 1rem; width: 100%;">Continuar con la Matrícula</button>
        <button type="button" id="btn-cancel-register" onclick="mostrarVista('login-screen-container')" style="background-color: transparent; color: #6B7280; padding: 10px; border: none; cursor: pointer; text-decoration: underline; text-align: center;">Volver al Acceso Principal</button>
        <div id="reg-feedback-msg" style="text-align: center; font-size: 0.95rem; display: none; font-weight: bold; padding: 10px; border-radius: 8px;"></div>
    </div>
</div>

<!-- DASHBOARD DOCENTE (NUEVO) -->
<div id="docente-dashboard-container" style="display: none; height: 100vh; overflow-y: auto; background-color: #F8FAFC;">
    <header style="background: white; border-bottom: 1px solid #E5E7EB; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center;">
        <div style="font-weight: 900; font-size: 1.4rem; color: #111827;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 55px; width: auto; object-fit: contain;">
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
            <a href="proyector-qr.html" target="_blank" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(37,99,235,0.25);"><span>📽️</span> Proyectar QR Matrícula</a>
            <a href="proyector.html" target="_blank" style="background: #10B981; color: white; border: none; padding: 8px 20px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px;"><i class="ph ph-projector-screen-chart" style="font-size: 1.2rem;"></i> Modo Proyector</a>
            <div style="background: #F3F4F6; padding: 8px 15px; border-radius: 20px; font-size: 0.9rem; font-weight: 700; color: #374151;">
                Panel Docente: <span id="docente-nombre-header">Docente</span>
            </div>
            <button onclick="location.reload()" style="background: #EF4444; color: white; border: none; padding: 8px 20px; border-radius: 8px; font-weight: bold; cursor: pointer;">Cerrar Sesi&oacute;n</button>
        </div>
    </header>

    <div style="padding: 40px 30px; max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
        <!-- Formulario Matrícula Estudiante -->
        <div style="background: white; padding: 30px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">
            <h3 style="font-weight: 800; margin-bottom: 20px; color: #111827; display: flex; align-items: center; gap: 8px;">
                <span>➕</span> Matricular Estudiante
            </h3>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <input type="number" id="docente-reg-doc" placeholder="Documento" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <input type="text" id="docente-reg-nom" placeholder="Nombres" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <input type="text" id="docente-reg-ape" placeholder="Apellidos" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <input type="number" id="docente-reg-edad" placeholder="Edad" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                <select id="docente-reg-gen" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;">
                    <option value="">Género...</option><option value="F">Femenino</option><option value="M">Masculino</option>
                </select>
                <select id="docente-reg-grado" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;" onchange="cargarAsignaturasDocente(this.value)">
                    <option value="">Grado...</option><option value="6">6°</option><option value="7">7°</option><option value="8">8°</option><option value="9">9°</option><option value="10">10°</option><option value="11">11°</option>
                    <option value="Ciclo I (1°, 2°, 3°)">Ciclo I (1°, 2°, 3°)</option>
                    <option value="Ciclo II (4°, 5°)">Ciclo II (4°, 5°)</option>
                    <option value="Ciclo III (6°, 7°)">Ciclo III (6°, 7°)</option>
                    <option value="Ciclo IV (8°, 9°)">Ciclo IV (8°, 9°)</option>
                    <option value="Ciclo V (10°)">Ciclo V (10°)</option>
                    <option value="Ciclo VI (11°)">Ciclo VI (11°)</option>
                </select>
                <div>
                    <strong>Materias a cursar:</strong>
                    <div id="materias-checkboxes-container" style="display: flex; flex-direction: column; gap: 5px; margin-top: 10px;">
                        <span style="color: #6B7280; font-size: 0.9rem;">Selecciona un grado primero.</span>
                    </div>
                </div>
                <button id="btn-docente-matricular" style="background-color: #10B981; color: white; padding: 12px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Matricular</button>
            </div>
        </div>

        <!-- Lista Estudiantes -->
        <div style="background: white; padding: 30px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">
            <h3 style="font-weight: 800; margin-bottom: 20px; color: #111827;">Mis Estudiantes Matriculados</h3>
            
            <div style="display: flex; gap: 15px; margin-bottom: 20px; align-items: center; flex-wrap: wrap;">
                <select id="filtro-asignatura" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;" onchange="cargarEstudiantesDocente(usuario_actual)">
                    <option value="Todas las Asignaturas">Todas las Asignaturas</option>
                    <option value="Física">Física</option>
                    <option value="Artística">Artística</option>
                    <option value="Ética">Ética</option>
                    <option value="Turismo">Turismo</option>
                    <option value="Química">Química</option>
                </select>
                <select id="filtro-grupo" style="padding: 10px; border: 1px solid #d1d5db; border-radius: 8px;" onchange="cargarEstudiantesDocente(usuario_actual)">
                    <option value="Todos los Grupos">Todos los Grupos</option>
                    <option value="6A">6A</option><option value="6B">6B</option>
                    <option value="7A">7A</option><option value="7B">7B</option><option value="7C">7C</option>
                    <option value="8A">8A</option><option value="8B">8B</option>
                    <option value="9A">9A</option>
                    <option value="10A">10A</option><option value="10D">10D</option>
                    <option value="PENS">PENS</option>
                    <option value="Ciclo I (1°, 2°, 3°)">Ciclo I (1°, 2°, 3°)</option>
                    <option value="Ciclo II (4°, 5°)">Ciclo II (4°, 5°)</option>
                    <option value="Ciclo III (6°, 7°)">Ciclo III (6°, 7°)</option>
                    <option value="Ciclo IV (8°, 9°)">Ciclo IV (8°, 9°)</option>
                    <option value="Ciclo V (10°)">Ciclo V (10°)</option>
                    <option value="Ciclo VI (11°)">Ciclo VI (11°)</option>
                </select>
                <button onclick="abrirProyeccionGrupo()" style="background: linear-gradient(135deg, #8B5CF6, #6D28D9); color: white; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 800; font-size: 0.92rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(139,92,246,0.3); margin-left: auto; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'" title="Abrir pantalla interactiva de proyección en vivo para VideoBeam / TV de clase">
                    📺 Proyectar Ránkin de Clase en Vivo (VideoBeam)
                </button>
            </div>

            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="border-bottom: 2px solid #E5E7EB; background: #F8FAFC;">
                        <th style="padding: 12px 10px;">Documento</th>
                        <th style="padding: 12px 10px;">Estudiante</th>
                        <th style="padding: 12px 10px;">Edad / Género</th>
                        <th style="padding: 12px 10px;">Grado / Grupo</th>
                        <th style="padding: 12px 10px;">Institución / Modalidad</th>
                        <th style="padding: 12px 10px;">Puntaje (XP)</th>
                        <th style="padding: 12px 10px; text-align: center;">Acciones</th>
                    </tr>
                </thead>
                <tbody id="tbody-docente-estudiantes">
                    <!-- Se llena con JS -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- DASHBOARD ADMIN RECREADO -->
<div id="dashboard-screen-container" style="display: none; height: 100vh; overflow-y: auto; background-color: #F8FAFC;">
    <!-- Header Superior -->
    <header style="background: white; border-bottom: 1px solid #E5E7EB; padding: 15px 30px; display: flex; justify-content: flex-end; align-items: center;">
        <div style="display: flex; align-items: center; gap: 15px;">
            <a href="proyector-qr.html" target="_blank" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(37,99,235,0.25);"><span>📽️</span> Proyectar QR Matrícula</a>
            <a href="proyector.html" target="_blank" style="background: #10B981; color: white; border: none; padding: 8px 20px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px;"><i class="ph ph-projector-screen-chart" style="font-size: 1.2rem;"></i> Modo Proyector</a>
            <div style="background: #F3F4F6; padding: 8px 15px; border-radius: 20px; font-size: 0.9rem; font-weight: 700; color: #374151;">
                Administrador Maestro ADMINISTRADOR
            </div>
            <button onclick="location.reload()" style="background: #EF4444; color: white; border: none; padding: 8px 20px; border-radius: 8px; font-weight: bold; cursor: pointer; font-family: Inter, sans-serif;">Cerrar Sesión</button>
        </div>
    </header>

    <!-- Contenedor Central -->
    <div id="student-main-content" style="padding: 40px 30px; max-width: 1200px; margin: 0 auto;">
        <div style="background: white; border-radius: 16px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05); overflow: hidden;">
            
            <!-- Cabecera Azul Claro -->
            <div style="background: #3B82F6; padding: 20px 30px; display: flex; align-items: center; justify-content: flex-start; gap: 20px;">
                <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 180px; width: auto; object-fit: contain;">
                <div style="text-align: left;">
                    <h1 style="color: white; margin: 0; font-size: 2.2rem; font-weight: 900; letter-spacing: 0.5px;">Hola Juan Felipe Ramirez Giraldo</h1>
                    <p style="color: #EFF6FF; margin: 8px 0 0 0; font-weight: 600; font-size: 1.3rem;">panel de administrador</p>
                </div>
            </div>

            <!-- TABS ADMIN -->
            <div style="display: flex; background: #F3F4F6; border-bottom: 1px solid #E5E7EB; flex-wrap: wrap;">
                <button class="admin-tab-btn active" data-tab="grupos" style="padding: 15px 30px; border: none; background: white; font-weight: bold; cursor: pointer; border-bottom: 3px solid #3B82F6;">Instituciones</button>
                <button class="admin-tab-btn" data-tab="docentes" style="padding: 15px 30px; border: none; background: transparent; font-weight: bold; cursor: pointer; color: #6B7280;">Lista Docentes</button>
            </div>
            
            <div id="admin-view-grupos" class="admin-view" style="display: block; padding: 20px;">
                <div id="admin-grupos-container">
                    <div style="display: flex; gap: 15px; margin-bottom: 25px; flex-wrap: wrap;">
                        <button class="admin-inst-btn" data-inst="montenegro" onclick="mostrarGruposInstitucion('montenegro')" style="padding: 14px 24px; background: #2563EB; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 800; font-size: 1rem; box-shadow: 0 4px 10px rgba(37,99,235,0.3); display: flex; align-items: center; gap: 8px; transition: 0.2s;">🏫 IE Instituto Montenegro</button>
                        <button class="admin-inst-btn" data-inst="homeschool" onclick="mostrarGruposInstitucion('homeschool')" style="padding: 14px 24px; background: #4B5563; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 800; font-size: 1rem; display: flex; align-items: center; gap: 8px; transition: 0.2s;">🏡 Tutores Home School</button>
                        <button class="admin-inst-btn" data-inst="validacion" onclick="mostrarGruposInstitucion('validacion')" style="padding: 14px 24px; background: #4B5563; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 800; font-size: 1rem; display: flex; align-items: center; gap: 8px; transition: 0.2s;">🎓 Validación Bachillerato</button>
                    </div>
                    
                    <!-- Contenedor para mostrar los grupos de IE Instituto Montenegro -->
                    <div id="grupos-montenegro" style="display: block;">
                        <h3 style="font-weight: 800; margin-bottom: 20px; color: #1E3A8A; display: flex; align-items: center; gap: 8px;">
                            <span>🏫</span> Grupos Matriculados - IE Instituto Montenegro
                        </h3>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 15px;">
                            <button onclick="abrirGrupo('6A')" class="grupo-btn">
                                <span class="grupo-nombre">6A</span>
                                <span class="grupo-materias">Física</span>
                            </button>
                            <button onclick="abrirGrupo('6B')" class="grupo-btn">
                                <span class="grupo-nombre">6B</span>
                                <span class="grupo-materias">Física</span>
                            </button>
                            <button onclick="abrirGrupo('7A')" class="grupo-btn">
                                <span class="grupo-nombre">7A</span>
                                <span class="grupo-materias">Turismo<br>Física</span>
                            </button>
                            <button onclick="abrirGrupo('7B')" class="grupo-btn">
                                <span class="grupo-nombre">7B</span>
                                <span class="grupo-materias">Turismo<br>Física</span>
                            </button>
                            <button onclick="abrirGrupo('7C')" class="grupo-btn">
                                <span class="grupo-nombre">7C</span>
                                <span class="grupo-materias">Turismo<br>Ética<br>Física</span>
                            </button>
                            <button onclick="abrirGrupo('8A')" class="grupo-btn">
                                <span class="grupo-nombre">8A</span>
                                <span class="grupo-materias">Artística</span>
                            </button>
                            <button onclick="abrirGrupo('8B')" class="grupo-btn">
                                <span class="grupo-nombre">8B</span>
                                <span class="grupo-materias">Artística</span>
                            </button>
                            <button onclick="abrirGrupo('9A')" class="grupo-btn">
                                <span class="grupo-nombre">9A</span>
                                <span class="grupo-materias">Artística</span>
                            </button>
                            <button onclick="abrirGrupo('10A')" class="grupo-btn">
                                <span class="grupo-nombre">10A</span>
                                <span class="grupo-materias">Ética</span>
                            </button>
                            <button onclick="abrirGrupo('10D')" class="grupo-btn">
                                <span class="grupo-nombre">10D</span>
                                <span class="grupo-materias">Ética</span>
                            </button>
                            <button onclick="abrirGrupo('PENS')" class="grupo-btn">
                                <span class="grupo-nombre">PENS</span>
                                <span class="grupo-materias">Turismo<br>Química</span>
                            </button>
                            <!-- CICLOS ADULTOS / NOCTURNA / ESPECIAL -->
                            <button onclick="abrirGrupo('Ciclo I (1°, 2°, 3°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;">
                                <span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo I</span>
                                <span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo II (4°, 5°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;">
                                <span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo II</span>
                                <span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo III (6°, 7°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;">
                                <span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo III</span>
                                <span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo IV (8°, 9°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;">
                                <span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo IV</span>
                                <span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo V (10°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;">
                                <span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo V</span>
                                <span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo VI (11°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;">
                                <span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo VI</span>
                                <span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span>
                            </button>
                        </div>
                    </div>

                    <!-- Contenedor para mostrar TUTORES Y ESTUDIANTES HOME SCHOOL -->
                    <div id="grupos-homeschool" style="display: none;">
                        <div style="background: linear-gradient(135deg, #1E40AF, #3B82F6); color: white; padding: 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(37,99,235,0.2);">
                            <h3 style="font-weight: 900; margin: 0; font-size: 1.5rem; display: flex; align-items: center; gap: 10px;">
                                <span>🏡</span> Gestión de Educación en Casa (Home School)
                            </h3>
                            <p style="margin: 8px 0 0 0; color: #DBEAFE; font-size: 0.95rem;">
                                Plataforma de acompañamiento pedagógico, matrículas independientes y pasarela de pago para tutores familiares.
                            </p>
                        </div>

                        <!-- Grados Home School -->
                        <h4 style="font-weight: 800; color: #1F2937; margin-bottom: 15px;">Aulas y Cursos Home School:</h4>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(135px, 1fr)); gap: 12px; margin-bottom: 30px;">
                            <button onclick="abrirGrupo('HS-1')" class="grupo-btn"><span class="grupo-nombre">1° Prim</span><span class="grupo-materias">STEAM Base</span></button>
                            <button onclick="abrirGrupo('HS-2')" class="grupo-btn"><span class="grupo-nombre">2° Prim</span><span class="grupo-materias">STEAM Base</span></button>
                            <button onclick="abrirGrupo('HS-3')" class="grupo-btn"><span class="grupo-nombre">3° Prim</span><span class="grupo-materias">STEAM Base</span></button>
                            <button onclick="abrirGrupo('HS-4')" class="grupo-btn"><span class="grupo-nombre">4° Prim</span><span class="grupo-materias">STEAM Base</span></button>
                            <button onclick="abrirGrupo('HS-5')" class="grupo-btn"><span class="grupo-nombre">5° Prim</span><span class="grupo-materias">STEAM Base</span></button>
                            <button onclick="abrirGrupo('HS-6')" class="grupo-btn"><span class="grupo-nombre">6° Sec</span><span class="grupo-materias">Física, Nat</span></button>
                            <button onclick="abrirGrupo('HS-7')" class="grupo-btn"><span class="grupo-nombre">7° Sec</span><span class="grupo-materias">Física, Turismo</span></button>
                            <button onclick="abrirGrupo('HS-8')" class="grupo-btn"><span class="grupo-nombre">8° Sec</span><span class="grupo-materias">Artística, Nat</span></button>
                            <button onclick="abrirGrupo('HS-9')" class="grupo-btn"><span class="grupo-nombre">9° Sec</span><span class="grupo-materias">Artística, Nat</span></button>
                            <button onclick="abrirGrupo('HS-10')" class="grupo-btn"><span class="grupo-nombre">10° Med</span><span class="grupo-materias">Ética, Física</span></button>
                            <button onclick="abrirGrupo('HS-11')" class="grupo-btn"><span class="grupo-nombre">11° Med</span><span class="grupo-materias">Física, Quím, Tur</span></button>
                            <button onclick="abrirGrupo('Ciclo I (1°, 2°, 3°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;"><span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo I</span><span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span></button>
                            <button onclick="abrirGrupo('Ciclo II (4°, 5°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;"><span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo II</span><span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span></button>
                            <button onclick="abrirGrupo('Ciclo III (6°, 7°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;"><span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo III</span><span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span></button>
                            <button onclick="abrirGrupo('Ciclo IV (8°, 9°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;"><span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo IV</span><span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span></button>
                            <button onclick="abrirGrupo('Ciclo V (10°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;"><span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo V</span><span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span></button>
                            <button onclick="abrirGrupo('Ciclo VI (11°)')" class="grupo-btn" style="border-color: #8B5CF6; background: #F5F3FF;"><span class="grupo-nombre" style="color: #6D28D9; font-size: 1.15rem;">Ciclo VI</span><span class="grupo-materias" style="color: #059669; font-weight: bold;">C. Naturales</span></button>
                        </div>
                    </div>

                    <!-- Contenedor para mostrar VALIDACIÓN BACHILLERATO -->
                    <div id="grupos-validacion" style="display: none;">
                        <div style="background: linear-gradient(135deg, #059669, #10B981); color: white; padding: 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(16,185,129,0.2);">
                            <h3 style="font-weight: 900; margin: 0; font-size: 1.5rem; display: flex; align-items: center; gap: 10px;">
                                <span>🎓</span> Programa de Validación de Bachillerato por Ciclos
                            </h3>
                            <p style="margin: 8px 0 0 0; color: #D1FAE5; font-size: 0.95rem;">
                                Acceso a guías STEAM modulares, simulacros de preparación ICFES Saber 11 y acreditación por ciclos lectivos especiales integrados (CLEI).
                            </p>
                        </div>

                        <h4 style="font-weight: 800; color: #1F2937; margin-bottom: 15px;">Ciclos de Formación Acreditados:</h4>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 15px; margin-bottom: 30px;">
                            <button onclick="abrirGrupo('Ciclo I (1°, 2°, 3°)')" class="grupo-btn" style="border-color: #10B981; background: #F0FDF4;">
                                <span class="grupo-nombre" style="color: #047857;">Ciclo I</span>
                                <span class="grupo-materias">1°, 2°, 3° Primaria<br><strong>C. Naturales</strong></span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo II (4°, 5°)')" class="grupo-btn" style="border-color: #10B981; background: #F0FDF4;">
                                <span class="grupo-nombre" style="color: #047857;">Ciclo II</span>
                                <span class="grupo-materias">4°, 5° Primaria<br><strong>C. Naturales</strong></span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo III (6°, 7°)')" class="grupo-btn" style="border-color: #10B981; background: #F0FDF4;">
                                <span class="grupo-nombre" style="color: #047857;">Ciclo III</span>
                                <span class="grupo-materias">6°, 7° Básica<br><strong>C. Naturales</strong></span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo IV (8°, 9°)')" class="grupo-btn" style="border-color: #10B981; background: #F0FDF4;">
                                <span class="grupo-nombre" style="color: #047857;">Ciclo IV</span>
                                <span class="grupo-materias">8°, 9° Básica<br><strong>C. Naturales</strong></span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo V (10°)')" class="grupo-btn" style="border-color: #10B981; background: #F0FDF4;">
                                <span class="grupo-nombre" style="color: #047857;">Ciclo V</span>
                                <span class="grupo-materias">10° Educación Media<br><strong>C. Naturales</strong></span>
                            </button>
                            <button onclick="abrirGrupo('Ciclo VI (11°)')" class="grupo-btn" style="border-color: #10B981; background: #F0FDF4;">
                                <span class="grupo-nombre" style="color: #047857;">Ciclo VI</span>
                                <span class="grupo-materias">11° Bachillerato<br><strong>C. Naturales</strong></span>
                            </button>
                        </div>
                    </div>

                    <style>
                        .grupo-btn { background: white; border: 1px solid #E5E7EB; border-radius: 12px; padding: 15px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: 0.2s; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; }
                        .grupo-nombre { font-size: 1.4rem; color: #1F2937; }
                        .grupo-materias { font-size: 0.85rem; color: #6B7280; font-weight: normal; text-align: center; line-height: 1.3; }
                        .grupo-btn:hover { border-color: #3B82F6; transform: translateY(-2px); box-shadow: 0 6px 12px rgba(59,130,246,0.15); }
                        .grupo-btn:hover .grupo-nombre { color: #3B82F6; }
                    </style>

                    <script>
                        function mostrarGruposInstitucion(inst) {
                            const list = ['montenegro', 'homeschool', 'validacion'];
                            list.forEach(item => {
                                const el = document.getElementById('grupos-' + item);
                                if (el) el.style.display = (item === inst) ? 'block' : 'none';
                            });
                            document.querySelectorAll('.admin-inst-btn').forEach(btn => {
                                if (btn.getAttribute('data-inst') === inst) {
                                    btn.style.background = '#2563EB';
                                    btn.style.boxShadow = '0 4px 10px rgba(37,99,235,0.4)';
                                } else {
                                    btn.style.background = '#4B5563';
                                    btn.style.boxShadow = 'none';
                                }
                            });
                    </script>
                </div>

                <!-- Vista Nivel 2: Estudiantes del Grupo Seleccionado -->
                <div id="admin-estudiantes-grupo-container" style="display: none;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                        <h4 id="admin-titulo-grupo-actual" style="font-weight: 800; font-size: 1.2rem; color: #111827;">Grupo...</h4>
                        <div style="display: flex; gap: 10px;">
                            <button onclick="volverAGrupos()" style="padding: 8px 16px; background: #E5E7EB; color: #374151; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">← Volver a Instituciones</button>
                        </div>
                    </div>
                    <style>@keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.02); } 100% { transform: scale(1); } }</style>
                    <div id="admin-materias-grupo-actual" style="margin-bottom: 20px;"></div>
                    
                    <div id="visualizador-planeacion-container" style="background: white; border: 1px solid #E5E7EB; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: none;">
                        <div style="display: flex; gap: 20px; margin-bottom: 15px; align-items: center; flex-wrap: wrap;">
                            <h5 style="margin: 0; font-size: 1.1rem; color: #111827; display: flex; align-items: center; gap: 8px; flex-grow: 1;">
                                <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                                Malla Curricular
                            </h5>
                            <button onclick="abrirRankingEnNuevaPestana()" style="padding: 8px 16px; background: linear-gradient(135deg, #F59E0B, #D97706); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 900; box-shadow: 0 4px 10px rgba(245, 158, 11, 0.4); animation: pulse 2s infinite;">🏆 Puntuación de Asignatura</button>
                            <select id="select-planeacion-asignatura" style="display: none; padding: 8px 12px; border-radius: 6px; border: 1px solid #D1D5DB; font-weight: bold; cursor: pointer;" onchange="actualizarVisualizadorPlaneacion()">
                            </select>
                            <select id="select-planeacion-periodo" style="padding: 8px 12px; border-radius: 6px; border: 1px solid #D1D5DB; font-weight: bold; cursor: pointer;" onchange="actualizarVisualizadorPlaneacion()">
                                <option value="1" disabled>Periodo 1 (Bloqueado)</option>
                                <option value="2" disabled>Periodo 2 (Bloqueado)</option>
                                <option value="3" selected>Periodo 3</option>
                                <option value="4" disabled>Periodo 4 (Bloqueado)</option>
                            </select>
                            <select id="select-planeacion-semana" style="padding: 8px 12px; border-radius: 6px; border: 1px solid #D1D5DB; font-weight: bold; cursor: pointer;" onchange="actualizarVisualizadorPlaneacion()">
                                <option value="1">Semana 1</option>
                                <option value="2">Semana 2</option>
                                <option value="3">Semana 3</option>
                                <option value="4">Semana 4</option>
                                <option value="5">Semana 5</option>
                                <option value="6">Semana 6</option>
                                <option value="7">Semana 7</option>
                                <option value="8">Semana 8</option>
                            </select>
                        </div>
                        <div id="planeacion-contenido-actual" style="background: #F9FAFB; padding: 15px; border-radius: 8px; border-left: 4px solid #3B82F6;">
                            <!-- Contenido inyectado por JS -->
                        </div>
                    </div>

                    <table style="width: 100%; border-collapse: collapse; text-align: left; background: white; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                        <thead><tr style="border-bottom: 2px solid #CBD5E1; background: #F1F5F9;">
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B;">Documento</th>
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B;">Estudiante</th>
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B;">Edad / Género</th>
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B;">Institución / Modalidad</th>
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B;">Puntaje Acumulado (XP)</th>
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B;">Asignaturas y Estado</th>
                            <th style="padding: 14px 10px; font-size: 0.88rem; color: #1E293B; text-align: center;">Acciones</th>
                        </tr></thead>
                        <tbody id="tbody-admin-estudiantes-por-grupo"></tbody>
                    </table>
                </div>
            </div>

            <div id="admin-view-docentes" class="admin-view" style="display: none; padding: 20px;">
                <h3 style="font-weight: 800; margin-bottom: 20px;">Directorio de Docentes</h3>
                
                <table style="width: 100%; border-collapse: collapse; text-align: left; background: white; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                    <thead><tr style="border-bottom: 2px solid #E5E7EB;"><th style="padding: 15px;">Documento</th><th style="padding: 15px;">Nombre del Docente</th><th style="padding: 15px;">Tipo de Vinculación</th></tr></thead>
                    <tbody id="tbody-admin-docentes"></tbody>
                </table>
            </div>
            <div id="admin-view-asignaturas" class="admin-view" style="display: none; padding: 20px;">
                <h3 style="font-weight: 800; margin-bottom: 20px;">Crear Asignatura</h3>
                <div style="display: flex; gap: 10px; margin-bottom: 20px; align-items: center; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                    <input type="text" id="admin-asig-nombre" placeholder="Nombre Asignatura" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; flex: 1;">
                    <select id="admin-asig-grado" style="padding: 12px; border: 1px solid #d1d5db; border-radius: 8px;">
                        <option value="6">6°</option><option value="7">7°</option><option value="8">8°</option><option value="9">9°</option><option value="10">10°</option><option value="11">11°</option>
                        <option value="Ciclo I">Ciclo I (1°, 2°, 3°)</option>
                        <option value="Ciclo II">Ciclo II (4°, 5°)</option>
                        <option value="Ciclo III">Ciclo III (6°, 7°)</option>
                        <option value="Ciclo IV">Ciclo IV (8°, 9°)</option>
                        <option value="Ciclo V">Ciclo V (10°)</option>
                        <option value="Ciclo VI">Ciclo VI (11°)</option>
                    </select>
                    <button id="btn-crear-asignatura" style="background: #10B981; color: white; padding: 12px 24px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Registrar Asignatura</button>
                </div>
            </div>

        </div> <!-- fin div bg white admin central -->
    </div> <!-- fin contenedor central -->
</div> <!-- fin dashboard-screen-container -->

<!-- PANEL DE TUTOR HOME SCHOOL -->
<div id="tutor-dashboard-container" style="display: none; height: 100vh; overflow-y: auto; background-color: #F8FAFC;">
    <!-- Header Superior -->
    <header style="background: white; border-bottom: 1px solid #E5E7EB; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,0.04);">
        <div style="display: flex; align-items: center; gap: 15px;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 45px; width: auto; object-fit: contain;">
            <div>
                <div style="font-weight: 800; color: #1E293B; font-size: 1.15rem; display: flex; align-items: center; gap: 6px;">
                    <span>🏡</span> Panel de Tutor Home School
                </div>
                <div style="font-size: 0.85rem; color: #6B7280; font-weight: 500;">
                    Tutor: <span id="tutor-nombre-header" style="font-weight: 700; color: #2563EB;">Tutor Familiar</span>
                </div>
            </div>
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
            <a href="proyector-qr.html" target="_blank" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; box-shadow: 0 4px 10px rgba(37,99,235,0.25);"><span>📽️</span> Proyectar QR Matrícula</a>
            <a href="proyector.html" target="_blank" style="background: #10B981; color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 0.9rem;"><i class="ph ph-projector-screen-chart"></i> Modo Proyector</a>
            <button onclick="location.reload()" style="background: #EF4444; color: white; border: none; padding: 8px 18px; border-radius: 8px; font-weight: bold; cursor: pointer; font-family: Inter, sans-serif; font-size: 0.9rem;">Cerrar Sesión</button>
        </div>
    </header>

    <!-- Contenido Principal Tutor -->
    <div style="padding: 30px; max-width: 1300px; margin: 0 auto;">
        
        <!-- Banner de Bienvenida -->
        <div style="background: linear-gradient(135deg, #1E40AF, #3B82F6); color: white; padding: 30px; border-radius: 16px; margin-bottom: 30px; box-shadow: 0 10px 25px rgba(37,99,235,0.2); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
            <div>
                <h1 style="margin: 0; font-size: 2rem; font-weight: 900; letter-spacing: 0.5px;">¡Bienvenido al Aula Home School!</h1>
                <p style="margin: 8px 0 0 0; color: #DBEAFE; font-size: 1.05rem;">Administra las matrículas de tus estudiantes, accede a guías personalizadas y gestiona los pagos seguros.</p>
            </div>
            <div style="background: rgba(255,255,255,0.15); backdrop-filter: blur(8px); padding: 15px 25px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.3); text-align: center;">
                <div style="font-size: 0.85rem; color: #E0E7FF; font-weight: 600; text-transform: uppercase;">Tarifa Base por Estudiante</div>
                <div style="font-size: 1.6rem; font-weight: 900; color: #FEF08A; margin-top: 4px;">$85.000 COP</div>
            </div>
        </div>

        <!-- Pestañas de Navegación del Tutor Home School -->
        <div style="display: flex; gap: 10px; margin-bottom: 25px; border-bottom: 2px solid #E2E8F0; padding-bottom: 12px; flex-wrap: wrap;">
            <button id="btn-tab-tutor-estudiantes" onclick="cambiarTabTutor('estudiantes')" style="background: #2563EB; color: white; border: none; padding: 12px 22px; border-radius: 10px; font-weight: 800; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 10px rgba(37,99,235,0.25); transition: 0.2s;">
                <span>👨‍🎓</span> Matrículas y Estudiantes a Cargo
            </button>
            <button id="btn-tab-tutor-mallas" onclick="cambiarTabTutor('mallas')" style="background: white; color: #475569; border: 1.5px solid #CBD5E1; padding: 12px 22px; border-radius: 10px; font-weight: 800; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: 0.2s;">
                <span>📚</span> Mallas Curriculares DBA (Materias Fundamentales)
            </button>
        </div>

        <!-- Vista 1: Matrículas y Lista de Estudiantes -->
        <div id="vista-tutor-estudiantes" style="display: grid; grid-template-columns: 1fr 1.6fr; gap: 30px; align-items: start;">
            
            <!-- Columna Izquierda: Formulario Matricular Nuevo Estudiante -->
            <div style="background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
                    <span style="font-size: 1.8rem;">➕</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.3rem; font-weight: 800; color: #111827;">Matricular Nuevo Estudiante</h3>
                        <p style="margin: 2px 0 0 0; font-size: 0.85rem; color: #6B7280;">Configura las materias, SIMAT y formaliza el acceso</p>
                    </div>
                </div>

                <!-- Aviso Legal Aclaratorio Obligatorio -->
                <div style="background: #FEF3C7; border: 1.5px solid #F59E0B; padding: 14px; border-radius: 10px; font-size: 0.84rem; color: #78350F; line-height: 1.45; margin-bottom: 15px;">
                    <div style="font-weight: 800; color: #92400E; display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                        <span>⚠️</span> Aviso Legal y Pedagógico Aclaratorio:
                    </div>
                    Con esta suscripción a <strong>Peidagogos STEAM</strong>, el estudiante <strong>no queda matriculado automáticamente en una institución educativa tradicional ni registrado en el SIMAT</strong>. Esta es una plataforma para el aprendizaje en casa orientada a desarrollar las competencias de acuerdo a los estándares y DBA del MEN. Si deseas registro oficial en SIMAT y boletín por periodo, activa la opción certificada abajo.
                </div>

                <form id="form-tutor-matricular" onsubmit="return false;" style="display: flex; flex-direction: column; gap: 14px;">
                    <div style="display: flex; gap: 10px;">
                        <select id="tutor-reg-tipo-doc" style="padding: 10px; border: 1px solid #D1D5DB; border-radius: 8px; width: 32%; font-weight: bold;">
                            <option value="TI">TI</option><option value="RC">RC</option><option value="CC">CC</option><option value="CE">CE</option>
                        </select>
                        <input type="text" id="tutor-reg-doc" placeholder="Número de Documento" style="padding: 10px 12px; border: 1px solid #D1D5DB; border-radius: 8px; flex: 1;" required>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <input type="text" id="tutor-reg-nom" placeholder="Nombres" style="padding: 10px 12px; border: 1px solid #D1D5DB; border-radius: 8px;" required>
                        <input type="text" id="tutor-reg-ape" placeholder="Apellidos" style="padding: 10px 12px; border: 1px solid #D1D5DB; border-radius: 8px;" required>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <input type="number" id="tutor-reg-edad" placeholder="Edad" style="padding: 10px 12px; border: 1px solid #D1D5DB; border-radius: 8px;" required>
                        <select id="tutor-reg-gen" style="padding: 10px 12px; border: 1px solid #D1D5DB; border-radius: 8px;">
                            <option value="">Género...</option><option value="M">Masculino</option><option value="F">Femenino</option><option value="otro">Otro</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-weight: 700; color: #374151; font-size: 0.85rem; display: block; margin-bottom: 4px;">Grado o Ciclo Académico:</label>
                        <select id="tutor-reg-grado" onchange="actualizarMateriasTutor()" style="width: 100%; padding: 10px 12px; border: 2px solid #3B82F6; border-radius: 8px; font-weight: bold; background: #F8FAFC;" required>
                            <option value="">Seleccionar Grado...</option>
                            <option value="1">1° de Primaria</option>
                            <option value="2">2° de Primaria</option>
                            <option value="3">3° de Primaria</option>
                            <option value="4">4° de Primaria</option>
                            <option value="5">5° de Primaria</option>
                            <option value="6">6° de Secundaria</option>
                            <option value="7">7° de Secundaria</option>
                            <option value="8">8° de Secundaria</option>
                            <option value="9">9° de Secundaria</option>
                            <option value="10">10° Media</option>
                            <option value="11">11° Media</option>
                            <option value="Ciclo I">Ciclo I (1°, 2°, 3°)</option>
                            <option value="Ciclo II">Ciclo II (4°, 5°)</option>
                            <option value="Ciclo III">Ciclo III (6°, 7°)</option>
                            <option value="Ciclo IV">Ciclo IV (8°, 9°)</option>
                            <option value="Ciclo V">Ciclo V (10°)</option>
                            <option value="Ciclo VI">Ciclo VI (11°)</option>
                        </select>
                    </div>

                    <div id="tutor-materias-preview" style="padding: 10px 12px; background: #EFF6FF; border: 1px dashed #93C5FD; border-radius: 8px; font-size: 0.85rem; color: #1E40AF;">
                        Selecciona un grado para ver las materias fundamentales (Ciencias Naturales, Matemáticas, Castellano, Sociales).
                    </div>

                    <!-- Módulo Opcional SIMAT -->
                    <div style="background: #F0FDF4; border: 1.5px solid #86EFAC; padding: 14px; border-radius: 10px;">
                        <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer; font-weight: 700; color: #166534; font-size: 0.88rem; margin: 0;">
                            <input type="checkbox" id="tutor-check-simat" onchange="actualizarTotalMatriculaTutor()" style="margin-top: 3px; transform: scale(1.2);">
                            <div>
                                <span>🏛️ Matrícula Oficial en SIMAT + Boletín Certificado (+$15.000 COP / mes)</span>
                                <div style="font-weight: normal; font-size: 0.78rem; color: #374151; margin-top: 3px; line-height: 1.35;">
                                    Convierte al estudiante en <strong>estudiante activo del Sistema Educativo Nacional</strong> adscrito a la <strong>IE Instituto Montenegro (Quindío)</strong> con boletín oficial de calificaciones por periodo.
                                </div>
                            </div>
                        </label>
                    </div>

                    <!-- Materias Electivas Personalizadas -->
                    <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; padding: 14px; border-radius: 10px; display: flex; flex-direction: column; gap: 10px;">
                        <div style="font-weight: 800; color: #1E293B; font-size: 0.88rem; display: flex; align-items: center; gap: 6px;">
                            <span>✨</span> Materias Adicionales Personalizadas (+$25.000 COP c/u):
                        </div>
                        
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.85rem; color: #334155; margin: 0;">
                            <input type="checkbox" id="tutor-check-ingles" onchange="actualizarTotalMatriculaTutor()" style="transform: scale(1.15);">
                            <span>🇬🇧 <strong>Inglés STEAM</strong> (+ $25.000 COP)</span>
                        </label>

                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.85rem; color: #334155; margin: 0;">
                            <input type="checkbox" id="tutor-check-artes" onchange="actualizarTotalMatriculaTutor()" style="transform: scale(1.15);">
                            <span>🎨 <strong>Educación Artística y Música</strong> (+ $25.000 COP)</span>
                        </label>

                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.85rem; color: #334155; margin: 0;">
                            <input type="checkbox" id="tutor-check-etica-religion" onchange="toggleEnfasisDoctrinal(); actualizarTotalMatriculaTutor();" style="transform: scale(1.15);">
                            <span>🕊️ <strong>Ética y Religión (Con Énfasis Doctrinal)</strong> (+ $25.000 COP)</span>
                        </label>

                        <div id="campo-enfasis-doctrinal" style="display: none; margin-top: 4px; padding: 10px; background: white; border: 1px dashed #93C5FD; border-radius: 8px;">
                            <label style="font-size: 0.8rem; font-weight: 700; color: #1E40AF; display: block; margin-bottom: 4px;">
                                Énfasis Doctrinal / Axiológico Solicitado:
                            </label>
                            <input type="text" id="tutor-reg-enfasis-doctrinal" placeholder="Ej: Católico, Cristiano Evangélico, Laico / Valores Cívicos, Bíblico..." style="width: 100%; padding: 8px 12px; border: 1px solid #94A3B8; border-radius: 6px; font-size: 0.85rem; box-sizing: border-box;">
                        </div>
                    </div>

                    <!-- Totalizador Dinámico -->
                    <div style="background: linear-gradient(135deg, #1E293B, #0F172A); color: white; padding: 14px 18px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-weight: 700;">Total Matrícula</div>
                            <div style="font-size: 0.78rem; color: #CBD5E1;" id="tutor-desglose-pago">Base Fundamentales ($85.000)</div>
                        </div>
                        <div style="font-size: 1.5rem; font-weight: 900; color: #38BDF8;" id="tutor-monto-total-badge">$85.000 COP</div>
                    </div>

                    <button type="button" id="btn-tutor-matricular-pagar" onclick="matricularYProcederPagoTutor()" style="background: linear-gradient(135deg, #009EE3, #007EB5); color: white; padding: 14px; border: none; border-radius: 10px; font-weight: 800; font-size: 1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 14px rgba(0,158,227,0.35); transition: 0.2s;">
                        <span>💳</span> Matricular y Pagar con Mercado Pago (<span id="btn-monto-texto">$85.000 COP</span>)
                    </button>
                </form>
            </div>

            <!-- Columna Derecha: Lista de Estudiantes a Cargo -->
            <div style="background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #E5E7EB;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 1.8rem;">👨‍🎓</span>
                        <div>
                            <h3 style="margin: 0; font-size: 1.3rem; font-weight: 800; color: #111827;">Mis Estudiantes Home School</h3>
                            <p style="margin: 2px 0 0 0; font-size: 0.85rem; color: #6B7280;">Estudiantes matriculados bajo tu tutoría</p>
                        </div>
                    </div>
                    <button onclick="cargarEstudiantesTutor(usuario_actual)" style="background: #F3F4F6; border: 1px solid #D1D5DB; color: #374151; padding: 6px 14px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 0.85rem; display: flex; align-items: center; gap: 5px;">🔄 Actualizar</button>
                </div>

                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; text-align: left;">
                        <thead>
                            <tr style="border-bottom: 2px solid #E5E7EB; background: #F9FAFB;">
                                <th style="padding: 12px 10px; font-size: 0.85rem; color: #4B5563;">Estudiante</th>
                                <th style="padding: 12px 10px; font-size: 0.85rem; color: #4B5563;">Curso / Materias</th>
                                <th style="padding: 12px 10px; font-size: 0.85rem; color: #4B5563; text-align: center;">Estado Pago</th>
                                <th style="padding: 12px 10px; font-size: 0.85rem; color: #4B5563; text-align: center;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-tutor-estudiantes">
                            <!-- Inyectado dinámicamente -->
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Vista 2: Explorador Curricular DBA para Tutores y Familias Home School -->
        <div id="vista-tutor-mallas" style="display: none;">
            <div style="background: white; padding: 25px 30px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #E5E7EB; margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                    <div>
                        <h2 style="font-size: 1.5rem; font-weight: 900; color: #0F172A; margin: 0; display: flex; align-items: center; gap: 10px;">
                            <span>📚</span> Explorador Curricular DBA para Familias Home School
                        </h2>
                        <p style="color: #64748B; font-size: 0.95rem; margin: 4px 0 0 0;">
                            Plan de estudios oficial estructurado según los <strong>Derechos Básicos de Aprendizaje (DBA V2 - MEN Colombia)</strong>.
                        </p>
                    </div>
                    <button onclick="window.print()" style="background: #F1F5F9; border: 1px solid #CBD5E1; color: #334155; padding: 8px 16px; border-radius: 8px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                        <span>🖨️</span> Imprimir Plan de Estudio
                    </button>
                </div>

                <!-- Controles de Selección -->
                <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px; background: #F8FAFC; padding: 18px; border-radius: 12px; border: 1px solid #E2E8F0; align-items: center;">
                    <div>
                        <label style="display: block; font-size: 0.85rem; font-weight: 800; color: #334155; margin-bottom: 6px;">Seleccionar Grado o Ciclo:</label>
                        <select id="select-tutor-malla-grado" onchange="renderizarMallaTutorHomeSchool()" style="width: 100%; padding: 10px 14px; border: 2px solid #3B82F6; border-radius: 8px; font-weight: 800; font-size: 0.95rem; background: white; color: #1E293B;">
                            <optgroup label="Primaria">
                                <option value="1">1° de Primaria</option>
                                <option value="2">2° de Primaria</option>
                                <option value="3">3° de Primaria</option>
                                <option value="4">4° de Primaria</option>
                                <option value="5">5° de Primaria</option>
                            </optgroup>
                            <optgroup label="Secundaria">
                                <option value="6">6° de Secundaria</option>
                                <option value="7" selected>7° de Secundaria</option>
                                <option value="8">8° de Secundaria</option>
                                <option value="9">9° de Secundaria</option>
                            </optgroup>
                            <optgroup label="Media">
                                <option value="10">10° Media Vocacional</option>
                                <option value="11">11° Media Vocacional (Saber 11)</option>
                            </optgroup>
                            <optgroup label="Educación de Adultos / Validación">
                                <option value="Ciclo I">Ciclo I (1°, 2°, 3°)</option>
                                <option value="Ciclo II">Ciclo II (4°, 5°)</option>
                                <option value="Ciclo III">Ciclo III (6°, 7°)</option>
                                <option value="Ciclo IV">Ciclo IV (8°, 9°)</option>
                                <option value="Ciclo V">Ciclo V (10°)</option>
                                <option value="Ciclo VI">Ciclo VI (11°)</option>
                            </optgroup>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 0.85rem; font-weight: 800; color: #334155; margin-bottom: 6px;">Materia Fundamental:</label>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button class="tutor-materia-pill active" data-materia="Naturales" onclick="seleccionarMateriaTutorMalla('Naturales')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 2px solid #2563EB; background: #EFF6FF; color: #1D4ED8;">🌿 Ciencias Naturales</button>
                            <button class="tutor-materia-pill" data-materia="Matematicas" onclick="seleccionarMateriaTutorMalla('Matematicas')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 1.5px solid #CBD5E1; background: white; color: #475569;">📐 Matemáticas</button>
                            <button class="tutor-materia-pill" data-materia="Lenguaje" onclick="seleccionarMateriaTutorMalla('Lenguaje')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 1.5px solid #CBD5E1; background: white; color: #475569;">📖 Lengua Castellana</button>
                            <button class="tutor-materia-pill" data-materia="Sociales" onclick="seleccionarMateriaTutorMalla('Sociales')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 1.5px solid #CBD5E1; background: white; color: #475569;">🌍 Ciencias Sociales</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contenedor del Detalle de la Malla -->
            <div id="tutor-malla-detalle-container">
                <!-- Renderizado dinámico desde app.js -->
            </div>
        </div>
    </div>
</div>

<!-- PANEL DE ESTUDIANTE -->
<div id="student-dashboard-container" style="display: none; height: 100vh; overflow-y: auto; background-color: #F8FAFC;">
    <!-- Header Superior Siempre Visible -->
    <header style="background: white; border-bottom: 1px solid #E5E7EB; padding: 12px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 100; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 12px;">
            <div style="font-weight: 800; color: #1E293B; font-size: 1.1rem; display: flex; align-items: center; gap: 10px;">
                <span id="header-student-avatar" style="font-size: 1.6rem; background: #EEF2FF; padding: 4px 8px; border-radius: 50%; border: 1px solid #C7D2FE; display: inline-block;">🚀</span> 
                <span id="header-student-name">Estudiante</span>
            </div>
            <div style="background: #E0E7FF; color: #4338CA; padding: 4px 12px; border-radius: 12px; font-weight: bold; font-size: 0.9rem; display: flex; align-items: center; gap: 4px;">
                🎓 <span id="header-student-grade">Ciclo VI</span>
            </div>
        </div>
        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <button onclick="abrirModalPerfilEstudiante()" style="background: linear-gradient(135deg, #6366F1, #4F46E5); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; font-size: 0.9rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(99,102,241,0.3); transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.03)'" onmouseout="this.style.transform='scale(1)'">
                🎨 Mi Perfil
            </button>
            <div style="background: linear-gradient(135deg, #10B981, #059669); padding: 8px 18px; border-radius: 20px; font-size: 1rem; font-weight: 800; color: white; box-shadow: 0 4px 6px rgba(16, 185, 129, 0.2); display: flex; align-items: center; gap: 6px;">
                🌟 <span id="student-score-display">0</span> Puntos
            </div>
            <button onclick="location.reload()" style="background: #EF4444; color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: bold; cursor: pointer; font-family: Inter, sans-serif;">Cerrar Sesión</button>
        </div>
    </header>
    <!-- Hero Banner -->
    <div style="background: linear-gradient(135deg, #1E40AF, #2563EB, #3B82F6); padding: 35px 30px; display: flex; align-items: center; justify-content: flex-start; gap: 25px; border-bottom: 5px solid #60A5FA; flex-wrap: wrap;">
        <div style="background: white; padding: 10px; border-radius: 16px; box-shadow: 0 8px 20px rgba(0,0,0,0.15); display: flex; align-items: center; justify-content: center;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 80px; width: auto; object-fit: contain;">
        </div>
        <div onclick="abrirModalPerfilEstudiante()" style="cursor: pointer; position: relative; font-size: 3.2rem; background: white; width: 80px; height: 80px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 16px rgba(0,0,0,0.2); border: 3px solid #FCD34D; transition: transform 0.2s;" title="Haz clic para personalizar tu avatar y nombre" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'">
            <span id="student-avatar-hero">🚀</span>
            <div style="position: absolute; bottom: -2px; right: -2px; background: #F59E0B; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">✏️</div>
        </div>
        <div style="text-align: left; flex: 1; min-width: 250px;">
            <h1 id="student-welcome-name" style="color: white; margin: 0; font-size: 2.2rem; font-weight: 900; letter-spacing: -0.5px;">¡Hola, Estudiante!</h1>
            <p id="student-welcome-subtitle" style="color: #DBEAFE; margin: 6px 0 0 0; font-weight: 500; font-size: 1.1rem;">Bienvenido a tu panel de aprendizaje STEAM. Elige una asignatura para comenzar.</p>
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 14px;">
                <div id="student-grade-badge" style="display: inline-block; background: rgba(255, 255, 255, 0.2); border: 1px solid rgba(255,255,255,0.4); padding: 5px 14px; border-radius: 20px; color: white; font-weight: bold; font-size: 0.9rem; letter-spacing: 0.5px;">
                    🎓 Grado / Ciclo
                </div>
                <button onclick="abrirModalPerfilEstudiante()" style="background: #F59E0B; color: #78350F; border: none; padding: 5px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; box-shadow: 0 2px 8px rgba(245,158,11,0.3); display: flex; align-items: center; gap: 5px; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    ✏️ Personalizar Nombre y Avatar
                </button>
            </div>

            <!-- Barra de Progreso de Nivel y Puntos Acumulados del Estudiante -->
            <div style="margin-top: 15px; background: rgba(15, 23, 42, 0.45); border: 1px solid rgba(255, 255, 255, 0.25); border-radius: 14px; padding: 12px 18px; max-width: 550px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; flex-wrap: wrap; gap: 6px;">
                    <span id="student-xp-level-name" style="color: #FDE047; font-weight: 800; font-size: 0.92rem; letter-spacing: 0.3px;">🌱 Nivel 1: Novato STEAM</span>
                    <span id="student-xp-progress-text" style="color: #F8FAFC; font-weight: 700; font-size: 0.85rem;">0 / 300 XP (0%)</span>
                </div>
                <div style="background: rgba(255, 255, 255, 0.2); height: 12px; border-radius: 10px; overflow: hidden; position: relative; border: 1px solid rgba(255, 255, 255, 0.3);">
                    <div id="student-xp-progress-bar" style="background: linear-gradient(90deg, #10B981, #34D399, #38BDF8); height: 100%; width: 10%; border-radius: 10px; transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1); box-shadow: 0 0 10px rgba(52, 211, 153, 0.6);"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contenedor Principal (Grid de Materias & Malla DBA Estudiante) -->
    <div id="student-main-content" style="padding: 30px; max-width: 1200px; margin: 0 auto;">
        
        <!-- Pestañas de Navegación del Estudiante / Validación / Home School -->
        <div id="student-nav-tabs" style="display: none; gap: 10px; margin-bottom: 25px; border-bottom: 2px solid #E2E8F0; padding-bottom: 12px; flex-wrap: wrap;">
            <button id="btn-tab-estudiante-materias" onclick="cambiarTabEstudiante('materias')" style="background: #2563EB; color: white; border: none; padding: 12px 22px; border-radius: 10px; font-weight: 800; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 10px rgba(37,99,235,0.25); transition: 0.2s;">
                <span>🚀</span> Mis Asignaturas y Misiones
            </button>
            <button id="btn-tab-estudiante-malla" onclick="cambiarTabEstudiante('malla')" style="background: white; color: #475569; border: 1.5px solid #CBD5E1; padding: 12px 22px; border-radius: 10px; font-weight: 800; font-size: 0.95rem; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: 0.2s;">
                <span>📚</span> Mi Malla Curricular DBA (Estándares Oficiales)
            </button>
        </div>

        <!-- Vista 1: Mis Asignaturas y Misiones -->
        <div id="vista-estudiante-materias">
            <!-- Banner de Felicitación / Bonificación (+10% XP) -->
            <div id="banner-bonificacion-alerta" style="display: none; margin-bottom: 25px; border-radius: 16px; padding: 20px; border: 2px solid #34D399; background: linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%); box-shadow: 0 10px 25px rgba(16,185,129,0.15);">
                <!-- Inyectado dinámicamente por JS -->
            </div>

            <!-- Banner de Alerta Disciplinaria / Penalización (Visibilidad Estudiante) -->
            <div id="banner-penalizacion-alerta" style="display: none; margin-bottom: 25px; border-radius: 16px; padding: 20px; border: 2px solid #F87171; background: linear-gradient(135deg, #FEF2F2 0%, #FEE2E2 100%); box-shadow: 0 10px 25px rgba(239,68,68,0.15);">
                <!-- Inyectado dinámicamente por JS -->
            </div>

            <!-- Banner de Estado de Pago (Para Validación y Home School) -->
            <div id="banner-pago-estado" style="display: none; margin-bottom: 25px; border-radius: 12px; padding: 20px; border: 2px solid #E5E7EB; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
                <!-- Inyectado por JS -->
            </div>

            <h2 style="font-weight: 900; color: #111827; margin-bottom: 25px; font-size: 1.8rem; border-left: 5px solid #3B82F6; padding-left: 15px;">Mis Asignaturas Matriculadas</h2>
            
            <div id="student-subjects-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 25px;">
                <!-- Las tarjetas de asignaturas se inyectarán aquí vía JS -->
            </div>
        </div>

        <!-- Vista 2: Explorador Curricular DBA para Estudiante / Validación -->
        <div id="vista-estudiante-malla" style="display: none;">
            <div style="background: white; padding: 25px 30px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid #E5E7EB; margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                    <div>
                        <h2 style="font-size: 1.5rem; font-weight: 900; color: #0F172A; margin: 0; display: flex; align-items: center; gap: 10px;">
                            <span>📚</span> Mi Malla Curricular y Derechos Básicos de Aprendizaje (DBA)
                        </h2>
                        <p style="color: #64748B; font-size: 0.95rem; margin: 4px 0 0 0;">
                            Estándares oficiales del <strong>MEN Colombia</strong> que acreditan y certifican tu ciclo o grado académico.
                        </p>
                    </div>
                    <button onclick="window.print()" style="background: #F1F5F9; border: 1px solid #CBD5E1; color: #334155; padding: 8px 16px; border-radius: 8px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                        <span>🖨️</span> Imprimir Mi Plan de Estudios
                    </button>
                </div>

                <!-- Controles de Selección Estudiante -->
                <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px; background: #F8FAFC; padding: 18px; border-radius: 12px; border: 1px solid #E2E8F0; align-items: center;">
                    <div>
                        <label style="display: block; font-size: 0.85rem; font-weight: 800; color: #334155; margin-bottom: 6px;">Grado o Ciclo en Curso:</label>
                        <select id="select-estudiante-malla-grado" onchange="renderizarMallaEstudianteDBA()" style="width: 100%; padding: 10px 14px; border: 2px solid #3B82F6; border-radius: 8px; font-weight: 800; font-size: 0.95rem; background: white; color: #1E293B;">
                            <optgroup label="Validación por Ciclos (Adultos / CLEI)">
                                <option value="Ciclo I">Ciclo I (1°, 2°, 3° Primaria)</option>
                                <option value="Ciclo II">Ciclo II (4°, 5° Primaria)</option>
                                <option value="Ciclo III">Ciclo III (6°, 7° Básica)</option>
                                <option value="Ciclo IV">Ciclo IV (8°, 9° Básica)</option>
                                <option value="Ciclo V">Ciclo V (10° Educación Media)</option>
                                <option value="Ciclo VI" selected>Ciclo VI (11° Bachillerato)</option>
                            </optgroup>
                            <optgroup label="Secundaria Regular">
                                <option value="6">6° de Secundaria</option>
                                <option value="7">7° de Secundaria</option>
                                <option value="8">8° de Secundaria</option>
                                <option value="9">9° de Secundaria</option>
                            </optgroup>
                            <optgroup label="Media Vocacional Regular">
                                <option value="10">10° Media Vocacional</option>
                                <option value="11">11° Media Vocacional (Saber 11)</option>
                            </optgroup>
                            <optgroup label="Básica Primaria Regular">
                                <option value="1">1° de Primaria</option>
                                <option value="2">2° de Primaria</option>
                                <option value="3">3° de Primaria</option>
                                <option value="4">4° de Primaria</option>
                                <option value="5">5° de Primaria</option>
                            </optgroup>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 0.85rem; font-weight: 800; color: #334155; margin-bottom: 6px;">Materia Fundamental:</label>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button class="estudiante-materia-pill active" data-materia="Naturales" onclick="seleccionarMateriaEstudianteMalla('Naturales')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 2px solid #2563EB; background: #EFF6FF; color: #1D4ED8;">🌿 Ciencias Naturales</button>
                            <button class="estudiante-materia-pill" data-materia="Matematicas" onclick="seleccionarMateriaEstudianteMalla('Matematicas')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 1.5px solid #CBD5E1; background: white; color: #475569;">📐 Matemáticas</button>
                            <button class="estudiante-materia-pill" data-materia="Lenguaje" onclick="seleccionarMateriaEstudianteMalla('Lenguaje')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 1.5px solid #CBD5E1; background: white; color: #475569;">📖 Lengua Castellana</button>
                            <button class="estudiante-materia-pill" data-materia="Sociales" onclick="seleccionarMateriaEstudianteMalla('Sociales')" style="padding: 8px 14px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; cursor: pointer; border: 1.5px solid #CBD5E1; background: white; color: #475569;">🌍 Ciencias Sociales</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contenedor del Detalle de la Malla Estudiante -->
            <div id="estudiante-malla-detalle-container">
                <!-- Renderizado dinámico desde app.js -->
            </div>
        </div>
    </div>
        
            <!-- Vista de Asignatura Específica (Gamificada) -->
            <div id="student-subject-view-container" style="display: none; padding: 40px 30px; max-width: 1200px; margin: 0 auto;">
                <button onclick="volverAlGridEstudiante()" style="background: none; border: none; color: #3B82F6; font-weight: bold; cursor: pointer; display: flex; align-items: center; gap: 5px; margin-bottom: 20px;">
                    &larr; Volver a Mis Asignaturas
                </button>
                <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                    <h2 id="student-subject-title" style="font-weight: 900; color: #111827; margin-bottom: 20px; font-size: 2rem; border-left: 5px solid #10B981; padding-left: 15px;">Materia</h2>
                    
                    <div style="background: #F3F4F6; padding: 20px; border-radius: 12px; margin-bottom: 30px; display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
                        <div>
                            <label style="font-weight: bold; color: #374151; display: block; margin-bottom: 5px;">Periodo:</label>
                            <select id="student-select-periodo" style="padding: 10px; border-radius: 8px; border: 1px solid #D1D5DB; font-weight: bold;" onchange="actualizarPlaneacionEstudiante()">
                                <option value="1">Periodo 1</option>
                                <option value="2">Periodo 2</option>
                                <option value="3" selected>Periodo 3</option>
                                <option value="4">Periodo 4</option>
                            </select>
                        </div>
                        <div>
                            <label style="font-weight: bold; color: #374151; display: block; margin-bottom: 5px;">Semana:</label>
                            <select id="student-select-semana" style="padding: 10px; border-radius: 8px; border: 1px solid #D1D5DB; font-weight: bold;" onchange="actualizarPlaneacionEstudiante()">
                                <option value="1">Semana 1</option><option value="2">Semana 2</option><option value="3">Semana 3</option><option value="4">Semana 4</option>
                                <option value="5">Semana 5</option><option value="6">Semana 6</option><option value="7">Semana 7</option><option value="8">Semana 8</option>
                            </select>
                        </div>
                    </div>
                    
                    <div id="student-planeacion-contenido" style="background: #F9FAFB; padding: 15px; border-radius: 8px; border-left: 4px solid #3B82F6; margin-bottom: 30px; display: none;">
                        <!-- Contenido inyectado por JS -->
                    </div>

                    <div id="student-quest-container" style="border: 2px dashed #3B82F6; padding: 25px; border-radius: 12px; background: #EFF6FF;">
                        <h3 style="font-weight: 800; color: #1D4ED8; margin-bottom: 15px;">&iexcl;Personaliza tu Aventura de Aprendizaje!</h3>
                        <p style="color: #1E3A8A; margin-bottom: 20px;">Antes de acceder a la gu&iacute;a de esta semana, configura los par&aacute;metros de tu misi&oacute;n.</p>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                            <div>
                                <label style="font-weight: bold; color: #111827;">Men&uacute; 1: Tu Rol</label>
                                <select id="student-quest-rol" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #93C5FD; margin-top: 5px;">
                                    <option value="">Seleccionar...</option>
                                    <option value="Detective de Misterios">Detective de Misterios</option>
                                    <option value="Explorador Espacial">Explorador Espacial</option>
                                    <option value="Cientifico Loco">Cient&iacute;fico Loco</option>
                                    <option value="Hacker Tecnologico">Hacker Tecnol&oacute;gico</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-weight: bold; color: #111827;">Men&uacute; 2: Ambiente de Trabajo</label>
                                <select id="student-quest-ambiente" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #93C5FD; margin-top: 5px;">
                                    <option value="">Seleccionar...</option>
                                    <option value="Mundo Post-Apocalíptico">Mundo Post-Apocal&iacute;ptico</option>
                                    <option value="Estación Espacial Internacional">Estaci&oacute;n Espacial Internacional</option>
                                    <option value="Expedición en la Selva">Expedici&oacute;n en la Selva</option>
                                    <option value="Laboratorio Secreto Subterráneo">Laboratorio Secreto Subterr&aacute;neo</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-weight: bold; color: #111827;">Men&uacute; 3: Nivel de Desaf&iacute;o</label>
                                <select id="student-quest-nivel" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #93C5FD; margin-top: 5px;">
                                    <option value="">Seleccionar...</option>
                                    <option value="Modo Novato (Fácil)">Modo Novato (F&aacute;cil)</option>
                                    <option value="Modo Supervivencia (Intermedio)">Modo Supervivencia (Intermedio)</option>
                                    <option value="Modo Héroe (Avanzado)">Modo H&eacute;roe (Avanzado)</option>
                                    <option value="Modo Dios (Experto)">Modo Dios (Experto)</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-weight: bold; color: #111827;">Men&uacute; 4: Enfoque de la Tarea</label>
                                <select id="student-quest-enfoque" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #93C5FD; margin-top: 5px;">
                                    <option value="">Seleccionar...</option>
                                    <option value="Resolver un misterio (Indagación)">Resolver un misterio (Indagaci&oacute;n)</option>
                                    <option value="Explicar un fenómeno extraño">Explicar un fen&oacute;meno extra&ntilde;o</option>
                                    <option value="Aplicar la ciencia para sobrevivir">Aplicar la ciencia para sobrevivir</option>
                                    <option value="Desmentir un mito popular (Análisis Crítico)">Desmentir un mito popular (An&aacute;lisis Cr&iacute;tico)</option>
                                </select>
                            </div>
                        </div>

                        <div style="margin-top: 30px; display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                            <button id="student-btn-ingresar-diag" onclick="iniciarDiagnosticoGamificado()" style="background: linear-gradient(135deg, #F59E0B, #D97706); color: white; padding: 14px 28px; border-radius: 30px; border: none; font-weight: 900; font-size: 1.05rem; cursor: pointer; box-shadow: 0 4px 15px rgba(245,158,11,0.35); display: flex; align-items: center; gap: 8px; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.03)'" onmouseout="this.style.transform='scale(1)'">
                                🥚 Diagnóstico Inicial (Gamificado)
                            </button>
                            <button id="student-btn-ingresar-guia" onclick="ingresarAGuia()" style="background: #10B981; color: white; padding: 14px 32px; border-radius: 30px; border: none; font-weight: 800; font-size: 1.05rem; cursor: pointer; box-shadow: 0 4px 15px rgba(16,185,129,0.3); transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.03)'" onmouseout="this.style.transform='scale(1)'">
                                🚀 Crear Guía Semanal Personalizada
                            </button>
                        </div>
                    </div>
                    
                    <div id="student-guide-content" style="display: none; margin-top: 30px; padding: 0; border-radius: 12px; background: #F8FAFC; border: 1px solid #E5E7EB; overflow: hidden; position: relative;">
                        
                        <!-- STICKY HEADER PERSONALIZADO -->
                        <div id="student-guide-sticky-header" style="position: sticky; top: 0; background: linear-gradient(135deg, #1E3A8A, #2563EB, #3B82F6); color: white; padding: 12px 25px; z-index: 100; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 15px rgba(0,0,0,0.15); flex-wrap: wrap; gap: 10px;">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <span id="student-guide-header-avatar" style="font-size: 1.8rem; background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 50%; display: inline-block;">🚀</span>
                                <div>
                                    <div style="font-weight: 800; font-size: 1.15rem; color: white;">
                                        👨‍🎓 <span id="student-guide-header-name" style="color: #FDE047; font-weight: 900;">Estudiante</span>
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 8px; margin-top: 2px;">
                                        <span id="student-guide-header-badge" style="background: rgba(255,255,255,0.2); padding: 2px 10px; border-radius: 12px; font-size: 0.8rem; font-weight: 700; color: #DBEAFE;">Ciclo VI</span>
                                        <span id="student-guide-header-materia" style="font-size: 0.8rem; color: #93C5FD; font-weight: 600;">Ciencias Naturales</span>
                                    </div>
                                </div>
                            </div>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div style="font-weight: 900; font-size: 1.25rem; color: #FCD34D; background: rgba(0,0,0,0.25); padding: 6px 16px; border-radius: 20px; border: 1px solid rgba(253,224,71,0.4); display: flex; align-items: center; gap: 6px;">
                                    🏆 XP: <span id="student-guide-header-xp">0</span>
                                </div>
                                <button onclick="cerrarGuia()" style="background: rgba(239,68,68,0.2); border: 1px solid #EF4444; color: #FECACA; padding: 6px 14px; border-radius: 8px; font-weight: 800; cursor: pointer; font-size: 0.85rem; transition: background 0.2s;" onmouseover="this.style.background='#EF4444'; this.style.color='white';" onmouseout="this.style.background='rgba(239,68,68,0.2)'; this.style.color='#FECACA';">✕ Cerrar Guía</button>
                            </div>
                        </div>

                        <div id="student-guide-inner-content" style="padding: 25px;"></div>
                        <div style="padding: 0 25px 25px 25px;">
                            <button onclick="cerrarGuia()" style="background: none; border: 1px solid #EF4444; color: #EF4444; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer;">Cerrar Gu&iacute;a</button>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- fin student-dashboard-container -->

    </div>

    <!-- Modal de Informe Detallado -->
    <div id="modal-informe-estudiante" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); align-items: center; justify-content: center; z-index: 1000;">
        <div style="background: white; padding: 30px; border-radius: 12px; max-width: 800px; width: 90%; max-height: 90vh; overflow-y: auto;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 id="informe-nombre-estudiante" style="font-weight: 800; font-size: 1.5rem; margin: 0; color: #111827;">Informe Detallado</h3>
                <button onclick="document.getElementById('modal-informe-estudiante').style.display='none'" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6B7280;">&times;</button>
            </div>
            <div id="informe-contenido" style="line-height: 1.6; color: #374151;">
                <!-- El contenido del informe se inyectará aquí -->
            </div>
            <div style="margin-top: 20px; text-align: right;">
                <button onclick="document.getElementById('modal-informe-estudiante').style.display='none'" style="padding: 10px 20px; background: #3B82F6; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Cerrar</button>
            </div>
        </div>
    </div>

    <!-- MODAL ESCANER QR DE REGISTRO INSTITUCIONAL -->
    <div id="modal-scanner-qr" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 10000; padding: 20px;">
        <div style="background: white; border-radius: 20px; max-width: 460px; width: 100%; padding: 25px; position: relative; box-shadow: 0 25px 50px rgba(0,0,0,0.3); text-align: center;">
            <button onclick="detenerEscaneoQR()" style="position: absolute; top: 15px; right: 15px; background: #F1F5F9; border: none; font-size: 1.4rem; cursor: pointer; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #475569;">✕</button>
            <div style="width: 50px; height: 50px; background: #EFF6FF; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px auto; font-size: 1.8rem;">📷</div>
            <h3 style="margin: 0 0 6px 0; color: #1E3A8A; font-weight: 800; font-size: 1.25rem;">Escanear QR de Matrícula</h3>
            <p style="margin: 0 0 15px 0; color: #64748B; font-size: 0.88rem;">Apunta la cámara de tu celular hacia el código QR proyectado en el salón por el docente.</p>
            
            <div id="qr-reader-container" style="width: 100%; min-height: 240px; background: #0F172A; border-radius: 12px; overflow: hidden; display: flex; align-items: center; justify-content: center;">
                <div id="qr-reader" style="width: 100%;"></div>
            </div>
            
            <div style="margin-top: 15px; display: flex; flex-direction: column; gap: 8px;">
                <button type="button" onclick="aplicarCodigoManualQR('ieinstituto2026')" style="background: #DEF7EC; border: 1px solid #31C48D; color: #03543F; padding: 10px 16px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 0.9rem;">
                    🔑 Aplicar Código Oficial Directo (ieinstituto2026)
                </button>
                <button type="button" onclick="detenerEscaneoQR()" style="background: #F3F4F6; border: 1px solid #D1D5DB; color: #4B5563; padding: 8px 14px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.85rem;">
                    Cancelar
                </button>
            </div>
        </div>
    </div>

    <!-- Modal de Auto-Habilitación e Ingreso Inmediato de Estudiantes -->
    <div id="modal-auto-habilitacion" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(6px); align-items: center; justify-content: center; z-index: 9999; padding: 20px;">
        <div style="background: white; border-radius: 16px; padding: 32px; max-width: 480px; width: 100%; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); text-align: center; position: relative; border: 1px solid #E2E8F0;">
            <button onclick="document.getElementById('modal-auto-habilitacion').style.display='none'" style="position: absolute; top: 16px; right: 16px; background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #94A3B8; line-height: 1;">&times;</button>
            <div style="width: 60px; height: 60px; background: #EFF6FF; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px auto; font-size: 2rem; color: #2563EB;">🎓</div>
            <h3 style="font-size: 1.4rem; font-weight: 800; color: #0F172A; margin: 0 0 8px 0;">¡Bienvenido(a) a tu Aula Virtual!</h3>
            <p style="color: #64748B; font-size: 0.95rem; margin: 0 0 20px 0; line-height: 1.4;">Tu documento <strong id="modal-auto-doc-badge" style="color: #2563EB; background: #DBEAFE; padding: 2px 8px; border-radius: 4px;"></strong> está listo. Confirma tus datos para entrar directamente:</p>
            
            <form id="form-auto-habilitacion" onsubmit="return false;" style="display: flex; flex-direction: column; gap: 14px; text-align: left;">
                <div>
                    <label style="font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 4px; display: block;">Nombres y Apellidos:</label>
                    <input type="text" id="auto-nombre-completo" placeholder="Ej. Juan Pérez" style="width: 100%; padding: 12px; border: 1.5px solid #CBD5E1; border-radius: 8px; font-size: 0.95rem; box-sizing: border-box; outline: none;" required>
                </div>
                <div>
                    <label style="font-size: 0.85rem; font-weight: 700; color: #334155; margin-bottom: 4px; display: block;">Ciclo / Grado de Estudio:</label>
                    <select id="auto-ciclo-grado" style="width: 100%; padding: 12px; border: 2px solid #3B82F6; border-radius: 8px; font-size: 0.95rem; font-weight: bold; background: #F8FAFC; color: #1E293B; box-sizing: border-box;">
                        <option value="Ciclo VI">🌙 Ciclo VI (Nocturno / Validación - 11°)</option>
                        <option value="Ciclo V">🌙 Ciclo V (Nocturno / Validación - 10°)</option>
                        <option value="Ciclo IV">🌙 Ciclo IV (Nocturno / Validación - 8°, 9°)</option>
                        <option value="Ciclo III">🌙 Ciclo III (Nocturno / Validación - 6°, 7°)</option>
                        <option value="Ciclo II">🌙 Ciclo II (Nocturno / Validación)</option>
                        <option value="Ciclo I">🌙 Ciclo I (Nocturno / Validación)</option>
                        <option value="6">🏫 Grado 6°</option>
                        <option value="7">🏫 Grado 7°</option>
                        <option value="8">🏫 Grado 8°</option>
                        <option value="9">🏫 Grado 9°</option>
                        <option value="10">🏫 Grado 10°</option>
                        <option value="11">🏫 Grado 11°</option>
                    </select>
                </div>
                <button type="button" id="btn-ejecutar-auto-ingreso" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 14px; border-radius: 8px; font-weight: 800; font-size: 1rem; cursor: pointer; margin-top: 6px; box-shadow: 0 4px 12px rgba(37,99,235,0.3); transition: transform 0.1s, box-shadow 0.1s;">
                    🚀 Entrar a Mi Aula de Clase
                </button>
            </form>
        </div>
    </div>

    <!-- Contenedor Toast Flotante de Puntos XP -->
    <div id="toast-xp-container" style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 999999; display: none; pointer-events: none;">
        <div id="toast-xp-content" style="background: linear-gradient(135deg, #065F46, #047857); color: white; padding: 12px 24px; border-radius: 30px; font-weight: 800; font-size: 1rem; box-shadow: 0 10px 25px rgba(4,120,87,0.4); border: 2px solid #34D399; display: flex; align-items: center; gap: 10px; animation: slideDownToast 0.3s ease-out;">
            ✨ +30 XP | ¡Misión Cumplida!
        </div>
    </div>

    <!-- Modal de Notificación Disciplinaria y Sanción de Puntos (Estudiante) -->
    <div id="modal-notificacion-disciplinaria" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 100000; padding: 20px;">
        <div style="background: linear-gradient(180deg, #FFFFFF 0%, #FEF2F2 100%); border-radius: 24px; padding: 35px 30px; max-width: 520px; width: 100%; box-shadow: 0 25px 60px -15px rgba(220, 38, 38, 0.5), 0 0 0 2px rgba(239, 68, 68, 0.4); text-align: center; position: relative; animation: popInAlert 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
            
            <!-- Icono animado -->
            <div style="width: 76px; height: 76px; background: linear-gradient(135deg, #FEE2E2, #FECACA); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px auto; font-size: 2.5rem; box-shadow: 0 8px 20px rgba(239,68,68,0.25); border: 2px solid #F87171;">
                🚨
            </div>

            <h3 style="font-size: 1.5rem; font-weight: 900; color: #991B1B; margin: 0 0 6px 0; letter-spacing: -0.5px;">
                Notificación Disciplinaria
            </h3>
            <p style="color: #7F1D1D; font-size: 0.95rem; margin: 0 0 20px 0; font-weight: 600;">
                Ajuste Formativo en tu Puntaje de Convivencia STEAM
            </p>

            <!-- Tarjeta de la Infracción -->
            <div style="background: white; border: 1.5px solid #FCA5A5; border-radius: 16px; padding: 18px; text-align: left; margin-bottom: 20px; box-shadow: 0 4px 12px rgba(239,68,68,0.08);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px dashed #FECACA; padding-bottom: 8px;">
                    <span style="font-size: 0.85rem; font-weight: 800; color: #991B1B; text-transform: uppercase;">Infracción Registrada:</span>
                    <span id="modal-sancion-descuento-badge" style="background: #EF4444; color: white; padding: 3px 10px; border-radius: 20px; font-weight: 900; font-size: 0.85rem; box-shadow: 0 2px 6px rgba(239,68,68,0.3);">-10% XP</span>
                </div>
                
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                    <span id="modal-sancion-icono" style="font-size: 1.8rem;">⚡</span>
                    <div>
                        <div id="modal-sancion-motivo-texto" style="font-size: 1.05rem; font-weight: 800; color: #1E293B;">Indisciplina en clase</div>
                        <div id="modal-sancion-fecha-texto" style="font-size: 0.8rem; color: #64748B;">Fecha y hora del registro</div>
                    </div>
                </div>

                <!-- Puntos descontados -->
                <div style="background: #FEF2F2; border-radius: 10px; padding: 10px 14px; display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-size: 0.85rem; color: #7F1D1D; font-weight: 700;">Puntos descontados:</span>
                    <span id="modal-sancion-puntos-descontados" style="font-size: 1rem; font-weight: 900; color: #DC2626;">-50 XP</span>
                </div>
            </div>

            <!-- Mensaje Reflexivo -->
            <p style="color: #4B5563; font-size: 0.88rem; line-height: 1.5; margin: 0 0 22px 0; background: rgba(255,255,255,0.7); padding: 12px; border-radius: 10px; border-left: 4px solid #EF4444; text-align: left;">
                💡 <strong>Reflexión Pedagógica:</strong> En el aula STEAM el respeto mutuo, la atención y el cuidado de los acuerdos de convivencia son fundamentales. Aprovecha esta oportunidad formativa para reflexionar y recuperar tu puntaje con las próximas misiones académicas.
            </p>

            <!-- Botón de Compromiso -->
            <button onclick="confirmarLecturaSancion()" style="background: linear-gradient(135deg, #DC2626, #B91C1C); color: white; border: none; width: 100%; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 1rem; cursor: pointer; box-shadow: 0 6px 18px rgba(220,38,38,0.35); transition: transform 0.15s, box-shadow 0.15s;" onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform='scale(1)'">
                🤝 Entendido y Me Comprometo a Mejorar
            </button>
        </div>
    </div>

    <script src="diagnostico_nocturno.js?v=20260806_v30"></script>
    <script src="app.js?v=20260806_v30"></script>
    <script>
        // --- BLINDAJE DE PROPIEDAD INTELECTUAL Y SEGURIDAD ---
        (function() {
            // Advertencia disuasiva en consola de desarrollador
            console.log("%c🛡️ ADVERTENCIA LEGAL DE PROPIEDAD INTELECTUAL - PEIDAGOGOS STEAM", "color: #1D4ED8; font-size: 15px; font-weight: 900;");
            console.log("%cEl software, mallas curriculares DBA, guías didácticas, preguntas ICFES y algoritmos de esta plataforma están registrados y protegidos por leyes de Propiedad Intelectual y Derechos de Autor (Ley 23 de 1982 / DNDA). Queda expresamente prohibida la copia, reproducción, scraping, distribución o ingeniería inversa total o parcial sin autorización escrita de Peidagogos STEAM.", "font-size: 11px; color: #4B5563; line-height: 1.5;");

            // Deshabilitar clic derecho en áreas pedagógicas protegidas
            document.addEventListener('contextmenu', function(e) {
                const target = e.target;
                if (target && (target.closest('.mega-guide-container') || target.closest('#student-guide-content') || target.closest('#student-planeacion-contenido') || target.closest('#vista-estudiante-malla') || target.closest('#docente-dashboard-container') || target.closest('#tutor-dashboard-container'))) {
                    // Permitir en inputs o textareas donde el estudiante escribe
                    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;
                    e.preventDefault();
                    if (window.mostrarToastXP) {
                        window.mostrarToastXP(0, '🛡️ Contenido protegido por derechos de autor - Peidagogos STEAM');
                    }
                }
            }, false);

            // Bloquear atajos comunes de clonación de código (Ctrl+U, Ctrl+S)
            document.addEventListener('keydown', function(e) {
                // Ctrl+U (Ver código fuente) o Ctrl+S (Guardar página)
                if ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U' || e.key === 's' || e.key === 'S')) {
                    e.preventDefault();
                    return false;
                }
            }, false);
        })();

        // Función global para navegación SPA instantánea y sin scroll residual
        function mostrarVista(id) {
            const vistas = [
                'login-screen-container',
                'register-screen-container',
                'docente-dashboard-container',
                'dashboard-screen-container',
                'student-dashboard-container',
                'tutor-dashboard-container'
            ];
            
            vistas.forEach(vista => {
                const el = document.getElementById(vista);
                if (el) {
                    el.style.display = 'none';
                    el.scrollTop = 0;
                }
            });
            
            const target = document.getElementById(id);
            if (target) {
                if (id === 'login-screen-container') {
                    target.style.display = 'grid';
                } else if (id === 'register-screen-container') {
                    target.style.display = 'flex';
                } else {
                    target.style.display = 'block';
                }
                target.scrollTop = 0;
            }
            window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
            if (document.documentElement) document.documentElement.scrollTop = 0;
        }

        // --- CONTROLADOR DE ESCANER QR PARA MATRÍCULA INSTITUCIONAL ---
        let html5QrScannerInstance = null;

        function iniciarEscaneoQRRegistro() {
            const modal = document.getElementById('modal-scanner-qr');
            if (modal) modal.style.display = 'flex';

            if (typeof Html5Qrcode !== 'undefined') {
                try {
                    if (html5QrScannerInstance) {
                        html5QrScannerInstance.stop().catch(() => {}).finally(() => {
                            html5QrScannerInstance = null;
                            arrancarCamaraQR();
                        });
                    } else {
                        arrancarCamaraQR();
                    }
                } catch(e) {
                    console.warn("Error inicializando Html5Qrcode:", e);
                }
            }
        }

        function arrancarCamaraQR() {
            html5QrScannerInstance = new Html5Qrcode("qr-reader");
            const config = { fps: 10, qrbox: { width: 220, height: 220 } };
            html5QrScannerInstance.start(
                { facingMode: "environment" },
                config,
                (decodedText, decodedResult) => {
                    console.log("QR Detectado:", decodedText);
                    procesarTextoQRDetectado(decodedText);
                },
                (errorMessage) => {
                    // scanning in progress...
                }
            ).catch(err => {
                console.warn("No se pudo iniciar cámara para QR:", err);
            });
        }

        function procesarTextoQRDetectado(texto) {
            detenerEscaneoQR();
            if (texto.includes('ieinstituto2026') || texto.includes('codigo=') || texto.includes('registro=instituto')) {
                aplicarCodigoManualQR('ieinstituto2026');

                // Si trae grupo en la URL
                try {
                    const parsedUrl = new URL(texto);
                    const grupo = parsedUrl.searchParams.get('grupo');
                    if (grupo && document.getElementById('registro-grupo')) {
                        document.getElementById('registro-grupo').value = decodeURIComponent(grupo);
                        actualizarMaterias();
                    }
                } catch(e) {}
            } else {
                aplicarCodigoManualQR(texto.trim());
            }
        }

        function aplicarCodigoManualQR(cod) {
            const codInput = document.getElementById('reg-codigo-institucional');
            if (codInput) codInput.value = cod || 'ieinstituto2026';

            const regIE = document.getElementById('reg-ie');
            if (regIE) {
                regIE.value = 'InstitutoMontenegro';
                toggleIEOptions();
            }

            const fb = document.getElementById('qr-feedback-status');
            if (fb) {
                fb.innerHTML = '✅ <strong>¡Código oficial verificado por QR!</strong> Matrícula Gratuita ($0 COP).';
                fb.style.color = '#059669';
                fb.style.fontWeight = 'bold';
            }

            detenerEscaneoQR();
        }

        function detenerEscaneoQR() {
            const modal = document.getElementById('modal-scanner-qr');
            if (modal) modal.style.display = 'none';
            if (html5QrScannerInstance) {
                html5QrScannerInstance.stop().catch(() => {}).finally(() => {
                    html5QrScannerInstance = null;
                });
            }
        }

        // Auto-detección de QR por URL al ingresar a la plataforma
        window.addEventListener('DOMContentLoaded', () => {
            const params = new URLSearchParams(window.location.search);
            const regParam = params.get('registro');
            const codParam = params.get('codigo');
            const grupoParam = params.get('grupo');

            if (regParam === 'instituto' || codParam === 'ieinstituto2026') {
                mostrarVista('register-screen-container');

                const regIE = document.getElementById('reg-ie');
                if (regIE) {
                    regIE.value = 'InstitutoMontenegro';
                    toggleIEOptions();
                }

                const codInput = document.getElementById('reg-codigo-institucional');
                if (codInput) codInput.value = codParam || 'ieinstituto2026';

                if (grupoParam && document.getElementById('registro-grupo')) {
                    document.getElementById('registro-grupo').value = decodeURIComponent(grupoParam);
                    actualizarMaterias();
                }

                const fb = document.getElementById('qr-feedback-status');
                if (fb) {
                    fb.innerHTML = '✅ <strong>Código QR verificado con éxito:</strong> IE Instituto Montenegro ($0 COP).';
                    fb.style.color = '#059669';
                    fb.style.fontWeight = 'bold';
                }
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <script>mermaid.initialize({startOnLoad:true});</script>
    
    <!-- Modal Ranking Global -->
    <div id="modal-ranking-global" style="display: none; position: fixed; inset: 0; background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(10px); align-items: center; justify-content: center; z-index: 2000; padding: 20px;">
        <div style="background: white; border-radius: 20px; max-width: 850px; width: 100%; max-height: 90vh; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); display: flex; flex-direction: column;">
            <div style="background: linear-gradient(90deg, #1E3A8A, #3B82F6); padding: 25px 30px; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <span style="font-size: 2.5rem;">🏆</span>
                    <div>
                        <h2 style="color: white; margin: 0; font-weight: 900; font-size: 1.8rem; letter-spacing: 1px;">Salón de la Fama</h2>
                        <p style="color: #93C5FD; margin: 5px 0 0 0; font-weight: 600;">Clasificación de Estudiantes (XP)</p>
                    </div>
                </div>
                <button onclick="cerrarRankingGlobal()" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; font-size: 1.2rem; font-weight: bold; transition: background 0.2s;">✕</button>
            </div>
            
            <div style="padding: 20px; background: rgba(255, 255, 255, 0.95); flex: 1; overflow-y: auto;">
                <table style="width: 100%; border-collapse: separate; border-spacing: 0 10px;">
                    <thead>
                        <tr>
                            <th style="padding: 10px 15px; text-align: center; color: #6B7280; font-weight: 800; border-bottom: 2px solid #E5E7EB; width: 60px;">Pos</th>
                            <th style="padding: 10px 15px; text-align: left; color: #6B7280; font-weight: 800; border-bottom: 2px solid #E5E7EB;">Estudiante</th>
                            <th style="padding: 10px 15px; text-align: center; color: #6B7280; font-weight: 800; border-bottom: 2px solid #E5E7EB;">Grupo</th>
                            <th style="padding: 10px 15px; text-align: right; color: #6B7280; font-weight: 800; border-bottom: 2px solid #E5E7EB;">Puntos XP</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-ranking-body">
                        <!-- Inyectado por JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- MODAL PASARELA DE PAGO SEGURA -->
    <div id="modal-pasarela-pago" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 3000; padding: 20px;">
        <div style="background: white; border-radius: 20px; max-width: 580px; width: 100%; max-height: 95vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); border: 1px solid #E2E8F0;">
            
            <!-- Header Pasarela -->
            <div style="background: linear-gradient(135deg, #1E3A8A, #2563EB); color: white; padding: 25px 30px; display: flex; justify-content: space-between; align-items: center; border-top-left-radius: 19px; border-top-right-radius: 19px;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="background: rgba(255,255,255,0.2); width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">🔒</div>
                    <div>
                        <h3 style="margin: 0; font-size: 1.35rem; font-weight: 900; letter-spacing: 0.5px;">Pasarela de Pago Segura</h3>
                        <p style="margin: 3px 0 0 0; font-size: 0.8rem; color: #93C5FD; font-weight: 600;">Peidagogos STEAM • Cifrado SSL 256-bit</p>
                    </div>
                </div>
                <button onclick="cerrarPasarelaPago()" style="background: rgba(255,255,255,0.15); border: none; color: white; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; font-size: 1.2rem; font-weight: bold; transition: 0.2s;">✕</button>
            </div>

            <div style="padding: 25px 30px;">
                <!-- Resumen de Pago -->
                <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 16px 20px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-size: 0.8rem; color: #64748B; font-weight: 700; text-transform: uppercase;">Concepto</div>
                        <div id="pago-concepto-texto" style="font-weight: 800; color: #1E293B; font-size: 1.05rem; margin-top: 2px;">Matrícula Estudiante</div>
                        <div id="pago-documento-texto" style="font-size: 0.85rem; color: #64748B; margin-top: 2px;">Doc: --</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 0.8rem; color: #64748B; font-weight: 700; text-transform: uppercase;">Total a Pagar</div>
                        <div id="pago-monto-texto" style="font-size: 1.5rem; font-weight: 900; color: #059669; margin-top: 2px;">$50.000 COP</div>
                    </div>
                </div>

                <!-- Selector de Métodos de Pago (Tabs) -->
                <label style="font-weight: 800; color: #1E293B; font-size: 0.9rem; display: block; margin-bottom: 10px;">Selecciona tu Método de Pago:</label>
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 20px;">
                    <button type="button" class="metodo-pago-tab active" data-metodo="pse" onclick="seleccionarMetodoPago('pse')" style="padding: 10px 6px; border: 2px solid #2563EB; background: #EFF6FF; border-radius: 10px; font-weight: 800; font-size: 0.75rem; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 4px; color: #1D4ED8;">
                        <span style="font-size: 1.2rem;">⚡</span> PSE
                    </button>
                    <button type="button" class="metodo-pago-tab" data-metodo="tarjeta" onclick="seleccionarMetodoPago('tarjeta')" style="padding: 10px 6px; border: 1px solid #CBD5E1; background: white; border-radius: 10px; font-weight: 700; font-size: 0.75rem; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 4px; color: #475569;">
                        <span style="font-size: 1.2rem;">💳</span> Tarjeta
                    </button>
                    <button type="button" class="metodo-pago-tab" data-metodo="nequi" onclick="seleccionarMetodoPago('nequi')" style="padding: 10px 6px; border: 1px solid #CBD5E1; background: white; border-radius: 10px; font-weight: 700; font-size: 0.75rem; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 4px; color: #475569;">
                        <span style="font-size: 1.2rem;">📱</span> Nequi / Davi
                    </button>
                    <button type="button" class="metodo-pago-tab" data-metodo="efecty" onclick="seleccionarMetodoPago('efecty')" style="padding: 10px 6px; border: 1px solid #CBD5E1; background: white; border-radius: 10px; font-weight: 700; font-size: 0.75rem; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 4px; color: #475569;">
                        <span style="font-size: 1.2rem;">🏢</span> Efecty / Corresp
                    </button>
                </div>

                <!-- Formulario PSE -->
                <div id="pago-form-pse" class="pago-form-seccion" style="display: flex; flex-direction: column; gap: 12px;">
                    <div>
                        <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">Banco emisor:</label>
                        <select id="pse-banco" style="width: 100%; padding: 10px; border: 1px solid #CBD5E1; border-radius: 8px; font-weight: 600;">
                            <option value="Bancolombia">Bancolombia</option>
                            <option value="Nequi">Nequi</option>
                            <option value="Davivienda">Davivienda / Daviplata</option>
                            <option value="Banco de Bogota">Banco de Bogotá</option>
                            <option value="BBVA Colombia">BBVA Colombia</option>
                            <option value="Banco Caja Social">Banco Caja Social</option>
                            <option value="Scotiabank Colpatria">Scotiabank Colpatria</option>
                            <option value="Banco Agrario">Banco Agrario</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">Correo registrado en PSE:</label>
                        <input type="email" id="pse-email" placeholder="ejemplo@correo.com" value="usuario.pago@peidagogos.com" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px;">
                    </div>
                </div>

                <!-- Formulario Tarjeta -->
                <div id="pago-form-tarjeta" class="pago-form-seccion" style="display: none; flex-direction: column; gap: 12px;">
                    <div>
                        <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">Número de Tarjeta (Débito o Crédito):</label>
                        <input type="text" id="card-number" placeholder="4500 •••• •••• 1234" maxlength="19" value="4500 1234 5678 9012" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-family: monospace; font-size: 1rem;">
                    </div>
                    <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 10px;">
                        <div>
                            <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">Titular:</label>
                            <input type="text" id="card-name" placeholder="Nombre completo" value="Tutor Responsable" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px;">
                        </div>
                        <div>
                            <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">Vence:</label>
                            <input type="text" id="card-exp" placeholder="MM/AA" maxlength="5" value="12/28" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; text-align: center;">
                        </div>
                        <div>
                            <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">CVV:</label>
                            <input type="password" id="card-cvv" placeholder="•••" maxlength="4" value="888" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; text-align: center;">
                        </div>
                    </div>
                </div>

                <!-- Formulario Nequi -->
                <div id="pago-form-nequi" class="pago-form-seccion" style="display: none; flex-direction: column; gap: 12px;">
                    <div>
                        <label style="font-size: 0.8rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">Número de Celular Nequi / Daviplata:</label>
                        <input type="tel" id="nequi-cel" placeholder="300 123 4567" value="310 987 6543" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 1rem;">
                    </div>
                    <div style="background: #F1F5F9; border-radius: 8px; padding: 10px 14px; font-size: 0.85rem; color: #475569;">
                        📲 Recibirás una notificación en tu celular para autorizar la transacción en menos de 5 minutos.
                    </div>
                </div>

                <!-- Formulario Efecty -->
                <div id="pago-form-efecty" class="pago-form-seccion" style="display: none; flex-direction: column; gap: 12px;">
                    <div style="background: #FEF3C7; border: 1px solid #FCD34D; border-radius: 8px; padding: 12px 14px; font-size: 0.85rem; color: #92400E;">
                        🏢 <strong>Convenio Nacional Peidagogos STEAM: #110542</strong><br>
                        Presenta tu número de documento en cualquier punto Efecty, Baloto o Corresponsal Bancolombia.
                    </div>
                </div>

                <!-- Feedback de Pago y Spinner -->
                <div id="pago-feedback-msg" style="margin-top: 15px; padding: 12px; border-radius: 8px; font-weight: bold; font-size: 0.9rem; display: none; text-align: center;"></div>

                <!-- Botones de Acción -->
                <div style="margin-top: 25px; display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" onclick="cerrarPasarelaPago()" style="padding: 12px 20px; background: #F1F5F9; border: 1px solid #CBD5E1; color: #475569; border-radius: 10px; font-weight: 700; cursor: pointer;">Cancelar</button>
                    <button type="button" id="btn-confirmar-pago-pasarela" onclick="ejecutarPagoPasarela()" style="padding: 12px 28px; background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; border-radius: 10px; font-weight: 900; font-size: 1rem; cursor: pointer; box-shadow: 0 4px 15px rgba(16,185,129,0.35); display: flex; align-items: center; gap: 8px;">
                        <span>🔒</span> Pagar Ahora
                    </button>
                </div>
            </div>

        </div>
    </div>

    <!-- Modal Personalización de Perfil de Estudiante -->
    <div id="modal-perfil-estudiante" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 2500; padding: 20px;">
        <div style="background: white; border-radius: 20px; max-width: 550px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4); border: 1px solid #E2E8F0;">
            <!-- Header Modal -->
            <div style="background: linear-gradient(135deg, #1E3A8A, #3B82F6); padding: 20px 25px; color: white; display: flex; justify-content: space-between; align-items: center; border-radius: 20px 20px 0 0;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.8rem;">🎨</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800;">Personalizar Mi Perfil STEAM</h3>
                        <p style="margin: 2px 0 0 0; font-size: 0.85rem; color: #BFDBFE;">Tu nombre y avatar aparecerán en todas tus guías y retos.</p>
                    </div>
                </div>
                <button onclick="cerrarModalPerfilEstudiante()" style="background: rgba(255,255,255,0.2); border: none; color: white; font-size: 1.4rem; cursor: pointer; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">&times;</button>
            </div>

            <!-- Body Modal -->
            <div style="padding: 25px;">
                <!-- Avatar Selector -->
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: 800; color: #1E293B; font-size: 0.95rem; display: block; margin-bottom: 8px;">Elige tu Avatar STEAM:</label>
                    <div id="grid-selector-avatar" style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-bottom: 10px;">
                        <!-- Opciones de avatar -->
                        <button type="button" class="avatar-opt-btn" data-avatar="🚀" onclick="seleccionarAvatarPerfil('🚀')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #3B82F6; background: #EFF6FF; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🚀</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🔬" onclick="seleccionarAvatarPerfil('🔬')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🔬</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🧬" onclick="seleccionarAvatarPerfil('🧬')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🧬</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="⚡" onclick="seleccionarAvatarPerfil('⚡')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">⚡</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🌿" onclick="seleccionarAvatarPerfil('🌿')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🌿</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🤖" onclick="seleccionarAvatarPerfil('🤖')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🤖</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🦉" onclick="seleccionarAvatarPerfil('🦉')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🦉</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="💡" onclick="seleccionarAvatarPerfil('💡')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">💡</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🎨" onclick="seleccionarAvatarPerfil('🎨')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🎨</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🛸" onclick="seleccionarAvatarPerfil('🛸')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🛸</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🦖" onclick="seleccionarAvatarPerfil('🦖')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🦖</button>
                        <button type="button" class="avatar-opt-btn" data-avatar="🏆" onclick="seleccionarAvatarPerfil('🏆')" style="font-size: 1.8rem; padding: 10px; border: 2px solid #E2E8F0; background: #F8FAFC; border-radius: 12px; cursor: pointer; transition: all 0.2s;">🏆</button>
                    </div>
                    <input type="hidden" id="perfil-avatar-selected" value="🚀">
                </div>

                <!-- Nombres y Apellidos -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                    <div>
                        <label style="font-size: 0.85rem; font-weight: 700; color: #475569; display: block; margin-bottom: 5px;">Tu Nombre (o Nombres):</label>
                        <input type="text" id="perfil-nombre-input" placeholder="Ej: Juan Carlos" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-weight: 600; font-size: 0.95rem; box-sizing: border-box;">
                    </div>
                    <div>
                        <label style="font-size: 0.85rem; font-weight: 700; color: #475569; display: block; margin-bottom: 5px;">Tus Apellidos:</label>
                        <input type="text" id="perfil-apellidos-input" placeholder="Ej: Perez Gómez" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-weight: 600; font-size: 0.95rem; box-sizing: border-box;">
                    </div>
                </div>

                <!-- Grado / Ciclo -->
                <div style="margin-bottom: 15px;">
                    <label style="font-size: 0.85rem; font-weight: 700; color: #475569; display: block; margin-bottom: 5px;">Grado / Ciclo Educativo:</label>
                    <select id="perfil-grado-ciclo-select" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-weight: 600; font-size: 0.95rem; box-sizing: border-box; background: white;">
                        <option value="Ciclo VI">Ciclo VI (Grado 11° - Educación Nocturna / Validación)</option>
                        <option value="Ciclo V">Ciclo V (Grado 10° - Educación Nocturna / Validación)</option>
                        <option value="Ciclo IV">Ciclo IV (Grados 8° y 9° - Educación Nocturna / Validación)</option>
                        <option value="Ciclo III">Ciclo III (Grados 6° y 7° - Educación Nocturna / Validación)</option>
                        <option value="Ciclo II">Ciclo II (Grados 4° y 5° - Educación Nocturna / Validación)</option>
                        <option value="Ciclo I">Ciclo I (Grados 1°, 2° y 3° - Educación Nocturna / Validación)</option>
                        <option value="6">Grado 6° Regular</option>
                        <option value="7">Grado 7° Regular</option>
                        <option value="8">Grado 8° Regular</option>
                        <option value="9">Grado 9° Regular</option>
                        <option value="10">Grado 10° Regular</option>
                        <option value="11">Grado 11° Regular</option>
                    </select>
                </div>

                <!-- Alias / Título de Explorador -->
                <div style="margin-bottom: 20px;">
                    <label style="font-size: 0.85rem; font-weight: 700; color: #475569; display: block; margin-bottom: 5px;">Alias o Título de Explorador STEAM:</label>
                    <input type="text" id="perfil-alias-input" placeholder="Ej: Explorador Cuántico, Científica de Campo" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.95rem; box-sizing: border-box;">
                </div>

                <!-- Botones de Acción -->
                <div style="display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" onclick="cerrarModalPerfilEstudiante()" style="padding: 10px 18px; background: #F1F5F9; border: 1px solid #CBD5E1; color: #475569; border-radius: 8px; font-weight: 700; cursor: pointer;">Cancelar</button>
                    <button type="button" id="btn-guardar-perfil-estudiante" onclick="guardarPerfilEstudiante()" style="padding: 10px 24px; background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.95rem; cursor: pointer; box-shadow: 0 4px 12px rgba(16,185,129,0.3); display: flex; align-items: center; gap: 6px;">
                        <span>💾</span> Guardar Cambios
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para que el Docente Aplique Penalización (-10% XP) -->
    <div id="modal-penalizacion-estudiante" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 2600; padding: 20px;">
        <div style="background: white; border-radius: 20px; max-width: 560px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); border: 1px solid #E2E8F0;">
            <!-- Header Modal -->
            <div style="background: linear-gradient(135deg, #DC2626, #EF4444); padding: 20px 25px; color: white; display: flex; justify-content: space-between; align-items: center; border-radius: 20px 20px 0 0;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 2rem;">⚡</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.25rem; font-weight: 900;">Rebajar 10% de Puntos XP</h3>
                        <p style="margin: 2px 0 0 0; font-size: 0.85rem; color: #FEE2E2;">Notificación en vivo e informe para el estudiante.</p>
                    </div>
                </div>
                <button onclick="cerrarModalPenalizacion()" style="background: rgba(255,255,255,0.2); border: none; color: white; font-size: 1.4rem; cursor: pointer; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">&times;</button>
            </div>

            <!-- Body Modal -->
            <div style="padding: 25px;">
                <!-- Info Estudiante -->
                <div style="background: #FEF2F2; border: 1px solid #FCA5A5; padding: 16px; border-radius: 12px; margin-bottom: 20px;">
                    <div style="font-weight: 900; color: #991B1B; font-size: 1.15rem;" id="penalizacion-estudiante-nombre">Estudiante</div>
                    <div style="font-size: 0.9rem; color: #7F1D1D; margin-top: 4px;" id="penalizacion-estudiante-detalles">Doc: --- | Grado: ---</div>
                    <div style="font-weight: 900; color: #DC2626; font-size: 1.2rem; margin-top: 8px; background: white; padding: 8px 12px; border-radius: 8px; border: 1px solid #FECACA; display: inline-block;" id="penalizacion-monto-descuento">⚡ Descuento: -10% XP</div>
                </div>

                <!-- Selección de Motivo -->
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: 800; color: #1E293B; font-size: 0.95rem; display: block; margin-bottom: 10px;">Motivo / Falta de Disciplina en Clase:</label>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#FEF2F2'">
                            <input type="radio" name="motivo-penalizacion" value="📱 Uso indebido del teléfono celular en clase" checked style="width: 18px; height: 18px;">
                            <span>📱 <b>Uso indebido del celular en clase</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#FEF2F2'">
                            <input type="radio" name="motivo-penalizacion" value="🚶‍♂️ Se levanta de su puesto sin permiso" style="width: 18px; height: 18px;">
                            <span>🚶‍♂️ <b>Se levanta de su puesto sin permiso</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#FEF2F2'">
                            <input type="radio" name="motivo-penalizacion" value="📢 Indisciplina / Interrupción constante de la clase" style="width: 18px; height: 18px;">
                            <span>📢 <b>Indisciplina / Interrupción de clase</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#FEF2F2'">
                            <input type="radio" name="motivo-penalizacion" value="🗑️ Generar basura / Dejar sucio o desordenado el aula" style="width: 18px; height: 18px;">
                            <span>🗑️ <b>Generar basura / Desorden en el aula</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#FEF2F2'">
                            <input type="radio" name="motivo-penalizacion" value="⏰ Impuntualidad o ingreso tardío sin justificación" style="width: 18px; height: 18px;">
                            <span>⏰ <b>Impuntualidad o ingreso tardío al aula</b></span>
                        </label>
                    </div>
                </div>

                <!-- Observación Adicional -->
                <div style="margin-bottom: 20px;">
                    <label style="font-size: 0.85rem; font-weight: 700; color: #475569; display: block; margin-bottom: 5px;">Observación Adicional / Nota del Profesor (Opcional):</label>
                    <input type="text" id="penalizacion-observacion-input" placeholder="Ej: Se le llamó la atención 2 veces antes de aplicar sanción" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.95rem; box-sizing: border-box;">
                </div>

                <input type="hidden" id="penalizacion-doc-target">
                <input type="hidden" id="penalizacion-xp-actual">

                <!-- Botones de Acción -->
                <div style="display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" onclick="cerrarModalPenalizacion()" style="padding: 10px 18px; background: #F1F5F9; border: 1px solid #CBD5E1; color: #475569; border-radius: 8px; font-weight: 700; cursor: pointer;">Cancelar</button>
                    <button type="button" onclick="ejecutarPenalizacionEstudiante()" style="padding: 10px 24px; background: linear-gradient(135deg, #DC2626, #B91C1C); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.95rem; cursor: pointer; box-shadow: 0 4px 12px rgba(220,38,38,0.3); display: flex; align-items: center; gap: 6px;">
                        <span>⚡</span> Confirmar y Descontar 10%
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Otorgar Bonificación (+10% XP) -->
    <div id="modal-bonificacion-estudiante" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(8px); align-items: center; justify-content: center; z-index: 2650; padding: 20px;">
        <div style="background: white; border-radius: 20px; max-width: 560px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); border: 1px solid #E2E8F0;">
            <div style="background: linear-gradient(135deg, #059669, #10B981); padding: 20px 25px; color: white; display: flex; justify-content: space-between; align-items: center; border-radius: 20px 20px 0 0;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 2rem;">🎁</span>
                    <div>
                        <h3 style="margin: 0; font-size: 1.25rem; font-weight: 900;">Otorgar Bonificación (+10% XP)</h3>
                        <p style="margin: 2px 0 0 0; font-size: 0.85rem; color: #D1FAE5;">Premiar la participación y logros del estudiante.</p>
                    </div>
                </div>
                <button onclick="cerrarModalBonificacion()" style="background: rgba(255,255,255,0.2); border: none; color: white; font-size: 1.4rem; cursor: pointer; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">&times;</button>
            </div>
            <div style="padding: 25px;">
                <div style="background: #ECFDF5; border: 1px solid #A7F3D0; padding: 16px; border-radius: 12px; margin-bottom: 20px;">
                    <div style="font-weight: 900; color: #065F46; font-size: 1.15rem;" id="bonificacion-estudiante-nombre">Estudiante</div>
                    <div style="font-size: 0.9rem; color: #047857; margin-top: 4px;" id="bonificacion-estudiante-detalles">Doc: --- | Grado: ---</div>
                    <div style="font-weight: 900; color: #059669; font-size: 1.2rem; margin-top: 8px; background: white; padding: 8px 12px; border-radius: 8px; border: 1px solid #A7F3D0; display: inline-block;" id="bonificacion-monto-incremento">🎁 Bonificación: +10% XP</div>
                </div>
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: 800; color: #1E293B; font-size: 0.95rem; display: block; margin-bottom: 10px;">Motivo / Logro Destacado:</label>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#ECFDF5'">
                            <input type="radio" name="motivo-bonificacion" value="🌟 Excelente participación activa y aportes en clase" checked style="width: 18px; height: 18px;">
                            <span>🌟 <b>Excelente participación activa en clase</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#ECFDF5'">
                            <input type="radio" name="motivo-bonificacion" value="💡 Aporte de alto valor pedagógico o solución brillante" style="width: 18px; height: 18px;">
                            <span>💡 <b>Aporte pedagógico o solución brillante</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#ECFDF5'">
                            <input type="radio" name="motivo-bonificacion" value="🤝 Trabajo colaborativo y apoyo a sus compañeros" style="width: 18px; height: 18px;">
                            <span>🤝 <b>Trabajo colaborativo y compañerismo</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#ECFDF5'">
                            <input type="radio" name="motivo-bonificacion" value="🧹 Orden impecable y cuidado de los materiales del aula" style="width: 18px; height: 18px;">
                            <span>🧹 <b>Orden impecable y cuidado del aula</b></span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #CBD5E1; border-radius: 10px; cursor: pointer; background: #F8FAFC; transition: all 0.2s;" onmouseover="this.style.background='#ECFDF5'">
                            <input type="radio" name="motivo-bonificacion" value="🏆 Cumplimiento de tareas y superación personal" style="width: 18px; height: 18px;">
                            <span>🏆 <b>Cumplimiento y superación personal</b></span>
                        </label>
                    </div>
                </div>
                <div style="margin-bottom: 20px;">
                    <label style="font-size: 0.85rem; font-weight: 700; color: #475569; display: block; margin-bottom: 5px;">Nota de Felicitación Adicional (Opcional):</label>
                    <input type="text" id="bonificacion-observacion-input" placeholder="Ej: ¡Felicitaciones por responder el reto en la pizarra!" style="width: 100%; padding: 10px 12px; border: 1px solid #CBD5E1; border-radius: 8px; font-size: 0.95rem; box-sizing: border-box;">
                </div>
                <input type="hidden" id="bonificacion-doc-target">
                <input type="hidden" id="bonificacion-xp-actual">
                <div style="display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" onclick="cerrarModalBonificacion()" style="padding: 10px 18px; background: #F1F5F9; border: 1px solid #CBD5E1; color: #475569; border-radius: 8px; font-weight: 700; cursor: pointer;">Cancelar</button>
                    <button type="button" onclick="ejecutarBonificacionEstudiante()" style="padding: 10px 24px; background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.95rem; cursor: pointer; box-shadow: 0 4px 12px rgba(16,185,129,0.3); display: flex; align-items: center; gap: 6px;">
                        <span>🎁</span> Confirmar y Bonificar +10%
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Fullscreen de Proyección en Vivo para VideoBeam / TV de Clase -->
    <div id="modal-proyeccion-grupo" style="display: none; position: fixed; inset: 0; background: #0F172A; z-index: 3000; overflow-y: auto; color: white; font-family: 'Inter', sans-serif;">
        <!-- Header Proyector -->
        <header style="background: rgba(30, 41, 59, 0.9); backdrop-filter: blur(10px); border-bottom: 2px solid #334155; padding: 20px 35px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 10;">
            <div style="display: flex; align-items: center; gap: 18px;">
                <div style="background: linear-gradient(135deg, #8B5CF6, #6D28D9); padding: 12px 16px; border-radius: 14px; font-size: 1.8rem; box-shadow: 0 4px 15px rgba(139,92,246,0.4);">
                    📺
                </div>
                <div>
                    <h2 style="margin: 0; font-size: 1.8rem; font-weight: 900; letter-spacing: -0.5px; background: linear-gradient(135deg, #F3E8FF, #C084FC); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        RÁNKING Y PUNTUACIÓN DE CLASE EN VIVO
                    </h2>
                    <div style="margin-top: 4px; font-size: 1.05rem; color: #94A3B8; font-weight: 600; display: flex; align-items: center; gap: 12px;">
                        <span>Grupo: <b id="proyeccion-grupo-nombre" style="color: #F59E0B;">6A</b></span>
                        <span>•</span>
                        <span>Asignatura: <b id="proyeccion-materia-nombre" style="color: #38BDF8;">Física</b></span>
                        <span>•</span>
                        <span>🏛️ IE Instituto Montenegro</span>
                    </div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 15px;">
                <div style="background: rgba(16, 185, 129, 0.2); border: 1px solid #10B981; color: #34D399; padding: 8px 16px; border-radius: 20px; font-weight: 800; font-size: 0.9rem; display: flex; align-items: center; gap: 8px; animation: pulse 2s infinite;">
                    <span style="width: 10px; height: 10px; background: #34D399; border-radius: 50%; display: inline-block;"></span> 🔴 TRANSMISIÓN EN VIVO
                </div>
                <button onclick="cerrarProyeccionGrupo()" style="background: rgba(239, 68, 68, 0.2); border: 1px solid #EF4444; color: #FCA5A5; padding: 10px 20px; border-radius: 10px; font-weight: 800; cursor: pointer; font-size: 0.95rem; transition: all 0.2s;" onmouseover="this.style.background='#EF4444'; this.style.color='white'">
                    ✖️ Salir de Proyección
                </button>
            </div>
        </header>

        <!-- Body Proyector -->
        <div style="padding: 40px 35px; max-width: 1400px; margin: 0 auto;">
            <!-- Indicador de Resumen del Grupo -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 35px;">
                <div style="background: rgba(30, 41, 59, 0.7); border: 1px solid #334155; padding: 20px; border-radius: 16px; text-align: center;">
                    <div style="color: #94A3B8; font-size: 0.85rem; font-weight: 700; text-transform: uppercase;">Estudiantes en Aula</div>
                    <div style="font-size: 2.2rem; font-weight: 900; color: #F8FAFC; margin-top: 4px;" id="proyeccion-total-estudiantes">0</div>
                </div>
                <div style="background: rgba(30, 41, 59, 0.7); border: 1px solid #334155; padding: 20px; border-radius: 16px; text-align: center;">
                    <div style="color: #94A3B8; font-size: 0.85rem; font-weight: 700; text-transform: uppercase;">Líder de la Clase</div>
                    <div style="font-size: 1.4rem; font-weight: 900; color: #F59E0B; margin-top: 6px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" id="proyeccion-lider-nombre">---</div>
                </div>
                <div style="background: rgba(30, 41, 59, 0.7); border: 1px solid #334155; padding: 20px; border-radius: 16px; text-align: center;">
                    <div style="color: #94A3B8; font-size: 0.85rem; font-weight: 700; text-transform: uppercase;">Puntaje Máximo</div>
                    <div style="font-size: 2.2rem; font-weight: 900; color: #34D399; margin-top: 4px;" id="proyeccion-max-xp">0 XP</div>
                </div>
            </div>

            <!-- Grid Dynamic Leaderboard -->
            <div id="proyeccion-estudiantes-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px;">
                <!-- Tarjetas animadas en vivo inyectadas por JS -->
            </div>
        </div>
    </div>
</body>
</html>


