const fs = require('fs');
const vm = require('vm');

// Mock browser globals
global.window = global;
global.window.addEventListener = function() {};
global.window.removeEventListener = function() {};
global.window.location = { reload() {}, href: '', search: '' };
global.localStorage = {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    clear() { this._data = {}; }
};
global.document = {
    getElementById(id) { return null; },
    querySelectorAll(sel) { return []; },
    addEventListener(evt, fn) {},
    removeEventListener(evt, fn) {},
    createElement(tag) {
        return {
            style: {},
            appendChild(c) {},
            innerHTML: ''
        };
    }
};

const appCode = fs.readFileSync('d:/Peidagogos_Local/app.js', 'utf8');
vm.runInThisContext(appCode);

console.log('--- TEST 1: Catálogo y Registro de Nueva Institución Educativa ---');
const listaIEs = window.obtenerListaInstituciones();
console.log('Lista IEs inicial:', listaIEs.map(i => i.nombre));
const nuevaIE = window.guardarNuevaInstitucion("Colegio San José", "Armenia, Quindío", "sanjose2026");
console.log('Nueva IE registrada:', nuevaIE);
const listaActualizada = window.obtenerListaInstituciones();
console.log('Lista IEs tras guardar:', listaActualizada.map(i => i.nombre));
if (listaActualizada.some(i => i.nombre === "Colegio San José")) {
    console.log('✅ TEST 1 PASÓ: Institución guardada y persistida en catálogo.');
} else {
    console.error('❌ TEST 1 FALLÓ');
}

console.log('\n--- TEST 2: Creación de Asignatura con Aprendizaje de Documentos ---');
const docTexto = `
Plan de Área de Robótica y Domótica Educativa para Grados 6 a 11.
Ejes temáticos: Programación por bloques, Microcontroladores Arduino y ESP32, Sensores infrarrojos y ultrasonido, Automatización del hogar, Servomotores y Cinemática básica, Inteligencia Artificial aplicada a la robótica móvil, Proyectos sostenibles de domótica rural en el Eje Cafetero.
`;
const nuevaMalla = window.procesarDocumentoYCrearMalla("Robótica y Domótica", ["6", "7", "8", "9", "10", "11"], "Fomentar el pensamiento computacional y la creación de prototipos tecnológicos para el agro y la domótica.", docTexto, "Plan_Area_Robotica.docx");
console.log('Malla Creada para Robótica:');
console.log('- Objetivo:', nuevaMalla.malla.objetivo);
console.log('- DBAs generados:', nuevaMalla.malla.dba.length);
console.log('- Temas Periodo 1:', nuevaMalla.malla.periodos['1']);
console.log('- Temas Periodo 2:', nuevaMalla.malla.periodos['2']);

if (nuevaMalla.malla.dba.length === 4 && nuevaMalla.malla.periodos['1']['1']) {
    console.log('✅ TEST 2 PASÓ: Malla curricular DBA de 4 periodos generada a partir del documento.');
} else {
    console.error('❌ TEST 2 FALLÓ');
}

console.log('\n--- TEST 3: Visualización de Malla Curricular Personalizada ---');
const htmlMalla = window.generarHTMLDetalleMallaDBA("7", "Robótica y Domótica", "docente");
console.log('Longitud HTML Malla generado:', htmlMalla.length);
if (htmlMalla.includes('Robótica y Domótica') && htmlMalla.includes('Meta Anual de Comprensión')) {
    console.log('✅ TEST 3 PASÓ: Renderizado HTML de Malla DBA personalizada exitoso.');
} else {
    console.error('❌ TEST 3 FALLÓ');
}

console.log('\n--- TODOS LOS TESTS AUTOMATIZADOS COMPLETADOS CON ÉXITO ---');
