const fs = require('fs');
const vm = require('vm');

const appPath = 'd:/Peidagogos_Local/app.js';
let code = fs.readFileSync(appPath, 'utf8');

// Normalizar a \n para consistencia
const isCRLF = code.includes('\r\n');
code = code.replace(/\r\n/g, '\n');

console.log('Iniciando reemplazos exactos con \\n normalizado...');

// 1. subjectsGrid
const targetGridCards = `        asignaturas.forEach(asig => {
            const card = document.createElement("div");
            card.style.cssText = "background: white; border-radius: 16px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.06); transition: transform 0.2s, box-shadow 0.2s; border-top: 5px solid #10B981; display: flex; flex-direction: column; justify-content: space-between; height: 190px;";
            card.onmouseover = () => { card.style.transform = "translateY(-5px)"; card.style.boxShadow = "0 12px 20px rgba(0,0,0,0.12)"; };
            card.onmouseout = () => { card.style.transform = "none"; card.style.boxShadow = "0 4px 15px rgba(0,0,0,0.06)"; };

            card.innerHTML = \`
                <div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <span style="font-size: 2.2rem;">🔬</span>
                        <span style="background: #ECFDF5; color: #047857; font-weight: 800; font-size: 0.8rem; padding: 3px 10px; border-radius: 12px; border: 1px solid #A7F3D0;">Activa</span>
                    </div>
                    <h3 style="margin: 0; font-size: 1.35rem; color: #111827; font-weight: 800;">\${asig}</h3>
                    <p style="margin: 4px 0 0 0; font-size: 0.85rem; color: #6B7280;">\${gradoCiclo} • STEAM 2026</p>
                </div>
                <button style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 12px; border-radius: 10px; font-weight: 800; cursor: pointer; width: 100%; font-family: Inter, sans-serif; box-shadow: 0 4px 10px rgba(16,185,129,0.25); display: flex; align-items: center; justify-content: center; gap: 8px;" onclick="abrirAsignaturaEstudiante('\${asig}', '\${gradoCiclo}')">
                    🚀 Entrar al Aula
                </button>
            \`;
            subjectsGrid.appendChild(card);
        });`;

const replacementGridCards = `        asignaturas.forEach(asig => {
            const card = document.createElement("div");
            card.style.cssText = "background: white; border-radius: 16px; padding: 22px; box-shadow: 0 4px 15px rgba(0,0,0,0.06); transition: transform 0.2s, box-shadow 0.2s; border-top: 5px solid #10B981; display: flex; flex-direction: column; justify-content: space-between; min-height: 205px;";
            card.onmouseover = () => { card.style.transform = "translateY(-5px)"; card.style.boxShadow = "0 12px 20px rgba(0,0,0,0.12)"; };
            card.onmouseout = () => { card.style.transform = "none"; card.style.boxShadow = "0 4px 15px rgba(0,0,0,0.06)"; };

            // 1. Icono temático
            let iconAsig = "🔬";
            const asigLow = asig.toLowerCase();
            if (asigLow.includes('física') || asigLow.includes('fisica')) iconAsig = "⚛️";
            else if (asigLow.includes('química') || asigLow.includes('quimica')) iconAsig = "🧪";
            else if (asigLow.includes('matemática') || asigLow.includes('matematica')) iconAsig = "📐";
            else if (asigLow.includes('social') || asigLow.includes('sociales')) iconAsig = "🌍";
            else if (asigLow.includes('lengua') || asigLow.includes('castellano')) iconAsig = "📖";
            else if (asigLow.includes('inglés') || asigLow.includes('ingles')) iconAsig = "🗣️";
            else if (asigLow.includes('tecno') || asigLow.includes('informática')) iconAsig = "💻";
            else if (asigLow.includes('turismo')) iconAsig = "✈️";
            else if (asigLow.includes('artística') || asigLow.includes('artistica')) iconAsig = "🎨";
            else if (asigLow.includes('ética') || asigLow.includes('filosofía')) iconAsig = "🤝";
            else if (asigLow.includes('robot') || asigLow.includes('robótica')) iconAsig = "🤖";
            else if (asigLow.includes('emprend')) iconAsig = "💡";
            else {
                try {
                    const customAsigs = JSON.parse(localStorage.getItem('asignaturas_personalizadas_db') || '[]');
                    const cMatch = customAsigs.find(c => c.nombre.toLowerCase().trim() === asigLow.trim());
                    if (cMatch && cMatch.icono) iconAsig = cMatch.icono;
                } catch(e) {}
            }

            // 2. Docente Titular Orientador
            let docenteTitular = "Docente Titular STEAM";
            try {
                const dList = JSON.parse(localStorage.getItem('docentes_db') || '[]');
                const ieEst = String(data.institucion || '').toLowerCase();
                const gEst = String(gradoCiclo).toLowerCase();
                
                const dFound = dList.find(doc => {
                    const dIE = String(doc.institucion || '').toLowerCase();
                    const dMat = (Array.isArray(doc.materias) ? doc.materias.join(' ') : String(doc.asignatura || '')).toLowerCase();
                    const dGra = (Array.isArray(doc.grados) ? doc.grados.join(' ') : String(doc.grado || doc.grupo || '')).toLowerCase();
                    
                    const coincideIE = !dIE || dIE.includes(ieEst) || ieEst.includes(dIE) || dIE.includes('instituto') || dIE.includes('todos');
                    const coincideMat = dMat.includes(asigLow) || dMat.includes('todas') || asigLow.includes(dMat);
                    const coincideGra = dGra.includes(gEst) || dGra.includes('todos') || dGra.includes(gEst.replace(/[^0-9CicloIVPENS]/g, ''));
                    
                    return coincideMat && (coincideGra || dGra.length === 0);
                });

                if (dFound) {
                    docenteTitular = \`Prof. \${dFound.nombre || dFound.nombres || dFound.nombre_completo || 'Docente'}\`;
                }
            } catch(e) {}

            card.innerHTML = \`
                <div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="font-size: 2rem;">\${iconAsig}</span>
                        <span style="background: #ECFDF5; color: #047857; font-weight: 800; font-size: 0.78rem; padding: 3px 10px; border-radius: 12px; border: 1px solid #A7F3D0;">Activa</span>
                    </div>
                    <h3 style="margin: 0; font-size: 1.22rem; color: #111827; font-weight: 800; line-height: 1.25;">\${asig}</h3>
                    <div style="margin-top: 6px; font-size: 0.82rem; color: #4B5563;">
                        <div style="font-weight: 700; color: #2563EB; display: flex; align-items: center; gap: 4px;">
                            <span>👨‍🏫</span> \${docenteTitular}
                        </div>
                        <div style="color: #6B7280; margin-top: 2px;">\${gradoCiclo} • STEAM 2026</div>
                    </div>
                </div>
                <button style="background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 10px 12px; border-radius: 10px; font-weight: 800; cursor: pointer; width: 100%; font-family: Inter, sans-serif; box-shadow: 0 4px 10px rgba(16,185,129,0.25); display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 10px;" onclick="abrirAsignaturaEstudiante('\${asig}', '\${gradoCiclo}')">
                    🚀 Entrar al Aula
                </button>
            \`;
            subjectsGrid.appendChild(card);
        });`;

if (code.includes(targetGridCards)) {
    code = code.replace(targetGridCards, replacementGridCards);
    console.log('1. ✅ subjectsGrid reemplazado');
} else {
    console.log('1. ⚠️ subjectsGrid no encontrado exacto');
}

// 2. Docente Regular
const targetDocenteReg = `            const selDocAsig = document.getElementById("reg-docente-asignatura-select");
            let asigDoc = selDocAsig ? selDocAsig.value : (asig || "Ciencias Naturales y Educación Ambiental");
            let graDoc = gra || grupo || "Todos";
            let grupoDoc = grupo || gra || "Todos";

            const payloadDocente = {
                tipo_doc: tipoDoc,
                tipo_documento: tipoDoc,
                documento: doc,
                cedula: doc,
                usuario: doc,
                nombre: nom,
                nombres: nom,
                apellidos: ap,
                nombre_completo: \`\${nom} \${ap}\`.trim(),
                edad: ed || '30',
                genero: gen || 'otro',
                rol: 'docente',
                tipo: 'docente_regular',
                institucion: 'IE Instituto Montenegro',
                codigo_institucional: codigoInst,
                asignatura: asigDoc,
                materias: [asigDoc],
                grado: graDoc,
                grupo: grupoDoc,
                pago_realizado: true,
                pago_activo: true,
                fecha_registro: new Date().toISOString()
            };`;

const replacementDocenteReg = `            const selDocIE = document.getElementById("reg-docente-ie-select");
            const ieDocenteSeleccionada = (selDocIE && selDocIE.value.trim()) ? selDocIE.value.trim() : "IE Instituto Montenegro";
            
            const materiasDocente = (window.obtenerMateriasDocenteSeleccionadas) ? window.obtenerMateriasDocenteSeleccionadas() : [asig || "Ciencias Naturales y Educación Ambiental"];
            const gradosDocente = (window.obtenerGradosDocenteSeleccionados) ? window.obtenerGradosDocenteSeleccionados() : ["6", "7", "8", "9"];
            let asigDoc = materiasDocente.join(', ');
            let graDoc = gradosDocente.join(', ');
            let grupoDoc = gradosDocente.join(', ');

            const payloadDocente = {
                tipo_doc: tipoDoc,
                tipo_documento: tipoDoc,
                documento: doc,
                cedula: doc,
                usuario: doc,
                nombre: nom,
                nombres: nom,
                apellidos: ap,
                nombre_completo: \`\${nom} \${ap}\`.trim(),
                edad: ed || '30',
                genero: gen || 'otro',
                rol: 'docente',
                tipo: 'docente_regular',
                institucion: ieDocenteSeleccionada,
                codigo_institucional: codigoInst,
                asignatura: asigDoc,
                materias: materiasDocente,
                grados: gradosDocente,
                grado: graDoc,
                grupo: grupoDoc,
                pago_realizado: true,
                pago_activo: true,
                fecha_registro: new Date().toISOString()
            };`;

if (code.includes(targetDocenteReg)) {
    code = code.replace(targetDocenteReg, replacementDocenteReg);
    console.log('2. ✅ Registro Docente reemplazado');
} else {
    console.log('2. ⚠️ Registro Docente no encontrado exacto');
}

// 3. Planeación Estudiante
const targetPlaneacionEndMalla = `    } else if (asignatura.toLowerCase().includes('ética') || asignatura.toLowerCase().includes('etica') || asignatura.toLowerCase().includes('filosofía') || asignatura.toLowerCase().includes('filosofia')) {
        malla = window.mallaEtica;
    }

    const dataGrado = malla ? (malla[gradoNum] || malla[gradoSeleccionado] || malla['6']) : null;`;

const replacementPlaneacionEndMalla = `    } else if (asignatura.toLowerCase().includes('ética') || asignatura.toLowerCase().includes('etica') || asignatura.toLowerCase().includes('filosofía') || asignatura.toLowerCase().includes('filosofia')) {
        malla = window.mallaEtica;
    }

    if (!malla) {
        try {
            const mallasCustom = JSON.parse(localStorage.getItem('mallas_personalizadas_db') || '{}');
            if (mallasCustom[asignatura]) {
                malla = mallasCustom[asignatura];
            } else {
                const asigCustomList = JSON.parse(localStorage.getItem('asignaturas_personalizadas_db') || '[]');
                const cObj = asigCustomList.find(a => a.nombre.toLowerCase().trim() === asignatura.toLowerCase().trim());
                if (cObj && mallasCustom[cObj.nombre]) {
                    malla = mallasCustom[cObj.nombre];
                }
            }
        } catch(e) {}
    }

    const dataGrado = malla ? (malla[gradoNum] || malla[gradoSeleccionado] || malla['6']) : null;`;

if (code.includes(targetPlaneacionEndMalla)) {
    code = code.replace(targetPlaneacionEndMalla, replacementPlaneacionEndMalla);
    console.log('3. ✅ Planeación Estudiante reemplazado');
} else {
    console.log('3. ⚠️ Planeación Estudiante no encontrado exacto');
}

// 4. generarHTMLDetalleMallaDBA
const targetGenerarMallaTop = `window.generarHTMLDetalleMallaDBA = function(grado, materiaKey, rol) {
    const gradoNum = window.normalizarGradoOCiclo ? window.normalizarGradoOCiclo(grado) : String(grado).replace(/[^0-9CicloIVPENS]/g, '').trim();
    
    let malla = null;
    let nombreMateria = "Ciencias Naturales";
    let iconoMateria = "🌿";
    let colorTema = "#2563EB";
    let colorFondo = "#EFF6FF";

    if (materiaKey === 'Matematicas' || materiaKey.includes('Matem')) {
        malla = window.mallaMatematicas;
        nombreMateria = "Matemáticas";
        iconoMateria = "📐";
        colorTema = "#7C3AED";
        colorFondo = "#F5F3FF";
    } else if (materiaKey === 'Lenguaje' || materiaKey.includes('Lengua') || materiaKey.includes('Castellano')) {
        malla = window.mallaCastellano;
        nombreMateria = "Lengua Castellana";
        iconoMateria = "📖";
        colorTema = "#EA580C";
        colorFondo = "#FFF7ED";
    } else if (materiaKey === 'Sociales' || materiaKey.includes('Social')) {
        malla = window.mallaSociales;
        nombreMateria = "Ciencias Sociales";
        iconoMateria = "🌍";
        colorTema = "#059669";
        colorFondo = "#ECFDF5";
    } else {
        malla = window.mallaNaturales;
        nombreMateria = "Ciencias Naturales";
        iconoMateria = "🌿";
        colorTema = "#2563EB";
        colorFondo = "#EFF6FF";
    }`;

const replacementGenerarMallaTop = `window.generarHTMLDetalleMallaDBA = function(grado, materiaKey, rol) {
    const gradoNum = window.normalizarGradoOCiclo ? window.normalizarGradoOCiclo(grado) : String(grado).replace(/[^0-9CicloIVPENS]/g, '').trim();
    
    let malla = null;
    let nombreMateria = "Ciencias Naturales";
    let iconoMateria = "🌿";
    let colorTema = "#2563EB";
    let colorFondo = "#EFF6FF";

    if (materiaKey === 'Matematicas' || materiaKey.includes('Matem')) {
        malla = window.mallaMatematicas;
        nombreMateria = "Matemáticas";
        iconoMateria = "📐";
        colorTema = "#7C3AED";
        colorFondo = "#F5F3FF";
    } else if (materiaKey === 'Lenguaje' || materiaKey.includes('Lengua') || materiaKey.includes('Castellano')) {
        malla = window.mallaCastellano;
        nombreMateria = "Lengua Castellana";
        iconoMateria = "📖";
        colorTema = "#EA580C";
        colorFondo = "#FFF7ED";
    } else if (materiaKey === 'Sociales' || materiaKey.includes('Social')) {
        malla = window.mallaSociales;
        nombreMateria = "Ciencias Sociales";
        iconoMateria = "🌍";
        colorTema = "#059669";
        colorFondo = "#ECFDF5";
    } else if (materiaKey === 'Fisica' || materiaKey.includes('Fís') || materiaKey.includes('Fis')) {
        malla = window.mallaFisica;
        nombreMateria = "Física";
        iconoMateria = "⚛️";
        colorTema = "#0284C7";
        colorFondo = "#F0F9FF";
    } else if (materiaKey === 'Quimica' || materiaKey.includes('Quím') || materiaKey.includes('Quim')) {
        malla = window.mallaQuimica;
        nombreMateria = "Química";
        iconoMateria = "🧪";
        colorTema = "#D97706";
        colorFondo = "#FFFBEB";
    } else if (materiaKey === 'Naturales' || materiaKey.includes('Ciencias') || materiaKey.includes('Natur')) {
        malla = window.mallaNaturales;
        nombreMateria = "Ciencias Naturales";
        iconoMateria = "🌿";
        colorTema = "#2563EB";
        colorFondo = "#EFF6FF";
    } else {
        // Buscar en mallas personalizadas creadas por docentes
        let mallasCustom = {};
        try { mallasCustom = JSON.parse(localStorage.getItem('mallas_personalizadas_db') || '{}'); } catch(e) {}
        let asigCustomList = [];
        try { asigCustomList = JSON.parse(localStorage.getItem('asignaturas_personalizadas_db') || '[]'); } catch(e) {}

        const foundCustomAsig = asigCustomList.find(a => a.nombre.toLowerCase().trim() === materiaKey.toLowerCase().trim() || a.id === materiaKey);

        if (foundCustomAsig || mallasCustom[materiaKey]) {
            const customMalla = mallasCustom[materiaKey] || (foundCustomAsig ? mallasCustom[foundCustomAsig.nombre] : null);
            if (customMalla) {
                malla = customMalla;
                nombreMateria = foundCustomAsig ? foundCustomAsig.nombre : materiaKey;
                iconoMateria = foundCustomAsig ? (foundCustomAsig.icono || "💡") : "💡";
                colorTema = foundCustomAsig ? (foundCustomAsig.color || "#4F46E5") : "#4F46E5";
                colorFondo = foundCustomAsig ? (foundCustomAsig.colorFondo || "#EEF2FF") : "#EEF2FF";
            }
        }
        if (!malla) {
            malla = window.mallaNaturales;
            nombreMateria = materiaKey || "Ciencias Naturales";
            iconoMateria = "💡";
            colorTema = "#2563EB";
            colorFondo = "#EFF6FF";
        }
    }`;

if (code.includes(targetGenerarMallaTop)) {
    code = code.replace(targetGenerarMallaTop, replacementGenerarMallaTop);
    console.log('4. ✅ generarHTMLDetalleMallaDBA reemplazado');
} else {
    console.log('4. ⚠️ generarHTMLDetalleMallaDBA no encontrado exacto');
}

fs.writeFileSync(appPath, code, 'utf8');

// Validar sintaxis completa con VM
try {
    new vm.Script(code);
    console.log('✨ Validación de sintaxis VM: CORRECTO (0 errores de sintaxis).');
} catch(err) {
    console.error('❌ Error de sintaxis detectado:', err);
}
