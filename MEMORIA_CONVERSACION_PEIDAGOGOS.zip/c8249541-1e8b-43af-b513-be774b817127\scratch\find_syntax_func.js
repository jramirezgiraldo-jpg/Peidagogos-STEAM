const fs = require('fs');
const code = fs.readFileSync('d:/Peidagogos_Local/app.js', 'utf8');
const lines = code.split('\n');

console.log("Total lines:", lines.length);

// Let's test parsing function blocks or slicing
// Let's find out which function in the modified range (10000 - 12000) has the error
for (let i = 10000; i < lines.length; i += 50) {
    const slice = lines.slice(0, i).join('\n');
    // Try wrapping in a function to test if valid up to line i
    // or evaluate syntax
    try {
        new Function(slice);
        // If it succeeds, the code up to line i is syntactically valid!
    } catch (e) {
        if (e.message !== "Unexpected end of input") {
            console.log(`Line ${i}: Error -> ${e.message}`);
        }
    }
}

// Let's test individual top-level functions in lines 10000-12000
let currentFunc = [];
let currentFuncName = "";
let startLine = 0;

for (let i = 10000; i < lines.length; i++) {
    const l = lines[i];
    if (l.startsWith("window.") || l.startsWith("function ")) {
        if (currentFunc.length > 0) {
            const funcCode = currentFunc.join('\n');
            try {
                new Function(funcCode);
            } catch (err) {
                console.log(`❌ SYNTAX ERROR in ${currentFuncName} (around line ${startLine}-${i}): ${err.message}`);
            }
        }
        currentFunc = [l];
        currentFuncName = l.split('=')[0].trim();
        startLine = i + 1;
    } else {
        currentFunc.push(l);
    }
}

if (currentFunc.length > 0) {
    const funcCode = currentFunc.join('\n');
    try {
        new Function(funcCode);
    } catch (err) {
        console.log(`❌ SYNTAX ERROR in ${currentFuncName} (around line ${startLine}-${lines.length}): ${err.message}`);
    }
}
