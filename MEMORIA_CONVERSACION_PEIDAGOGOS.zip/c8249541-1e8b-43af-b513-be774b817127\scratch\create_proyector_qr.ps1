$html = @"
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyección QR de Matrícula - IE Instituto Montenegro • Peidagogos STEAM</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>
    <style>
        body, html {
            margin: 0; padding: 0; width: 100%; height: 100%;
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 50%, #0F172A 100%);
            color: #F8FAFC; font-family: 'Inter', sans-serif;
            display: flex; flex-direction: column; justify-content: space-between;
            align-items: center; box-sizing: border-box; overflow: hidden;
        }
        header {
            width: 100%; padding: 15px 40px; display: flex; justify-content: space-between;
            align-items: center; background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.1); box-sizing: border-box;
        }
        .main-container {
            display: flex; flex-direction: row; justify-content: center; align-items: center;
            gap: 60px; max-width: 1400px; width: 95%; flex: 1; padding: 20px 0;
        }
        .qr-card {
            background: white; padding: 30px; border-radius: 28px;
            box-shadow: 0 25px 60px rgba(0,0,0,0.5), 0 0 40px rgba(59,130,246,0.3);
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            border: 4px solid #3B82F6; animation: floatCard 4s ease-in-out infinite;
        }
        @keyframes floatCard {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }
        #canvas-qr {
            width: 340px !important; height: 340px !important;
            border-radius: 12px;
        }
        .info-panel {
            max-width: 600px; text-align: left;
        }
        .badge-inst {
            background: rgba(37, 99, 235, 0.25); color: #93C5FD;
            border: 1px solid #3B82F6; padding: 6px 16px; border-radius: 20px;
            font-size: 0.95rem; font-weight: 800; display: inline-flex; align-items: center; gap: 8px;
            margin-bottom: 15px; text-transform: uppercase; letter-spacing: 0.5px;
        }
        h1 {
            font-size: 3rem; font-weight: 900; margin: 0 0 15px 0; line-height: 1.15;
            background: linear-gradient(90deg, #FFFFFF, #93C5FD);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }
        p {
            font-size: 1.25rem; color: #CBD5E1; line-height: 1.5; margin: 0 0 25px 0;
        }
        .steps-box {
            background: rgba(30, 41, 59, 0.8); border: 1px solid rgba(255,255,255,0.15);
            border-radius: 16px; padding: 20px; display: flex; flex-direction: column; gap: 12px;
        }
        .step-item {
            display: flex; align-items: center; gap: 15px; font-size: 1.1rem; color: #F1F5F9; font-weight: 600;
        }
        .step-num {
            background: #2563EB; color: white; width: 34px; height: 34px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 1rem;
            flex-shrink: 0; box-shadow: 0 0 12px rgba(37,99,235,0.6);
        }
        .selector-box {
            margin-top: 20px; display: flex; align-items: center; gap: 15px; flex-wrap: wrap;
        }
        select {
            background: #1E293B; color: white; border: 2px solid #3B82F6; padding: 12px 18px;
            border-radius: 10px; font-size: 1.1rem; font-weight: bold; outline: none; cursor: pointer;
        }
        .btn-fullscreen {
            background: rgba(255,255,255,0.1); color: white; border: 1px solid rgba(255,255,255,0.2);
            padding: 10px 20px; border-radius: 10px; font-weight: bold; cursor: pointer; font-size: 0.95rem;
            display: flex; align-items: center; gap: 8px; transition: 0.2s;
        }
        .btn-fullscreen:hover { background: #2563EB; border-color: #2563EB; }
        footer {
            width: 100%; padding: 12px 40px; background: rgba(15, 23, 42, 0.9);
            border-top: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between;
            align-items: center; font-size: 0.9rem; color: #94A3B8; box-sizing: border-box;
        }
    </style>
</head>
<body>
    <header>
        <div style="display: flex; align-items: center; gap: 15px;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 42px; width: auto; object-fit: contain;">
            <div style="font-weight: 900; font-size: 1.2rem; color: white;">AULA STEAM • MODO PROYECCIÓN VIDEOBEAM</div>
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
            <button class="btn-fullscreen" onclick="toggleFullscreen()">
                <span>⛶</span> Pantalla Completa
            </button>
            <button onclick="window.close()" style="background: #EF4444; color: white; border: none; padding: 10px 18px; border-radius: 10px; font-weight: bold; cursor: pointer;">
                ✕ Cerrar
            </button>
        </div>
    </header>

    <div class="main-container">
        <!-- QR Gigante -->
        <div class="qr-card">
            <canvas id="canvas-qr"></canvas>
            <div style="margin-top: 15px; text-align: center;">
                <div style="font-size: 1.2rem; font-weight: 900; color: #1E3A8A;">CÓDIGO OFICIAL ACTIVADO</div>
                <div style="font-size: 0.85rem; color: #059669; font-weight: 800; background: #DEF7EC; padding: 4px 12px; border-radius: 20px; display: inline-block; margin-top: 6px;">
                    🔑 ieinstituto2026 • Matrícula $0 COP
                </div>
            </div>
        </div>

        <!-- Panel Informativo -->
        <div class="info-panel">
            <div class="badge-inst">🏫 IE INSTITUTO MONTENEGRO</div>
            <h1>Escanea con tu celular para matricularte</h1>
            <p>Apunta con la cámara de tu teléfono al código QR proyectado para ingresar a tu aula virtual con acceso institucional gratuito.</p>

            <div class="steps-box">
                <div class="step-item">
                    <div class="step-num">1</div>
                    <div>Abre la <strong>cámara</strong> o lector QR de tu celular.</div>
                </div>
                <div class="step-item">
                    <div class="step-num">2</div>
                    <div>Apunta al <strong>código QR</strong> gigante en la pantalla.</div>
                </div>
                <div class="step-item">
                    <div class="step-num">3</div>
                    <div>Toca el enlace para abrir el formulario con el <strong>código verificado</strong>.</div>
                </div>
            </div>

            <!-- Selector de Grupo / Ciclo -->
            <div class="selector-box">
                <span style="font-weight: 700; color: #94A3B8;">Filtrar por Grupo / Ciclo:</span>
                <select id="select-grupo-qr" onchange="actualizarQR()">
                    <option value="">-- Todos los Grupos --</option>
                    <option value="6A">Grado 6A</option>
                    <option value="6B">Grado 6B</option>
                    <option value="7A">Grado 7A</option>
                    <option value="7B">Grado 7B</option>
                    <option value="7C">Grado 7C</option>
                    <option value="8A">Grado 8A</option>
                    <option value="8B">Grado 8B</option>
                    <option value="9A">Grado 9A</option>
                    <option value="10A">Grado 10A</option>
                    <option value="10D">Grado 10D</option>
                    <option value="PENS">Grado PENS</option>
                    <option value="Ciclo I">🌙 Ciclo I (Nocturno)</option>
                    <option value="Ciclo II">🌙 Ciclo II (Nocturno)</option>
                    <option value="Ciclo III">🌙 Ciclo III (Nocturno)</option>
                    <option value="Ciclo IV">🌙 Ciclo IV (Nocturno)</option>
                    <option value="Ciclo V">🌙 Ciclo V (Nocturno)</option>
                    <option value="Ciclo VI">🌙 Ciclo VI (Nocturno)</option>
                </select>
            </div>
        </div>
    </div>

    <footer>
        <div>IE Instituto Montenegro • Educación Oficial Gratuita en STEAM</div>
        <div id="url-preview-text" style="color: #60A5FA; font-weight: 600;">https://peidagogosteam.com/login.html?registro=instituto&codigo=ieinstituto2026</div>
    </footer>

    <script>
        function generarURL(grupo) {
            const host = window.location.origin || 'https://peidagogosteam.com';
            let url = host + '/login.html?registro=instituto&codigo=ieinstituto2026';
            if (grupo) {
                url += '&grupo=' + encodeURIComponent(grupo);
            }
            return url;
        }

        function actualizarQR() {
            const sel = document.getElementById('select-grupo-qr');
            const grupo = sel ? sel.value : '';
            const url = generarURL(grupo);
            
            const canvas = document.getElementById('canvas-qr');
            QRCode.toCanvas(canvas, url, {
                width: 340,
                margin: 2,
                color: {
                    dark: '#0F172A',
                    light: '#FFFFFF'
                }
            }, function (error) {
                if (error) console.error(error);
            });

            const txt = document.getElementById('url-preview-text');
            if (txt) txt.innerText = url;
        }

        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen().catch(() => {});
                }
            }
        }

        window.addEventListener('DOMContentLoaded', () => {
            const params = new URLSearchParams(window.location.search);
            const g = params.get('grupo');
            if (g && document.getElementById('select-grupo-qr')) {
                document.getElementById('select-grupo-qr').value = g;
            }
            actualizarQR();
        });
    </script>
</body>
</html>
"@

[System.IO.File]::WriteAllText('d:\Peidagogos_Local\proyector-qr.html', $html, [System.Text.Encoding]::UTF8)
Get-Item 'd:\Peidagogos_Local\proyector-qr.html' | Select-Object Name, Length
