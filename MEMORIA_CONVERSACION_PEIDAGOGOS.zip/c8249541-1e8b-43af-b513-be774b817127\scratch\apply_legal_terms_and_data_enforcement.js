const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

loginHtml = loginHtml.replace(/\r\n/g, '\n');
appJs = appJs.replace(/\r\n/g, '\n');

console.log('Iniciando refuerzo legal obligatorio de Habeas Data y Términos de Uso en Contingencia...');

// 1. ACTUALIZAR BLOQUE DE HABEAS DATA EN EL FORMULARIO DE REGISTRO DE LOGIN.HTML
const targetHabeasHtml = `<!-- Casilla de Autorización de Tratamiento de Datos (Ley 1581 de 2012 / Protección a Menores) -->
        <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 10px; padding: 12px 14px; margin-top: 5px; text-align: left;">
            <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer; font-size: 0.82rem; color: #334155; line-height: 1.35;">
                <input type="checkbox" id="reg-check-tratamiento-datos" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; accent-color: #2563EB;" checked>
                <span>
                    Autorizo el <strong>Tratamiento de Datos Personales</strong> conforme a la <strong>Ley 1581 de 2012</strong> y Decreto 1377 de 2013, con fines estrictamente formativos, pedagógicos y de atención educativa de menores de edad en el marco institucional.
                    <a href="javascript:void(0)" onclick="window.abrirModalPoliticaDatos()" style="color: #2563EB; font-weight: 700; text-decoration: underline; display: inline-block; margin-top: 2px;">Leer Política de Privacidad y Salvaguarda de Menores</a>
                </span>
            </label>
        </div>`;

const replacementHabeasHtml = `<!-- Bloque de Consentimiento Legal, Protección DNDA y Tratamiento de Datos Obligatorio -->
        <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 12px; padding: 14px 16px; margin-top: 6px; text-align: left;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; flex-wrap: wrap; gap: 6px;">
                <span style="font-weight: 900; font-size: 0.88rem; color: #1E293B; display: flex; align-items: center; gap: 6px;">
                    <span>🛡️</span> Términos Legales y Tratamiento de Datos:
                </span>
                <a href="javascript:void(0)" onclick="window.abrirModalPoliticaDatos()" style="color: #2563EB; font-weight: 800; font-size: 0.8rem; text-decoration: underline;">
                    📖 Leer Política Completa (Ley 1581)
                </a>
            </div>
            <p style="margin: 0 0 10px 0; color: #64748B; font-size: 0.78rem; line-height: 1.4;">
                Software registrado ante la DNDA (Radicado 1-2026-000055). Uso educativo y formativo no comercial por contingencia sísmica.
            </p>
            <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer; font-size: 0.82rem; color: #334155; line-height: 1.35;">
                <input type="checkbox" id="reg-check-tratamiento-datos" style="margin-top: 2px; cursor: pointer; width: 18px; height: 18px; accent-color: #2563EB;">
                <span>
                    <strong>Acepto los Términos de Uso en Contingencia</strong> y autorizo el <strong>Tratamiento de Datos Personales</strong> conforme a la <strong>Ley 1581 de 2012</strong>, Decreto 1377 de 2013 y Ley 1098 de 2006 (Código de Infancia) con fines estrictamente pedagógicos.
                </span>
            </label>
        </div>`;

if (loginHtml.includes(targetHabeasHtml)) {
    loginHtml = loginHtml.replace(targetHabeasHtml, replacementHabeasHtml);
    console.log('✅ Bloque de Habeas Data actualizado a no-premarcado y con información explícita.');
} else {
    console.warn('⚠️ No se encontró targetHabeasHtml.');
}

// Actualizar versión de scripts a v56
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v56');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v56');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v56');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// =========================================================
// 2. ENFORZAR VALIDACIÓN DE HABEAS DATA EN APP.JS
// =========================================================

const targetDocCheck = `if (!doc) { mostrarErrorReg("⚠️ El campo Documento es obligatorio."); return; }`;

const replacementDocCheck = `// Validación obligatoria de Habeas Data y Términos de Contingencia
        const checkHabeas = document.getElementById("reg-check-tratamiento-datos");
        if (checkHabeas && !checkHabeas.checked) {
            if (typeof window.abrirModalPoliticaDatos === 'function') {
                window.abrirModalPoliticaDatos();
            }
            mostrarErrorReg("⚠️ Debes marcar la casilla de autorización de Tratamiento de Datos Personales (Ley 1581 de 2012 / DNDA 1-2026-000055) para continuar.");
            return;
        }

        if (!doc) { mostrarErrorReg("⚠️ El campo Documento es obligatorio."); return; }`;

if (appJs.includes(targetDocCheck)) {
    appJs = appJs.replace(targetDocCheck, replacementDocCheck);
    console.log('✅ Validación estricta de Habeas Data inyectada en ejecutarRegistroEstudiante.');
}

// Modificar mensaje de éxito del docente para incluir el recordatorio legal de contingencia
const targetDocAlert = `alert(\`✅ ¡Inscripción de Docente Regular Exitosa!\\n\\nBienvenido(a) Profesor(a) \${nom} \${ap}.\\n\\nHas ingresado a tu Panel Docente. Desde aquí puedes proyectar la clase, consultar el Leaderboard en vivo, evaluar con rúbricas formativas y utilizar la Caja de Herramientas STEAM.\`);`;

const replacementDocAlert = `alert(\`✅ ¡Inscripción de Docente Exitosa!\\n\\nBienvenido(a) Profesor(a) \${nom} \${ap}.\\n\\n🛡️ AVISO LEGAL Y TÉRMINOS DE CONTINGENCIA:\\n• Titular de Software: Juan Felipe Ramírez Giraldo (DNDA Radicado 1-2026-000055)\\n• Finalidad: Piloto Pedagógico de Contingencia no comercial\\n• Protección de Datos: Ley 1581 de 2012 y Ley 1098 de 2006 (Código de Infancia)\\n• Referentes MEN: Estándares DBA propiedad del Ministerio de Educación Nacional\\n\\nHas ingresado a tu Panel Docente. Ya puedes crear tus grupos, compartir los enlaces directos para redes y proyectar tus clases STEAM.\`);`;

if (appJs.includes(targetDocAlert)) {
    appJs = appJs.replace(targetDocAlert, replacementDocAlert);
    console.log('✅ Alerta legal de bienvenida de contingencia agregada al registro docente.');
}

fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
