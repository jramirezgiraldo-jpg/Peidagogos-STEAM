const fs = require('fs');
const html = fs.readFileSync('d:/Peidagogos_Local/login.html', 'utf8');

// Check modal elements
const modals = [
    'modal-configurador-diapositivas',
    'modal-presentador-diapositivas',
    'modal-caja-herramientas',
    'modal-visor-herramienta',
    'modal-auditor-qa'
];

modals.forEach(id => {
    const idx = html.indexOf(`id="${id}"`);
    console.log(`Modal ${id} found at index: ${idx}`);
});
