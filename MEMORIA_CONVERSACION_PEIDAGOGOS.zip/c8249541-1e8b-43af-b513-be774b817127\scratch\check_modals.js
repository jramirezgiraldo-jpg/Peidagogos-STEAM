const fs = require('fs');
const html = fs.readFileSync('d:/Peidagogos_Local/login.html', 'utf8');

const modals = [
  'modal-asignar-actividad',
  'modal-juego-actividad',
  'modal-notificacion-disciplinaria',
  'modal-generar-diapositivas',
  'modal-diapositivas-presentador',
  'modal-caja-herramientas',
  'modal-visor-herramienta'
];

modals.forEach(m => {
  const marker = 'id="' + m + '"';
  const idx = html.indexOf(marker);
  console.log(m, idx !== -1 ? 'FOUND at line ' + html.substring(0, idx).split('\n').length : 'NOT FOUND');
});
