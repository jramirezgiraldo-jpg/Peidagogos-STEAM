const fs = require('fs');
const html = fs.readFileSync('d:/Peidagogos_Local/login.html', 'utf8');

const modals = [
  'modal-asignar-actividad',
  'modal-juego-actividad',
  'modal-notificacion-disciplinaria',
  'modal-generar-diapositivas',
  'modal-diapositivas-presentador',
  'modal-caja-herramientas',
  'modal-visor-herramienta'
];

modals.forEach(m => {
  const marker = '<div id="' + m + '"';
  const startIdx = html.indexOf(marker);
  if (startIdx === -1) {
    console.log(m, 'NOT FOUND');
    return;
  }
  
  // count divs starting from startIdx
  let depth = 0;
  let i = startIdx;
  let endIdx = -1;
  while (i < html.length) {
    if (html.startsWith('<div', i)) {
      depth++;
      i += 4;
    } else if (html.startsWith('</div>', i)) {
      depth--;
      if (depth === 0) {
        endIdx = i + 6;
        break;
      }
      i += 6;
    } else {
      i++;
    }
  }
  
  const startLine = html.substring(0, startIdx).split('\n').length;
  const endLine = html.substring(0, endIdx).split('\n').length;
  console.log(m, 'starts at line', startLine, 'ends at line', endLine, 'depth 0 reached:', depth === 0);
});
