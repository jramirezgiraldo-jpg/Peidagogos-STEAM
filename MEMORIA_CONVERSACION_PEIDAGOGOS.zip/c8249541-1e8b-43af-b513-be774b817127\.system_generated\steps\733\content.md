Title: Live Content

Description: Fetched live

Source: https://www.callmebot.com/blog/telegram-text-messages/

---

<!DOCTYPE html>
<html class="no-js" lang="en-US" itemscope="itemscope" itemtype="http://schema.org/Article">

    <head>
                <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
                    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
                <meta charset="UTF-8" />
        <!-- icons & favicons -->
                    <link rel="shortcut icon" href="https://www.callmebot.com/wp-content/uploads/2019/10/Logo-carita_16.png" type="image/x-icon" />
        
                    <!-- For iPhone -->
            <link rel="apple-touch-icon-precomposed" href="https://www.callmebot.com/wp-content/uploads/2019/10/Logo-carita_57.png">
        
                    <!-- For iPhone 4 Retina display -->
            <link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://www.callmebot.com/wp-content/uploads/2019/10/Logo-carita_114.png">
        
                    <!-- For iPad -->
            <link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://www.callmebot.com/wp-content/uploads/2019/10/Logo-carita_72.png">
        
                    <!-- For iPad Retina display -->
            <link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://www.callmebot.com/wp-content/uploads/2019/10/Logo-carita_144.png">
        
        <link rel="pingback" href="https://www.callmebot.com/xmlrpc.php" />

        <title>Telegram Text Messages - CallMeBot API</title>
<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//use.fontawesome.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="CallMeBot API &raquo; Feed" href="https://www.callmebot.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="CallMeBot API &raquo; Comments Feed" href="https://www.callmebot.com/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="CallMeBot API &raquo; Telegram Text Messages Comments Feed" href="https://www.callmebot.com/blog/telegram-text-messages/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.callmebot.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.6"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='flick-css'  href='https://www.callmebot.com/wp-content/plugins/mailchimp/css/flick/flick.css?ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='mailchimpSF_main_css-css'  href='https://www.callmebot.com/?mcsf_action=main_css&#038;ver=5.2.6' type='text/css' media='all' />
<!--[if IE]>
<link rel='stylesheet' id='mailchimpSF_ie_css-css'  href='https://www.callmebot.com/wp-content/plugins/mailchimp/css/ie.css?ver=5.2.6' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='ot-google-fonts-css'  href='//fonts.googleapis.com/css?family=Slabo+27px:regular%7COpen+Sans:regular%7CRoboto:regular' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://www.callmebot.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='essential-grid-plugin-settings-css'  href='https://www.callmebot.com/wp-content/plugins/essential-grid/public/assets/css/settings.css?ver=2.2.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='tp-open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700%2C800&#038;ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='tp-raleway-css'  href='https://fonts.googleapis.com/css?family=Raleway%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900&#038;ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='tp-droid-serif-css'  href='https://fonts.googleapis.com/css?family=Droid+Serif%3A400%2C700&#038;ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='tp-fontello-css'  href='https://www.callmebot.com/wp-content/plugins/essential-grid/public/assets/font/fontello/css/fontello.css?ver=2.2.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://www.callmebot.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.7.4' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='dashicons-css'  href='https://www.callmebot.com/wp-includes/css/dashicons.min.css?ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='leap-font-awesome-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/font-awesome/css/font-awesome.min.css?ver=3.0.5' type='text/css' media='screen' />
<link rel='stylesheet' id='bootstrap-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/bootstrap/ltr/css/bootstrap.min.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-ui-core-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/jquery/jquery-ui/jquery.ui.core.min.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-ui-accordion-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/jquery/jquery-ui/jquery.ui.accordion.min.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='superfish-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/superfish/css/superfish.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='slicknav-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/slicknav/slicknav.min.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='leap-masonry-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/masonry/masonry.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-prettyPhoto-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/prettyPhoto/css/prettyPhoto.css?ver=3.0.5' type='text/css' media='screen' />
<link rel='stylesheet' id='flexslider-css'  href='https://www.callmebot.com/wp-content/plugins/js_composer/assets/lib/bower/flexslider/flexslider.min.css?ver=6.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-carouFredSel-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/caroufredsel/jquery.carouFredSel.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='leap-animate-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/animation/animate.min.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-custom-scrollbar-css'  href='https://www.callmebot.com/wp-content/themes/wiz/vendor/custom-scrollbar/jquery.mCustomScrollbar.min.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='leap-theme-css'  href='https://www.callmebot.com/wp-content/themes/wiz/css/theme.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='style-responsive-css'  href='https://www.callmebot.com/wp-content/themes/wiz/css/style-responsive.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='leap-retina-css'  href='https://www.callmebot.com/wp-content/themes/wiz/css/retina.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='https://www.callmebot.com/wp-content/themes/wiz/style.css?ver=3.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-free-css'  href='//use.fontawesome.com/releases/v5.3.1/css/all.css?ver=5.2.6' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://www.callmebot.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.5' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet' id='elementor-icons-css'  href='https://www.callmebot.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='https://www.callmebot.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=2.7.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='https://www.callmebot.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=2.7.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='https://www.callmebot.com/wp-content/uploads/elementor/css/global.css?ver=1586109070' type='text/css' media='all' />
<link rel='stylesheet' id='bsf-Defaults-css'  href='https://www.callmebot.com/wp-content/uploads/smile_fonts/Defaults/Defaults.css?ver=5.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='ulp-css'  href='https://www.callmebot.com/wp-content/plugins/layered-popups/css/style.min.css?ver=6.37' type='text/css' media='all' />
<link rel='stylesheet' id='ulp-link-buttons-css'  href='https://www.callmebot.com/wp-content/plugins/layered-popups/css/link-buttons.min.css?ver=6.37' type='text/css' media='all' />
<link rel='stylesheet' id='animate.css-css'  href='https://www.callmebot.com/wp-content/plugins/layered-popups/css/animate.min.css?ver=6.37' type='text/css' media='all' />
<link rel='stylesheet' id='spinkit-css'  href='https://www.callmebot.com/wp-content/plugins/layered-popups/css/spinkit.min.css?ver=6.37' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.2.6' type='text/css' media='all' />
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/mailchimp/js/scrollTo.js?ver=1.5.8'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/jquery.form.min.js?ver=4.2.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimpSF = {"ajax_url":"https:\/\/www.callmebot.com\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/mailchimp/js/mailchimp.js?ver=1.5.8'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/mailchimp/js/datepicker.js?ver=5.2.6'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/essential-grid/public/assets/js/jquery.esgbox.min.js?ver=2.2.4.1'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/essential-grid/public/assets/js/jquery.themepunch.tools.min.js?ver=2.2.4.1'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.7.4'></script>

<!-- Google Analytics snippet added by Site Kit -->
<script type='text/javascript' src='https://www.googletagmanager.com/gtag/js?id=UA-149177385-2' async></script>
<script type='text/javascript'>
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["www.callmebot.com"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-149177385-2", {"anonymize_ip":true});
gtag("config", "G-4L3JDV4SQ2");
</script>

<!-- End Google Analytics snippet added by Site Kit -->
<link rel='https://api.w.org/' href='https://www.callmebot.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.callmebot.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.callmebot.com/wp-includes/wlwmanifest.xml" /> 
<link rel='prev' title='Free API to Send Whatsapp Messages' href='https://www.callmebot.com/blog/free-api-whatsapp-messages/' />
<link rel='next' title='Free API to Send Signal Messaging' href='https://www.callmebot.com/blog/free-api-signal-send-messages/' />
<meta name="generator" content="WordPress 5.2.6" />
<link rel="canonical" href="https://www.callmebot.com/blog/telegram-text-messages/" />
<link rel='shortlink' href='https://www.callmebot.com/?p=4294' />
<link rel="alternate" type="application/json+oembed" href="https://www.callmebot.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://www.callmebot.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F&#038;format=xml" />
<style type='text/css'> .ae_data .elementor-editor-element-setting {
                        display:none !important;
                }
                </style><meta name="generator" content="Site Kit by Google 1.93.0" /><script type="text/javascript">
        jQuery(function($) {
            $('.date-pick').each(function() {
                var format = $(this).data('format') || 'mm/dd/yyyy';
                format = format.replace(/yyyy/i, 'yy');
                $(this).datepicker({
                    autoFocusNextInput: true,
                    constrainInput: false,
                    changeMonth: true,
                    changeYear: true,
                    beforeShow: function(input, inst) { $('#ui-datepicker-div').addClass('show'); },
                    dateFormat: format.toLowerCase(),
                });
            });
            d = new Date();
            $('.birthdate-pick').each(function() {
                var format = $(this).data('format') || 'mm/dd';
                format = format.replace(/yyyy/i, 'yy');
                $(this).datepicker({
                    autoFocusNextInput: true,
                    constrainInput: false,
                    changeMonth: true,
                    changeYear: false,
                    minDate: new Date(d.getFullYear(), 1-1, 1),
                    maxDate: new Date(d.getFullYear(), 12-1, 31),
                    beforeShow: function(input, inst) { $('#ui-datepicker-div').removeClass('show'); },
                    dateFormat: format.toLowerCase(),
                });

            });

        });
    </script>
		<script type="text/javascript">
			var ajaxRevslider;
			
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = '87534b42f6';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"https://www.callmebot.com/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});
		</script>
		<!--[if lt IE 9]><script src="https://www.callmebot.com/wp-content/themes/wiz/js/html5shiv-printshiv.min.js"></script><![endif]-->
<meta name="description" content="Send Telegram Text Messages with a simple Web API (HTTP GET). It is super easy to send messages with this API and integrate it in all IoT devices, domotics, scripts, automations, etc. You don&#039;t need to create Telegram Bots or getting chatID just call to the API!" />
        <meta property="og:title" content="Telegram Text Messages"/>
        <meta property="og:description" content="CallMeBot can now send Text Messages! As expected, it is super easy to use the Web API and integrate it in all your scripts, automations, devices, IoT, etc. You..."/>
        <meta property="og:type" content="article"/>
        <meta property="og:url" content="https://www.callmebot.com/blog/telegram-text-messages/"/>
        <meta property="og:site_name" content="CallMeBot API"/>
                    <meta property="og:image" content="https://www.callmebot.com/wp-content/uploads/2020/03/Text-1024x440.jpg"/>
                <meta property="article:author" content="https://www.callmebot.com/author/admin/"/>
        <meta property="article:published_time" content="2021-03-23T22:04:10+00:00" />
        <meta property="article:modified_time" content="2021-05-03T15:02:24+00:00" />
        <meta property="og:updated_time" content="2021-05-03T15:02:24+00:00" />

                <meta itemprop="description" content="CallMeBot can now send Text Messages! As expected, it is super easy to use the Web API and integrate it in all your scripts, automations, devices, IoT, etc. You...">
        <meta itemprop="datePublished" content="2021-03-23T22:04:10+00:00">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2604115859432824" crossorigin="anonymous"></script>
<meta name="facebook-domain-verification" content="ehcdimhciane5c1clanandnv6oa62r" />

    <script type="text/javascript">
        ( function ( $ ) {
            "use strict";

            function setCookie( key, value ) {
                var expires = new Date();
                expires.setTime( expires.getTime() + ( 365 * 24 * 60 * 60 * 1000 ) );
                document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
            }

            function getCookie( key ) {
                var keyValue = document.cookie.match( '(^|;) ?' + key + '=([^;]*)(;|$)' );
                return keyValue ? keyValue[2] : null;
            }


            if ( getCookie( 'isRetina' ) == null ) {
                var isRetina = (
                    window.devicePixelRatio > 1 ||
                    ( window.matchMedia && window.matchMedia( "(-webkit-min-device-pixel-ratio: 1.5),(-moz-min-device-pixel-ratio: 1.5),(min-device-pixel-ratio: 1.5)" ).matches )
                    );

                setCookie( 'isRetina', isRetina );
            }


                var logo_retina = 'http://www.callmebot.com/wp-content/uploads/2019/10/Logo-Negro_x2.png';
            var logo_retina_width = '200';
            var logo_retina_height = '50';

            function retina_logo_dimensions() {
                if ( !jQuery( '.header .navbar-fixed-top' ).hasClass( "fixed-header" ) ) {
                    jQuery( '.logo img' ).css( {
                        "max-width": logo_retina_width + "px",
                        "max-height": logo_retina_height + ">px"
                    } );
                } else {
                    jQuery( '.logo img' ).css( {
                        "max-width": "",
                        "max-height": ""
                    } );
                }
            }

            jQuery( document ).ready( function ( $ ) {

                if ( logo_retina && logo_retina_width && logo_retina_height ) {
                    if ( getCookie( 'isRetina' ) === 'true' ) {

                        jQuery( '.logo img' ).attr( 'src', logo_retina );
                        retina_logo_dimensions();
                        jQuery( document ).scroll( function () {
                            retina_logo_dimensions();
                        } );

                    }
                }

            } );

        } )( jQuery );
    </script>
    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>

<!-- Google Tag Manager snippet added by Site Kit -->
<script>
			( function( w, d, s, l, i ) {
				w[l] = w[l] || [];
				w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
				var f = d.getElementsByTagName( s )[0],
					j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
				j.async = true;
				j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
				f.parentNode.insertBefore( j, f );
			} )( window, document, 'script', 'dataLayer', 'GTM-W2F4XK6' );
			
</script>

<!-- End Google Tag Manager snippet added by Site Kit -->
<meta name="generator" content="Powered by Slider Revolution 5.4.7.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />

		<script>
			var ulp_custom_handlers = {};
			var ulp_cookie_value = "ilovelencha";
			var ulp_recaptcha_enable = "off";
			var ulp_content_id = "4294";
		</script><script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
    <style type="text/css">

                .container-fluid, .container {
            max-width: 1300px;
        }
        @media (min-width: 1200px) {
            .container-fluid, .container {
                width: auto;
            }
        }
        
        #leap-wrapper.container {
            padding: 0;
        }

        .sf-menu .container-fluid.sf-mega.menu-fullwidth {
            max-width: 1300px;
        }

        /******************* skin ***********************/

                /******** primary color ***********/

        /******* Buttons ****/
        .btn-leap, a.btn-leap, input[type="submit"], input[type="reset"], input[type="button"] {
            background-color: #f67207;
            border: 1px solid #dd6706;
        }
        .btn-leap:hover, .btn-leap:focus, .btn-leap:active, .btn-leap:active:focus, input[type="submit"]:hover, 
        input[type="reset"]:hover, input[type="button"]:hover {
            background-color: #dd6706;
            border-color: #dd6706;
        }
        #footer-sidebar .btn-leap, #footer-sidebar input[type="submit"], #footer-sidebar  input[type="reset"], 
        #footer-sidebar input[type="button"], #footer-sidebar .btn-leap:hover, #footer-sidebar .btn-leap:focus, 
        #footer-sidebar .btn-leap:active, #footer-sidebar .btn-leap:active:focus, #footer-sidebar input[type="submit"]:hover, 
        #footer-sidebar input[type="reset"]:hover, #footer-sidebar input[type="button"]:hover {
            color: rgba(255,255,255,0.7); 
        }
        a:hover, a:focus, a:active, .main-menu li a:hover, .main-menu li a:focus, .main-menu li a:active, .main-menu li.sfHover > a,
        .main-menu li a:hover span, .main-menu li a:focus span, .main-menu li a:active span,
        div.entry-title h1, .item-overlay .item-links a:hover:before, 
        .leap-post-details .post-type, .entry-meta a:hover, .entry-meta a:active, .entry-meta a:focus, 
        .entry-meta a:hover span, .leap-share-buttons a:hover i, .header a#searchbutton:hover, 
        .header a#searchbutton:focus, .header a#searchbutton:active, p.social-networks a:hover i, 
        p.social-networks a:focus i, .main-menu li.current-menu-item > a, 
        .main-menu li.current-page-ancestor > a, 
        .main-menu li.current-page-ancestor > a:hover,
        .main-menu li.current-menu-ancestor > a, 
        .main-menu li.current-menu-ancestor > a:hover, 
        .main-menu li.current-menu-parent > a, 
        .main-menu li.current-menu-parent > a:hover, 
        .main-menu li.current_page_ancestor > a, 
        .main-menu li.current_page_ancestor > a:hover,.top-menu li > a:hover, .top-menu a:focus,
        .top-menu a:active, .top-men li.current_page_item > a, .top-menu li.current_page_ancestor > a, 
        .top-menu ul li.current_page_item a, #crumbs a:hover, #crumbs a:active, #crumbs a:focus, 
        .ui-accordion .ui-accordion-header:hover, 
        .ui-accordion .ui-accordion-header .ui-accordion-header-icon:before, 
        .ui-accordion h3.ui-accordion-header-active, .price em.exact_price, .price sup, ul.ul-leap li:before,
        .sc-rposts .leap-content .post-title a:hover, .sc-rposts .leap-content .post-title a:active, 
        .sc-rposts .leap-content .post-title a:focus, .sc-rposts .post-comment a:hover, 
        .style-1.table tr th, .style-2.table tr th, .list_carousel .cfs-nav span:hover:before, 
        .widget a:hover, .widget a:focus, .widget a:active, ol.commentlist div.comment-author a:hover ,
        ol.commentlist div.comment-author a:active ,ol.commentlist div.comment-author a:focus, 
        .pagination ul > .active > a, .pagination ul > .active > span, ul.portfolio-tabs li a:hover, 
        ul.portfolio-tabs li.active a, #footer-sidebar .widget a:hover, #footer-sidebar .widget a:active,
        #footer-sidebar .widget a:focus, .post-navigation div:hover span, .post-navigation div:hover a, 
        .archive-info .author-links i:hover, #tag-cloud a:hover, .tags a:hover, 
        #leap-contact .contact-info div strong, .widget.widget_rss h4.widget-title a, 
        .leap-widget-style2 .widget.widget_rss h4.widget-title a, 
        .leap-widget-style8 .widget.widget_rss h4.widget-title a, 
        .leap-widget-style7 .widget.widget_rss h4.widget-title a,
        .widget.widget_rss h4.widget-title a:hover, 
        .leap-widget-style2 .widget.widget_rss h4.widget-title a:hover, 
        .leap-widget-style8 .widget.widget_rss h4.widget-title a:hover, 
        .leap-widget-style9 .widget.widget_rss h4.widget-title a:hover, 
        ul.products li.product .price, .cart-loading:hover, .entry-summary .price .amount, 
        .woocommerce .price .amount, .widget.woocommerce .price ins, .widget.woocommerce ins span.amount,
        .widget.woocommerce ins, .widget.woocommerce span.amount, 
        .yith-woocompare-widget ul.products-list a.remove, .cart_totals.calculated_shipping table td .amount,
        .shipping_calculator h2 a, .cart-collaterals h2, .cross-sells h2, table.shop_table .order-total th, 
        table.shop_table .order-total td, .woocommerce .login span.required, .myaccount_user strong, 
        .myaccount_user a, .woocommerce-account .woocommerce > h2, .header.title h3, 
        .single_variation_wrap .single_variation span span, .woocommerce-tabs ul.tabs li.active a, 
        .yith-woocompare-widget a.clear-all:after, .yith-woocompare-widget a.clear-all:before,
        ul.order_details li:before, .shop_table.order_details tfoot tr:last-child .amount, 
        .customer_details dt, .woocommerce-tabs ul.tabs li a:hover, ul.products li.product h3:hover, 
        ul.products li.product h3:focus,
        #leap-footer .footer-block a:hover, #leap-footer .footer-block a:focus, 
        #leap-footer .footer-block a:active, #leap-footer .footer-block a:hover span, 
        .sc-rposts.style-2 .leap-post-entry .post-type:hover a.item-icon, 
        .woocommerce #content table.wishlist_table.cart a.remove:hover, 
        .ui-tabs .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor, 
        .ui-tabs .ui-tabs-nav li.ui-state-disabled .ui-tabs-anchor, 
        .ui-tabs .ui-tabs-nav li.ui-tabs-loading .ui-tabs-anchor , 
        .leap-sc-tabs.horizontal.style-3 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-3 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .slicknav_nav li a:hover, .slicknav_nav li.slicknav_parent:hover > a, 
        .slicknav_nav .slicknav_item a:hover a, .slicknav_nav .slicknav_row:hover, 
        .slicknav_nav .slicknav_open > .slicknav_row a, .slicknav_nav li.slicknav_open:hover > *, 
        .pagination ul > li > a:hover, span.bbp-admin-links a:hover,
        span.bbp-admin-links a:focus, span.bbp-admin-links a:active , 
        .status-publish .bbp-topic-meta a:hover , .status-publish .bbp-topic-meta a:focus, 
        #lang_sel a.lang_sel_sel:hover, #lang_sel a.lang_sel_sel:focus, .icon-box2:hover .main-icon i,
        .header12 .menu-icon:hover, .header12 .menu-icon:focus:hover,.header13 .menu-icon:hover, .header13 .menu-icon:focus:hover,
        .header14 a.menu-icon:hover .fa-bars, .header14 a.menu-icon:focus:hover .fa-bars, .woocommerce-MyAccount-navigation li.is-active a {
            color: #f67207;
        }
        .leap-post-details .post-type, .post-icon a:hover, .post-icon a:hover, .leap-pricing-table .featured ul li.title-row, 
        .leap-pricing-table .column:hover ul li.title-row, .sep-boxed-pricing.leap-pricing-table .column:hover ul li.title-row, 
        .pagination ul > li.active > a span, .pagination ul > li.active > a:hover span, a.scrollup:hover, 
        .leap-overlay .item-img-color, .leap-widget-style3 .widget-title, .leap-widget-style6 .widget-head, 
        .leap-widget-style7 .widget-head, .woocommerce-pagination ul li span.current, 
        .yith-woocompare-widget ul.products-list a.remove:hover, .price_slider_wrapper .ui-slider .ui-slider-range, 
        .widget.woocommerce.widget_layered_nav_filters ul li a, .chosen-container .chosen-results li:hover, 
        .chosen-container .chosen-results li:focus, .chosen-container .chosen-results li:active, 
        .chosen-container .chosen-results li.highlighted, .searchform form button.btn, div.static-search form button.btn, .onsale, 
        .leap-sc-tabs.horizontal.style-3 .ui-tabs-nav .ui-tabs-anchor, .leap-sc-tabs.vertical.style-3 .ui-tabs-nav .ui-tabs-anchor, 
        .pagination-page ul > li > span, .pagetitle2 div.entry-title h1:after, #bbpress-forums div.bbp-forum-author .bbp-author-role,
        div.title.title-style3 .title-heading, div.title.title-style4 .title-heading, .leap-widget-style11 div.title .widget-title:after , 
        .header #nav-icon.icon-close span, .header #nav-icon.active span ,.title-style8 .strip:before, .header16 #v-menu li a:after  {
            background-color: #f67207;
        }
        blockquote, .topbar-block, .main-menu li:hover, .main-menu li:active, .main-menu li:focus, .main-menu li.sfHover, 
        .header2, 
        .leap-pricing-table ul li.footer-row, .tagline-box.tagline-4, .wdg-counter li a:hover i, .pagination ul > li.active > a span, 
        .pagination ul > li.active > a:hover span, ul.portfolio-tabs li.active a, .leap-widget-style3 .widget-head, 
        .leap-widget-style4 .widget-title, .leap-widget-style8 .widget-head, .leap-widget-style9 div.title .widget-title, 
        .sf-menu .menu-item-cart .widget_shopping_cart_content, .woocommerce-pagination ul li span.current, .header .topbar-block, 
        .header4 .topbar-block, .header5 .topbar-block, .header6 .topbar-block, .slicknav_nav li:hover, 
        .pagination-page ul > li > span, .pagetitle3 .entry-title, div.title.title-style3, div.title.title-style5, 
        div.title.title-style6 .title-heading, div.title.title-style7 .title-heading, .main-menu ul li a:hover, 
        .leap-testimonials-2 .person-image img {
            border-color: #f67207;
        }
        .leap-widget-style5 .widget-content, .leap-widget-style9 .widget-title:before, 
        div.title.title-style7 .title-heading:before,
        .header-vh .sf-menu > li:hover, .header-vh .sf-menu > li:focus, .header-vh .sf-menu > li:active {
            border-bottom-color: #f67207;
        }
        div.title.title-style2 .title-heading , div.title.title-style2.alignright .title-heading, 
        div.title.title-style2.title-center .title-heading{
            border-left-color: #f67207;
            border-right-color: #f67207;
        }
        /******** smart skin ***********/	
        a, .main-menu a, .main-menu .mega-section-head a, .main-menu .mega-section-head > span, a#searchbutton, .widget-title, 
        .widget a, .ui-accordion .ui-accordion-header, .ui-accordion .ui-accordion-header-active span.ui-accordion-header-icon:before, 
        .leap-icon-box .col .heading h4, h1, h2, h3, h4, h5, h6, .pagination a, .item-overlay a, 
        .woocommerce #content table.wishlist_table.cart a.remove, .slicknav_nav a, .main-menu > li a:hover span.menu-item-description, 
        .main-menu > li a:active span.menu-item-description, .main-menu > li a:focus span.menu-item-description, 
        .main-menu > li:visited a span.menu-item-description, .main-menu > li.current-menu-item a span.menu-item-description, 
        .header.header-vh .contact-info, .header.header-vh .contact-info span, 
        .header.header-vh .contact-info a, .header.header-vh p.social-networks a, 
        .header12 .menu-icon, .header12 .menu-icon:focus,.header13 .menu-icon, .header13 .menu-icon:focus,
        .menu-icon .fa-close, .menu-icon:focus .fa-close, .menu-icon:hover .fa-close , 
        .menu-icon:focus:hover .fa-close {
            color: #1c1c1c;
        }
        .slicknav_btn {
            background-color: rgba(28,28,28,0.7);
        }
        body, caption, select, textarea, .widget.woocommerce ul li del span.amount, 
        .entry-summary .price del .amount, .product-price-rate .price del .amount, 
        .woocommerce .price del, .chosen-container-single .chosen-single, 
        #reviews .stars a, #reviews .stars a:hover, 
        .wishlist_table tr td.product-stock-status span.wishlist-in-stock, 
        input[type="text"], input[type="text"]:focus, .form-control, .form-control:focus, 
        textarea, textarea:focus, input[type="password"], input[type="password"]:focus, 
        input[type="email"], input[type="date"], input[type="number"], input[type="email"]:focus,
        input[type="date"]:focus, input[type="number"]:focus, input[type="tel"],
        input[type="tel"]:focus, .variations .label, div.bbp-template-notice, div.indicator-hint,
        .select2-container .select2-choice, .select2-container .select2-choice:focus,
        #lang_sel a.lang_sel_sel, #lang_sel ul ul a, #lang_sel ul ul a:hover, #lang_sel ul ul a:focus, legend {
            color: #4c4c4c;
        }
        ::-moz-placeholder , .form-control::-moz-placeholder {
            color: #4c4c4c;
        }
        ::-ms-input-placeholder, .form-control::-ms-input-placeholder {
            color: #4c4c4c;
        }
        ::-webkit-input-placeholder, .form-control::-webkit-input-placeholder {
            color: #4c4c4c;
        }
        .main-menu > li:before, ul.portfolio-tabs li:before, .post-not-found-head h1, .post-not-found-head p , 
        small.small, .widget span.date, .widget_recent_entries ul li span.post-date, .widget .rss-date, small a, 
        .commentmetadata a , .wp-caption, .wp-caption a, .widget_display_topics li div, .widget_display_replies li div {
            color: rgba(76,76,76,0.6);
        }
        .header-vh .sf-menu > li {
            border-color: rgba(76,76,76,0.6);
        } 
        #nav-icon, .header17 .logo a:after {
            background-color: rgba(76,76,76,0.9);
        }
        .header14 .menu-icon {
            background-color: rgba(76,76,76,0.9);
        }
        div.entry-title h1, #crumbs span, #crumbs a {
            color: #6c6c6c;
        }
        h5.subtitle {
            color: rgba(108,108,108,0.7);
        }
        .leap-testimonials-2 .testimonial-text-container > .fa {
            color: rgba(108,108,108,0.3);
        }
        blockquote p, .single-quotes-bg, .double-quotes-bg, .highlight, .leap-share-buttons i, .header.header2 .contact-info, 
        .header.header2 .contact-info span, .header.header2 .contact-info a, .archive-info .author-links i, .archive-info .author-links, 
        .post-icon a:before, mark, .header.header2 p.social-networks a, .header.header15 p.social-networks a {
            color: #828282;
        }
        #bbpress-forums ul.bbp-topics, #bbpress-forums .bbp-forum-info .bbp-forum-content, 
        #bbpress-forums .status-publish p.bbp-topic-meta, #bbpress-forums ul.bbp-forums, .bbp-reply-content, .bbp-forum-freshness a, 
        .bbp-topic-freshness a , .bbp-pagination-count, #bbpress-forums ul.bbp-lead-topic, .status-publish .bbp-topic-meta a {
            color: #707070;
        }
        #bbpress-forums li.bbp-header, #bbpress-forums li.bbp-footer, #bbpress-forums .status-closed, 
        #bbpress-forums .status-closed a, #bbpress-forums li.bbp-header .bbp-reply-content, 
        #bbpress-forums li.bbp-footer .bbp-reply-content, span.bbp-admin-links a, .bbp-reply-post-date, 
        .bbp-forum-header a.bbp-forum-permalink, .bbp-topic-header a.bbp-topic-permalink, .bbp-reply-header a.bbp-reply-permalink {
            color: #b7b7b7;
        }
        .pagination ul > li > a span, .wdg-post img , #calendar_wrap , #wp-calendar tr, 
        .post_tags .label , select , .leap-widget-style5 .widget-content, .leap-widget-style8 .widget, 
        img.avatar, .avatar > img , .commentlist .thread-even .comment-text em, 
        .blog-grid .hentry .entry-wrapper, .archive-grid .hentry .entry-wrapper, 
        #main .ui-accordion .ui-accordion-content img, .style-2 .ui-accordion-header:hover, 
        .style-2 .ui-accordion-header .ui-accordion-header-icon:before, 
        .style-2 .ui-accordion-header-active , .style-3 .ui-accordion-header:hover, 
        .style-3 .ui-accordion-header .ui-accordion-header-icon:before, 
        .style-3 .ui-accordion-header-active , .style-3 .ui-accordion-header-active, 
        .dropcap.style-2, .testimonial .company-details .person-image img , 
        .testimonial .testimonial-content, .flickr-wrapper .flickr_badge_image img, 
        .leap-pricing-table .column > ul, .tagline-box.tagline-4 , .sc-rposts .item-img, .table-responsive
        .table>thead>tr>th, .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, 
        .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td, .leap-table,
        .woocommerce.widget_product_categories ul li, .woocommerce .widget_layered_nav ul li, 
        .woocommerce .widget_layered_nav ul li, .woocommerce-page .widget_layered_nav ul li, 
        .woocommerce-page .widget_layered_nav ul li , .woocommerce ul.cart_list li img, 
        .woocommerce ul.product_list_widget li img, .woocommerce-page ul.cart_list li img, 
        .woocommerce-page ul.product_list_widget li img, .main-menu .menu-item-cart ul.cart_list li, 
        .main-menu .menu-item-cart ul.cart_list li:first-child, .product-container, .product-list-hover,
        ul.products .product-list-hover .button.add_to_cart_button, 
        ul.products .product-list-hover .button.product_type_simple, 
        ul.products .product-list-hover .button.product_type_grouped, div.product div.images img, 
        .woocommerce-tabs .entry-content, .woocommerce-tabs ul.tabs li.active a, 
        .main-menu .widget_shopping_cart_content .buttons, .main-menu .menu-item-cart ul.cart_list li a img, 
        .woocommerce-message, .woocommerce-info, .chosen-container-active.chosen-with-drop .chosen-single, 
        #reviews .comment_container img,
        .woocommerce-billing-fields .chosen-container-single .chosen-single, 
        .chosen-container-single .chosen-single, table.shop_table th, div table.shop_table td, 
        .cart_totals table td , .cart_totals table th, .woocommerce table.wishlist_table thead th, 
        .woocommerce table.wishlist_table tbody td, .shop_attributes tr , .leap-separator span, 
        .leap-sc-tabs.horizontal.style-1 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.horizontal.style-1 .ui-tabs-panel, 
        .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.horizontal.style-2 .ui-tabs-panel, 
        .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-1 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-1 .ui-tabs-panel, 
        .leap-sc-tabs.vertical.style-2 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-2 .ui-tabs-panel , .widget.leatabs .ui-tabs-panel li, 
        .comment-body, input[type="text"], input[type="text"]:focus, .form-control, .form-control:focus,
        textarea, textarea:focus, input[type="password"], input[type="password"]:focus, input[type="email"],
        input[type="date"], input[type="number"], input[type="email"]:focus, input[type="tel"],
        input[type="tel"]:focus, input[type="date"]:focus, input[type="number"]:focus, 
        .select2-container .select2-choice, #bbpress-forums .hentry div.bbp-reply-content, 
        #bbpress-forums .hentry div.bbp-topic-content, #bbpress-forums .hentry div.bbp-reply-content:before,
        #bbpress-forums .hentry div.bbp-topic-content:before, #lang_sel a.lang_sel_sel, 
        #lang_sel a.lang_sel_sel:hover, #lang_sel a.lang_sel_sel:focus, #lang_sel ul ul a, 
        #lang_sel ul ul a:hover, #lang_sel ul ul a:focus, #lang_sel ul ul, #main-menu .menu-item-cart ul.cart_list li a img,
        .yith-woocompare-widget ul li, #bbpress-forums #bbp-your-profile fieldset input, 
        #bbpress-forums #bbp-your-profile fieldset textarea, form#new-post, .comment.list li img,
        .blog-large-modern .entry-content, .archive-large-modern .entry-content,
        .blog-large-modern .entry-content .post-content, .archive-large-modern .entry-content .post-content,
        .blog-large-modern .entry-content, .archive-large-modern .entry-content, .woocommerce-MyAccount-navigation li, .woocommerce-MyAccount-content,
        .leap-widget-style11 > div.widget {
            border-color: #e3e3e3;
        }
        .rtl .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-tabs-anchor, #bbpress-forums .bbp-forums-list {
            border-left-color: #e3e3e3;
        }
        .header2 .topbar-block, .main-menu ul li a, .widget_archive ul li, .widget_categories ul li, .widget_nav_menu ul li, 
        .widget_meta ul li , .widget_pages ul li, .widget_recent_comments ul li, .widget_recent_entries ul li, .widget_rss ul li, 
        div.category-posts ul li , .widget.comments-avatar ul li, .widget_author_posts ul li, .widget.posts-list ul li, .widget.leap-tabs .ui-tabs-panel li, div.widget.category-posts ul li,
        .widget.tweets ul li, .leap-widget-style4 .widget-head, .leap-widget-style9 .widget-head, ol.commentlist li , 
        .post-entry, .style-2 .ui-accordion-content, .accordion.style-3, .toggle-open.style-3:last-child, .toggle.style-3:last-child , 
        .toggle.style-3 , ul.feedlist > li, div.sep1, div.sep2 , .sc-rposts.style-2 .leap-date .sc-recent-posts-date-day, 
        .portfolio-sep, .project-details .box, .slicknav_nav li, .widget_display_forums li, .widget_display_replies li, 
        .widget_display_topics li, .widget_display_views li , .woocommerce ul.product_list_widget li , 
        .main-menu .menu-item-cart .widget_shopping_cart_content, .navbar-fixed-top.fixed-header, 
        .blog-wrapper .hentry, .archive-wrapper .hentry, #main-menu .menu-item-cart ul.cart_list li, 
        #main-menu .menu-item-cart ul.cart_list li:first-child, #main-menu .menu-item-cart .widget_shopping_cart_content,
        div.title.title-style6, div.title.title-style7, .header-vh .sf-menu > li , .woocommerce-MyAccount-navigation li, .person2 .person-img {
            border-bottom-color: #e3e3e3;
        }
        .header2 .topbar-block, .header4 .navbar-inner, .header5 .navbar-inner, .header6 .navbar-inner, .separator-widget, 
        ol.commentlist ul.children li, .ui-accordion .ui-accordion-header, .ui-accordion .ui-accordion-content , 
        .style-3 .ui-accordion-header, .toggle-open.style-3, .toggle.style-3, .testimonial .testimonial-content:before, 
        table>thead>tr>th, table>tbody>tr>th, table>tfoot>tr>th, table>thead>tr>td, table>tbody>tr>td, table>tfoot>tr>td, 
        #bbpress-forums li.bbp-body ul.forum, #bbpress-forums li.bbp-body ul.topic {
            border-top-color: #e3e3e3;
        }
        .style-2 .ui-accordion-content, .style-3 .ui-accordion-header , .style-3 .ui-accordion-content, .toggle-open.style-3, .toggle.style-3 {
            border-left-color: #e3e3e3;
            border-right-color: #e3e3e3;
        }
        #post-not-found .input-prepend.input-append .add-on:first-child {
            border-right-color: #e3e3e3;
        }
        span.bbp-admin-links {
            color: #e3e3e3;
        }
        .icon-box2 {
            background-color: #e3e3e3;
        }
        .searchform .navbar-search, .leap-sc-tabs.horizontal.style-1 .ui-tabs-nav .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-1 .ui-tabs-nav .ui-tabs-anchor, #bbpress-forums p.bbp-topic-meta img.avatar, 
        #bbpress-forums ul.bbp-reply-revision-log img.avatar, #bbpress-forums ul.bbp-topic-revision-log img.avatar, 
        #bbpress-forums div.bbp-template-notice img.avatar, #bbpress-forums .widget_display_topics img.avatar, 
        #bbpress-forums .widget_display_replies img.avatar, #bbpress-forums div.bbp-forum-author img.avatar, 
        #bbpress-forums div.bbp-topic-author img.avatar, #bbpress-forums div.bbp-reply-author img.avatar, 
        div.bbp-template-notice, div.indicator-hint {
            border-color:  #f2f2f2;
        }
        blockquote, .main-menu ul li, .main-menu ul ul li, .main-menu ul li:hover, .main-menu ul li:focus, .main-menu ul li.sfHover, 
        span.mega-section-head, .sf-menu .sf-mega, .sf-menu .sf-mega.menu-fullwidth .row, span:hover.mega-section-head, .main-menu .menu-item-has-megamenu ul ul li, 
        .searchform .navbar-search, .static-search .navbar-search, .widget_calendar a, .wdg-counter li a i, .leap-widget-style7 .widget,
        .leap-widget-style8 .widget, .leap-share-buttons , .hentry .leap-share-buttons, .post-icon a, .archive-info .author-links, 
        .ui-accordion .ui-accordion-header-active, .ui-accordion .ui-accordion-header:hover, .single-quotes-bg, .double-quotes-bg, 
        .layout-icon-boxed .col, .testimonial .testimonial-content, .highlight , .leap-pricing-table ul li, .tagline-box.tagline-2, 
        .leap-post-details .post-type:hover, .style-2.table tr th, .list_carousel .cfs-nav span:before, .portfolio-tabs, 
        .woocommerce .widget_shopping_cart .buttons, .woocommerce-page .widget_shopping_cart .buttons, 
        .woocommerce.widget_shopping_cart .buttons, .ui-accordion .ui-accordion-content, .style-3.ui-accordion .ui-accordion-content, 
        .style-2.ui-accordion .ui-accordion-header, .cart-loading, .woocommerce-tabs ul.tabs li a, table.shop_table thead tr, 
        table.shop_table tr:nth-child(even), ul.payment_methods li div p , 
        .entry-summary .product-buttons .leap-yith-wcwl-add-to-wishlist a:before, 
        .entry-summary .product-buttons a.compare.button:before, .leap-sc-tabs.horizontal.style-1 .ui-tabs-nav .ui-tabs-anchor, 
        .leap-sc-tabs.horizontal.style-3 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.horizontal.style-3 .ui-tabs-panel , .leap-sc-tabs.vertical.style-1 .ui-tabs-nav .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-3 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, .leap-sc-tabs.vertical.style-3 .ui-tabs-panel, 
        .slicknav_nav , .slicknav_nav li a:hover, .slicknav_nav li.slicknav_parent:hover a a, .slicknav_nav .slicknav_item a:hover a, 
        .slicknav_nav .slicknav_row:hover, .slicknav_nav .slicknav_open > .slicknav_row a, .slicknav_nav li.slicknav_open:hover > *, 
        .slicknav_nav a, #bbpress-forums #bbp-single-user-details #bbp-user-navigation li.current a, div.bbp-template-notice, 
        div.indicator-hint, .quicktags-toolbar, mark, .leap-widget-style10 .widget, .entry-summary .product-buttons .leap-yith-wcwl-add-to-wishlist a:after, 
        .entry-summary .product-buttons a.compare.button:after  {
            background-color: #f2f2f2;
        }
        .searchform .navbar-search:before , .quicktags-toolbar {
            border-bottom-color: #f2f2f2;
        }
        .testimonial .testimonial-content:after {
            border-top-color: #f2f2f2;
        }
        .person2 .person-data {
            background-color: #e3e3e3;
        }
        div#title {
            background-color: #f7f7f7;
        }
        .framed #leap-wrapper {
            border-color: #f7f7f7;
        }
        #leap-wrapper, .navbar-inner, .boxed .header8 .mainmenu-logo-container .nav-container ,.wide .header8 .mainmenu-logo-container , 
        .header8 .mainmenu-logo-container.boxed-header .mainmenu-logo, .boxed .header9 .mainmenu-logo-container .nav-container ,
        .wide .header9 .mainmenu-logo-container , .header9 .mainmenu-logo-container.boxed-header .mainmenu-logo, 
        .header7 .navbar-inner.navbar-fixed-top.fixed-header, 
        .header8 .navbar-inner.navbar-fixed-top.fixed-header, .header9 .navbar-inner.navbar-fixed-top.fixed-header, 
        .ui-accordion .ui-accordion-header, .style-2 .ui-accordion-content, .style-3 .ui-accordion-header-active, 
        .style-3 .ui-accordion-header:hover , .leap-pricing-table ul li:nth-child(2n+1), .navbar-inner.navbar-fixed-top.fixed-header, 
        .leap-sc-tabs.horizontal.style-1 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.horizontal.style-1 .ui-tabs-panel, 
        .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.horizontal.style-2 .ui-tabs-panel, .leap-sc-tabs.vertical.style-1 .ui-tabs-nav .ui-state-active .ui-tabs-anchor, 
        .leap-sc-tabs.vertical.style-1 .ui-tabs-panel , .leap-sc-tabs.vertical.style-2 .ui-tabs-nav .ui-state-active .ui-tabs-anchor,
        .leap-sc-tabs.vertical.style-2 .ui-tabs-panel, .leap-sc-tabs.vertical.style-2 .ui-tabs-nav .ui-tabs-anchor, 
        .slicknav_menu .slicknav_icon-bar, #bbpress-forums .hentry div.bbp-reply-content:before, 
        #bbpress-forums .hentry div.bbp-topic-content:before, .header10 , 
        .header11 , .header12 .header-vh-wrapper, .header13 .header-vh-wrapper , .header15 .icon-header {
            background-color: #fcfcfc;
        }
        .header14 .header-vh-wrapper .header-content {
            background-color: rgba(252,252,252,0.9);
        }
        .icon-box2 .icon-box-details {
            background-color: rgba(252,252,252,0.6);
        }
        .header14 a.menu-icon .fa-bars, .header14 a.menu-icon:focus .fa-bars {
            color: #fcfcfc;
        }
        .header #nav-icon span {
            background-color: #fcfcfc;
        }
.product-container , .product-list-details, .product-list-hover, .woocommerce-tabs ul.tabs li.active a, .woocommerce-tabs .entry-content {
            background-color: #fcfcfc;
}
        .leap-sc-tabs.vertical.style-2 .ui-tabs-nav .ui-tabs-anchor {
            border-color: #fcfcfc;
        }
        .leap-sc-tabs.vertical.style-2 .ui-tabs-nav .ui-tabs-anchor {
            border-bottom-color: #e3e3e3;
        }
        .header.header7 .contact-info , .header.header7 .contact-info span, .header.header7 .contact-info a,
        .header.header8 .contact-info , .header.header8 .contact-info span, .header.header8 .contact-info a,
        .header.header9 .contact-info , .header.header9 .contact-info span, .header.header9 .contact-info a,
        .header.header7 p.social-networks a, .header.header8 p.social-networks a, .header.header9 p.social-networks a
        {
            color: #fcfcfc;
        }
        input[type="text"], input[type="text"]:focus, .form-control, .form-control:focus, textarea, 
        textarea:focus, input[type="password"], input[type="password"]:focus, input[type="email"], 
        input[type="date"], input[type="number"], input[type="email"]:focus, input[type="tel"], 
        input[type="tel"]:focus, input[type="date"]:focus, input[type="number"]:focus, 
        .select2-container .select2-choice, select, #lang_sel a.lang_sel_sel, #lang_sel a.lang_sel_sel:hover,
        #lang_sel a.lang_sel_sel:focus, #lang_sel ul ul a, #lang_sel ul ul a:hover, #lang_sel ul ul a:focus, 
        #bbpress-forums #bbp-your-profile fieldset input, #bbpress-forums #bbp-your-profile fieldset textarea {
            background-color: #fdfdfd;
        }
        .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-tabs-anchor {
            border-top-color: #fcfcfc;
            border-bottom-color: #fcfcfc;
            border-left-color: #fcfcfc;
        }
        .rtl .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-tabs-anchor {
            border-right-color: #fcfcfc;
        }
        .blog-large-modern .entry-content, .archive-large-modern .entry-content {
            background-color: #fdfdfd;
        }        
        .dark-skin .btn-leap, .dark-skin a.btn-leap, .dark-skin .btn-leap:hover, .dark-skin a.btn-leap:hover, .dark-skin .btn-leap:focus, 
        .dark-skin a.btn-leap:focus, .dark-skin .btn-leap:active, .dark-skin .btn-leap:active:focus, .dark-skin input[type="submit"], 
        .dark-skin input[type="reset"], .dark-skin input[type="button"], .dark-skin input[type="submit"]:hover, 
        .dark-skin input[type="reset"]:hover, .dark-skin input[type="button"]:hover, .dark-skin input[type="submit"]:focus, 
        .dark-skin input[type="reset"]:focus, .dark-skin input[type="button"]:focus, .dark-skin .btn-default.btn-leap:active:hover, 
        .dark-skin .btn-default.btn-leap:active, .dark-skin .pp_details {
            color: #fcfcfc;
        }
        .rtl .leap-sc-tabs.horizontal.style-2 .ui-tabs-nav .ui-state-active .ui-tabs-anchor {
            border-right-color: #e3e3e3;
        }
        #footer-sidebar a, #footer-sidebar .widget-title, #footer-sidebar .widget a, #footer-sidebar h1, #footer-sidebar h2, 
        #footer-sidebar h3, #footer-sidebar h4, #footer-sidebar h5, #footer-sidebar h6, .header .contact-info, 
        .header .contact-info span, .header .contact-info a, #leap-footer a, #leap-footer .widget a, .header p.social-networks a,
        .top-menu li a {
            color: #ffffff;
        } 
        #footer-sidebar , #footer-sidebar caption, #footer-sidebar select, #footer-sidebar textarea, 
        #footer-sidebar .form-control, #footer-sidebar .footer-block p, #leap-footer .footer-block p, ul#footer-menu li:before {
            color: rgba(255,255,255,0.7);
        }
        #footer-sidebar .form-control::-moz-placeholder {
            color: rgba(255,255,255,0.7);
        }
        #footer-sidebar .form-control:-ms-input-placeholder {
            color: rgba(255,255,255,0.7);
        }
        #footer-sidebar .form-control::-webkit-input-placeholder {
            color: rgba(255,255,255,0.7);
        }	
        #footer-sidebar small.small, #footer-sidebar .widget span.date, #footer-sidebar .widget_recent_entries ul li span.post-date, 
        #footer-sidebar .widget .rss-date, #footer-sidebar small a , #footer-sidebar .wp-caption, #footer-sidebar .wp-caption a, 
        #footer-sidebar .widget_display_replies li div, #footer-sidebar .widget_display_topics li div {
            color: rgba(255,255,255,0.5);
        }
        .top-menu ul li, .top-menu ul li:hover, .top-menu ul li.sfHover {
            border-bottom-color: #ffffff;
        }
        #footer-sidebar input[type="text"], #footer-sidebar input[type="text"]:focus, 
        #footer-sidebar .form-control, #footer-sidebar .form-control:focus, #footer-sidebar textarea, 
        #footer-sidebar textarea:focus, #footer-sidebar input[type="password"], #footer-sidebar input[type="password"]:focus, 
        #footer-sidebar #calendar_wrap , #footer-sidebar #wp-calendar tr, 
        #footer-sidebar .post_tags .label , #footer-sidebar .leap-widget-style5 .widget-content, 
        #footer-sidebar .leap-widget-style8 .widget, #footer-sidebar img.avatar, 
        #footer-sidebar .avatar > img , #footer-sidebar .woocommerce.widget_product_categories ul li, 
        #footer-sidebar .woocommerce .widget_layered_nav ul li, 
        #footer-sidebar .woocommerce .widget_layered_nav ul li, 
        #footer-sidebar .woocommerce-page .widget_layered_nav ul li,
        #footer-sidebar .woocommerce-page .widget_layered_nav ul li , 
        #footer-sidebar .woocommerce ul.cart_list li img, 
        #footer-sidebar .woocommerce ul.product_list_widget li img, 
        #footer-sidebar .woocommerce-page ul.cart_list li img, 
        #footer-sidebar .woocommerce-page ul.product_list_widget li img, #footer-sidebar .wdg-post img, 
        #footer-sidebar input[type="email"], #footer-sidebar input[type="date"], 
        #footer-sidebar input[type="number"], #footer-sidebar input[type="email"]:focus, 
        #footer-sidebar input[type="date"]:focus, #footer-sidebar input[type="number"]:focus, 
        #footer-sidebar #lang_sel a.lang_sel_sel, #footer-sidebar #lang_sel a.lang_sel_sel:hover, 
        #footer-sidebar #lang_sel a.lang_sel_sel:focus, #footer-sidebar #lang_sel ul ul a, 
        #footer-sidebar #lang_sel ul ul a:hover, #footer-sidebar #lang_sel ul ul a:focus, 
        #footer-sidebar #lang_sel ul ul, .woocommerce-MyAccount-content {
            border-color: #424242;
        }
        #footer-sidebar .woocommerce ul.product_list_widget li, #footer-sidebar .widget_archive ul li, 
        #footer-sidebar .widget_categories ul li, #footer-sidebar .widget_nav_menu ul li, #footer-sidebar .widget_meta ul li , 
        #footer-sidebar .widget_pages ul li, #footer-sidebar .widget_recent_comments ul li, #footer-sidebar .widget_recent_entries ul li, 
        #footer-sidebar .widget_rss ul li , #footer-sidebar .widget.comments-avatar ul li, #footer-sidebar div.category-posts ul li, 
        #footer-sidebar .widget_author_posts ul li, #footer-sidebar .widget.posts-list ul li, #footer-sidebar div.widget.category-posts ul li ,#footer-sidebar .widget.leap-tabs .ui-tabs-panel li, #footer-sidebar .widget.tweets ul li, 
        #footer-sidebar .leap-widget-style4 .widget-head, #footer-sidebar .leap-widget-style9 .widget-head, 
        #footer-sidebar ol.commentlist li, .woocommerce-MyAccount-navigation li  {  
            border-bottom-color: #424242;
        }
        #footer-sidebar .separator-widget, #footer-sidebar ol.commentlist ul.children li {
            border-top-color: #424242;
        }
        #footer-sidebar .widget_calendar a, #footer-sidebar .wdg-counter li a i, #footer-sidebar .leap-widget-style7 .widget, 
        #footer-sidebar .leap-widget-style8 .widget, #footer-sidebar .leap-widget-style10 .widget {
            background-color: #282828;
        }
        .header1 .topbar-block, .header4 .topbar-block, .header5 .topbar-block, .header6 .topbar-block, #leap-footer, 
        .top-menu.sf-menu ul li, .top-menu.sf-menu ul li:hover, .top-menu.sf-menu ul li.sfHover,
        .top-menu ul {
            background-color: #2c2c2c;
        }
        a.scrollup {
            background-color: #565656;
        }
        #footer-sidebar input[type="text"], #footer-sidebar input[type="text"]:focus, 
        #footer-sidebar .form-control, #footer-sidebar .form-control:focus, #footer-sidebar textarea, 
        #footer-sidebar textarea:focus, #footer-sidebar input[type="password"], 
        #footer-sidebar input[type="password"]:focus, #footer-sidebar input[type="email"], 
        #footer-sidebar input[type="date"], #footer-sidebar input[type="number"], 
        #footer-sidebar input[type="email"]:focus, #footer-sidebar input[type="date"]:focus, 
        #footer-sidebar input[type="number"]:focus, #footer-sidebar #lang_sel a.lang_sel_sel, 
        #footer-sidebar #lang_sel a.lang_sel_sel:hover, #footer-sidebar #lang_sel a.lang_sel_sel:focus, 
        #footer-sidebar #lang_sel ul ul a, #footer-sidebar #lang_sel ul ul a:hover, 
        #footer-sidebar #lang_sel ul ul a:focus  {
            background-color: rgba(0, 0, 0, 0.1);
        }	
        #footer-sidebar .btn-leap, #footer-sidebar a.btn-leap, #footer-sidebar .widget a.btn-leap, #footer-sidebar .btn-leap:hover, 
        #footer-sidebar .btn-leap:focus, #footer-sidebar .btn-leap:active, #footer-sidebar .btn-leap.active, 
        #footer-sidebar .btn-leap.disabled, #footer-sidebar .btn-leap[disabled], #footer-sidebar a.btn-leap:hover, 
        #footer-sidebar a.btn-leap:focus, #footer-sidebar a.btn-leap:active, #footer-sidebar a.btn-leap.active, 
        #footer-sidebar a.btn-leap.disabled, #footer-sidebar a.btn-leap[disabled], #footer-sidebar .widget a.btn-leap.disabled, 
        #footer-sidebar .widget a.btn-leap[disabled] , #footer-sidebar input[type="submit"], #footer-sidebar input[type="reset"], 
        #footer-sidebar input[type="button"], #footer-sidebar input[type="submit"]:hover, #footer-sidebar input[type="reset"]:hover, 
        #footer-sidebar input[type="button"]:hover, #footer-sidebar input[type="submit"]:focus, 
        #footer-sidebar input[type="reset"]:focus, #footer-sidebar input[type="button"]:focus {
            background-color: rgba(0, 0, 0, 0.1);
            border-color: #232323;
        }	
        #footer-sidebar .btn-leap:hover, #footer-sidebar .btn-leap:focus, #footer-sidebar .widget a.btn-leap:hover, 
        #footer-sidebar .widget a.btn-leap:focus, #footer-sidebar .widget a.btn-leap:active, 
        #footer-sidebar .widget a.btn-leap.active , #footer-sidebar input[type="submit"]:hover, 
        #footer-sidebar input[type="reset"]:hover, #footer-sidebar input[type="button"]:hover, 
        #footer-sidebar input[type="submit"]:focus, #footer-sidebar input[type="reset"]:focus, 
        #footer-sidebar input[type="button"]:focus{
            background-color: rgba(0, 0, 0, 0.2);
        }	
        /************* copyright *****************/
        #leap-footer div.footer-block {
            border-color: #424242;
            background-color: #282828;
        }

        /**************** header options ***********/
        
                
        .header-vh.header10, .header-vh.header11, .header-vh #main-menu .menu-item-cart > ul {
            width: 250px;
        }      
        .header-vh.header12.side-header, .header-vh.header13.side-header,
        .header12 .header-content, .header13 .header-content{
            width: 250px;
        }  
        .header10-layout  {
            padding-left: 250px;
        }
        .header11-layout  {
            padding-right: 250px;
        }
        .header11-layout a.scrollup {
            margin-right: 250px;
        }
                    .header-vh .header-vh-wrapper {
                box-shadow: none;
            }
                        .header10, .header11 , .header12 .header-vh-wrapper , .header13 .header-vh-wrapper {
                                            }   
                .header #nav-icon span, .header17 .logo a:after {
                    }
        header #nav-icon.icon-close span, .header #nav-icon.active span {
                    }
        #nav-icon  {
                    } 
        .menu-icon , .header14 .menu-icon{
                    }     
        
        .header14 .menu-icon, .admin-bar .header14 .menu-icon {
                                                                    }
        .header15 .icon-header, .header17 .icon-header, .header16 {
                                                                    }

        
        
        #leap-header.header15 .fixed-header p.social-networks a, #leap-header.header17 .fixed-header p.social-networks a,
        #leap-header.header17 .fixed-header .contact-info, #leap-header.header17 .fixed-header .contact-info span {
                    }	
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        .framed #leap-wrapper {
                                                                    }
                .framed #leap-wrapper {
                    }
        
        
        
        
        #nav-icon.icon-close, #nav-icon.active {
                    } 

        
                a, .sc-rposts .post-title a, .sc-rposts .post-comment a, .list_carousel .cfs-nav span:before, .widget a, 
        ol.commentlist div.comment-author a, .pagination ul > .active > a, .pagination ul > .active > span, .post-navigation div span, 
        .post-navigation div a, #tag-cloud a, .shipping_calculator h2 a, .woocommerce-info a, .myaccount_user a, 
        .woocommerce-tabs ul.tabs li.active a, .yith-woocompare-widget a.clear-all:after, .yith-woocompare-widget a.clear-all:before, 
        .woocommerce-tabs ul.tabs li a {
                    }
        a:hover, a:focus, a:active, .entry-meta a:hover, .entry-meta a:active, .entry-meta a:focus, .entry-meta a:hover span, 
        .sc-rposts .post-title a:hover, .sc-rposts .post-title a:active, .sc-rposts .post-title a:focus, .sc-rposts .post-comment a:hover,  
        .list_carousel .cfs-nav span:hover:before, .widget a:hover, .widget a:focus, 
        .widget a:active, ol.commentlist div.comment-author a:hover, ol.commentlist div.comment-author a:active, 
        ol.commentlist div.comment-author a:focus, .pagination ul > .active > a:hover, .pagination ul > .active > span:hover, 
        ul.portfolio-tabs li a:hover, ul.portfolio-tabs li.active a:hover, .post-navigation div:hover span, 
        .post-navigation div:hover a, #tag-cloud a:hover, .tags a:hover, .shipping_calculator h2 a:hover, 
        .woocommerce-info a:hover, .myaccount_user a:hover, .woocommerce-tabs ul.tabs li.active a:hover, 
        .yith-woocompare-widget a.clear-all:hover:after, .yith-woocompare-widget a.clear-all:hover:before , 
        .woocommerce-tabs ul.tabs li a:hover, .woocommerce-MyAccount-navigation li.is-active a {
                    }

        /*****************styling ******************/
        /******* Custom Background *******/
        
        #leap-wrapper {
                    }

        
        /********************* overlay ***************************/
                .leap-overlay .item-img-color {
                                }
        .item-img .item-overlay .item-title a, .item-overlay .item-category, .item-overlay .item-category a, .item-overlay .item-category a:hover, .item-overlay .item-category a:focus, .item-overlay .item-category a:active {
                    }
        .item-overlay .item-links a:before {
                    }
        .item-overlay .item-links a:hover:before {
                    }
        .item-overlay .item-links a {
                    }

        div.title h1:after, div.title h2:after, div.title h3:after, div.title h4:after, 
        div.title h5:after, div.title h6:after, div.title.title-strip.title-center h1:before, 
        div.title.title-strip.title-center h2:before, div.title.title-strip.title-center h3:before, 
        div.title.title-strip.title-center h4:before, div.title.title-strip.title-center h5:before, 
        div.title.title-strip.title-center h6:before, div.title.title-strip.title-center h1:after, 
        div.title.title-strip.title-center h2:after, div.title.title-strip.title-center h3:after, 
        div.title.title-strip.title-center h4:after, div.title.title-strip.title-center h5:after, 
        div.title.title-strip.title-center h6:after, div.title.title-strip h1:after, div.title.title-strip h2:after, 
        div.title.title-strip h3:after, div.title.title-strip h4:after, div.title.title-strip h5:after, 
        div.title.title-strip h6:after {
                    }

        /******** header *********/

                .header .topbar-block, .header2 .topbar-block, .header7 .topbar-block, .header8 .topbar-block, .header9 .topbar-block, 
        .header4 .topbar-block, .header5 .topbar-block, .header6 .topbar-block {
             
                    }
        .header2 {
                    }
        #leap-header p.social-networks a {
                    }
        #leap-header.header p.social-networks a:hover i, #leap-header.header p.social-networks a:focus i {
                    }
        .header1 .navbar-inner, .header2 .navbar-inner, .header3 .navbar-inner, .header4 .logo-block, 
        .header5 .logo-block, .header6 .logo-block, .header7, .header8, .header9, 
        .header10 , .header11 , 
        .header12 .header-vh-wrapper, .header13 .header-vh-wrapper , .header15 .icon-header {
                    }
        .header .navbar-inner.navbar-fixed-top.fixed-header, .header15 .fixed-header .icon-header {
                    }
                .navbar-fixed-top.fixed-header {
                    }
        .header4 .navbar-inner, .header5 .navbar-inner, .header6 .navbar-inner, 
        .header14 .header-vh-wrapper .header-content, .header15 #main-menu-container {
                    }
        .wide .header8 .mainmenu-logo-container , .boxed .header8 .mainmenu-logo-container .nav-container,
        .header8 .mainmenu-logo-container.boxed-header .mainmenu-logo, .wide .header9 .mainmenu-logo-container , 
        .boxed .header9 .mainmenu-logo-container .nav-container, .header9 .mainmenu-logo-container.boxed-header .mainmenu-logo  {
                    }

                .header7 .nav-container .transparent-header, .header8 .navbar-inner, .header9 .navbar-inner {
                            padding-top: 0px;
                                        padding-bottom: 100px;
                    }
        .header .main-menu > li > a, .header a#searchbutton, .header15 .main-menu > li, .header15 .main-menu > li.sfHove {
            font-family: Roboto;        }
        .header12 .menu-icon, .header12 .menu-icon:focus,.header13 .menu-icon, .header13 .menu-icon:focus,
        .menu-icon .fa-close, .menu-icon:focus .fa-close, .menu-icon:hover .fa-close , 
        .menu-icon:focus:hover .fa-close {
                                }
        .header .main-menu > li:before {
                                }
        .header15 .top-header-content {
                    }
        .main-menu > li a:hover span.menu-item-description, .main-menu > li a:active span.menu-item-description, 
        .main-menu > li a:focus span.menu-item-description, .main-menu > li:hover a span.menu-item-description, 
        .main-menu > li:active a span.menu-item-description, .main-menu > li:focus a span.menu-item-description, 
        .main-menu > li:visited a span.menu-item-description, .main-menu > li.current-menu-item a span.menu-item-description {
                    }

                .main-menu > li > a:hover, .main-menu > li > a:focus, .main-menu > li > a:active, .main-menu > li.sfHover > a,
        .main-menu > li > a:hover span, .main-menu > li > a:focus span, .main-menu > li > a:active span,.main-menu > li.current-menu-item > a, 
        .main-menu > li.current-page-ancestor > a, 
        .main-menu > li.current-page-ancestor > a:hover,
        .main-menu > li.current-menu-ancestor > a, 
        .main-menu > li.current-menu-ancestor > a:hover, 
        .main-menu > li.current-menu-parent > a, 
        .main-menu > li.current-menu-parent > a:hover, 
        .main-menu > li.current_page_ancestor > a, 
        .main-menu > li.current_page_ancestor > a:hover,
        .header12 .menu-icon:hover, .header12 .menu-icon:focus:hover, .header13 .menu-icon:hover, .header13 .menu-icon:focus:hover,
        .header a#searchbutton:hover, .header a#searchbutton:focus, .header a#searchbutton:active {
                    }
        .header-vh .sf-menu > li:hover, .header-vh .sf-menu > li:focus, .header-vh .sf-menu > li:active {
                    }
        .main-menu > li:hover, .main-menu > li:active, .main-menu > li:focus, .main-menu > li.sfHover, .main-menu > li > a:hover, 
        .main-menu > li.sfHover > a.sf-with-ul,
        .main-menu > ul > li > a:hover, .main-menu > ul > li > a:focus, .main-menu > ul > li > a:active {
                    }
        .header16 #v-menu li a:after {
                    }

                            
                .main-menu ul li, .main-menu ul ul li, .main-menu ul li:hover, .main-menu ul li:focus, .main-menu ul li.sfHover, 
        .sf-menu .sf-mega, .sf-menu .sf-mega.menu-fullwidth .row , span.mega-section-head, span:hover.mega-section-head, .main-menu ul li.sfHover, 
        span.mega-section-head, span:hover.mega-section-head, .main-menu .menu-item-has-megamenu ul ul li, .searchform .navbar-search, 
        .slicknav_nav, .slicknav_nav li a:hover, .slicknav_nav li.slicknav_parent:hover a a, .slicknav_nav .slicknav_item a:hover a, 
        .slicknav_nav .slicknav_row:hover, .slicknav_nav .slicknav_open > .slicknav_row a, .slicknav_nav li.slicknav_open:hover > *, .slicknav_nav a {
                    }
        .searchform .navbar-search {
                    }
        .searchform .navbar-search:before {
                    }
        .main-menu ul li a, #main-menu .menu-item-cart ul.cart_list li, #main-menu .menu-item-cart ul.cart_list li:first-child, 
        #main-menu .menu-item-cart .widget_shopping_cart_content, #main-menu .widget_shopping_cart_content .buttons , .slicknav_nav li {
                    }

        .main-menu ul li > a:hover, .main-menu ul li a:active, .main-menu ul li a:focus, 
        .main-menu li ul a:hover span, .main-menu ul li a:active span, .main-menu ul li a:focus span, .main-menu ul li.sfHover > a,
        .main-menu li .mega-section-head a:hover, .main-menu li .mega-section-head a:hover span,
        .header ul.main-menu ul li.current-menu-item > a, .header ul.main-menu ul li.current-menu-item > a span, 
        .header ul.main-menu ul li.current-menu-item > a:hover, .header ul.main-menu ul li.current-page-ancestor > a, 
        .header ul.main-menu ul li.current-page-ancestor > a:hover, 
        .header ul.main-menu ul li.current-menu-ancestor > a,
        .slicknav_nav li:hover,
        .slicknav_nav li a:hover, .slicknav_nav li.slicknav_parent:hover > a, .slicknav_nav .slicknav_item a:hover a, .slicknav_nav .slicknav_row:hover, 
        .slicknav_nav .slicknav_open > .slicknav_row > a, .slicknav_nav li.slicknav_open:hover > *, .slicknav_nav li:hover {
                    }

        .main-menu ul li a, .main-menu ul li span, .main-menu ul li strong, .main-menu .mega-section-head a, 
        .main-menu .mega-section-head > span, .slicknav_nav a {
                    }

        .sf-menu .menu-item-no-megamenu ul, .sub-menu.submenu-languages {
                        width: 180px;
        }
        #v-menu li a, #v-menu li span, #v-menu li strong {
                    }
        #v-menu li:hover a, #v-menu li:focus a, #v-menu li:active a,
        #v-menu li:hover a span, #v-menu li:focus a span, #v-menu li:active a span {
                    }
        .header16 #v-menu li a:after {
                    }
                    .leap-slider:before, .leap-slider:after {
                background: none;
            }
                .navbar-search input[type="text"].search-query {
                    }	
        /****** page top/bottom padding ********/
                #content {
                            padding-top: 25px;
                                        padding-bottom: 25px;
            
        }

        /****** page title ********/
                    #title:before, #title:after {
                background: none;
            }
                div#title {
                    }
                #title .row {
                            margin-top: 30px;
                                        margin-bottom: 30px;
                    }

        #title h5.subtitle {
                    }
        .pagetitle2 div.entry-title h1:after {
            background-color: #f67207;
        }
        .pagetitle3 .entry-title {
            border-color: #f67207;
        }

        /****** content *************/
        #main {
                    }
        /********* divider ***********/
        /************* Social Sharing Box **********************/
                .leap-share-buttons, .archive-info .author-links, .hentry .leap-share-buttons {
                    }
        .leap-share-buttons i, .leap-share-buttons .pull-left, .archive-info .author-links i {
                    }
        .leap-share-buttons a:hover i {
                    }
        /******************* Sidebar ***************/
        #main-sidebar .main-sidebar-content {
                                    
            
                    }

        #main-sidebar .widget-title {
            font-family: "Slabo 27px";        }

                #main-sidebar .widget span.date, #main-sidebar .widget small.small, #main-sidebar .widget_recent_entries ul li span.post-date ,  
        #main-sidebar .widget small a, #main-sidebar .wp-caption , #main-sidebar .wp-caption a, 
        #main-sidebar .widget_display_topics li div, #main-sidebar .widget_display_replies li div {
                    }	
        #main-sidebar a {
                    }
        #main-sidebar a:hover {
                    }
        .sidebar .widget ul li  {
                    }
        /********** element option *************/
        .btn-leap, a.btn-leap, .btn-leap.disabled, 
        .btn-leap[disabled] , a.btn-leap.disabled, 
        a.btn-leap[disabled],  .widget a.btn-leap, input[type="submit"], 
        input[type="reset"], input[type="button"] {
                                                                                                                                                            border-radius: 0px;
        }           
                .btn-leap:hover, .btn-leap:focus, .btn-leap:active, .btn-leap.active,  
        a.btn-leap:hover, a.btn-leap:focus, a.btn-leap:active, a.btn-leap.active, 
        .widget a.btn-leap:hover, .widget a.btn-leap:focus, input[type="submit"]:hover, input[type="reset"]:hover, 
        input[type="button"]:hover, input[type="submit"]:focus, input[type="reset"]:focus, input[type="button"]:focus {
                                                
        }
        .header .logo,  .header15-layout .header .fixed-header .logo {
                                                                    }
                input[type="text"], input[type="text"]:focus, .form-control, .form-control:focus, textarea, 
        textarea:focus, input[type="password"], input[type="password"]:focus, 
        .select2-container .select2-choice, .select2-container .select2-choice:focus, 
        .select2-results .select2-highlighted, .select2-results, input[type="email"], 
        input[type="date"], input[type="number"], input[type="email"]:focus, input[type="tel"], 
        input[type="tel"]:focus, input[type="date"]:focus, input[type="number"]:focus, 
        .select2-container .select2-choice, #lang_sel a.lang_sel_sel, 
        #lang_sel a.lang_sel_sel:hover, #lang_sel a.lang_sel_sel:focus , #lang_sel ul ul a ,
        #lang_sel ul ul a:hover, #lang_sel ul ul a:focus
        {                                }
        .form-control::-moz-placeholder {
                    }
        .form-control::-ms-input-placeholder {
                    }
        .form-control::-webkit-input-placeholder {
                    }
        .searchform .navbar-search:before {
                    }
        .searchform .navbar-search, .static-search .navbar-search {
                    }         
        
        .portfolio-sep, .blog-wrapper .hentry, .archive-wrapper .hentry {
                                            } 


        /********************************************************************************/
        /***********************************  typography ***************************************/
        body, caption, .variations .label, legend {
            font-family: "Open Sans";        }
        .top-menu > li > a {
                    }
        .top-menu > li:before {
                                }
                .top-menu.sf-menu > li > a:hover , .top-menu.sf-menu > li.current_page_ancestor > a, .top-menu ul > li.current_page_item a,
        .top-menu.sf-menu > li > a:active, .top-menu.sf-menu > li > a:focus  {
                    }
                                    .top-menu.sf-menu ul li a , .top-menu.sf-menu ul li:before {
                    }

                .top-menu ul, .top-menu.sf-menu ul li, .top-menu.sf-menu ul li:hover, .top-menu.sf-menu ul li.sfHover {
                                }
        .top-menu.sf-menu ul > li:hover > a , .top-menu.sf-menu ul > li.current_page_item > a {
                    }


        #leap-header.header .contact-info, #leap-header.header .contact-info span, #leap-header.header .contact-info a {
                    }
                .fixed-header .main-menu > li > a , .fixed-header a#searchbutton {
                    }
        .fixed-header .main-menu li a:hover, .fixed-header .main-menu li a:focus, .fixed-header .main-menu li a:active, 
        .fixed-header .main-menu li.sfHover > a,
        .fixed-header .main-menu li a:hover span, .fixed-header .main-menu li a:focus span, .fixed-header .main-menu li a:active span,
        .fixed-header .main-menu li.current-menu-item > a, 
        .fixed-header .main-menu li.current-page-ancestor > a, 
        .fixed-header .main-menu li.current-page-ancestor > a:hover,
        .fixed-header .main-menu li.current-menu-ancestor > a, 
        .fixed-header .main-menu li.current-menu-ancestor > a:hover, 
        .fixed-header .main-menu li.current-menu-parent > a, 
        .fixed-header .main-menu li.current-menu-parent > a:hover, 
        .fixed-header .main-menu li.current_page_ancestor > a, 
        .fixed-header .main-menu li.current_page_ancestor > a:hover {
                    }
        .fixed-header .main-menu > li:hover, .fixed-header .main-menu > li:active, .fixed-header .main-menu > li:focus, 
        .fixed-header .main-menu > li.sfHover, .fixed-header .main-menu > li a:hover, 
        .fixed-header .main-menu > li.sfHover > a.sf-with-ul,
        .fixed-header .main-menu ul li a:hover, .fixed-header .main-menu ul li a:focus, .fixed-header .main-menu ul li a:active {
                    }
        .fixed-header .main-menu > li:before {
                    }


                .fixed-header .main-menu ul li, .fixed-header .main-menu ul ul li, .fixed-header .main-menu ul li:hover, 
        .fixed-header .main-menu ul li:focus, .fixed-header .sf-menu ul li.sfHover, .fixed-header .sf-menu .sf-mega, .fixed-header .sf-menu .sf-mega.menu-fullwidth .row,
        .fixed-header span.mega-section-head, .fixed-header span:hover.mega-section-head, .fixed-header .main-menu ul li.sfHover, 
        .fixed-header span.mega-section-head, .fixed-header span:hover.mega-section-head, 
        .fixed-header .main-menu .menu-item-has-megamenu ul ul li {
                    }
        .fixed-header .main-menu ul li a, .fixed-header .main-menu ul li span, .fixed-header .main-menu ul li strong, 
        .fixed-header .main-menu .mega-section-head a, .fixed-header .main-menu .mega-section-head > span {
                    }
        .fixed-header .main-menu ul li a, .fixed-header #main-menu .menu-item-cart ul.cart_list li, 
        .fixed-header #main-menu .menu-item-cart ul.cart_list li:first-child, 
        .fixed-header #main-menu .menu-item-cart .widget_shopping_cart_content, 
        .fixed-header #main-menu .widget_shopping_cart_content .buttons {
                    }
        .fixed-header .main-menu ul li a:hover, .fixed-header .main-menu > li.sfHover ul li a:hover, 
        .fixed-header .main-menu .mega-section-head a:hover, .header .fixed-header ul.main-menu ul li.current-menu-item > a, 
        .header .fixed-header ul.main-menu ul li.current-menu-item > a:hover, 
        .header .fixed-header ul.main-menu ul li.current-page-ancestor > a, 
        .header .fixed-header ul.main-menu ul li.current-page-ancestor > a:hover, 
        .header .fixed-header ul.main-menu ul li.current-menu-ancestor > a,
        .fixed-header .main-menu ul li a:hover span {
                    }
        #crumbs, #crumbs span, #crumbs a {
                    }
                #crumbs a:hover, #crumbs a:active, #crumbs a:focus {
                    }
        div.entry-title h1, .pagetitle3 .entry-title h1 {
            font-family: "Slabo 27px";        }
                .content-section small.small, .content-section a:hover small.small, .content-section small a, 
        .content-section small a:hover, .commentmetadata a, .content-section .wp-caption , .content-section .wp-caption a {
                    }
        .content-section {
                    }
        /*** post entry ***/
        /*****************************************************/
        h2.entry-title, .content-section h2.entry-title , h2.entry-title a, .portfolio-wrapper h2.entry-title a , 
        .content-section .portfolio-wrapper h2.entry-title {
                    }
        /***** headers ********/
        .content-section h1{
            font-family: "Slabo 27px";font-size: 50px;        }
        .content-section h2{
            font-family: "Slabo 27px";font-size: 37px;        }
        .content-section h3{
            font-family: "Slabo 27px";font-size: 28px;        }
        .content-section h4{
            font-family: "Slabo 27px";font-size: 21px;        }
        .content-section h5{
            font-family: "Slabo 27px";font-size: 16px;        }
        .content-section h6{
            font-family: "Slabo 27px";font-size: 12px;        }
        /************* footer *********/
        /************* footer *****************/
        #leap-footer {
                    }
                #leap-footer p.social-networks a {
                    }
        #leap-footer p.social-networks a:hover i {
                    }


                a.scrollup span {
                    }
        a.scrollup {
                    }
        a.scrollup {
                                                                    }

         
        #footer-sidebar input[type="text"], #footer-sidebar input[type="text"]:focus, #footer-sidebar .form-control, 
        #footer-sidebar .form-control:focus, #footer-sidebar textarea, #footer-sidebar textarea:focus, 
        #footer-sidebar input[type="password"], #footer-sidebar input[type="password"]:focus, 
        #footer-sidebar input[type="email"], #footer-sidebar input[type="date"], #footer-sidebar input[type="number"], 
        #footer-sidebar input[type="email"]:focus, #footer-sidebar input[type="date"]:focus, 
        #footer-sidebar input[type="number"]:focus {
                                        }
        #footer-sidebar .form-control::-moz-placeholder {
                    }
        #footer-sidebar .form-control:-ms-input-placeholder {
                    }
        #footer-sidebar .form-control::-webkit-input-placeholder {
                    }

             #footer-sidebar input:focus:invalid:focus, #footer-sidebar textarea:focus:invalid:focus, #footer-sidebar select:focus:invalid:focus  {
                                        
        }

        #footer-sidebar .form-control::-moz-placeholder {
                    }
        #footer-sidebar .form-control:-ms-input-placeholder {
                    }
        #footer-sidebar .form-control::-webkit-input-placeholder {
                    }

                #footer-sidebar .btn-leap, #footer-sidebar .btn-leap:hover, #footer-sidebar .btn-leap:focus, 
        #footer-sidebar .btn-leap.disabled, #footer-sidebar .btn-leap[disabled], #footer-sidebar a.btn-leap, 
        #footer-sidebar a.btn-leap:hover, #footer-sidebar a.btn-leap:focus, #footer-sidebar .widget a.btn-leap, 
        #footer-sidebar .widget a.btn-leap:hover, #footer-sidebar .widget a.btn-leap:focus, 
        #footer-sidebar input[type="submit"], #footer-sidebar input[type="reset"], #footer-sidebar input[type="button"], 
        #footer-sidebar input[type="submit"]:hover, #footer-sidebar input[type="reset"]:hover, 
        #footer-sidebar input[type="button"]:hover, #footer-sidebar input[type="submit"]:focus, 
        #footer-sidebar input[type="reset"]:focus, #footer-sidebar input[type="button"]:focus {
            
            
                    }
        #footer-sidebar .btn-leap:hover, #footer-sidebar .btn-leap:focus, #footer-sidebar .btn-leap.disabled, 
        #footer-sidebar .btn-leap[disabled], #footer-sidebar a.btn-leap:hover, #footer-sidebar a.btn-leap:focus, 
        #footer-sidebar .widget a.btn-leap:hover, #footer-sidebar .widget a.btn-leap:focus, #footer-sidebar input[type="submit"]:hover, 
        #footer-sidebar input[type="reset"]:hover, #footer-sidebar input[type="button"]:hover, 
        #footer-sidebar input[type="submit"]:focus, #footer-sidebar input[type="reset"]:focus, 
        #footer-sidebar input[type="button"]:focus {
                                         
        }
        #footer-sidebar .container-fluid, #footer-sidebar > .container {
                                }

                #footer-sidebar .widget span.date, #footer-sidebar .widget small.small, #footer-sidebar .widget small a, 
        #footer-sidebar .widget_recent_entries ul li span.post-date, #footer-sidebar .widget.woocommerce ul li del, 
        #footer-sidebar .widget.woocommerce ul li del span.amount, #footer-sidebar .wp-caption , 
        #footer-sidebar .wp-caption a, #footer-sidebar .widget_display_topics li div, 
        #footer-sidebar .widget_display_replies li div {
                    }

        #footer-sidebar a, #footer-sidebar .entry-meta a, #footer-sidebar div.entry-meta a span, 
        #footer-sidebar #crumbs a, #footer-sidebar a.more-link span.meta-nav:after, 
        #footer-sidebar a.readmore:after, #footer-sidebar a.readmore, #footer-sidebar a.more-link, 
        #footer-sidebar .leap-icon-box .more, #footer-sidebar .leap-icon-box .more a, #footer-sidebar .leap-icon-box .more a:after, 
        #footer-sidebar .more a span, #footer-sidebar .more a span:before, #footer-sidebar .more a span:after, 
        #footer-sidebar a.readmore:after, #footer-sidebar .sc-rposts .post-title a, #footer-sidebar .sc-rposts .post-comment a, 
        #footer-sidebar .list_carousel .cfs-nav span:before, #footer-sidebar .widget a, 
        #footer-sidebar ol.commentlist div.comment-author a, #footer-sidebar .pagination ul > .active > a, 
        #footer-sidebar .pagination ul > .active > span, #footer-sidebar ul.portfolio-tabs li.active a, 
        #footer-sidebar .post-navigation div span, #footer-sidebar .post-navigation div a, #footer-sidebar #tag-cloud a, 
        #footer-sidebar .tags a, #footer-sidebar .shipping_calculator h2 a, #footer-sidebar .woocommerce-info a, 
        #footer-sidebar .myaccount_user a, #footer-sidebar .woocommerce-tabs ul.tabs li.active a, 
        #footer-sidebar .yith-woocompare-widget a.clear-all:after, #footer-sidebar .yith-woocompare-widget a.clear-all:before, 
        #footer-sidebar .woocommerce-tabs ul.tabs li a {
                    }
        #footer-sidebar a:hover, #footer-sidebar a:focus, #footer-sidebar a:active, #footer-sidebar .widget a:hover, 
        #footer-sidebar .widget a:focus, #footer-sidebar .widget a:active, #footer-sidebar .entry-meta a:hover, 
        #footer-sidebar .entry-meta a:active, #footer-sidebar .entry-meta a:focus, #footer-sidebar .entry-meta a:hover span, 
        #footer-sidebar a.more-link:hover span.meta-nav:after, #footer-sidebar a.readmore:hover, 
        #footer-sidebar a.readmore:hover:after, #footer-sidebar a.more-link:hover, #footer-sidebar .more a:hover span, 
        #footer-sidebar .more a:hover span:before, #footer-sidebar .more a:hover span:after, 
        #footer-sidebar .leap-icon-box .more:hover, #footer-sidebar .leap-icon-box .more a:hover, 
        #footer-sidebar .leap-icon-box .more:hover a:after, #footer-sidebar .sc-rposts .post-title a:hover, 
        #footer-sidebar .sc-rposts .post-title a:active, #footer-sidebar .sc-rposts .post-title a:focus, 
        #footer-sidebar .sc-rposts .post-comment a:hover, #footer-sidebar ol.commentlist div.comment-author a:hover, 
        #footer-sidebar ol.commentlist div.comment-author a:active, #footer-sidebar ol.commentlist div.comment-author a:focus, 
        #footer-sidebar .pagination ul > .active > a:hover, #footer-sidebar .pagination ul > .active > span:hover, 
        #footer-sidebar ul.portfolio-tabs li a:hover, #footer-sidebar ul.portfolio-tabs li.active a:hover, 
        #footer-sidebar .post-navigation div:hover span, #footer-sidebar .post-navigation div:hover a, 
        #footer-sidebar #tag-cloud a:hover, #footer-sidebar .tags a:hover, #footer-sidebar .shipping_calculator h2 a:hover, 
        #footer-sidebar .woocommerce-info a:hover, #footer-sidebar .myaccount_user a:hover, 
        #footer-sidebar .woocommerce-tabs ul.tabs li.active a:hover, #footer-sidebar .woocommerce-tabs ul.tabs li a:hover, 
        #footer-sidebar .list_carousel .cfs-nav span:hover:before, #footer-sidebar .yith-woocompare-widget a.clear-all:hover:after {
                    }
        #footer-sidebar .woocommerce.widget_product_categories ul li, #footer-sidebar .woocommerce .widget_layered_nav ul li, 
        #footer-sidebar .woocommerce .widget_layered_nav ul li, #footer-sidebar .woocommerce-page .widget_layered_nav ul li, 
        #footer-sidebar .woocommerce-page .widget_layered_nav ul li, #footer-sidebar .woocommerce ul.product_list_widget li, 
        #footer-sidebar .widget_archive ul li, #footer-sidebar .widget_categories ul li, #footer-sidebar .widget_nav_menu ul li, 
        #footer-sidebar .widget_meta ul li , #footer-sidebar .widget_pages ul li, #footer-sidebar .widget_recent_comments ul li, 
        #footer-sidebar .widget_recent_entries ul li, #footer-sidebar .widget_rss ul li , 
        #footer-sidebar .widget.comments-avatar ul li, #footer-sidebar div.category-posts ul li, 
        #footer-sidebar .widget_author_posts ul li, #footer-sidebar .widget.posts-list ul li,#footer-sidebar div.widget.category-posts ul li, #footer-sidebar .widget.leap-tabs .ui-tabs-panel li,
        #footer-sidebar .widget.tweets ul li, #footer-sidebar ol.commentlist li, 
        #footer-sidebar ol.commentlist ul.children li, .woocommerce-MyAccount-navigation li {
                    }

                        #leap-footer div.footer-block {
                                                
        }

        #leap-footer .footer-block a, ul#footer-menu li:before {
                    }
        #leap-footer .footer-block a:hover {
                    }

        #footer-sidebar p, #footer-sidebar div, #footer-sidebar li {
                    }
        #footer-sidebar .widget-title {
            font-family: "Slabo 27px";        }
        #leap-footer .footer-block p {
                    }
        /*********************************************/
        /********** Mobile options ****************/
                @media screen and (max-width: 1000px) {
            #mobile-menu {
                display: block;
            }
            .header15 #main-menu-container, .header15 .icon-social-block {
                display: none;
            }
            .header15 .top-header-content {
                display: block;
                position: absolute;
                z-index: 10;
            }
            .header15 #nav-icon {
                display: none;
            }
           .header15 .top-header-content {
                height: auto;
            }
            .header15 .slicknav_btn {
                margin-right: 18px;
            }
            .rtl .header15 .slicknav_btn {
                float: left;
                margin-left: 18px;
            }
            .rtl .header15 .icon-header .logo {
                margin-right: 18px;
            }
            .header15 .icon-header .logo {
                position: absolute;
                top: 0px;
                z-index: 1000;
                margin-left: 18px;
            }
            .header16 .social-icons {
                display: none;
            }
            .header16 {
                padding: 0px;
            }
            .header16 .navbar-inner {
                padding: 0px 20px;
            }
            .header .col-sm-6 {
                width: 100%;
                float: none;
            }
            .header4 .logo-block, .header5 .logo-block , .header6 .logo-block {
                display: none;
            }
            .header-vh .logo {
                position: relative;
                z-index: 101;
            }
            .header .logo a, .header .logo, .header-vh .logo a, .header-vh .logo {
                float: left
            }
            .rtl .header .logo a, .rtl .header .logo {
                float: right;
            }
            .header4 .navbar-inner .logo-block , .header6 .navbar-inner .logo-block {
                display: block;
            }
            .header4 .navbar-inner .logo , .header5 .navbar-inner .logo , .header6 .navbar-inner .logo  {
                display: block;
            }
            .header5 #top-menu.sf-menu > li {
                display: inline-block;
                float: none;
            }
            .header .row [class*="col-sm-"] {
                margin-bottom: 0px;
            }
            .header .pull-right, .header div.social-icons, .header .pull-left {
                float: none !important;
            }
            .header .logo.pull-left  {
                float: left;
                text-align: left;
            }
            .topbar-block .contact-info, .topbar-block .social-networks {
                width: 100%;
            }
            p.social-networks a {
                float: none;
            }
            .logo a {
                float: none;
                clear: both;
            }
            .header .pull-right, .header .pull-left {
                float: none;
                text-align: center;
                width: 100%;
            }
            .header .main-menu, .header .search, a#searchbutton:before, .header .static-search {
                display: none;
            }
            .fixed-header .main-menu-container, .main-menu-container {
                float: none;
            }
            .navbar-fixed-top.fixed-header {
                display: none;
            }
            .header .col-sm-8, .header .col-sm-4 {
                width: 100%;
                float: none;
            }
            /*.header6 .logo img, .header6 .logo h1 {
                margin: 35px 0px;
            }*/
            .header-vh .header-vh-wrapper {
                position: relative;
                width: 100%;
                left: auto;
                right: auto;
                padding: 0px 15px;
                border: none;
                box-shadow: none;
            }
            .admin-bar .header-vh .header-vh-wrapper {
                padding-top: 0px;
            }
            .header-vh .bottom-bar {
                display: none;
            }
            .header10 .header-vh-wrapper, .header-vh.header10 {
                height: auto !important;
            } 
            .header10-layout .header-vh {
                float: none;
            }
            .header10-layout #leap-wrapper, .header11-layout #leap-wrapper  {
                margin: 0px;
            }
            .slicknav_btn {
                margin-top: 18px;
                margin-bottom: 18px;
            }
            #leap-wrapper .header .logo , .header .logo  {
                margin: 0px;
            }
            #leap-wrapper .logo a , .logo a {
                margin: 16px 0px;
            }
            #leap-wrapper .logo a img, #leap-wrapper .logo a h1 , .logo a img, .logo a h1 {
                
                max-height: 31px;
                height: 31px;  /*** for spa demo ****/
            }
            .header7 .nav-container .transparent-header {
                padding-bottom: 0px;
            }
            .header8 .navbar-inner, .header9 .navbar-inner {
                padding-top: 15px;
                padding-bottom: 15px;
            }
            .header9 .logo.text-center {
                text-align: left;
            }
            .header8 .nav-container .mainmenu-logo > .pull-right, 
            .header8 .nav-container .mainmenu-logo> .pull-left, 
            .header9 .nav-container .mainmenu-logo > .pull-right, 
            .header9 .nav-container .mainmenu-logo > .pull-left {
                padding-left: 0px;
                padding-right: 0px;
            }
            .header9 .nav-container .mainmenu-logo > .logo {
                width: 50%;
            }
            .header9 .nav-container .mainmenu-logo > .logo a {
                margin-left: 15px !important;
                position: relative;
            }
            .header-vh.header10, .header-vh.header11, .header-vh.header12, .header-vh.header13 {
                width: 100% !important;
            }
            .boxed.header10-layout, .boxed.header11-layout  {
                padding: 0px;
            }
            .header-vh.header10, .header-vh.header11 {
                position: relative;
                margin-top: 0px;
            }
            .header14.side-header .header-vh-wrapper {
                display: block;
            }
            .header12 .header-content, .header13 .header-content {
                opacity: 1;
            }
            .header12-layout #leap-wrapper {
                margin-left: 0px;
            }
            .header13-layout #leap-wrapper, .header13-layout a.scrollup {
                margin-right: 0px;
            }
            .header-vh.header12 {
                left: 0px;
            }
            .header-vh.header13 {
                right: 0px;
            }
            .header12 .header-content, .header13 .header-content {
                width: 100%;
            }
            .header-vh-wrapper .menu-icon {
                display: none;
            }
            .header14 {
                position: relative;
            }
            .header-vh.header14 .header-vh-wrapper {
                display: block !important;
                padding: 0px;
                position: relative;
            }
            .header-vh.header14 .header-vh-wrapper, .header-vh.header14 .header-vh-wrapper .header-content {
                opacity: 1;
            }
            .header14 .header-vh-wrapper .header-content {
                padding: 0px 15px;
            }
            .header14 .nav-container {
                display: block;
            }
            .header14 a.menu-icon {
                display: none;
            }
                            .topbar-block {
                    display: none;
                }
                    }



        /***************************************************************/
        /****** Custom CSS ********/

        h1.entry-title {
    font-size: 38px !important;
}
/*a {
    color: #f67207 !important;
}
a:hover {
  color: black !important;;
}*/

.content-section small.small, .content-section a:hover small.small, .content-section small a, .content-section small a:hover, .commentmetadata a, .content-section .wp-caption, .content-section .wp-caption a {
    color: #333 !important;
}
        @media screen and (min-width: 768px) and (max-width:985px) {
            	
        }
        @media screen and (min-width: 480px) and (max-width:767px) {
            	
        }
        @media screen and (min-width: 320px) and (max-width:479px) {
            	
        }
    </style>
        <style type="text/css" >
        		
    		
    </style>

    <noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style>
.ai-rotate {position: relative;}
.ai-rotate-hidden {visibility: hidden;}
.ai-rotate-hidden-2 {position: absolute; top: 0; left: 0; width: 100%; height: 100%;}
.ai-list-data, .ai-ip-data, .ai-filter-check, .ai-fallback, .ai-list-block, .ai-list-block-ip, .ai-list-block-filter {visibility: hidden; position: absolute; width: 50%; height: 1px; top: -1000px; z-index: -9999; margin: 0px!important;}
.ai-list-data, .ai-ip-data, .ai-filter-check, .ai-fallback {min-width: 1px;}
</style>

    </head>

    <body class="post-template-default single single-post postid-4294 single-format-standard wide light-skin sticky-header header3-layout absolute-header wpb-js-composer js-comp-ver-6.0.5 vc_responsive elementor-default elementor-page elementor-page-4294">

                        

        <div id="leap-wrapper" class="">

                        
                            <div id="leap-header" class="header header3">

	<div class="header-placholder"></div>

    <div class="navbar-inner navbar-fixed-top">
		<div class="container-fluid nav-container">
            <div class="row">
                <div class="col-sm-12">
            <div class="logo">
				<a title="CallMeBot API" href="https://www.callmebot.com/">
											<img alt="CallMeBot API" src="https://www.callmebot.com/wp-content/uploads/2019/10/Logo-Negro_x1.png" />
										</a>
            </div>

			<div class="pull-right">                               
								<div id="main-menu-container" class="menu-main-menu-container"><ul id="main-menu" class="sf-menu main-menu"><li  id="menu-item-5168" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-5168 menu-item-no-megamenu"><a href="https://www.callmebot.com/blog/free-api-signal-send-messages/"><span>Signal API</span></a>
<ul class="sub-menu">
	<li  id="menu-item-5169" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5169"><a href="https://www.callmebot.com/blog/free-api-signal-send-messages/"><span>Send Messages</span></a></li>
</ul>
</li>
<li  id="menu-item-5084" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-5084 menu-item-no-megamenu"><a href="https://www.callmebot.com/blog/free-api-facebook-messenger/"><span>Facebook Msg. API</span></a>
<ul class="sub-menu">
	<li  id="menu-item-5085" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5085"><a href="https://www.callmebot.com/blog/free-api-facebook-messenger/"><span>Send Messages</span></a></li>
	<li  id="menu-item-5104" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5104"><a href="https://www.callmebot.com/blog/facebook-messenger-free-api-home-assistant/"><span>With HomeAssistant</span></a></li>
</ul>
</li>
<li  id="menu-item-5805" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5805 menu-item-no-megamenu"><a href="https://www.callmebot.com/phone-call/"><span>Phone Call API</span></a>
<ul class="sub-menu">
	<li  id="menu-item-5806" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5806"><a href="https://www.callmebot.com/phone-call/"><span>📞 Make a Phone Call</span></a></li>
</ul>
</li>
<li  id="menu-item-4340" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-4340 menu-item-no-megamenu"><a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/"><span>Free WhatsApp API</span></a>
<ul class="sub-menu">
	<li  id="menu-item-4464" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4464"><a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/"><span>Send Messages</span></a></li>
	<li  id="menu-item-5345" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5345"><a href="https://community.athom.com/t/48374"><span>With Homey</span></a></li>
	<li  id="menu-item-5357" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5357"><a href="https://www.callmebot.com/blog/whatsapp-from-php/"><span>With PHP</span></a></li>
	<li  id="menu-item-4417" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4417"><a href="https://www.callmebot.com/blog/test-whatsapp-api/"><span>With WebBrowser</span></a></li>
	<li  id="menu-item-5450" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5450"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-apple-home-app-homekit/"><span>With Apple HomeKit</span></a></li>
	<li  id="menu-item-4583" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4583"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-ifttt/"><span>With IFTTT</span></a></li>
	<li  id="menu-item-4449" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4449"><a href="https://www.callmebot.com/blog/whatsapp-text-messages-from-openhab/"><span>With OpenHAB</span></a></li>
	<li  id="menu-item-4418" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4418"><a href="https://www.callmebot.com/blog/whatsapp-text-messages-from-homeassistant/"><span>With HomeAssistant</span></a></li>
	<li  id="menu-item-4640" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4640"><a href="https://www.callmebot.com/blog/whatsapp-text-messages-from-domoticz/"><span>With Domoticz</span></a></li>
	<li  id="menu-item-5406" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5406"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-shopify/"><span>With Shopify</span></a></li>
	<li  id="menu-item-5334" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5334"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-appsheet/"><span>With AppSheet</span></a></li>
	<li  id="menu-item-5019" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5019"><a href="https://www.callmebot.com/blog/gmail-to-whatsapp/"><span>With Gmail</span></a></li>
	<li  id="menu-item-5671" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5671"><a href="https://www.callmebot.com/blog/whatsapp-microsoft-ms-flow-automate/"><span>With Microsoft MS Flow</span></a></li>
	<li  id="menu-item-5679" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5679"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-esp8266-esp32/"><span>With ESP8266 / ESP32</span></a></li>
</ul>
</li>
<li  id="menu-item-5734" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-5734 menu-item-has-megamenu menu-item-has-megamenu-fullwidth"><a href="https://www.callmebot.com/telegram-call-api/"><span>Telegram Call/Text API</span></a>
<div class='sf-mega container-fluid menu-fullwidth'>

<div class='row'>
	<div class="col-sm-6"><span class="leap_col_title-5733 mega-section-head"><a href="https://www.callmebot.com/telegram-call-api/"><span>Telegram Voice Call</span><span class="menu-item-description">Start a voice call on Telegram App</span></a>
	</span><ul class="sub-menu">
		<li  id="menu-item-5318" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5318"><a href="https://www.callmebot.com/telegram-call-api/"><span>Make a Phone Call</span></a></li>
		<li  id="menu-item-3983" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3983"><a href="https://www.callmebot.com/blog/telegram-phone-call-using-your-browser/"><span>With Web Browser</span></a></li>
		<li  id="menu-item-5020" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5020"><a href="https://www.callmebot.com/blog/gmail-to-telegram/"><span>With Gmail</span></a></li>
		<li  id="menu-item-4312" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4312"><a href="https://www.callmebot.com/blog/ifttt-telegram-phone-calls/"><span>With IFTTT</span></a></li>
		<li  id="menu-item-4017" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4017"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-openhab/"><span>With OpenHab</span></a></li>
		<li  id="menu-item-3984" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3984"><a href="https://www.callmebot.com/blog/telegram-call-from-home-assistant/"><span>With HomeAssistant</span></a></li>
		<li  id="menu-item-4624" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4624"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-domoticz-with-voice-messages/"><span>With Domoticz</span></a></li>
		<li  id="menu-item-4255" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4255"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-vera/"><span>With Vera</span></a></li>
		<li  id="menu-item-5710" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5710"><a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/"><span>With UpDown.io</span></a></li>
		<li  id="menu-item-4107" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4107"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-uptimerobot-com/"><span>With UptimeRobot.com</span></a></li>
		<li  id="menu-item-4072" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4072"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-freshping-com/"><span>With Freshping.com</span></a></li>
		<li  id="menu-item-4179" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4179"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-iobroker/"><span>With ioBroker</span></a></li>
	</ul>
</div>	<div class="col-sm-6"><span class="leap_col_title-4300 mega-section-head"><a href="https://www.callmebot.com/blog/telegram-text-messages/"><span>Telegram Text API</span><span class="menu-item-description">Send a Telegram Text message</span></a>
	</span><ul class="sub-menu">
		<li  id="menu-item-4489" class="menu-item menu-item-type-post_type menu-item-object-post current-menu-item menu-item-4489"><a href="https://www.callmebot.com/blog/telegram-text-messages/"><span>Send Text Messages</span></a></li>
		<li  id="menu-item-4698" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4698"><a href="https://www.callmebot.com/blog/telegram-group-messages-api-easy/"><span>Send Group Messages</span></a></li>
		<li  id="menu-item-4324" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4324"><a href="https://www.callmebot.com/blog/telegram-text-messages-from-browser/"><span>With Web Browser</span></a></li>
		<li  id="menu-item-5018" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5018"><a href="https://www.callmebot.com/blog/gmail-to-telegram/"><span>With Gmail</span></a></li>
		<li  id="menu-item-4668" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4668"><a href="https://www.callmebot.com/blog/telegram-text-messages-from-homeassistant-easy-way/"><span>With Home Assistant</span></a></li>
	</ul>
</div></div>
</div>
</li>
<li  id="menu-item-3625" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3625 menu-item-no-megamenu"><a href="https://www.callmebot.com/get-telegram-id-from-phone-number/"><span>Get Phone / ID</span></a>
<ul class="sub-menu">
	<li  id="menu-item-4879" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4879"><a href="https://www.callmebot.com/get-phone-number-from-telegram-user-id/"><span>Get Phone Number</span></a></li>
	<li  id="menu-item-4880" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4880"><a href="https://www.callmebot.com/get-telegram-id-from-phone-number/"><span>Get Telegram ID</span></a></li>
</ul>
</li>
<li  id="menu-item-4198" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4198 menu-item-no-megamenu"><a href="https://www.callmebot.com/faq/"><span>❔ Support</span></a>
<ul class="sub-menu">
	<li  id="menu-item-5508" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5508"><a href="https://documenter.getpostman.com/view/20714522/UyrEiFgK"><span>Postman Doc.</span></a></li>
	<li  id="menu-item-4196" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4196"><a href="https://www.callmebot.com/faq/"><span>FAQ</span></a></li>
	<li  id="menu-item-4197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-4197"><a href="https://www.callmebot.com/#need_support"><span>Contact</span></a></li>
</ul>
</li>
</ul></div>			</div>
			<div id="main-menu-mobile-container" class="menu-main-menu-container"><ul id="main-menu-mobile" class="main-menu-mobile hidden"><li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-5168"><a href="https://www.callmebot.com/blog/free-api-signal-send-messages/">Signal API</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5169"><a href="https://www.callmebot.com/blog/free-api-signal-send-messages/">Send Messages</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-5084"><a href="https://www.callmebot.com/blog/free-api-facebook-messenger/">Facebook Msg. API</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5085"><a href="https://www.callmebot.com/blog/free-api-facebook-messenger/">Send Messages</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5104"><a href="https://www.callmebot.com/blog/facebook-messenger-free-api-home-assistant/">With HomeAssistant</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5805"><a href="https://www.callmebot.com/phone-call/">Phone Call API</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5806"><a href="https://www.callmebot.com/phone-call/">📞 Make a Phone Call</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-4340"><a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/">Free WhatsApp API</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4464"><a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/">Send Messages</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5345"><a href="https://community.athom.com/t/48374">With Homey</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5357"><a href="https://www.callmebot.com/blog/whatsapp-from-php/">With PHP</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4417"><a href="https://www.callmebot.com/blog/test-whatsapp-api/">With WebBrowser</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5450"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-apple-home-app-homekit/">With Apple HomeKit</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4583"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-ifttt/">With IFTTT</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4449"><a href="https://www.callmebot.com/blog/whatsapp-text-messages-from-openhab/">With OpenHAB</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4418"><a href="https://www.callmebot.com/blog/whatsapp-text-messages-from-homeassistant/">With HomeAssistant</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4640"><a href="https://www.callmebot.com/blog/whatsapp-text-messages-from-domoticz/">With Domoticz</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5406"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-shopify/">With Shopify</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5334"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-appsheet/">With AppSheet</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5019"><a href="https://www.callmebot.com/blog/gmail-to-whatsapp/">With Gmail</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5671"><a href="https://www.callmebot.com/blog/whatsapp-microsoft-ms-flow-automate/">With Microsoft MS Flow</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5679"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-esp8266-esp32/">With ESP8266 / ESP32</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-5734"><a href="https://www.callmebot.com/telegram-call-api/">Telegram Call/Text API</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5733"><a href="https://www.callmebot.com/telegram-call-api/">Telegram Voice Call</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5318"><a href="https://www.callmebot.com/telegram-call-api/">Make a Phone Call</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3983"><a href="https://www.callmebot.com/blog/telegram-phone-call-using-your-browser/">With Web Browser</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5020"><a href="https://www.callmebot.com/blog/gmail-to-telegram/">With Gmail</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4312"><a href="https://www.callmebot.com/blog/ifttt-telegram-phone-calls/">With IFTTT</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4017"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-openhab/">With OpenHab</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3984"><a href="https://www.callmebot.com/blog/telegram-call-from-home-assistant/">With HomeAssistant</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4624"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-domoticz-with-voice-messages/">With Domoticz</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4255"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-vera/">With Vera</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5710"><a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/">With UpDown.io</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4107"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-uptimerobot-com/">With UptimeRobot.com</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4072"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-freshping-com/">With Freshping.com</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4179"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-iobroker/">With ioBroker</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post current-menu-item current-menu-ancestor current-menu-parent menu-item-has-children menu-item-4300"><a href="https://www.callmebot.com/blog/telegram-text-messages/" aria-current="page">Telegram Text API</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-post current-menu-item menu-item-4489"><a href="https://www.callmebot.com/blog/telegram-text-messages/" aria-current="page">Send Text Messages</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4698"><a href="https://www.callmebot.com/blog/telegram-group-messages-api-easy/">Send Group Messages</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4324"><a href="https://www.callmebot.com/blog/telegram-text-messages-from-browser/">With Web Browser</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-5018"><a href="https://www.callmebot.com/blog/gmail-to-telegram/">With Gmail</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4668"><a href="https://www.callmebot.com/blog/telegram-text-messages-from-homeassistant-easy-way/">With Home Assistant</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3625"><a href="https://www.callmebot.com/get-telegram-id-from-phone-number/">Get Phone / ID</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4879"><a href="https://www.callmebot.com/get-phone-number-from-telegram-user-id/">Get Phone Number</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4880"><a href="https://www.callmebot.com/get-telegram-id-from-phone-number/">Get Telegram ID</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4198"><a href="https://www.callmebot.com/faq/">❔ Support</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5508"><a href="https://documenter.getpostman.com/view/20714522/UyrEiFgK">Postman Doc.</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4196"><a href="https://www.callmebot.com/faq/">FAQ</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-4197"><a href="https://www.callmebot.com/#need_support">Contact</a></li>
</ul>
</li>
</ul></div>			<div id="mobile-menu"></div>


        </div>
    </div>
</div>
        </div>
</div>
            
            
            
                        
            

            
            
            <div id="leap-content">
                
                <div id="content" class="sidebar-right">
                                        <div class="container-fluid">
                        <div class="row">
<div id="main" class="col-sm-9">

    
    <div class="content-section">

        
        
            <div id="post-4294" class="post-4294 post type-post status-publish format-standard has-post-thumbnail hentry category-blog tag-bot tag-calls tag-domoticz tag-homeassistant tag-messages tag-openhab tag-telegram tag-text tag-vera">
	<div class="entry-wrapper">
		<div class="entry-header">
									<div class="entry-head">				
							<div class="post-img">
								<a data-rel="prettyPhoto" href="https://www.callmebot.com/wp-content/uploads/2020/03/Text-1024x440.jpg"  title="Telegram Text Messages"><img width="1140" height="450"  itemprop="image" src="https://www.callmebot.com/wp-content/uploads/2020/03/Text-1140x450.jpg" class="attachment-leap-portfolio-1col size-leap-portfolio-1col wp-post-image" alt="Telegram Message from easy API" /></a>
							</div>
						</div>
						
						<div class="entry-info">
										 	
						<h1 class="entry-title"><a href="https://www.callmebot.com/blog/telegram-text-messages/" title="Telegram Text Messages">Telegram Text Messages</a></h1>
									
				<div class="entry-meta">
					<small class="entry-author small"><i class="fa fa-user"></i> <a href="https://www.callmebot.com/author/admin/" title="View all posts by admin">admin</a></small> <small class="entry-date small"><i class="fa fa-calendar"></i> <a href="https://www.callmebot.com/blog/telegram-text-messages/">March 23, 2021</a></small><small class="entry-category small"><i class="fa fa-align-left"></i> <a href="https://www.callmebot.com/category/blog/" rel="category tag">Blog</a></small>				</div>
			</div>
		</div>

		<div class="entry-content">

						<div class="post-content">
						<div data-elementor-type="wp-post" data-elementor-id="4294" class="elementor elementor-4294" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section class="elementor-element elementor-element-16090c3 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="16090c3" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-9ca0b0a elementor-column elementor-col-100 elementor-top-column" data-id="9ca0b0a" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-f304eaf elementor-widget elementor-widget-text-editor" data-id="f304eaf" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>CallMeBot can now send Text Messages! As expected, it is super easy to use the Web API and integrate it in all your scripts, automations, devices, IoT, etc. You don't need to create Telegram Bots or getting chatID just call to this simple API.</p><p>Simply, call to this API URL:</p><pre>https://api.callmebot.com/text.php?user=<span style="color: #0000ff;">[username]</span>&amp;text=<span style="color: #ff6600;"><span style="color: #0000ff;">[text]</span><span style="color: #000000;">&amp;html=</span><span style="color: #0000ff;">[html_format]</span><span style="color: #000000;">&amp;links=</span><span style="color: #0000ff;">[link_preview]</span></span></pre><p><span style="text-decoration: underline;"><strong>Where:</strong></span><br /><span style="color: #0000ff;">[username]</span>: Is the Telegram recipient of the message (ei: @myusername). <strong><span style="color: #ff0000;">Important!</span></strong>: You need to authorize CallMeBot to contact you using <span style="text-decoration: underline;"><span style="color: #ff6600;"><a style="color: #ff6600; text-decoration: underline;" href="https://api2.callmebot.com/txt/login.php" target="_blank" rel="noopener">this link</a></span></span>. Or alternatively, you can start the bot sending<b> <span style="font-family: 'courier new', courier, monospace;">/start</span></b> to <a href="https://t.me/CallMeBot_txtbot">@CallMeBot_txtbot</a>.<br />This is required to avoid Spam.  You can send the same message to multiple recipients with the same web API request. Just separate the users with the "|" character. Please note that all users needs to go through the authorization process. If you want to send messages to Telegram Groups, plese use <span style="text-decoration: underline;"><span style="color: #ff6600;"><a style="color: #ff6600; text-decoration: underline;" href="https://www.callmebot.com/blog/telegram-group-messages-api-easy/">this API</a></span></span>.<br /><span style="color: #0000ff;">[text]</span>: Message to send (urlencoded). You can use <span style="text-decoration: underline; color: #ff6600;"><a style="color: #ff6600; text-decoration: underline;" href="https://www.urlencoder.io/">this</a></span> online converter to encode the url. Check <span style="text-decoration: underline; color: #ff6600;"><a style="color: #ff6600; text-decoration: underline;" href="https://www.callmebot.com/uncategorized/how-to-use-emoticos-with-the-api/">here</a></span> how to include emoticons in the message 👍.<br /><span style="color: #0000ff;">[html_format]</span>:  yes/no -  Default: no - Optional parameter to send the message in html format or plain text. Put "yes" when you want to send "bold" text using <b>test</b> (url example: &amp;html=yes)<br /><span style="color: #0000ff;">[link_preview]</span>: yes/no - Default: no - It will enable or disable the webpage preview that is sent together with the text message when there is an URL on it.</p><p><span style="text-decoration: underline;"><strong>Example:</strong></span></p><pre><span style="color: #808080;">#for one recipient:</span><br />https://api.callmebot.com/text.php?user=<span style="color: #0000ff;">@myusername</span>&amp;text=<span style="color: #0000ff;">This+is+a+test+from+CallMeBot</span></pre><pre><span style="color: #808080;">#for multiple recipients:</span><br />https://api.callmebot.com/text.php?user=<span style="color: #0000ff;">@myusername1|@username2</span>&amp;text=<span style="color: #0000ff;">This+is+a+test+from+CallMeBot</span></pre></div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section class="elementor-element elementor-element-56f4c70 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="56f4c70" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-01f155f elementor-column elementor-col-100 elementor-top-column" data-id="01f155f" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-e4214d6 elementor-widget elementor-widget-button" data-id="e4214d6" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="https://www.callmebot.com/blog/telegram-text-messages-from-browser/" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Try to Send a test message now!</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section class="elementor-element elementor-element-b9fdb4a elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="b9fdb4a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-48a2747 elementor-column elementor-col-100 elementor-top-column" data-id="48a2747" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-7971d31 elementor-widget elementor-widget-shortcode" data-id="7971d31" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode">		<div data-elementor-type="wp-post" data-elementor-id="4380" class="elementor elementor-4380" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section class="elementor-element elementor-element-b94ec01 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="b94ec01" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-585a285 elementor-column elementor-col-100 elementor-top-column" data-id="585a285" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-ddf0427 elementor-widget elementor-widget-text-editor" data-id="ddf0427" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><h2><span style="font-size: 24pt;">Problems?</span></h2><p>If you have problems, like not receiving the Call on Telegram, or not receiving the WhatsApp messages,  try to test the CallMeBot API using your Web Browser:</p><ul><li>Telegram Phone Calls using Web Browser: <span style="text-decoration: underline;"><a href="https://www.callmebot.com/blog/telegram-phone-call-using-your-browser/"><span style="color: #ff6600; text-decoration: underline;">here</span></a></span></li><li>Telegram Text Messages using Web Browsers: <span style="text-decoration: underline;"><span style="color: #ff6600;"><a style="color: #ff6600; text-decoration: underline;" href="https://www.callmebot.com/blog/telegram-text-messages-from-browser/">here</a></span></span></li><li>WhatsApp Text Messages using Web Browser: <span style="text-decoration: underline;"><span style="color: #ff6600;"><a style="color: #ff6600; text-decoration: underline;" href="https://www.callmebot.com/blog/test-whatsapp-api/">here</a></span></span></li></ul><p>You might get some errors on the screen that will help you to identify the problem. (Ex: Calls disabled in the Telegram Security Settings, WhatsApp not activated, etc.)</p><p>If you still have problems using the API, don’t hesitate to contact me by email at <span style="color: #000000;"><b><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ccbfb9bcbca3beb88cafada0a0a1a9aea3b8e2afa3a1">[email&#160;protected]</a>. </b></span>Remember to <strong><a href="https://twitter.com/callmebot_com">Follow me on Twitter</a></strong> to get news about coming features, changes, invitations, etc.</p></div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
		</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
									</div>

		</div>

		<div class="entry-footer">
			<small class="entry-tags small"><i class="fa fa-tags"></i> Tags: <a href="https://www.callmebot.com/tag/bot/" rel="tag">Bot</a>, <a href="https://www.callmebot.com/tag/calls/" rel="tag">Calls</a>, <a href="https://www.callmebot.com/tag/domoticz/" rel="tag">Domoticz</a>, <a href="https://www.callmebot.com/tag/homeassistant/" rel="tag">HomeAssistant</a>, <a href="https://www.callmebot.com/tag/messages/" rel="tag">Messages</a>, <a href="https://www.callmebot.com/tag/openhab/" rel="tag">OpenHAB</a>, <a href="https://www.callmebot.com/tag/telegram/" rel="tag">Telegram</a>, <a href="https://www.callmebot.com/tag/text/" rel="tag">Text</a>, <a href="https://www.callmebot.com/tag/vera/" rel="tag">Vera</a></small>	<div class="leap-share-buttons">
		<div class="pull-left">Share This</div>
		<div class="pull-right">
			<a data-toggle="tooltip" data-placement="top" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F" title="Facebook"><i class="fab fa-facebook"></i></a><a data-toggle="tooltip" data-placement="top" href="https://twitter.com/share?text=Telegram+Text+Messages&amp;url=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F" title="Twitter"><i class="fab fa-twitter"></i></a><a data-toggle="tooltip" data-placement="top" href="http://linkedin.com/shareArticle?mini=true&amp;url=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F&amp;title=Telegram+Text+Messages" title="Linkedin"><i class="fab fa-linkedin"></i></a><a data-toggle="tooltip" data-placement="top" href="http://reddit.com/submit?url=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F&amp;title=Telegram+Text+Messages" title="Reddit"><i class="fab fa-reddit"></i></a><a data-toggle="tooltip" data-placement="top" href="https://www.tumblr.com/share/link?url=https%3A%2F%2Fwww.callmebot.com%2Fblog%2Ftelegram-text-messages%2F&amp;name=Telegram+Text+Messages&amp;description=CallMeBot+can+now+send+Text+Messages%21+As+expected%2C+it+is+super+easy+to+use+the+Web+API+and+integrate+it+in+all+your+scripts%2C+automations%2C+devices%2C+IoT%2C+etc.+You+don%27t+need+to+create+Telegram+Bots+or+getting+chatID+just+call+to+this+simple+API.+Simply%2C+call+to+this+API+URL%3A+https%3A%2F%2Fapi.callmebot.com%2Ftext.php%3Fuser%3D%5Busername%5D%26amp%3Btext%3D%5Btext%5D%26amp%3Bhtml%3D%5Bhtml_format%5D%26amp%3Blinks%3D%5Blink_preview%5D+Where%3A%5Busername%5D%3A+Is+the+Telegram%5B...%5D" title="Tumblr"><i class="fab fa-tumblr"></i></a>		</div>
	</div>
		</div>

	</div>
</div>
        	


        

                    <div class="post-navigation">
                <div class="post-previous"><a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/" rel="prev"><span></span>Free API to Send Whatsapp Messages</a></div>
                <div class="post-next"><a href="https://www.callmebot.com/blog/free-api-signal-send-messages/" rel="next"><span></span>Free API to Send Signal Messaging</a></div>
            </div>
        

        <div class="relatedposts">
			        <div class="title">
			    		<h4>Related Posts</h4>
			        </div><div class="list_carousel responsive"><ul class="portfolio-slider"><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-190x145.png" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/test-phone-call-api/" title="Test Phone Call API from Web Browser">Test Phone Call API from Web Browser</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/test-phone-call-api/" title="Test Phone Call API from Web Browser">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-1024x440.png" title="Test Phone Call API from Web Browser">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-190x145.png" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/" title="Whatsapp Messages from UpDown.io">Whatsapp Messages from UpDown.io</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-from-updown-io/" title="Whatsapp Messages from UpDown.io">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-1024x440.png" title="Whatsapp Messages from UpDown.io">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/ESP8266_WhatsApp-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-esp8266-esp32/" title="Whatsapp Messages from ESP8266 / ESP32 NodeMCU">Whatsapp Messages from ESP8266 / ESP32 NodeMCU</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-messages-from-esp8266-esp32/" title="Whatsapp Messages from ESP8266 / ESP32 NodeMCU">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/ESP8266_WhatsApp-1024x440.jpg" title="Whatsapp Messages from ESP8266 / ESP32 NodeMCU">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/MSFlow_WhatsApp-1-190x145.png" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-microsoft-ms-flow-automate/" title="Whatsapp Messages from Microsoft MS Flow (Power Automate)">Whatsapp Messages from Microsoft MS Flow (Power Automate)</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-microsoft-ms-flow-automate/" title="Whatsapp Messages from Microsoft MS Flow (Power Automate)">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/MSFlow_WhatsApp-1-1024x440.png" title="Whatsapp Messages from Microsoft MS Flow (Power Automate)">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/HomeKit_WhatsApp-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="CallMeBot WhatsApp API works with Homekit" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-apple-home-app-homekit/" title="Whatsapp Messages from Apple Home App or HomeKit">Whatsapp Messages from Apple Home App or HomeKit</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-messages-from-apple-home-app-homekit/" title="Whatsapp Messages from Apple Home App or HomeKit">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/HomeKit_WhatsApp-1024x440.jpg" title="Whatsapp Messages from Apple Home App or HomeKit">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Shopify_WhatsApp-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-shopify/" title="Whatsapp Notification Messages from Shopify">Whatsapp Notification Messages from Shopify</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-messages-from-shopify/" title="Whatsapp Notification Messages from Shopify">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Shopify_WhatsApp-1024x440.jpg" title="Whatsapp Notification Messages from Shopify">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Php_WhatsApp2-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-from-php/" title="Whatsapp Messages from PHP">Whatsapp Messages from PHP</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-from-php/" title="Whatsapp Messages from PHP">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Php_WhatsApp2-1024x440.jpg" title="Whatsapp Messages from PHP">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/AppSheet_WhatsApp-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="WhatsApp with AppSheet" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/whatsapp-messages-from-appsheet/" title="Whatsapp Messages from AppSheet">Whatsapp Messages from AppSheet</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/whatsapp-messages-from-appsheet/" title="Whatsapp Messages from AppSheet">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/AppSheet_WhatsApp-1024x440.jpg" title="Whatsapp Messages from AppSheet">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/GMAIL_Calls-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Telegram Calls from Gamil" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/gmail-to-telegram/" title="Gmail to Telegram">Gmail to Telegram</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/gmail-to-telegram/" title="Gmail to Telegram">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/GMAIL_Calls-1024x440.jpg" title="Gmail to Telegram">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/2020/03/BrowsersText-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Telegram Messages from simple REST API" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/telegram-text-messages-from-browser/" title="Telegram Text Messages using your Browser">Telegram Text Messages using your Browser</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/telegram-text-messages-from-browser/" title="Telegram Text Messages using your Browser">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/2020/03/BrowsersText-1024x440.jpg" title="Telegram Text Messages using your Browser">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Webhook_Signal-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Send Signal Messages from simple REST API" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/free-api-signal-send-messages/" title="Free API to Send Signal Messaging">Free API to Send Signal Messaging</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/free-api-signal-send-messages/" title="Free API to Send Signal Messaging">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Webhook_Signal-1024x440.jpg" title="Free API to Send Signal Messaging">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/2020/03/Text_whatsapp-1-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Send WhatsApp from simple REST API" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/" title="Free API to Send Whatsapp Messages">Free API to Send Whatsapp Messages</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/free-api-whatsapp-messages/" title="Free API to Send Whatsapp Messages">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/2020/03/Text_whatsapp-1-1024x440.jpg" title="Free API to Send Whatsapp Messages">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Text_HomeAssistant-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Send Telegram Text Messages from Home Assistant" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/telegram-text-messages-from-homeassistant-easy-way/" title="Telegram Text Messages from HomeAssistant (easy way!)">Telegram Text Messages from HomeAssistant (easy way!)</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/telegram-text-messages-from-homeassistant-easy-way/" title="Telegram Text Messages from HomeAssistant (easy way!)">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Text_HomeAssistant-1024x440.jpg" title="Telegram Text Messages from HomeAssistant (easy way!)">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Webhook_Facebook-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="FaceBook Messenger Simple REST API" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/facebook-messenger-custom-commands/" title="Manage Facebook Messenger Custom Commands (user defined)">Manage Facebook Messenger Custom Commands (user defined)</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/facebook-messenger-custom-commands/" title="Manage Facebook Messenger Custom Commands (user defined)">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Webhook_Facebook-1024x440.jpg" title="Manage Facebook Messenger Custom Commands (user defined)">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/HA_Facebook-1-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="FaceBook Messenger from Home Assistant" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/facebook-messenger-free-api-home-assistant/" title="Facebook Messenger from HomeAssistant">Facebook Messenger from HomeAssistant</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/facebook-messenger-free-api-home-assistant/" title="Facebook Messenger from HomeAssistant">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/HA_Facebook-1-1024x440.jpg" title="Facebook Messenger from HomeAssistant">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/Webhook_Facebo_Images2-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Facebook Messenger Simple REST Web API" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/free-api-facebook-messenger/" title="Free API to Send Facebook Messages and Images">Free API to Send Facebook Messages and Images</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/free-api-facebook-messenger/" title="Free API to Send Facebook Messages and Images">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/Webhook_Facebo_Images2-1024x440.jpg" title="Free API to Send Facebook Messages and Images">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/2020/03/Text-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Telegram Message from easy API" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/telegram-group-messages-api-easy/" title="Telegram Group Messages">Telegram Group Messages</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/telegram-group-messages-api-easy/" title="Telegram Group Messages">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/2020/03/Text-1024x440.jpg" title="Telegram Group Messages">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/spam_error-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Telegram SPAM error" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/spam-error/" title="Telegram SPAM error using the API">Telegram SPAM error using the API</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/spam-error/" title="Telegram SPAM error using the API">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/spam_error-1024x440.jpg" title="Telegram SPAM error using the API">Enlarge</a></div></div></div></div></li><li><div class="leap-overlay item-img"><img width="190" height="145" src="https://www.callmebot.com/wp-content/uploads/2019/10/HA-1-190x145.jpg" class="attachment-leap-related-thumbnail size-leap-related-thumbnail wp-post-image" alt="Telegram Calls from Home Assistant" /><div class="item-overlay"><div class="item-img-color"></div><div class="item-details"><h4 class="item-title"><a href="https://www.callmebot.com/blog/telegram-phone-calls-from-homeassistant-old/" title="Telegram Phone Calls from HomeAssistant (OLD method)">Telegram Phone Calls from HomeAssistant (OLD method)</a></h4><div class="item-links"><a class="item-link" href="https://www.callmebot.com/blog/telegram-phone-calls-from-homeassistant-old/" title="Telegram Phone Calls from HomeAssistant (OLD method)">Link</a><a class="enlarge" data-rel="prettyPhoto[sc_related_gal]" href="https://www.callmebot.com/wp-content/uploads/2019/10/HA-1-1024x440.jpg" title="Telegram Phone Calls from HomeAssistant (OLD method)">Enlarge</a></div></div></div></div></li></ul><div class="cfs-nav"><span class="cfs-prev">Previous</span><span class="cfs-next">Next</span></div></div></div>
        
        
    </div> <!-- end .content-section -->

    
</div> <!-- end #main -->

<div id="main-sidebar" class="fluid-sidebar sidebar  col-sm-3">
    <div class="main-sidebar-content">
        <div id="leap-category-posts-widget-2" class ="leap-widget-style4">                <style type="text/css" scoped>
                    #category-posts-widget-2 .widget-title {
                                    }
                </style>
                        <style type="text/css" scoped>
                #category-posts-widget-2 {
                                            margin-top: px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="category-posts-widget-2" class="widget category-posts"><div class="widget-head"><div class="title"><h4 class="widget-title">Recent Posts</h4></div></div><div class="widget-content">        <ul>
                        <li class="thumb" >
                                <div class="wdg-posttitle"><a href="https://www.callmebot.com/blog/update/" title="How to Update a PayPal Subscription">How to Update a PayPal Subscription</a></div>
                            </li>
                        <li class="thumb" >
                			
                    <div class="wdg-post">
                        <a href="https://www.callmebot.com/blog/test-phone-call-api/" title="Test Phone Call API from Web Browser"><img width="50" height="50" src="https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-50x50.png" class="attachment-leap-thumbnail size-leap-thumbnail wp-post-image" alt="" srcset="https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-50x50.png 50w, https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-150x150.png 150w, https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-100x100.png 100w, https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-570x570.png 570w" sizes="(max-width: 50px) 100vw, 50px" /></a>
                    </div><!-- wdg-post /-->
                                <div class="wdg-posttitle"><a href="https://www.callmebot.com/blog/test-phone-call-api/" title="Test Phone Call API from Web Browser">Test Phone Call API from Web Browser</a></div>
                            </li>
                        <li class="thumb" >
                			
                    <div class="wdg-post">
                        <a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/" title="Whatsapp Messages from UpDown.io"><img width="50" height="50" src="https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-50x50.png" class="attachment-leap-thumbnail size-leap-thumbnail wp-post-image" alt="" srcset="https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-50x50.png 50w, https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-150x150.png 150w, https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-100x100.png 100w, https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-570x570.png 570w" sizes="(max-width: 50px) 100vw, 50px" /></a>
                    </div><!-- wdg-post /-->
                                <div class="wdg-posttitle"><a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/" title="Whatsapp Messages from UpDown.io">Whatsapp Messages from UpDown.io</a></div>
                            </li>
            	
        </ul>
        <div class="clear"></div>
        </div></div></div><div id="leap-text-html-widget-2" class ="leap-widget-style4">                <style type="text/css" scoped>
                    #text-html-widget-2 .widget-title {
                                    }
                </style>
                        <style type="text/css" scoped>
                #text-html-widget-2 {
                                            margin-top: px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="text-html-widget-2" class="widget text-html"><div class="widget-head"><div class="title"><h4 class="widget-title">About us</h4></div></div><div class="widget-content"><div >mmmm…  Us? It is only the Bot and myself. This project has started as a personal need for my home automation system & alarm. Then my friends and colleagues wanted to use the same API that I created so I decided to share it with them.
When I realized about growing adoption, I decided to invest on AWS (Amazon Web Services) and GC (Google Cloud) to make it more reliable and accessible to everyone.
				</div><div class="clear"></div></div></div></div><div id="leap-ai_widget-3" class ="leap-widget-style4">                <style type="text/css" scoped>
                    #ai_widget-3 .widget-title {
                                    }
                </style>
                        <style type="text/css" scoped>
                #ai_widget-3 {
                                            margin-top: 0px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="ai_widget-3" class="widget block-widget"><div class="widget-head"><div class="title"><h4 class="widget-title">Ads</h4></div></div><div class="widget-content"><div class='code-block code-block-3' style='margin: 8px 0; clear: both;'>
You can now make 📞 <b>phone calls</b> 📞 usign CallMeBot API!  Check it <u><a href="https://www.callmebot.com/phone-call/">here!</a></u><br>Use the traditional calls + TTS for urgent/critical voice notifications.</div>
</div></div></div><div id="leap-mailchimpsf_widget-2" class ="leap-widget-style1">                <style type="text/css" scoped>
                    #mailchimpsf_widget-2 .widget-title {
                                            }
                </style>
                        <style type="text/css" scoped>
                #mailchimpsf_widget-2 {
                                            margin-top: px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="mailchimpsf_widget-2" class="widget widget_mailchimpsf_widget"><div class="widget-content"><div class="widget-head"><div class="title"><h4 class="widget-title">Sign up for CallMeBot News</h4></div></div>	<style>
		.widget_mailchimpsf_widget .widget-title {
		line-height: 1.4em;
		margin-bottom: 0.75em;
	}
	#mc_subheader {
		line-height: 1.25em;
		margin-bottom: 18px;
	}
	.mc_merge_var {
		margin-bottom: 1.0em;
	}
	.mc_var_label,
	.mc_interest_label {
		display: block;
		margin-bottom: 0.5em;
	}
	.mc_input {
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
		width: 100%;
	}
	.mc_input.mc_phone {
		width: auto;
	}
	select.mc_select {
		margin-top: 0.5em;
		width: 100%;
	}
	.mc_address_label {
		margin-top: 1.0em;
		margin-bottom: 0.5em;
		display: block;
	}
	.mc_address_label ~ select {
		width: 100%;		
	}
	.mc_list li {
		list-style: none;
		background: none !important;
	}
	.mc_interests_header {
		margin-top: 1.0em;
		margin-bottom: 0.5em;
	}
	.mc_interest label,
	.mc_interest input {
		margin-bottom: 0.4em;
	}
	#mc_signup_submit {
		margin-top: 1.5em;
		width: 80%;
	}
	#mc_unsub_link a {
		font-size: 0.75em;
	}
	#mc_unsub_link {
		margin-top: 1.0em;
	}
	.mc_header_address,
	.mc_email_format {
		display: block;
		font-weight: bold;
		margin-top: 1.0em;
		margin-bottom: 0.5em;
	}
	.mc_email_options {
		margin-top: 0.5em;
	}
	.mc_email_type {
		padding-left: 4px;
	}
	</style>
	
<div id="mc_signup">
	<form method="post" action="#mc_signup" id="mc_signup_form">
		<input type="hidden" id="mc_submit_type" name="mc_submit_type" value="html" />
		<input type="hidden" name="mcsf_action" value="mc_submit_signup_form" />
		<input type="hidden" id="_mc_submit_signup_form_nonce" name="_mc_submit_signup_form_nonce" value="fe92cc8884" />		
			<div id="mc_subheader">
			Subscribe if you want to be informed about new services and functionalities (1 email every 6 months - no more!)		</div><!-- /mc_subheader -->
			
	<div class="mc_form_inside">
		
		<div class="updated" id="mc_message">
					</div><!-- /mc_message -->

		
<div class="mc_merge_var">
		<label for="mc_mv_EMAIL" class="mc_var_label mc_header mc_header_email">Email Address</label>
	<input type="text" size="18" placeholder="" name="mc_mv_EMAIL" id="mc_mv_EMAIL" class="mc_input"/>
</div><!-- /mc_merge_var --><div style="display:none;"></div><div style="display:none;"></div>
		<div class="mc_signup_submit">
			<input type="submit" name="mc_signup_submit" id="mc_signup_submit" value="Subscribe" class="button" />
		</div><!-- /mc_signup_submit -->
	
	
				
	</div><!-- /mc_form_inside -->
	</form><!-- /mc_signup_form -->
</div><!-- /mc_signup_container -->
	</div></div></div><div id="leap-text-html-widget-5" class ="leap-widget-style1">                <style type="text/css" scoped>
                    #text-html-widget-5 .widget-title {
                                            }
                </style>
                        <style type="text/css" scoped>
                #text-html-widget-5 {
                                            margin-top: px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="text-html-widget-5" class="widget text-html"><div class="widget-head"><div class="title"><h4 class="widget-title">Follow me</h4></div></div><div class="widget-content"><div style="text-align:center;"><a href="https://twitter.com/callmebot_com"><img src="https://www.callmebot.com/wp-content/uploads/2020/02/twitter_small.png"></a>
				</div><div class="clear"></div></div></div></div>    </div>
</div>
</div> <!-- end row -->
</div> <!-- end container -->
</div> <!-- end #content -->


</div><!-- end #leap-content - wrap -->





<div id="leap-footer">
    <div id="inner-footer">

        
			<div id="footer-sidebar" >
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-3" ><div id="leap-posts-list-widget-3" class ="leap-widget-style2">                <style type="text/css" scoped>
                    #posts-list-widget-3 .widget-title {
                                            }
                </style>
                        <style type="text/css" scoped>
                #posts-list-widget-3 {
                                            margin-top: px !important;
                                                                margin-bottom: 0px !important;
                            }
            </style>
            <div id="posts-list-widget-3" class="widget posts-list"><div class="widget-head"><div class="title"><h4 class="widget-title">Recent Posts</h4></div></div><div class="widget-content">		<ul>
						<li class="thumb" >
								<div class="wdg-posttitle"><a href="https://www.callmebot.com/blog/update/">How to Update a PayPal Subscription</a></div>
				<small class="small">May 12, 2026</small>
			</li>
						<li class="thumb" >
							
					<div class="wdg-post">
						<a href="https://www.callmebot.com/blog/test-phone-call-api/" title="Permalink to Test Phone Call API from Web Browser"><img width="50" height="50" src="https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-50x50.png" class="attachment-leap-thumbnail size-leap-thumbnail wp-post-image" alt="" srcset="https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-50x50.png 50w, https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-150x150.png 150w, https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-100x100.png 100w, https://www.callmebot.com/wp-content/uploads/Diseño-sin-título-1-570x570.png 570w" sizes="(max-width: 50px) 100vw, 50px" /></a>
					</div><!-- wdg-post /-->
							<div class="wdg-posttitle"><a href="https://www.callmebot.com/blog/test-phone-call-api/">Test Phone Call API from Web Browser</a></div>
				<small class="small">August 13, 2025</small>
			</li>
						<li class="thumb" >
							
					<div class="wdg-post">
						<a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/" title="Permalink to Whatsapp Messages from UpDown.io"><img width="50" height="50" src="https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-50x50.png" class="attachment-leap-thumbnail size-leap-thumbnail wp-post-image" alt="" srcset="https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-50x50.png 50w, https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-150x150.png 150w, https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-100x100.png 100w, https://www.callmebot.com/wp-content/uploads/updown_WhatsApp-570x570.png 570w" sizes="(max-width: 50px) 100vw, 50px" /></a>
					</div><!-- wdg-post /-->
							<div class="wdg-posttitle"><a href="https://www.callmebot.com/blog/whatsapp-from-updown-io/">Whatsapp Messages from UpDown.io</a></div>
				<small class="small">May 1, 2024</small>
			</li>
				
		</ul>
		<div class="clear"></div>
		</div></div></div></div><div class="col-sm-3" ><div id="leap-ai_widget-2" class ="leap-widget-style1">                <style type="text/css" scoped>
                    #ai_widget-2 .widget-title {
                                            }
                </style>
                        <style type="text/css" scoped>
                #ai_widget-2 {
                                            margin-top: px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="ai_widget-2" class="widget block-widget ai-sticky-widget"><div class="widget-head"><div class="title"><h4 class="widget-title"> </h4></div></div><div class="widget-content"><div class='code-block code-block-2' style='margin: 8px 0; clear: both;'>

<div class='ai-rotate ai-unprocessed ai-timed-rotation ai-2-1' data-info='WyIyLTEiLDJd' style='position: relative;'>
<div class='ai-rotate-option' style='visibility: hidden;' data-index="1" data-name="QQ==" data-time="Nw==">
<p style="padding: 10px; background-color: #444; border-radius: 10px;">Ads: Send pictures, documents, buttons to unlimited recipients with <u><a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=2A">TextMeBot.com</a></u> low cost API. Check it <u><a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=2A">here</a></u>.</p></div>
<div class='ai-rotate-option' style='visibility: hidden; position: absolute; top: 0; left: 0; width: 100%; height: 100%;' data-index="2" data-name="Qg==" data-time="Nw==">
<p style="padding: 10px; background-color: #444; border-radius: 10px;">Ads: Send unlimited whatsapp messages to unlimited recipients with <u><a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=2B">TextMeBot.com</a></u> low cost API. Check it <u><a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=2B">here</a></u>.</p></div>
</div>
</div>
</div></div></div></div><div class="col-sm-3" ><div id="leap-mailchimpsf_widget-3" class ="leap-widget-style1">                <style type="text/css" scoped>
                    #mailchimpsf_widget-3 .widget-title {
                                            }
                </style>
                        <style type="text/css" scoped>
                #mailchimpsf_widget-3 {
                                            margin-top: px !important;
                                                                margin-bottom: px !important;
                            }
            </style>
            <div id="mailchimpsf_widget-3" class="widget widget_mailchimpsf_widget"><div class="widget-content"><div class="widget-head"><div class="title"><h4 class="widget-title">Sign up for CallMeBot News</h4></div></div>	<style>
		.widget_mailchimpsf_widget .widget-title {
		line-height: 1.4em;
		margin-bottom: 0.75em;
	}
	#mc_subheader {
		line-height: 1.25em;
		margin-bottom: 18px;
	}
	.mc_merge_var {
		margin-bottom: 1.0em;
	}
	.mc_var_label,
	.mc_interest_label {
		display: block;
		margin-bottom: 0.5em;
	}
	.mc_input {
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
		width: 100%;
	}
	.mc_input.mc_phone {
		width: auto;
	}
	select.mc_select {
		margin-top: 0.5em;
		width: 100%;
	}
	.mc_address_label {
		margin-top: 1.0em;
		margin-bottom: 0.5em;
		display: block;
	}
	.mc_address_label ~ select {
		width: 100%;		
	}
	.mc_list li {
		list-style: none;
		background: none !important;
	}
	.mc_interests_header {
		margin-top: 1.0em;
		margin-bottom: 0.5em;
	}
	.mc_interest label,
	.mc_interest input {
		margin-bottom: 0.4em;
	}
	#mc_signup_submit {
		margin-top: 1.5em;
		width: 80%;
	}
	#mc_unsub_link a {
		font-size: 0.75em;
	}
	#mc_unsub_link {
		margin-top: 1.0em;
	}
	.mc_header_address,
	.mc_email_format {
		display: block;
		font-weight: bold;
		margin-top: 1.0em;
		margin-bottom: 0.5em;
	}
	.mc_email_options {
		margin-top: 0.5em;
	}
	.mc_email_type {
		padding-left: 4px;
	}
	</style>
	
<div id="mc_signup">
	<form method="post" action="#mc_signup" id="mc_signup_form">
		<input type="hidden" id="mc_submit_type" name="mc_submit_type" value="html" />
		<input type="hidden" name="mcsf_action" value="mc_submit_signup_form" />
		<input type="hidden" id="_mc_submit_signup_form_nonce" name="_mc_submit_signup_form_nonce" value="fe92cc8884" />		
			<div id="mc_subheader">
			Subscribe if you want to be informed about new services and functionalities (1 email every 6 months - no more!)		</div><!-- /mc_subheader -->
			
	<div class="mc_form_inside">
		
		<div class="updated" id="mc_message">
					</div><!-- /mc_message -->

		
<div class="mc_merge_var">
		<label for="mc_mv_EMAIL" class="mc_var_label mc_header mc_header_email">Email Address</label>
	<input type="text" size="18" placeholder="" name="mc_mv_EMAIL" id="mc_mv_EMAIL" class="mc_input"/>
</div><!-- /mc_merge_var --><div style="display:none;"></div><div style="display:none;"></div>
		<div class="mc_signup_submit">
			<input type="submit" name="mc_signup_submit" id="mc_signup_submit" value="Subscribe" class="button" />
		</div><!-- /mc_signup_submit -->
	
	
				
	</div><!-- /mc_form_inside -->
	</form><!-- /mc_signup_form -->
</div><!-- /mc_signup_container -->
	</div></div></div></div><div class="col-sm-3" ><div id="leap-contact_info-widget-2" class ="leap-widget-style2">                <style type="text/css" scoped>
                    #contact_info-widget-2 .widget-title {
                                            }
                </style>
                        <style type="text/css" scoped>
                #contact_info-widget-2 {
                                            margin-top: px !important;
                                                                margin-bottom: 0px !important;
                            }
            </style>
            <div id="contact_info-widget-2" class="widget contact_info"><div class="widget-head"><div class="title"><h4 class="widget-title">Contact Info</h4></div></div><div class="widget-content">		
		
					<div class="mobile"><i class="fab fa-twitter"></i> <span>Twitter:</span> <a href="https://twitter.com/callmebot_com" target="_blank">@callmebot_com</a></div>
		
		
					<div class="email"><i class="fa fa-envelope"></i> <span>Email:</span> <a href="/cdn-cgi/l/email-protection#9eedebeeeef1eceadefdfff2f2f3fbfcf1eab0fdf1f3"><span class="__cf_email__" data-cfemail="26555356564954526645474a4a4b434449520845494b">[email&#160;protected]</span></a></div>
		
					<div class="web"><i class="fa fa-globe"></i> <span>Website:</span>  <a href="http://callmebot.com">http://callmebot.com</a></div>
				</div></div></div></div>					</div>
				</div>
			</div>
			
    </div> <!-- end #inner-footer -->

            <div class="footer-block">
            <div class="container-fluid">
                <div class="row">
                <div class="col-sm-12">
                <div class="pull-right">
                    <div id="footer-menu-container" class="menu-footer-container"><ul id="footer-menu" class="menu"><li id="menu-item-4123" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4123"><a href="https://www.callmebot.com/telegram-call-api2/">Home</a></li>
<li id="menu-item-4122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4122"><a href="https://www.callmebot.com/callmebot-servers-availability/">Availability</a></li>
<li id="menu-item-4132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4132"><a href="https://www.callmebot.com/cookies/">Availability</a></li>
<li id="menu-item-4231" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4231"><a href="https://www.callmebot.com/terms-of-service/">Terms of Service</a></li>
<li id="menu-item-4232" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4232"><a href="https://www.callmebot.com/cookies/">Cookies</a></li>
<li id="menu-item-4233" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-4233"><a href="https://www.callmebot.com/privacy-policy/">Privacy Policy</a></li>
</ul></div>                </div>
                <div class="pull-left">
                                        
                                        <p class="copyright">Thanks for using <a target="_blank" href="https://www.callmebot.com/">CallMeBot.com</a> - Chat Support on Telegram <a target="_blank" href="https://t.me/callmebot_com">@callmebot_com</a></p>                </div>
            </div>
        </div>
    </div></div>
    </div><!-- end footer -->

</div> <!-- end #leap-wrapper -->

<div class='code-block code-block-1' style='clear: both; left: 0;  position: fixed; bottom: 0; background-color: #333; color: white; text-align: center; padding: 10px 0; border-top-right-radius: 10px;'>

<div class='ai-rotate ai-unprocessed ai-timed-rotation ai-1-1' data-info='WyIxLTEiLDJd' style='position: relative;'>
<div class='ai-rotate-option' style='visibility: hidden;' data-index="1" data-name="QQ==" data-time="MTA=">
&nbspAds: Send unlimited messages to unlimited recipients with <a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=1A" style="color: orange; text-decoration: none !important;" target="_blank">TextMeBot.com</a> low cost API. Check it 👉 <a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=1A" style="color: orange; text-decoration: none !important;" target="_blank">here</a> 👈&nbsp&nbsp&nbsp&nbsp</div>
<div class='ai-rotate-option' style='visibility: hidden; position: absolute; top: 0; left: 0; width: 100%; height: 100%;' data-index="2" data-name="Qg==" data-time="MTA=">
&nbspAds: Send pictures, documents, buttons to unlimited recipients with <a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=1B" style="color: orange; text-decoration: none !important;" target="_blank">TextMeBot.com</a> low cost API. Check it 👉 <a href="https://textmebot.com/?utm_source=cmb&utm_medium=ads&utm_campaign=1B" style="color: orange; text-decoration: none !important;" target="_blank">here</a> 👈&nbsp&nbsp&nbsp&nbsp</div>
</div>
</div>
        <a class="scrollup" href="#"><span>Top</span></a>
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
            ( function ( $ ) {
                "use strict";
                // scroll-to-top button show and hide
                jQuery( document ).ready( function () {

                    'use strict';

                    jQuery( window ).scroll( function () {
                        if ( jQuery( this ).scrollTop() > 100 ) {
                            jQuery( '.scrollup' ).fadeIn();
                        } else {
                            jQuery( '.scrollup' ).fadeOut();
                        }
                    } );
                    // scroll-to-top animate
                    jQuery( '.scrollup' ).click( function () {
                        jQuery( "html, body" ).animate( { scrollTop: 0 }, 1500, 'easeInOutExpo' );
                        return false;
                    } );
                } );
            } )( jQuery );
        </script>
        					<script type="text/javascript">

						/*
						 * 	- 	Add VC_Row classes [with - support theme]
						 *  - 	Add Active Menu class
						 *-------------------------------------------------------------*/
						;(function ( $, window, undefined ) {
							var pluginName = 'OPN_Scroll',
							    document = window.document,
							    defaults = {
									vc_version: parseFloat('6.0.5'),
									activeItem: 'opn_active_menu',
									rowClass: 'vc_row',
									inc_class: 'a[href!="#"]',
									ex_class: '.imd_tour_link a, .ult_tab_li a, .bx-pager a, .ui-tabs-anchor, .vc_tta-panel-title a, .vc_tta-tab a, .vc_tta-panel, .ui-title, .portfolio-tabs li a, a.scrollup',
									active: '',
									firstItem: false,
							    };

							function opn( element, options ) {
							  this.element = element;
							  this.options = $.extend( {}, defaults, options) ;
							  this._defaults = defaults;
							  this._name = pluginName;
							  this.init();
							}
						  	opn.prototype.init = function () {
							    var self 		= this,
							    	p 			= self._defaults,
							    	ac 			= p.activeItem,
							    	includes 	= p.inc_class;

							    //	Add active class
							    $( includes ).bind('click touchstart', function(){
									$(this).parent('li').siblings().removeClass( ac );
									$(this).parent('li').addClass( ac );
								});

								if(typeof p.rowClass != 'undefined' && p.rowClass != null) {

									//	Add THEME Support for VC ROW ID from OPN
							        $('.opn-row-pre-element').each(function(index, el) {
									    var id = $(el).attr('data-id');
									    var gutter = $(el).attr('data-gutter');
									    var opn_enable_overlay = $(el).attr('data-opn_enable_overlay') || '';
									    var opn_hide_navigation = $(el).attr('data-opn_hide_navigation') || '';

									    //	set VC row class from user
									    var $row = $(el).prevAll('.'+p.rowClass+':first');

									    $row.attr('data-op-gutter', gutter);
									    $row.attr('data-opn_enable_overlay', opn_enable_overlay);
									    $row.attr('data-opn_hide_navigation', opn_hide_navigation);
									    if (id != '') {
									    	//	Add ID for VC version <= 4.4
									    	/*if( parseFloat(p.vc_version) <= parseFloat(4.4) ) {*/
									    		//	Check VC version 4.5 set ROW ID
									    		//	if not found set OPN ID for row.

									    		/* 	Does not check VC version or Row has ID.
									    		 * 	Add ID for row Either VC or OPN.
									    		 * 	To fix theme ID's issue.
									    		 *------------------------------------------------------------*/
									    		var hasID = $row.attr('id') || '';
									    		if(hasID === 'undefined' || hasID === null || hasID==='') {
										        	$row.attr('id', id);
									    		}
									    	/*}*/
									    }
									    $(el).remove();
									});

							        //  Apply for 1 Scroll
									setTimeout(function(){
										$('.'+p.rowClass).each( function(index, elem) {
											var id = $(elem).attr('id') || null;
											if(typeof id!= 'undefined' && id != null) {

							                    // 	Get fist Item
							                    if( p.firstItem == false ) {
							                    	p.firstItem = id;
							                    	$('#'+p.firstItem).addClass('opn-active');
							                    	$('#'+p.firstItem).parent().addClass('opn-row-container');
							                    }
											}
										});
							        },700);
								}
	  						};
							$.fn[pluginName] = function ( options ) {
								return this.each(function () {
									if (!$.data(this, 'plugin_' + pluginName)) {
										$.data(this, 'plugin_' + pluginName, new opn( this, options ));
									}
								});
							}
							$(document).ready(function() {

								$('body').OPN_Scroll();

								//	on Visit Scroll to # link
								var opn_jump = function(e)
						        {
						        	var target = 'undefined';

						            if (e)
						            {
						                e.preventDefault();
						                if( !$(this).hasClass('.imd_tour_link a, .ult_tab_li a, .bx-pager a, .ui-tabs-anchor, .vc_tta-panel-title a, .vc_tta-tab a, .vc_tta-panel, .ui-title, .portfolio-tabs li a, a.scrollup') ) {
						                	target = $(this).attr("href");
						                }
						            } else
						            {
						                target = location.hash;
						            }
						            if (typeof target === 'undefined' || target === '')
						                return false;
						            var gutter = $(target).attr('data-op-gutter');
						            if (typeof gutter === 'undefined')
						                gutter = 0;

						            $(target).animatescroll({
						                scrollSpeed: 1000,
						                easing: 'easeOutQuad',
						                padding: gutter
						            });
						            location.hash = target;
						            $(window).load(function(){
						                setTimeout(function(){
						                     $(target).animatescroll({
						                        scrollSpeed: 1000,
						                        easing: 'easeOutQuad',
						                        padding: gutter
						                    });
						                },500);
						            });
						        }

                                opn_jump();

                                //  Add EXCLUDE - Classes & ID's
                                $('.imd_tour_link a, .ult_tab_li a, .bx-pager a, .ui-tabs-anchor, .vc_tta-panel-title a, .vc_tta-tab a, .vc_tta-panel, .ui-title, .portfolio-tabs li a, a.scrollup').addClass('opn-exclude');

                                /*
                                 *  on Click / Touch
                                 *--------------------------------------------------------*/
                                // For menu it will works
                                $('a[href!="#"]').bind('click touchstart', function(){
                                	//	Exclude Anchors who has class - '.opn-exclude'
					        		if( !$(this).hasClass('opn-exclude') ) {
	                                    if (location.pathname.replace(/\/$/, '') == this.pathname.replace(/\/$/, '') && location.hostname == this.hostname) {
	                                        var target  = $(this.hash);
	                                        var hasHash = this.hash;
	                                        if(typeof hasHash != 'undefined' && hasHash != null && hasHash != '') {
		                                        target = target.length ? target : $('[name=' + hasHash.slice(1) + ']');
		                                        if (target.length) {
		                                            var id = hasHash.slice(1);
		                                            var gutter = $('#' + id).attr('data-op-gutter') || 0;

		                                            $('#' + id).animatescroll({
		                                                scrollSpeed: 1000,
		                                                easing: "easeOutQuad",
		                                                padding: gutter
		                                            });
		                                            return false;
		                                        }
	                                        }
	                                    }
	                              	}
                                });

							});

					        $(document).on('click touchstart', 'a[href!="#"]', function(e) {
					        	//	Exclude Anchors who has class - '.opn-exclude'
					        	if( !$(this).hasClass('opn-exclude') ) {
							        if (location.pathname.replace(/\/$/, '') == this.pathname.replace(/\/$/, '') && location.hostname == this.hostname) {
							            var target  = $(this.hash);
	                                    var hasHash = this.hash;
	                                    if(typeof hasHash != 'undefined' && hasHash != null && hasHash != '') {
								            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
								            if (target.length) {

								            	var scroll_speed = 1000;
								                var scroll_effect = "easeOutQuad";
								                var id = this.hash.slice(1);
								                // Above settings works JUST for - One Page Navigator - Menu
								                var i = p = '';
								                $('.opn_fixed .opn_list').each(function(index, element) {
								                    var anch = $(element).find('a');
								                    anch.each(function(ind, elm) {
								                        var a = $(elm).attr('href');

								                        if(typeof a !== 'undefined' && a != null) {
								                            ind = a.split('#')[1];
								                            if(id == ind) {
								                                p = $(elm).parent().parent();
								                                scroll_speed = p.attr('data-scroll_speed') || 1000;
								                                scroll_effect = p.attr('data-scroll_effect') || "easeOutQuad";
								                            }
								                        }
								                    });
								                });

								                var gutter = $('#' + id).attr('data-op-gutter') || 0;
								                scroll_speed = parseInt(scroll_speed);

								                $('#' + id).animatescroll({
								                    scrollSpeed: scroll_speed,
								                    easing: scroll_effect,
								                    padding: gutter
								                });
								                return false;
								            }
								    	}
							        }
							    }
						    });

						}(jQuery, window));
					</script>
					<!-- Google Tag Manager (noscript) snippet added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W2F4XK6" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) snippet added by Site Kit -->
		<link rel='stylesheet' id='opn-custom-style-css'  href='https://www.callmebot.com/wp-content/plugins/one-page-navigator/elements/../assets/css/op-custom.min.css?ver=1.1.10' type='text/css' media='all' />
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/effect.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/effect-drop.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/hoverIntent.min.js?ver=1.8.1'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/comment-reply.min.js?ver=5.2.6'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/bootstrap/ltr/js/bootstrap.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/jquery.cycle.lite.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/caroufredsel/jquery.carouFredSel-6.2.1-packed.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/superfish/js/superfish.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/slicknav/jquery.slicknav.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/prettyPhoto/js/jquery.prettyPhoto.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/js_composer/assets/lib/bower/flexslider/jquery.flexslider-min.js?ver=6.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/masonry/jquery.masonry.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/animation/wow.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/parallax/jquery.parallax.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/SmoothScroll/SmoothScroll.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/stickUp/stickUp.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/vendor/jquery/jquery.easing.min.js?ver=3.0.5'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var theme_vars = {"logo_url":"http:\/\/www.callmebot.com\/wp-content\/uploads\/2019\/10\/Logo-Negro_x1.png","sticky_logo_url":"","mobile_menu_width":"1000","smooth_scroll":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/themes/wiz/js/theme.js?ver=3.0.5'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/layered-popups/js/script.min.js?ver=6.37'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/wp-embed.min.js?ver=5.2.6'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/one-page-navigator/assets/js/animatescroll.min.js?ver=1.1.10'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/one-page-navigator/assets/js/op-custom.min.js?ver=1.1.10'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=2.7.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.7.3'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2'></script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=4.4.6'></script>
<script type='text/javascript'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"2.7.4","urls":{"assets":"https:\/\/www.callmebot.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"general":{"elementor_global_image_lightbox":"yes","elementor_enable_lightbox_in_editor":"yes"}},"post":{"id":4294,"title":"Telegram Text Messages","excerpt":""}};
</script>
<script type='text/javascript' src='https://www.callmebot.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=2.7.4'></script>

		<script>
			var ulp_ajax_url = "https://www.callmebot.com/wp-admin/admin-ajax.php";
			var ulp_css3_enable = "on";
			var ulp_ga_tracking = "off";
			var ulp_km_tracking = "off";
			var ulp_onexit_limits = "off";
			var ulp_no_preload = "on";
			var ulp_campaigns = {"none":[""]};
			var ulp_overlays = {"m6SKa3JMUzBv4LZi":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"v57ZqbtFig5H9Obq":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"NbzDMbNCYjD5tdVu":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"AuUSIts9PHiyZQF2":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"DWlQqnfYI7bQQk5y":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"1c2Hg3CZClEDXu7A":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"vEPEwU9kAs76L3SG":["", "0.9", "on", "bottom-right", "fadeIn", "classic", "#ffffff"],"rrtWwXq3BzEdKMxQ":["#e0e0e0", "0.9", "on", "middle-center", "fadeIn", "classic", "#ffffff"],"none":["", "", "", "", ""]};
			if (typeof ulp_init == "function") { 
				ulp_init(); jQuery(document).ready(function() {ulp_ready();});
			} else {
				jQuery(document).ready(function(){ulp_init(); ulp_ready();});
			}
		</script><script src="https://www.callmebot.com/wp-content/plugins/layered-popups/js/ads.js?ver=6.37"></script><script>
function b2a(a){var b,c=0,l=0,f="",g=[];if(!a)return a;do{var e=a.charCodeAt(c++);var h=a.charCodeAt(c++);var k=a.charCodeAt(c++);var d=e<<16|h<<8|k;e=63&d>>18;h=63&d>>12;k=63&d>>6;d&=63;g[l++]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(e)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(h)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(k)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(d)}while(c<
a.length);return f=g.join(""),b=a.length%3,(b?f.slice(0,b-3):f)+"===".slice(b||3)}function a2b(a){var b,c,l,f={},g=0,e=0,h="",k=String.fromCharCode,d=a.length;for(b=0;64>b;b++)f["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(b)]=b;for(c=0;d>c;c++)for(b=f[a.charAt(c)],g=(g<<6)+b,e+=6;8<=e;)((l=255&g>>>(e-=8))||d-2>c)&&(h+=k(l));return h}b64e=function(a){return btoa(encodeURIComponent(a).replace(/%([0-9A-F]{2})/g,function(b,a){return String.fromCharCode("0x"+a)}))};
b64d=function(a){return decodeURIComponent(atob(a).split("").map(function(a){return"%"+("00"+a.charCodeAt(0).toString(16)).slice(-2)}).join(""))};
/* <![CDATA[ */
ai_front = {"insertion_before":"BEFORE","insertion_after":"AFTER","insertion_prepend":"PREPEND CONTENT","insertion_append":"APPEND CONTENT","insertion_replace_content":"REPLACE CONTENT","insertion_replace_element":"REPLACE ELEMENT","visible":"VISIBLE","hidden":"HIDDEN","fallback":"FALLBACK","automatically_placed":"Automatically placed by AdSense Auto ads code","cancel":"Cancel","use":"Use","add":"Add","parent":"Parent","cancel_element_selection":"Cancel element selection","select_parent_element":"Select parent element","css_selector":"CSS selector","use_current_selector":"Use current selector","element":"ELEMENT","path":"PATH","selector":"SELECTOR"};
/* ]]> */
var sticky_widget_mode=0,sticky_widget_margin=15,ai_block_class_def="code-block";
"undefined"!=typeof sticky_widget_mode&&function(d){"complete"===document.readyState||"loading"!==document.readyState&&!document.documentElement.doScroll?d():document.addEventListener("DOMContentLoaded",d)}(function(){var d=function(){var e=document.body.clientWidth;document.querySelectorAll(".ai-sticky-widget").forEach((b,a)=>{if(2==sticky_widget_mode)a=b.querySelector("."+ai_block_class_def),null!=a&&(a.style.position="sticky",a.style.position="-webkit-sticky",a.style.top=sticky_widget_margin+"px"),
a=b.querySelector(".ai-sticky-space"),null!=a&&(a.style.height=window.innerHeight+"px");else{var c=b.clientWidth,f=!1;for(a=b.parentElement;"BODY"!=a.tagName;){if(a.classList.contains("theiaStickySidebar")){f=!0;break}var g=a.parentElement,h=g.clientWidth;if(h>1.2*c||h>e/2)break;a=g}if(!f)if(c=a.getBoundingClientRect(),b=b.getBoundingClientRect(),b=c.top-b.top+sticky_widget_margin,0==sticky_widget_mode){if("sticky"!=a.style.position||isNaN(parseInt(a.style.top))||a.style.top<b)if(a.style.position=
"sticky",a.style.position="-webkit-sticky",a.style.top=b+"px","undefined"==typeof ai_no_sticky_sidebar_height)for(b=a;"BODY"!=b.tagName;)if(b=b.parentElement,(b.clientWidth>1.5*a.clientWidth||b.clientWidth>e/2)&&b.clientHeight>a.clientHeight){c=b.clientHeight;a.parentElement.style.height=c+"px";a.parentElement.style.height=c-(b.clientHeight-c)+"px";break}}else 1==sticky_widget_mode&&(window.jQuery&&window.jQuery.fn?jQuery(a).theiaStickySidebar({additionalMarginTop:b,sidebarBehavior:"stick-to-top"}):
console.error("AI STICKY WIDGET MODE Javascript USES jQuery","- jQuery not found"))}})};"undefined"==typeof ai_sticky_sidebar_delay&&(ai_sticky_sidebar_delay=200);setTimeout(function(){d()},ai_sticky_sidebar_delay)});
var ai_cookie_js=!0,ai_block_class_def="code-block";
/*
 js-cookie v3.0.5 | MIT  JavaScript Cookie v2.2.0
 https://github.com/js-cookie/js-cookie

 Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 Released under the MIT license
*/
if("undefined"!==typeof ai_cookie_js){(function(a,f){"object"===typeof exports&&"undefined"!==typeof module?module.exports=f():"function"===typeof define&&define.amd?define(f):(a="undefined"!==typeof globalThis?globalThis:a||self,function(){var b=a.Cookies,c=a.Cookies=f();c.noConflict=function(){a.Cookies=b;return c}}())})(this,function(){function a(b){for(var c=1;c<arguments.length;c++){var g=arguments[c],e;for(e in g)b[e]=g[e]}return b}function f(b,c){function g(e,d,h){if("undefined"!==typeof document){h=
a({},c,h);"number"===typeof h.expires&&(h.expires=new Date(Date.now()+864E5*h.expires));h.expires&&(h.expires=h.expires.toUTCString());e=encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape);var l="",k;for(k in h)h[k]&&(l+="; "+k,!0!==h[k]&&(l+="="+h[k].split(";")[0]));return document.cookie=e+"="+b.write(d,e)+l}}return Object.create({set:g,get:function(e){if("undefined"!==typeof document&&(!arguments.length||e)){for(var d=document.cookie?document.cookie.split("; "):
[],h={},l=0;l<d.length;l++){var k=d[l].split("="),p=k.slice(1).join("=");try{var n=decodeURIComponent(k[0]);h[n]=b.read(p,n);if(e===n)break}catch(q){}}return e?h[e]:h}},remove:function(e,d){g(e,"",a({},d,{expires:-1}))},withAttributes:function(e){return f(this.converter,a({},this.attributes,e))},withConverter:function(e){return f(a({},this.converter,e),this.attributes)}},{attributes:{value:Object.freeze(c)},converter:{value:Object.freeze(b)}})}return f({read:function(b){'"'===b[0]&&(b=b.slice(1,-1));
return b.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent)},write:function(b){return encodeURIComponent(b).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,decodeURIComponent)}},{path:"/"})});AiCookies=Cookies.noConflict();function m(a){if(null==a)return a;'"'===a.charAt(0)&&(a=a.slice(1,-1));try{a=JSON.parse(a)}catch(f){}return a}ai_check_block=function(a){var f="undefined"!==typeof ai_debugging;if(null==a)return!0;var b=m(AiCookies.get("aiBLOCKS"));ai_debug_cookie_status="";null==b&&(b={});"undefined"!==
typeof ai_delay_showing_pageviews&&(b.hasOwnProperty(a)||(b[a]={}),b[a].hasOwnProperty("d")||(b[a].d=ai_delay_showing_pageviews,f&&console.log("AI CHECK block",a,"NO COOKIE DATA d, delayed for",ai_delay_showing_pageviews,"pageviews")));if(b.hasOwnProperty(a)){for(var c in b[a]){if("x"==c){var g="",e=document.querySelectorAll('span[data-ai-block="'+a+'"]')[0];"aiHash"in e.dataset&&(g=e.dataset.aiHash);e="";b[a].hasOwnProperty("h")&&(e=b[a].h);f&&console.log("AI CHECK block",a,"x cookie hash",e,"code hash",
g);var d=new Date;d=b[a][c]-Math.round(d.getTime()/1E3);if(0<d&&e==g)return ai_debug_cookie_status=b="closed for "+d+" s = "+Math.round(1E4*d/3600/24)/1E4+" days",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1;f&&console.log("AI CHECK block",a,"removing x");ai_set_cookie(a,"x","");b[a].hasOwnProperty("i")||b[a].hasOwnProperty("c")||ai_set_cookie(a,"h","")}else if("d"==c){if(0!=b[a][c])return ai_debug_cookie_status=b="delayed for "+b[a][c]+" pageviews",f&&console.log("AI CHECK block",a,
b),f&&console.log(""),!1}else if("i"==c){g="";e=document.querySelectorAll('span[data-ai-block="'+a+'"]')[0];"aiHash"in e.dataset&&(g=e.dataset.aiHash);e="";b[a].hasOwnProperty("h")&&(e=b[a].h);f&&console.log("AI CHECK block",a,"i cookie hash",e,"code hash",g);if(0==b[a][c]&&e==g)return ai_debug_cookie_status=b="max impressions reached",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1;if(0>b[a][c]&&e==g){d=new Date;d=-b[a][c]-Math.round(d.getTime()/1E3);if(0<d)return ai_debug_cookie_status=
b="max imp. reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1;f&&console.log("AI CHECK block",a,"removing i");ai_set_cookie(a,"i","");b[a].hasOwnProperty("c")||b[a].hasOwnProperty("x")||(f&&console.log("AI CHECK block",a,"cookie h removed"),ai_set_cookie(a,"h",""))}}if("ipt"==c&&0==b[a][c]&&(d=new Date,g=Math.round(d.getTime()/1E3),d=b[a].it-g,0<d))return ai_debug_cookie_status=b="max imp. per time reached ("+Math.round(1E4*d/24/
3600)/1E4+" days = "+d+" s)",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1;if("c"==c){g="";e=document.querySelectorAll('span[data-ai-block="'+a+'"]')[0];"aiHash"in e.dataset&&(g=e.dataset.aiHash);e="";b[a].hasOwnProperty("h")&&(e=b[a].h);f&&console.log("AI CHECK block",a,"c cookie hash",e,"code hash",g);if(0==b[a][c]&&e==g)return ai_debug_cookie_status=b="max clicks reached",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1;if(0>b[a][c]&&e==g){d=new Date;d=-b[a][c]-Math.round(d.getTime()/
1E3);if(0<d)return ai_debug_cookie_status=b="max clicks reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1;f&&console.log("AI CHECK block",a,"removing c");ai_set_cookie(a,"c","");b[a].hasOwnProperty("i")||b[a].hasOwnProperty("x")||(f&&console.log("AI CHECK block",a,"cookie h removed"),ai_set_cookie(a,"h",""))}}if("cpt"==c&&0==b[a][c]&&(d=new Date,g=Math.round(d.getTime()/1E3),d=b[a].ct-g,0<d))return ai_debug_cookie_status=b="max clicks per time reached ("+
Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",f&&console.log("AI CHECK block",a,b),f&&console.log(""),!1}if(b.hasOwnProperty("G")&&b.G.hasOwnProperty("cpt")&&0==b.G.cpt&&(d=new Date,g=Math.round(d.getTime()/1E3),d=b.G.ct-g,0<d))return ai_debug_cookie_status=b="max global clicks per time reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",f&&console.log("AI CHECK GLOBAL",b),f&&console.log(""),!1}ai_debug_cookie_status="OK";f&&console.log("AI CHECK block",a,"OK");f&&console.log("");return!0};
ai_check_and_insert_block=function(a,f){var b="undefined"!==typeof ai_debugging;if(null==a)return!0;var c=document.getElementsByClassName(f);if(c.length){c=c[0];var g=c.closest("."+ai_block_class_def),e=ai_check_block(a);!e&&0!=parseInt(c.getAttribute("limits-fallback"))&&c.hasAttribute("data-fallback-code")&&(b&&console.log("AI CHECK FAILED, INSERTING FALLBACK BLOCK",c.getAttribute("limits-fallback")),c.setAttribute("data-code",c.getAttribute("data-fallback-code")),null!=g&&g.hasAttribute("data-ai")&&
c.hasAttribute("fallback-tracking")&&c.hasAttribute("fallback_level")&&g.setAttribute("data-ai-"+c.getAttribute("fallback_level"),c.getAttribute("fallback-tracking")),e=!0);c.removeAttribute("data-selector");e?(ai_insert_code(c),g&&(b=g.querySelectorAll(".ai-debug-block"),b.length&&(g.classList.remove("ai-list-block"),g.classList.remove("ai-list-block-ip"),g.classList.remove("ai-list-block-filter"),g.style.visibility="",g.classList.contains("ai-remove-position")&&(g.style.position="")))):(b=c.closest("div[data-ai]"),
null!=b&&"undefined"!=typeof b.getAttribute("data-ai")&&(e=JSON.parse(b64d(b.getAttribute("data-ai"))),"undefined"!==typeof e&&e.constructor===Array&&(e[1]="",b.setAttribute("data-ai",b64e(JSON.stringify(e))))),g&&(b=g.querySelectorAll(".ai-debug-block"),b.length&&(g.classList.remove("ai-list-block"),g.classList.remove("ai-list-block-ip"),g.classList.remove("ai-list-block-filter"),g.style.visibility="",g.classList.contains("ai-remove-position")&&(g.style.position=""))));c.classList.remove(f)}c=document.querySelectorAll("."+
f+"-dbg");g=0;for(b=c.length;g<b;g++)e=c[g],e.querySelector(".ai-status").textContent=ai_debug_cookie_status,e.querySelector(".ai-cookie-data").textContent=ai_get_cookie_text(a),e.classList.remove(f+"-dbg")};ai_load_cookie=function(){var a="undefined"!==typeof ai_debugging,f=m(AiCookies.get("aiBLOCKS"));null==f&&(f={},a&&console.log("AI COOKIE NOT PRESENT"));a&&console.log("AI COOKIE LOAD",f);return f};ai_set_cookie=function(a,f,b){var c="undefined"!==typeof ai_debugging;c&&console.log("AI COOKIE SET block:",
a,"property:",f,"value:",b);var g=ai_load_cookie();if(""===b){if(g.hasOwnProperty(a)){delete g[a][f];a:{f=g[a];for(e in f)if(f.hasOwnProperty(e)){var e=!1;break a}e=!0}e&&delete g[a]}}else g.hasOwnProperty(a)||(g[a]={}),g[a][f]=b;0===Object.keys(g).length&&g.constructor===Object?(AiCookies.remove("aiBLOCKS"),c&&console.log("AI COOKIE REMOVED")):AiCookies.set("aiBLOCKS",JSON.stringify(g),{expires:365,path:"/"});if(c)if(a=m(AiCookies.get("aiBLOCKS")),"undefined"!=typeof a){console.log("AI COOKIE NEW",
a);console.log("AI COOKIE DATA:");for(var d in a){for(var h in a[d])"x"==h?(c=new Date,c=a[d][h]-Math.round(c.getTime()/1E3),console.log("  BLOCK",d,"closed for",c,"s = ",Math.round(1E4*c/3600/24)/1E4,"days")):"d"==h?console.log("  BLOCK",d,"delayed for",a[d][h],"pageviews"):"e"==h?console.log("  BLOCK",d,"show every",a[d][h],"pageviews"):"i"==h?(e=a[d][h],0<=e?console.log("  BLOCK",d,a[d][h],"impressions until limit"):(c=new Date,c=-e-Math.round(c.getTime()/1E3),console.log("  BLOCK",d,"max impressions, closed for",
c,"s =",Math.round(1E4*c/3600/24)/1E4,"days"))):"ipt"==h?console.log("  BLOCK",d,a[d][h],"impressions until limit per time period"):"it"==h?(c=new Date,c=a[d][h]-Math.round(c.getTime()/1E3),console.log("  BLOCK",d,"impressions limit expiration in",c,"s =",Math.round(1E4*c/3600/24)/1E4,"days")):"c"==h?(e=a[d][h],0<=e?console.log("  BLOCK",d,e,"clicks until limit"):(c=new Date,c=-e-Math.round(c.getTime()/1E3),console.log("  BLOCK",d,"max clicks, closed for",c,"s =",Math.round(1E4*c/3600/24)/1E4,"days"))):
"cpt"==h?console.log("  BLOCK",d,a[d][h],"clicks until limit per time period"):"ct"==h?(c=new Date,c=a[d][h]-Math.round(c.getTime()/1E3),console.log("  BLOCK",d,"clicks limit expiration in ",c,"s =",Math.round(1E4*c/3600/24)/1E4,"days")):"h"==h?console.log("  BLOCK",d,"hash",a[d][h]):console.log("      ?:",d,":",h,a[d][h]);console.log("")}}else console.log("AI COOKIE NOT PRESENT");return g};ai_get_cookie_text=function(a){var f=m(AiCookies.get("aiBLOCKS"));null==f&&(f={});var b="";f.hasOwnProperty("G")&&
(b="G["+JSON.stringify(f.G).replace(/"/g,"").replace("{","").replace("}","")+"] ");var c="";f.hasOwnProperty(a)&&(c=JSON.stringify(f[a]).replace(/"/g,"").replace("{","").replace("}",""));return b+c}};
var ai_rotation_triggers=[],ai_block_class_def="code-block";
if("undefined"!=typeof ai_rotation_triggers){ai_process_rotation=function(b){var d="number"==typeof b.length;window.jQuery&&window.jQuery.fn&&b instanceof jQuery&&(b=d?Array.prototype.slice.call(b):b[0]);if(d){var e=!1;b.forEach((c,h)=>{if(c.classList.contains("ai-unprocessed")||c.classList.contains("ai-timer"))e=!0});if(!e)return;b.forEach((c,h)=>{c.classList.remove("ai-unprocessed");c.classList.remove("ai-timer")})}else{if(!b.classList.contains("ai-unprocessed")&&!b.classList.contains("ai-timer"))return;
b.classList.remove("ai-unprocessed");b.classList.remove("ai-timer")}var a=!1;if(d?b[0].hasAttribute("data-info"):b.hasAttribute("data-info")){var f="div.ai-rotate.ai-"+(d?JSON.parse(atob(b[0].dataset.info)):JSON.parse(atob(b.dataset.info)))[0];ai_rotation_triggers.includes(f)&&(ai_rotation_triggers.splice(ai_rotation_triggers.indexOf(f),1),a=!0)}if(d)for(d=0;d<b.length;d++)0==d?ai_process_single_rotation(b[d],!0):ai_process_single_rotation(b[d],!1);else ai_process_single_rotation(b,!a)};ai_process_single_rotation=
function(b,d){var e=[];Array.from(b.children).forEach((g,p)=>{g.matches(".ai-rotate-option")&&e.push(g)});if(0!=e.length){e.forEach((g,p)=>{g.style.display="none"});if(b.hasAttribute("data-next")){k=parseInt(b.getAttribute("data-next"));var a=e[k];if(a.hasAttribute("data-code")){var f=document.createRange(),c=!0;try{var h=f.createContextualFragment(b64d(a.dataset.code))}catch(g){c=!1}c&&(a=h)}0!=a.querySelectorAll("span[data-ai-groups]").length&&0!=document.querySelectorAll(".ai-rotation-groups").length&&
setTimeout(function(){B()},5)}else if(e[0].hasAttribute("data-group")){var k=-1,u=[];document.querySelectorAll("span[data-ai-groups]").forEach((g,p)=>{(g.offsetWidth||g.offsetHeight||g.getClientRects().length)&&u.push(g)});1<=u.length&&(timed_groups=[],groups=[],u.forEach(function(g,p){active_groups=JSON.parse(b64d(g.dataset.aiGroups));var r=!1;g=g.closest(".ai-rotate");null!=g&&g.classList.contains("ai-timed-rotation")&&(r=!0);active_groups.forEach(function(t,v){groups.push(t);r&&timed_groups.push(t)})}),
groups.forEach(function(g,p){-1==k&&e.forEach((r,t)=>{var v=b64d(r.dataset.group);option_group_items=v.split(",");option_group_items.forEach(function(C,E){-1==k&&C.trim()==g&&(k=t,timed_groups.includes(v)&&b.classList.add("ai-timed-rotation"))})})}))}else if(b.hasAttribute("data-shares"))for(f=JSON.parse(atob(b.dataset.shares)),a=Math.round(100*Math.random()),c=0;c<f.length&&(k=c,0>f[c]||!(a<=f[c]));c++);else f=b.classList.contains("ai-unique"),a=new Date,f?("number"!=typeof ai_rotation_seed&&(ai_rotation_seed=
(Math.floor(1E3*Math.random())+a.getMilliseconds())%e.length),f=ai_rotation_seed,f>e.length&&(f%=e.length),a=parseInt(b.dataset.counter),a<=e.length?(k=parseInt(f+a-1),k>=e.length&&(k-=e.length)):k=e.length):(k=Math.floor(Math.random()*e.length),a.getMilliseconds()%2&&(k=e.length-k-1));if(b.classList.contains("ai-rotation-scheduling"))for(k=-1,f=0;f<e.length;f++)if(a=e[f],a.hasAttribute("data-scheduling")){c=b64d(a.dataset.scheduling);a=!0;0==c.indexOf("^")&&(a=!1,c=c.substring(1));var q=c.split("="),
m=-1!=c.indexOf("%")?q[0].split("%"):[q[0]];c=m[0].trim().toLowerCase();m="undefined"!=typeof m[1]?m[1].trim():0;q=q[1].replace(" ","");var n=(new Date).getTime();n=new Date(n);var l=0;switch(c){case "s":l=n.getSeconds();break;case "i":l=n.getMinutes();break;case "h":l=n.getHours();break;case "d":l=n.getDate();break;case "m":l=n.getMonth();break;case "y":l=n.getFullYear();break;case "w":l=n.getDay(),l=0==l?6:l-1}c=0!=m?l%m:l;m=q.split(",");q=!a;for(n=0;n<m.length;n++)if(l=m[n],-1!=l.indexOf("-")){if(l=
l.split("-"),c>=l[0]&&c<=l[1]){q=a;break}}else if(c==l){q=a;break}if(q){k=f;break}}if(!(0>k||k>=e.length)){a=e[k];var z="",w=b.classList.contains("ai-timed-rotation");e.forEach((g,p)=>{g.hasAttribute("data-time")&&(w=!0)});if(a.hasAttribute("data-time")){f=atob(a.dataset.time);if(0==f&&1<e.length){c=k;do{c++;c>=e.length&&(c=0);m=e[c];if(!m.hasAttribute("data-time")){k=c;a=e[k];f=0;break}m=atob(m.dataset.time)}while(0==m&&c!=k);0!=f&&(k=c,a=e[k],f=atob(a.dataset.time))}if(0<f&&(c=k+1,c>=e.length&&
(c=0),b.hasAttribute("data-info"))){m=JSON.parse(atob(b.dataset.info))[0];b.setAttribute("data-next",c);var x="div.ai-rotate.ai-"+m;ai_rotation_triggers.includes(x)&&(d=!1);d&&(ai_rotation_triggers.push(x),setTimeout(function(){var g=document.querySelectorAll(x);g.forEach((p,r)=>{p.classList.add("ai-timer")});ai_process_rotation(g)},1E3*f));z=" ("+f+" s)"}}else a.hasAttribute("data-group")||e.forEach((g,p)=>{p!=k&&g.remove()});a.style.display="";a.style.visibility="";a.style.position="";a.style.width=
"";a.style.height="";a.style.top="";a.style.left="";a.classList.remove("ai-rotate-hidden");a.classList.remove("ai-rotate-hidden-2");b.style.position="";if(a.hasAttribute("data-code")){e.forEach((g,p)=>{g.innerText=""});d=b64d(a.dataset.code);f=document.createRange();c=!0;try{h=f.createContextualFragment(d)}catch(g){c=!1}a.append(h);D()}f=parseInt(a.dataset.index);var y=b64d(a.dataset.name);d=b.closest(".ai-debug-block");if(null!=d){h=d.querySelectorAll("kbd.ai-option-name");d=d.querySelectorAll(".ai-debug-block");
if(0!=d.length){var A=[];d.forEach((g,p)=>{g.querySelectorAll("kbd.ai-option-name").forEach((r,t)=>{A.push(r)})});h=Array.from(h);h=h.slice(0,h.length-A.length)}0!=h.length&&(separator=h[0].hasAttribute("data-separator")?h[0].dataset.separator:"",h.forEach((g,p)=>{g.innerText=separator+y+z}))}d=!1;a=b.closest(".ai-adb-show");null!=a&&a.hasAttribute("data-ai-tracking")&&(h=JSON.parse(b64d(a.getAttribute("data-ai-tracking"))),"undefined"!==typeof h&&h.constructor===Array&&(h[1]=f,h[3]=y,a.setAttribute("data-ai-tracking",
b64e(JSON.stringify(h))),a.classList.add("ai-track"),w&&ai_tracking_finished&&a.classList.add("ai-no-pageview"),d=!0));d||(d=b.closest("div[data-ai]"),null!=d&&d.hasAttribute("data-ai")&&(h=JSON.parse(b64d(d.getAttribute("data-ai"))),"undefined"!==typeof h&&h.constructor===Array&&(h[1]=f,h[3]=y,d.setAttribute("data-ai",b64e(JSON.stringify(h))),d.classList.add("ai-track"),w&&ai_tracking_finished&&d.classList.add("ai-no-pageview"))))}}};ai_process_rotations=function(){document.querySelectorAll("div.ai-rotate").forEach((b,
d)=>{ai_process_rotation(b)})};function B(){document.querySelectorAll("div.ai-rotate.ai-rotation-groups").forEach((b,d)=>{b.classList.add("ai-timer");ai_process_rotation(b)})}ai_process_rotations_in_element=function(b){null!=b&&b.querySelectorAll("div.ai-rotate").forEach((d,e)=>{ai_process_rotation(d)})};(function(b){"complete"===document.readyState||"loading"!==document.readyState&&!document.documentElement.doScroll?b():document.addEventListener("DOMContentLoaded",b)})(function(){setTimeout(function(){ai_process_rotations()},
10)});ai_process_elements_active=!1;function D(){ai_process_elements_active||setTimeout(function(){ai_process_elements_active=!1;"function"==typeof ai_process_rotations&&ai_process_rotations();"function"==typeof ai_process_lists&&ai_process_lists();"function"==typeof ai_process_ip_addresses&&ai_process_ip_addresses();"function"==typeof ai_process_filter_hooks&&ai_process_filter_hooks();"function"==typeof ai_adb_process_blocks&&ai_adb_process_blocks();"function"==typeof ai_process_impressions&&1==
ai_tracking_finished&&ai_process_impressions();"function"==typeof ai_install_click_trackers&&1==ai_tracking_finished&&ai_install_click_trackers();"function"==typeof ai_install_close_buttons&&ai_install_close_buttons(document)},5);ai_process_elements_active=!0}};
;!function(a,b){a(function(){"use strict";function a(a,b){return null!=a&&null!=b&&a.toLowerCase()===b.toLowerCase()}function c(a,b){var c,d,e=a.length;if(!e||!b)return!1;for(c=b.toLowerCase(),d=0;d<e;++d)if(c===a[d].toLowerCase())return!0;return!1}function d(a){for(var b in a)i.call(a,b)&&(a[b]=new RegExp(a[b],"i"))}function e(a){return(a||"").substr(0,500)}function f(a,b){this.ua=e(a),this._cache={},this.maxPhoneWidth=b||600}var g={};g.mobileDetectRules={phones:{iPhone:"\\biPhone\\b|\\biPod\\b",BlackBerry:"BlackBerry|\\bBB10\\b|rim[0-9]+|\\b(BBA100|BBB100|BBD100|BBE100|BBF100|STH100)\\b-[0-9]+",Pixel:"; \\bPixel\\b",HTC:"HTC|HTC.*(Sensation|Evo|Vision|Explorer|6800|8100|8900|A7272|S510e|C110e|Legend|Desire|T8282)|APX515CKT|Qtek9090|APA9292KT|HD_mini|Sensation.*Z710e|PG86100|Z715e|Desire.*(A8181|HD)|ADR6200|ADR6400L|ADR6425|001HT|Inspire 4G|Android.*\\bEVO\\b|T-Mobile G1|Z520m|Android [0-9.]+; Pixel",Nexus:"Nexus One|Nexus S|Galaxy.*Nexus|Android.*Nexus.*Mobile|Nexus 4|Nexus 5|Nexus 5X|Nexus 6",Dell:"Dell[;]? (Streak|Aero|Venue|Venue Pro|Flash|Smoke|Mini 3iX)|XCD28|XCD35|\\b001DL\\b|\\b101DL\\b|\\bGS01\\b",Motorola:"Motorola|DROIDX|DROID BIONIC|\\bDroid\\b.*Build|Android.*Xoom|HRI39|MOT-|A1260|A1680|A555|A853|A855|A953|A955|A956|Motorola.*ELECTRIFY|Motorola.*i1|i867|i940|MB200|MB300|MB501|MB502|MB508|MB511|MB520|MB525|MB526|MB611|MB612|MB632|MB810|MB855|MB860|MB861|MB865|MB870|ME501|ME502|ME511|ME525|ME600|ME632|ME722|ME811|ME860|ME863|ME865|MT620|MT710|MT716|MT720|MT810|MT870|MT917|Motorola.*TITANIUM|WX435|WX445|XT300|XT301|XT311|XT316|XT317|XT319|XT320|XT390|XT502|XT530|XT531|XT532|XT535|XT603|XT610|XT611|XT615|XT681|XT701|XT702|XT711|XT720|XT800|XT806|XT860|XT862|XT875|XT882|XT883|XT894|XT901|XT907|XT909|XT910|XT912|XT928|XT926|XT915|XT919|XT925|XT1021|\\bMoto E\\b|XT1068|XT1092|XT1052",Samsung:"\\bSamsung\\b|SM-G950F|SM-G955F|SM-G9250|GT-19300|SGH-I337|BGT-S5230|GT-B2100|GT-B2700|GT-B2710|GT-B3210|GT-B3310|GT-B3410|GT-B3730|GT-B3740|GT-B5510|GT-B5512|GT-B5722|GT-B6520|GT-B7300|GT-B7320|GT-B7330|GT-B7350|GT-B7510|GT-B7722|GT-B7800|GT-C3010|GT-C3011|GT-C3060|GT-C3200|GT-C3212|GT-C3212I|GT-C3262|GT-C3222|GT-C3300|GT-C3300K|GT-C3303|GT-C3303K|GT-C3310|GT-C3322|GT-C3330|GT-C3350|GT-C3500|GT-C3510|GT-C3530|GT-C3630|GT-C3780|GT-C5010|GT-C5212|GT-C6620|GT-C6625|GT-C6712|GT-E1050|GT-E1070|GT-E1075|GT-E1080|GT-E1081|GT-E1085|GT-E1087|GT-E1100|GT-E1107|GT-E1110|GT-E1120|GT-E1125|GT-E1130|GT-E1160|GT-E1170|GT-E1175|GT-E1180|GT-E1182|GT-E1200|GT-E1210|GT-E1225|GT-E1230|GT-E1390|GT-E2100|GT-E2120|GT-E2121|GT-E2152|GT-E2220|GT-E2222|GT-E2230|GT-E2232|GT-E2250|GT-E2370|GT-E2550|GT-E2652|GT-E3210|GT-E3213|GT-I5500|GT-I5503|GT-I5700|GT-I5800|GT-I5801|GT-I6410|GT-I6420|GT-I7110|GT-I7410|GT-I7500|GT-I8000|GT-I8150|GT-I8160|GT-I8190|GT-I8320|GT-I8330|GT-I8350|GT-I8530|GT-I8700|GT-I8703|GT-I8910|GT-I9000|GT-I9001|GT-I9003|GT-I9010|GT-I9020|GT-I9023|GT-I9070|GT-I9082|GT-I9100|GT-I9103|GT-I9220|GT-I9250|GT-I9300|GT-I9305|GT-I9500|GT-I9505|GT-M3510|GT-M5650|GT-M7500|GT-M7600|GT-M7603|GT-M8800|GT-M8910|GT-N7000|GT-S3110|GT-S3310|GT-S3350|GT-S3353|GT-S3370|GT-S3650|GT-S3653|GT-S3770|GT-S3850|GT-S5210|GT-S5220|GT-S5229|GT-S5230|GT-S5233|GT-S5250|GT-S5253|GT-S5260|GT-S5263|GT-S5270|GT-S5300|GT-S5330|GT-S5350|GT-S5360|GT-S5363|GT-S5369|GT-S5380|GT-S5380D|GT-S5560|GT-S5570|GT-S5600|GT-S5603|GT-S5610|GT-S5620|GT-S5660|GT-S5670|GT-S5690|GT-S5750|GT-S5780|GT-S5830|GT-S5839|GT-S6102|GT-S6500|GT-S7070|GT-S7200|GT-S7220|GT-S7230|GT-S7233|GT-S7250|GT-S7500|GT-S7530|GT-S7550|GT-S7562|GT-S7710|GT-S8000|GT-S8003|GT-S8500|GT-S8530|GT-S8600|SCH-A310|SCH-A530|SCH-A570|SCH-A610|SCH-A630|SCH-A650|SCH-A790|SCH-A795|SCH-A850|SCH-A870|SCH-A890|SCH-A930|SCH-A950|SCH-A970|SCH-A990|SCH-I100|SCH-I110|SCH-I400|SCH-I405|SCH-I500|SCH-I510|SCH-I515|SCH-I600|SCH-I730|SCH-I760|SCH-I770|SCH-I830|SCH-I910|SCH-I920|SCH-I959|SCH-LC11|SCH-N150|SCH-N300|SCH-R100|SCH-R300|SCH-R351|SCH-R400|SCH-R410|SCH-T300|SCH-U310|SCH-U320|SCH-U350|SCH-U360|SCH-U365|SCH-U370|SCH-U380|SCH-U410|SCH-U430|SCH-U450|SCH-U460|SCH-U470|SCH-U490|SCH-U540|SCH-U550|SCH-U620|SCH-U640|SCH-U650|SCH-U660|SCH-U700|SCH-U740|SCH-U750|SCH-U810|SCH-U820|SCH-U900|SCH-U940|SCH-U960|SCS-26UC|SGH-A107|SGH-A117|SGH-A127|SGH-A137|SGH-A157|SGH-A167|SGH-A177|SGH-A187|SGH-A197|SGH-A227|SGH-A237|SGH-A257|SGH-A437|SGH-A517|SGH-A597|SGH-A637|SGH-A657|SGH-A667|SGH-A687|SGH-A697|SGH-A707|SGH-A717|SGH-A727|SGH-A737|SGH-A747|SGH-A767|SGH-A777|SGH-A797|SGH-A817|SGH-A827|SGH-A837|SGH-A847|SGH-A867|SGH-A877|SGH-A887|SGH-A897|SGH-A927|SGH-B100|SGH-B130|SGH-B200|SGH-B220|SGH-C100|SGH-C110|SGH-C120|SGH-C130|SGH-C140|SGH-C160|SGH-C170|SGH-C180|SGH-C200|SGH-C207|SGH-C210|SGH-C225|SGH-C230|SGH-C417|SGH-C450|SGH-D307|SGH-D347|SGH-D357|SGH-D407|SGH-D415|SGH-D780|SGH-D807|SGH-D980|SGH-E105|SGH-E200|SGH-E315|SGH-E316|SGH-E317|SGH-E335|SGH-E590|SGH-E635|SGH-E715|SGH-E890|SGH-F300|SGH-F480|SGH-I200|SGH-I300|SGH-I320|SGH-I550|SGH-I577|SGH-I600|SGH-I607|SGH-I617|SGH-I627|SGH-I637|SGH-I677|SGH-I700|SGH-I717|SGH-I727|SGH-i747M|SGH-I777|SGH-I780|SGH-I827|SGH-I847|SGH-I857|SGH-I896|SGH-I897|SGH-I900|SGH-I907|SGH-I917|SGH-I927|SGH-I937|SGH-I997|SGH-J150|SGH-J200|SGH-L170|SGH-L700|SGH-M110|SGH-M150|SGH-M200|SGH-N105|SGH-N500|SGH-N600|SGH-N620|SGH-N625|SGH-N700|SGH-N710|SGH-P107|SGH-P207|SGH-P300|SGH-P310|SGH-P520|SGH-P735|SGH-P777|SGH-Q105|SGH-R210|SGH-R220|SGH-R225|SGH-S105|SGH-S307|SGH-T109|SGH-T119|SGH-T139|SGH-T209|SGH-T219|SGH-T229|SGH-T239|SGH-T249|SGH-T259|SGH-T309|SGH-T319|SGH-T329|SGH-T339|SGH-T349|SGH-T359|SGH-T369|SGH-T379|SGH-T409|SGH-T429|SGH-T439|SGH-T459|SGH-T469|SGH-T479|SGH-T499|SGH-T509|SGH-T519|SGH-T539|SGH-T559|SGH-T589|SGH-T609|SGH-T619|SGH-T629|SGH-T639|SGH-T659|SGH-T669|SGH-T679|SGH-T709|SGH-T719|SGH-T729|SGH-T739|SGH-T746|SGH-T749|SGH-T759|SGH-T769|SGH-T809|SGH-T819|SGH-T839|SGH-T919|SGH-T929|SGH-T939|SGH-T959|SGH-T989|SGH-U100|SGH-U200|SGH-U800|SGH-V205|SGH-V206|SGH-X100|SGH-X105|SGH-X120|SGH-X140|SGH-X426|SGH-X427|SGH-X475|SGH-X495|SGH-X497|SGH-X507|SGH-X600|SGH-X610|SGH-X620|SGH-X630|SGH-X700|SGH-X820|SGH-X890|SGH-Z130|SGH-Z150|SGH-Z170|SGH-ZX10|SGH-ZX20|SHW-M110|SPH-A120|SPH-A400|SPH-A420|SPH-A460|SPH-A500|SPH-A560|SPH-A600|SPH-A620|SPH-A660|SPH-A700|SPH-A740|SPH-A760|SPH-A790|SPH-A800|SPH-A820|SPH-A840|SPH-A880|SPH-A900|SPH-A940|SPH-A960|SPH-D600|SPH-D700|SPH-D710|SPH-D720|SPH-I300|SPH-I325|SPH-I330|SPH-I350|SPH-I500|SPH-I600|SPH-I700|SPH-L700|SPH-M100|SPH-M220|SPH-M240|SPH-M300|SPH-M305|SPH-M320|SPH-M330|SPH-M350|SPH-M360|SPH-M370|SPH-M380|SPH-M510|SPH-M540|SPH-M550|SPH-M560|SPH-M570|SPH-M580|SPH-M610|SPH-M620|SPH-M630|SPH-M800|SPH-M810|SPH-M850|SPH-M900|SPH-M910|SPH-M920|SPH-M930|SPH-N100|SPH-N200|SPH-N240|SPH-N300|SPH-N400|SPH-Z400|SWC-E100|SCH-i909|GT-N7100|GT-N7105|SCH-I535|SM-N900A|SGH-I317|SGH-T999L|GT-S5360B|GT-I8262|GT-S6802|GT-S6312|GT-S6310|GT-S5312|GT-S5310|GT-I9105|GT-I8510|GT-S6790N|SM-G7105|SM-N9005|GT-S5301|GT-I9295|GT-I9195|SM-C101|GT-S7392|GT-S7560|GT-B7610|GT-I5510|GT-S7582|GT-S7530E|GT-I8750|SM-G9006V|SM-G9008V|SM-G9009D|SM-G900A|SM-G900D|SM-G900F|SM-G900H|SM-G900I|SM-G900J|SM-G900K|SM-G900L|SM-G900M|SM-G900P|SM-G900R4|SM-G900S|SM-G900T|SM-G900V|SM-G900W8|SHV-E160K|SCH-P709|SCH-P729|SM-T2558|GT-I9205|SM-G9350|SM-J120F|SM-G920F|SM-G920V|SM-G930F|SM-N910C|SM-A310F|GT-I9190|SM-J500FN|SM-G903F|SM-J330F|SM-G610F|SM-G981B|SM-G892A|SM-A530F",LG:"\\bLG\\b;|LG[- ]?(C800|C900|E400|E610|E900|E-900|F160|F180K|F180L|F180S|730|855|L160|LS740|LS840|LS970|LU6200|MS690|MS695|MS770|MS840|MS870|MS910|P500|P700|P705|VM696|AS680|AS695|AX840|C729|E970|GS505|272|C395|E739BK|E960|L55C|L75C|LS696|LS860|P769BK|P350|P500|P509|P870|UN272|US730|VS840|VS950|LN272|LN510|LS670|LS855|LW690|MN270|MN510|P509|P769|P930|UN200|UN270|UN510|UN610|US670|US740|US760|UX265|UX840|VN271|VN530|VS660|VS700|VS740|VS750|VS910|VS920|VS930|VX9200|VX11000|AX840A|LW770|P506|P925|P999|E612|D955|D802|MS323|M257)|LM-G710",Sony:"SonyST|SonyLT|SonyEricsson|SonyEricssonLT15iv|LT18i|E10i|LT28h|LT26w|SonyEricssonMT27i|C5303|C6902|C6903|C6906|C6943|D2533|SOV34|601SO|F8332",Asus:"Asus.*Galaxy|PadFone.*Mobile",Xiaomi:"^(?!.*\\bx11\\b).*xiaomi.*$|POCOPHONE F1|MI 8|Redmi Note 9S|Redmi Note 5A Prime|N2G47H|M2001J2G|M2001J2I|M1805E10A|M2004J11G|M1902F1G|M2002J9G|M2004J19G|M2003J6A1G",NokiaLumia:"Lumia [0-9]{3,4}",Micromax:"Micromax.*\\b(A210|A92|A88|A72|A111|A110Q|A115|A116|A110|A90S|A26|A51|A35|A54|A25|A27|A89|A68|A65|A57|A90)\\b",Palm:"PalmSource|Palm",Vertu:"Vertu|Vertu.*Ltd|Vertu.*Ascent|Vertu.*Ayxta|Vertu.*Constellation(F|Quest)?|Vertu.*Monika|Vertu.*Signature",Pantech:"PANTECH|IM-A850S|IM-A840S|IM-A830L|IM-A830K|IM-A830S|IM-A820L|IM-A810K|IM-A810S|IM-A800S|IM-T100K|IM-A725L|IM-A780L|IM-A775C|IM-A770K|IM-A760S|IM-A750K|IM-A740S|IM-A730S|IM-A720L|IM-A710K|IM-A690L|IM-A690S|IM-A650S|IM-A630K|IM-A600S|VEGA PTL21|PT003|P8010|ADR910L|P6030|P6020|P9070|P4100|P9060|P5000|CDM8992|TXT8045|ADR8995|IS11PT|P2030|P6010|P8000|PT002|IS06|CDM8999|P9050|PT001|TXT8040|P2020|P9020|P2000|P7040|P7000|C790",Fly:"IQ230|IQ444|IQ450|IQ440|IQ442|IQ441|IQ245|IQ256|IQ236|IQ255|IQ235|IQ245|IQ275|IQ240|IQ285|IQ280|IQ270|IQ260|IQ250",Wiko:"KITE 4G|HIGHWAY|GETAWAY|STAIRWAY|DARKSIDE|DARKFULL|DARKNIGHT|DARKMOON|SLIDE|WAX 4G|RAINBOW|BLOOM|SUNSET|GOA(?!nna)|LENNY|BARRY|IGGY|OZZY|CINK FIVE|CINK PEAX|CINK PEAX 2|CINK SLIM|CINK SLIM 2|CINK +|CINK KING|CINK PEAX|CINK SLIM|SUBLIM",iMobile:"i-mobile (IQ|i-STYLE|idea|ZAA|Hitz)",SimValley:"\\b(SP-80|XT-930|SX-340|XT-930|SX-310|SP-360|SP60|SPT-800|SP-120|SPT-800|SP-140|SPX-5|SPX-8|SP-100|SPX-8|SPX-12)\\b",Wolfgang:"AT-B24D|AT-AS50HD|AT-AS40W|AT-AS55HD|AT-AS45q2|AT-B26D|AT-AS50Q",Alcatel:"Alcatel",Nintendo:"Nintendo (3DS|Switch)",Amoi:"Amoi",INQ:"INQ",OnePlus:"ONEPLUS",GenericPhone:"Tapatalk|PDA;|SAGEM|\\bmmp\\b|pocket|\\bpsp\\b|symbian|Smartphone|smartfon|treo|up.browser|up.link|vodafone|\\bwap\\b|nokia|Series40|Series60|S60|SonyEricsson|N900|MAUI.*WAP.*Browser"},tablets:{iPad:"iPad|iPad.*Mobile",NexusTablet:"Android.*Nexus[\\s]+(7|9|10)",GoogleTablet:"Android.*Pixel C",SamsungTablet:"SAMSUNG.*Tablet|Galaxy.*Tab|SC-01C|GT-P1000|GT-P1003|GT-P1010|GT-P3105|GT-P6210|GT-P6800|GT-P6810|GT-P7100|GT-P7300|GT-P7310|GT-P7500|GT-P7510|SCH-I800|SCH-I815|SCH-I905|SGH-I957|SGH-I987|SGH-T849|SGH-T859|SGH-T869|SPH-P100|GT-P3100|GT-P3108|GT-P3110|GT-P5100|GT-P5110|GT-P6200|GT-P7320|GT-P7511|GT-N8000|GT-P8510|SGH-I497|SPH-P500|SGH-T779|SCH-I705|SCH-I915|GT-N8013|GT-P3113|GT-P5113|GT-P8110|GT-N8010|GT-N8005|GT-N8020|GT-P1013|GT-P6201|GT-P7501|GT-N5100|GT-N5105|GT-N5110|SHV-E140K|SHV-E140L|SHV-E140S|SHV-E150S|SHV-E230K|SHV-E230L|SHV-E230S|SHW-M180K|SHW-M180L|SHW-M180S|SHW-M180W|SHW-M300W|SHW-M305W|SHW-M380K|SHW-M380S|SHW-M380W|SHW-M430W|SHW-M480K|SHW-M480S|SHW-M480W|SHW-M485W|SHW-M486W|SHW-M500W|GT-I9228|SCH-P739|SCH-I925|GT-I9200|GT-P5200|GT-P5210|GT-P5210X|SM-T311|SM-T310|SM-T310X|SM-T210|SM-T210R|SM-T211|SM-P600|SM-P601|SM-P605|SM-P900|SM-P901|SM-T217|SM-T217A|SM-T217S|SM-P6000|SM-T3100|SGH-I467|XE500|SM-T110|GT-P5220|GT-I9200X|GT-N5110X|GT-N5120|SM-P905|SM-T111|SM-T2105|SM-T315|SM-T320|SM-T320X|SM-T321|SM-T520|SM-T525|SM-T530NU|SM-T230NU|SM-T330NU|SM-T900|XE500T1C|SM-P605V|SM-P905V|SM-T337V|SM-T537V|SM-T707V|SM-T807V|SM-P600X|SM-P900X|SM-T210X|SM-T230|SM-T230X|SM-T325|GT-P7503|SM-T531|SM-T330|SM-T530|SM-T705|SM-T705C|SM-T535|SM-T331|SM-T800|SM-T700|SM-T537|SM-T807|SM-P907A|SM-T337A|SM-T537A|SM-T707A|SM-T807A|SM-T237|SM-T807P|SM-P607T|SM-T217T|SM-T337T|SM-T807T|SM-T116NQ|SM-T116BU|SM-P550|SM-T350|SM-T550|SM-T9000|SM-P9000|SM-T705Y|SM-T805|GT-P3113|SM-T710|SM-T810|SM-T815|SM-T360|SM-T533|SM-T113|SM-T335|SM-T715|SM-T560|SM-T670|SM-T677|SM-T377|SM-T567|SM-T357T|SM-T555|SM-T561|SM-T713|SM-T719|SM-T813|SM-T819|SM-T580|SM-T355Y?|SM-T280|SM-T817A|SM-T820|SM-W700|SM-P580|SM-T587|SM-P350|SM-P555M|SM-P355M|SM-T113NU|SM-T815Y|SM-T585|SM-T285|SM-T825|SM-W708|SM-T835|SM-T830|SM-T837V|SM-T720|SM-T510|SM-T387V|SM-P610|SM-T290|SM-T515|SM-T590|SM-T595|SM-T725|SM-T817P|SM-P585N0|SM-T395|SM-T295|SM-T865|SM-P610N|SM-P615|SM-T970|SM-T380|SM-T5950|SM-T905|SM-T231|SM-T500|SM-T860",Kindle:"Kindle|Silk.*Accelerated|Android.*\\b(KFOT|KFTT|KFJWI|KFJWA|KFOTE|KFSOWI|KFTHWI|KFTHWA|KFAPWI|KFAPWA|WFJWAE|KFSAWA|KFSAWI|KFASWI|KFARWI|KFFOWI|KFGIWI|KFMEWI)\\b|Android.*Silk/[0-9.]+ like Chrome/[0-9.]+ (?!Mobile)",SurfaceTablet:"Windows NT [0-9.]+; ARM;.*(Tablet|ARMBJS)",HPTablet:"HP Slate (7|8|10)|HP ElitePad 900|hp-tablet|EliteBook.*Touch|HP 8|Slate 21|HP SlateBook 10",AsusTablet:"^.*PadFone((?!Mobile).)*$|Transformer|TF101|TF101G|TF300T|TF300TG|TF300TL|TF700T|TF700KL|TF701T|TF810C|ME171|ME301T|ME302C|ME371MG|ME370T|ME372MG|ME172V|ME173X|ME400C|Slider SL101|\\bK00F\\b|\\bK00C\\b|\\bK00E\\b|\\bK00L\\b|TX201LA|ME176C|ME102A|\\bM80TA\\b|ME372CL|ME560CG|ME372CG|ME302KL| K010 | K011 | K017 | K01E |ME572C|ME103K|ME170C|ME171C|\\bME70C\\b|ME581C|ME581CL|ME8510C|ME181C|P01Y|PO1MA|P01Z|\\bP027\\b|\\bP024\\b|\\bP00C\\b",BlackBerryTablet:"PlayBook|RIM Tablet",HTCtablet:"HTC_Flyer_P512|HTC Flyer|HTC Jetstream|HTC-P715a|HTC EVO View 4G|PG41200|PG09410",MotorolaTablet:"xoom|sholest|MZ615|MZ605|MZ505|MZ601|MZ602|MZ603|MZ604|MZ606|MZ607|MZ608|MZ609|MZ615|MZ616|MZ617",NookTablet:"Android.*Nook|NookColor|nook browser|BNRV200|BNRV200A|BNTV250|BNTV250A|BNTV400|BNTV600|LogicPD Zoom2",AcerTablet:"Android.*; \\b(A100|A101|A110|A200|A210|A211|A500|A501|A510|A511|A700|A701|W500|W500P|W501|W501P|W510|W511|W700|G100|G100W|B1-A71|B1-710|B1-711|A1-810|A1-811|A1-830)\\b|W3-810|\\bA3-A10\\b|\\bA3-A11\\b|\\bA3-A20\\b|\\bA3-A30|A3-A40",ToshibaTablet:"Android.*(AT100|AT105|AT200|AT205|AT270|AT275|AT300|AT305|AT1S5|AT500|AT570|AT700|AT830)|TOSHIBA.*FOLIO",LGTablet:"\\bL-06C|LG-V909|LG-V900|LG-V700|LG-V510|LG-V500|LG-V410|LG-V400|LG-VK810\\b",FujitsuTablet:"Android.*\\b(F-01D|F-02F|F-05E|F-10D|M532|Q572)\\b",PrestigioTablet:"PMP3170B|PMP3270B|PMP3470B|PMP7170B|PMP3370B|PMP3570C|PMP5870C|PMP3670B|PMP5570C|PMP5770D|PMP3970B|PMP3870C|PMP5580C|PMP5880D|PMP5780D|PMP5588C|PMP7280C|PMP7280C3G|PMP7280|PMP7880D|PMP5597D|PMP5597|PMP7100D|PER3464|PER3274|PER3574|PER3884|PER5274|PER5474|PMP5097CPRO|PMP5097|PMP7380D|PMP5297C|PMP5297C_QUAD|PMP812E|PMP812E3G|PMP812F|PMP810E|PMP880TD|PMT3017|PMT3037|PMT3047|PMT3057|PMT7008|PMT5887|PMT5001|PMT5002",LenovoTablet:"Lenovo TAB|Idea(Tab|Pad)( A1|A10| K1|)|ThinkPad([ ]+)?Tablet|YT3-850M|YT3-X90L|YT3-X90F|YT3-X90X|Lenovo.*(S2109|S2110|S5000|S6000|K3011|A3000|A3500|A1000|A2107|A2109|A1107|A5500|A7600|B6000|B8000|B8080)(-|)(FL|F|HV|H|)|TB-X103F|TB-X304X|TB-X304F|TB-X304L|TB-X505F|TB-X505L|TB-X505X|TB-X605F|TB-X605L|TB-8703F|TB-8703X|TB-8703N|TB-8704N|TB-8704F|TB-8704X|TB-8704V|TB-7304F|TB-7304I|TB-7304X|Tab2A7-10F|Tab2A7-20F|TB2-X30L|YT3-X50L|YT3-X50F|YT3-X50M|YT-X705F|YT-X703F|YT-X703L|YT-X705L|YT-X705X|TB2-X30F|TB2-X30L|TB2-X30M|A2107A-F|A2107A-H|TB3-730F|TB3-730M|TB3-730X|TB-7504F|TB-7504X|TB-X704F|TB-X104F|TB3-X70F|TB-X705F|TB-8504F|TB3-X70L|TB3-710F|TB-X704L",DellTablet:"Venue 11|Venue 8|Venue 7|Dell Streak 10|Dell Streak 7",YarvikTablet:"Android.*\\b(TAB210|TAB211|TAB224|TAB250|TAB260|TAB264|TAB310|TAB360|TAB364|TAB410|TAB411|TAB420|TAB424|TAB450|TAB460|TAB461|TAB464|TAB465|TAB467|TAB468|TAB07-100|TAB07-101|TAB07-150|TAB07-151|TAB07-152|TAB07-200|TAB07-201-3G|TAB07-210|TAB07-211|TAB07-212|TAB07-214|TAB07-220|TAB07-400|TAB07-485|TAB08-150|TAB08-200|TAB08-201-3G|TAB08-201-30|TAB09-100|TAB09-211|TAB09-410|TAB10-150|TAB10-201|TAB10-211|TAB10-400|TAB10-410|TAB13-201|TAB274EUK|TAB275EUK|TAB374EUK|TAB462EUK|TAB474EUK|TAB9-200)\\b",MedionTablet:"Android.*\\bOYO\\b|LIFE.*(P9212|P9514|P9516|S9512)|LIFETAB",ArnovaTablet:"97G4|AN10G2|AN7bG3|AN7fG3|AN8G3|AN8cG3|AN7G3|AN9G3|AN7dG3|AN7dG3ST|AN7dG3ChildPad|AN10bG3|AN10bG3DT|AN9G2",IntensoTablet:"INM8002KP|INM1010FP|INM805ND|Intenso Tab|TAB1004",IRUTablet:"M702pro",MegafonTablet:"MegaFon V9|\\bZTE V9\\b|Android.*\\bMT7A\\b",EbodaTablet:"E-Boda (Supreme|Impresspeed|Izzycomm|Essential)",AllViewTablet:"Allview.*(Viva|Alldro|City|Speed|All TV|Frenzy|Quasar|Shine|TX1|AX1|AX2)",ArchosTablet:"\\b(101G9|80G9|A101IT)\\b|Qilive 97R|Archos5|\\bARCHOS (70|79|80|90|97|101|FAMILYPAD|)(b|c|)(G10| Cobalt| TITANIUM(HD|)| Xenon| Neon|XSK| 2| XS 2| PLATINUM| CARBON|GAMEPAD)\\b",AinolTablet:"NOVO7|NOVO8|NOVO10|Novo7Aurora|Novo7Basic|NOVO7PALADIN|novo9-Spark",NokiaLumiaTablet:"Lumia 2520",SonyTablet:"Sony.*Tablet|Xperia Tablet|Sony Tablet S|SO-03E|SGPT12|SGPT13|SGPT114|SGPT121|SGPT122|SGPT123|SGPT111|SGPT112|SGPT113|SGPT131|SGPT132|SGPT133|SGPT211|SGPT212|SGPT213|SGP311|SGP312|SGP321|EBRD1101|EBRD1102|EBRD1201|SGP351|SGP341|SGP511|SGP512|SGP521|SGP541|SGP551|SGP621|SGP641|SGP612|SOT31|SGP771|SGP611|SGP612|SGP712",PhilipsTablet:"\\b(PI2010|PI3000|PI3100|PI3105|PI3110|PI3205|PI3210|PI3900|PI4010|PI7000|PI7100)\\b",CubeTablet:"Android.*(K8GT|U9GT|U10GT|U16GT|U17GT|U18GT|U19GT|U20GT|U23GT|U30GT)|CUBE U8GT",CobyTablet:"MID1042|MID1045|MID1125|MID1126|MID7012|MID7014|MID7015|MID7034|MID7035|MID7036|MID7042|MID7048|MID7127|MID8042|MID8048|MID8127|MID9042|MID9740|MID9742|MID7022|MID7010",MIDTablet:"M9701|M9000|M9100|M806|M1052|M806|T703|MID701|MID713|MID710|MID727|MID760|MID830|MID728|MID933|MID125|MID810|MID732|MID120|MID930|MID800|MID731|MID900|MID100|MID820|MID735|MID980|MID130|MID833|MID737|MID960|MID135|MID860|MID736|MID140|MID930|MID835|MID733|MID4X10",MSITablet:"MSI \\b(Primo 73K|Primo 73L|Primo 81L|Primo 77|Primo 93|Primo 75|Primo 76|Primo 73|Primo 81|Primo 91|Primo 90|Enjoy 71|Enjoy 7|Enjoy 10)\\b",SMiTTablet:"Android.*(\\bMID\\b|MID-560|MTV-T1200|MTV-PND531|MTV-P1101|MTV-PND530)",RockChipTablet:"Android.*(RK2818|RK2808A|RK2918|RK3066)|RK2738|RK2808A",FlyTablet:"IQ310|Fly Vision",bqTablet:"Android.*(bq)?.*\\b(Elcano|Curie|Edison|Maxwell|Kepler|Pascal|Tesla|Hypatia|Platon|Newton|Livingstone|Cervantes|Avant|Aquaris ([E|M]10|M8))\\b|Maxwell.*Lite|Maxwell.*Plus",HuaweiTablet:"MediaPad|MediaPad 7 Youth|IDEOS S7|S7-201c|S7-202u|S7-101|S7-103|S7-104|S7-105|S7-106|S7-201|S7-Slim|M2-A01L|BAH-L09|BAH-W09|AGS-L09|CMR-AL19",NecTablet:"\\bN-06D|\\bN-08D",PantechTablet:"Pantech.*P4100",BronchoTablet:"Broncho.*(N701|N708|N802|a710)",VersusTablet:"TOUCHPAD.*[78910]|\\bTOUCHTAB\\b",ZyncTablet:"z1000|Z99 2G|z930|z990|z909|Z919|z900",PositivoTablet:"TB07STA|TB10STA|TB07FTA|TB10FTA",NabiTablet:"Android.*\\bNabi",KoboTablet:"Kobo Touch|\\bK080\\b|\\bVox\\b Build|\\bArc\\b Build",DanewTablet:"DSlide.*\\b(700|701R|702|703R|704|802|970|971|972|973|974|1010|1012)\\b",TexetTablet:"NaviPad|TB-772A|TM-7045|TM-7055|TM-9750|TM-7016|TM-7024|TM-7026|TM-7041|TM-7043|TM-7047|TM-8041|TM-9741|TM-9747|TM-9748|TM-9751|TM-7022|TM-7021|TM-7020|TM-7011|TM-7010|TM-7023|TM-7025|TM-7037W|TM-7038W|TM-7027W|TM-9720|TM-9725|TM-9737W|TM-1020|TM-9738W|TM-9740|TM-9743W|TB-807A|TB-771A|TB-727A|TB-725A|TB-719A|TB-823A|TB-805A|TB-723A|TB-715A|TB-707A|TB-705A|TB-709A|TB-711A|TB-890HD|TB-880HD|TB-790HD|TB-780HD|TB-770HD|TB-721HD|TB-710HD|TB-434HD|TB-860HD|TB-840HD|TB-760HD|TB-750HD|TB-740HD|TB-730HD|TB-722HD|TB-720HD|TB-700HD|TB-500HD|TB-470HD|TB-431HD|TB-430HD|TB-506|TB-504|TB-446|TB-436|TB-416|TB-146SE|TB-126SE",PlaystationTablet:"Playstation.*(Portable|Vita)",TrekstorTablet:"ST10416-1|VT10416-1|ST70408-1|ST702xx-1|ST702xx-2|ST80208|ST97216|ST70104-2|VT10416-2|ST10216-2A|SurfTab",PyleAudioTablet:"\\b(PTBL10CEU|PTBL10C|PTBL72BC|PTBL72BCEU|PTBL7CEU|PTBL7C|PTBL92BC|PTBL92BCEU|PTBL9CEU|PTBL9CUK|PTBL9C)\\b",AdvanTablet:"Android.* \\b(E3A|T3X|T5C|T5B|T3E|T3C|T3B|T1J|T1F|T2A|T1H|T1i|E1C|T1-E|T5-A|T4|E1-B|T2Ci|T1-B|T1-D|O1-A|E1-A|T1-A|T3A|T4i)\\b ",DanyTechTablet:"Genius Tab G3|Genius Tab S2|Genius Tab Q3|Genius Tab G4|Genius Tab Q4|Genius Tab G-II|Genius TAB GII|Genius TAB GIII|Genius Tab S1",GalapadTablet:"Android [0-9.]+; [a-z-]+; \\bG1\\b",MicromaxTablet:"Funbook|Micromax.*\\b(P250|P560|P360|P362|P600|P300|P350|P500|P275)\\b",KarbonnTablet:"Android.*\\b(A39|A37|A34|ST8|ST10|ST7|Smart Tab3|Smart Tab2)\\b",AllFineTablet:"Fine7 Genius|Fine7 Shine|Fine7 Air|Fine8 Style|Fine9 More|Fine10 Joy|Fine11 Wide",PROSCANTablet:"\\b(PEM63|PLT1023G|PLT1041|PLT1044|PLT1044G|PLT1091|PLT4311|PLT4311PL|PLT4315|PLT7030|PLT7033|PLT7033D|PLT7035|PLT7035D|PLT7044K|PLT7045K|PLT7045KB|PLT7071KG|PLT7072|PLT7223G|PLT7225G|PLT7777G|PLT7810K|PLT7849G|PLT7851G|PLT7852G|PLT8015|PLT8031|PLT8034|PLT8036|PLT8080K|PLT8082|PLT8088|PLT8223G|PLT8234G|PLT8235G|PLT8816K|PLT9011|PLT9045K|PLT9233G|PLT9735|PLT9760G|PLT9770G)\\b",YONESTablet:"BQ1078|BC1003|BC1077|RK9702|BC9730|BC9001|IT9001|BC7008|BC7010|BC708|BC728|BC7012|BC7030|BC7027|BC7026",ChangJiaTablet:"TPC7102|TPC7103|TPC7105|TPC7106|TPC7107|TPC7201|TPC7203|TPC7205|TPC7210|TPC7708|TPC7709|TPC7712|TPC7110|TPC8101|TPC8103|TPC8105|TPC8106|TPC8203|TPC8205|TPC8503|TPC9106|TPC9701|TPC97101|TPC97103|TPC97105|TPC97106|TPC97111|TPC97113|TPC97203|TPC97603|TPC97809|TPC97205|TPC10101|TPC10103|TPC10106|TPC10111|TPC10203|TPC10205|TPC10503",GUTablet:"TX-A1301|TX-M9002|Q702|kf026",PointOfViewTablet:"TAB-P506|TAB-navi-7-3G-M|TAB-P517|TAB-P-527|TAB-P701|TAB-P703|TAB-P721|TAB-P731N|TAB-P741|TAB-P825|TAB-P905|TAB-P925|TAB-PR945|TAB-PL1015|TAB-P1025|TAB-PI1045|TAB-P1325|TAB-PROTAB[0-9]+|TAB-PROTAB25|TAB-PROTAB26|TAB-PROTAB27|TAB-PROTAB26XL|TAB-PROTAB2-IPS9|TAB-PROTAB30-IPS9|TAB-PROTAB25XXL|TAB-PROTAB26-IPS10|TAB-PROTAB30-IPS10",OvermaxTablet:"OV-(SteelCore|NewBase|Basecore|Baseone|Exellen|Quattor|EduTab|Solution|ACTION|BasicTab|TeddyTab|MagicTab|Stream|TB-08|TB-09)|Qualcore 1027",HCLTablet:"HCL.*Tablet|Connect-3G-2.0|Connect-2G-2.0|ME Tablet U1|ME Tablet U2|ME Tablet G1|ME Tablet X1|ME Tablet Y2|ME Tablet Sync",DPSTablet:"DPS Dream 9|DPS Dual 7",VistureTablet:"V97 HD|i75 3G|Visture V4( HD)?|Visture V5( HD)?|Visture V10",CrestaTablet:"CTP(-)?810|CTP(-)?818|CTP(-)?828|CTP(-)?838|CTP(-)?888|CTP(-)?978|CTP(-)?980|CTP(-)?987|CTP(-)?988|CTP(-)?989",MediatekTablet:"\\bMT8125|MT8389|MT8135|MT8377\\b",ConcordeTablet:"Concorde([ ]+)?Tab|ConCorde ReadMan",GoCleverTablet:"GOCLEVER TAB|A7GOCLEVER|M1042|M7841|M742|R1042BK|R1041|TAB A975|TAB A7842|TAB A741|TAB A741L|TAB M723G|TAB M721|TAB A1021|TAB I921|TAB R721|TAB I720|TAB T76|TAB R70|TAB R76.2|TAB R106|TAB R83.2|TAB M813G|TAB I721|GCTA722|TAB I70|TAB I71|TAB S73|TAB R73|TAB R74|TAB R93|TAB R75|TAB R76.1|TAB A73|TAB A93|TAB A93.2|TAB T72|TAB R83|TAB R974|TAB R973|TAB A101|TAB A103|TAB A104|TAB A104.2|R105BK|M713G|A972BK|TAB A971|TAB R974.2|TAB R104|TAB R83.3|TAB A1042",ModecomTablet:"FreeTAB 9000|FreeTAB 7.4|FreeTAB 7004|FreeTAB 7800|FreeTAB 2096|FreeTAB 7.5|FreeTAB 1014|FreeTAB 1001 |FreeTAB 8001|FreeTAB 9706|FreeTAB 9702|FreeTAB 7003|FreeTAB 7002|FreeTAB 1002|FreeTAB 7801|FreeTAB 1331|FreeTAB 1004|FreeTAB 8002|FreeTAB 8014|FreeTAB 9704|FreeTAB 1003",VoninoTablet:"\\b(Argus[ _]?S|Diamond[ _]?79HD|Emerald[ _]?78E|Luna[ _]?70C|Onyx[ _]?S|Onyx[ _]?Z|Orin[ _]?HD|Orin[ _]?S|Otis[ _]?S|SpeedStar[ _]?S|Magnet[ _]?M9|Primus[ _]?94[ _]?3G|Primus[ _]?94HD|Primus[ _]?QS|Android.*\\bQ8\\b|Sirius[ _]?EVO[ _]?QS|Sirius[ _]?QS|Spirit[ _]?S)\\b",ECSTablet:"V07OT2|TM105A|S10OT1|TR10CS1",StorexTablet:"eZee[_']?(Tab|Go)[0-9]+|TabLC7|Looney Tunes Tab",VodafoneTablet:"SmartTab([ ]+)?[0-9]+|SmartTabII10|SmartTabII7|VF-1497|VFD 1400",EssentielBTablet:"Smart[ ']?TAB[ ]+?[0-9]+|Family[ ']?TAB2",RossMoorTablet:"RM-790|RM-997|RMD-878G|RMD-974R|RMT-705A|RMT-701|RME-601|RMT-501|RMT-711",iMobileTablet:"i-mobile i-note",TolinoTablet:"tolino tab [0-9.]+|tolino shine",AudioSonicTablet:"\\bC-22Q|T7-QC|T-17B|T-17P\\b",AMPETablet:"Android.* A78 ",SkkTablet:"Android.* (SKYPAD|PHOENIX|CYCLOPS)",TecnoTablet:"TECNO P9|TECNO DP8D",JXDTablet:"Android.* \\b(F3000|A3300|JXD5000|JXD3000|JXD2000|JXD300B|JXD300|S5800|S7800|S602b|S5110b|S7300|S5300|S602|S603|S5100|S5110|S601|S7100a|P3000F|P3000s|P101|P200s|P1000m|P200m|P9100|P1000s|S6600b|S908|P1000|P300|S18|S6600|S9100)\\b",iJoyTablet:"Tablet (Spirit 7|Essentia|Galatea|Fusion|Onix 7|Landa|Titan|Scooby|Deox|Stella|Themis|Argon|Unique 7|Sygnus|Hexen|Finity 7|Cream|Cream X2|Jade|Neon 7|Neron 7|Kandy|Scape|Saphyr 7|Rebel|Biox|Rebel|Rebel 8GB|Myst|Draco 7|Myst|Tab7-004|Myst|Tadeo Jones|Tablet Boing|Arrow|Draco Dual Cam|Aurix|Mint|Amity|Revolution|Finity 9|Neon 9|T9w|Amity 4GB Dual Cam|Stone 4GB|Stone 8GB|Andromeda|Silken|X2|Andromeda II|Halley|Flame|Saphyr 9,7|Touch 8|Planet|Triton|Unique 10|Hexen 10|Memphis 4GB|Memphis 8GB|Onix 10)",FX2Tablet:"FX2 PAD7|FX2 PAD10",XoroTablet:"KidsPAD 701|PAD[ ]?712|PAD[ ]?714|PAD[ ]?716|PAD[ ]?717|PAD[ ]?718|PAD[ ]?720|PAD[ ]?721|PAD[ ]?722|PAD[ ]?790|PAD[ ]?792|PAD[ ]?900|PAD[ ]?9715D|PAD[ ]?9716DR|PAD[ ]?9718DR|PAD[ ]?9719QR|PAD[ ]?9720QR|TelePAD1030|Telepad1032|TelePAD730|TelePAD731|TelePAD732|TelePAD735Q|TelePAD830|TelePAD9730|TelePAD795|MegaPAD 1331|MegaPAD 1851|MegaPAD 2151",ViewsonicTablet:"ViewPad 10pi|ViewPad 10e|ViewPad 10s|ViewPad E72|ViewPad7|ViewPad E100|ViewPad 7e|ViewSonic VB733|VB100a",VerizonTablet:"QTAQZ3|QTAIR7|QTAQTZ3|QTASUN1|QTASUN2|QTAXIA1",OdysTablet:"LOOX|XENO10|ODYS[ -](Space|EVO|Xpress|NOON)|\\bXELIO\\b|Xelio10Pro|XELIO7PHONETAB|XELIO10EXTREME|XELIOPT2|NEO_QUAD10",CaptivaTablet:"CAPTIVA PAD",IconbitTablet:"NetTAB|NT-3702|NT-3702S|NT-3702S|NT-3603P|NT-3603P|NT-0704S|NT-0704S|NT-3805C|NT-3805C|NT-0806C|NT-0806C|NT-0909T|NT-0909T|NT-0907S|NT-0907S|NT-0902S|NT-0902S",TeclastTablet:"T98 4G|\\bP80\\b|\\bX90HD\\b|X98 Air|X98 Air 3G|\\bX89\\b|P80 3G|\\bX80h\\b|P98 Air|\\bX89HD\\b|P98 3G|\\bP90HD\\b|P89 3G|X98 3G|\\bP70h\\b|P79HD 3G|G18d 3G|\\bP79HD\\b|\\bP89s\\b|\\bA88\\b|\\bP10HD\\b|\\bP19HD\\b|G18 3G|\\bP78HD\\b|\\bA78\\b|\\bP75\\b|G17s 3G|G17h 3G|\\bP85t\\b|\\bP90\\b|\\bP11\\b|\\bP98t\\b|\\bP98HD\\b|\\bG18d\\b|\\bP85s\\b|\\bP11HD\\b|\\bP88s\\b|\\bA80HD\\b|\\bA80se\\b|\\bA10h\\b|\\bP89\\b|\\bP78s\\b|\\bG18\\b|\\bP85\\b|\\bA70h\\b|\\bA70\\b|\\bG17\\b|\\bP18\\b|\\bA80s\\b|\\bA11s\\b|\\bP88HD\\b|\\bA80h\\b|\\bP76s\\b|\\bP76h\\b|\\bP98\\b|\\bA10HD\\b|\\bP78\\b|\\bP88\\b|\\bA11\\b|\\bA10t\\b|\\bP76a\\b|\\bP76t\\b|\\bP76e\\b|\\bP85HD\\b|\\bP85a\\b|\\bP86\\b|\\bP75HD\\b|\\bP76v\\b|\\bA12\\b|\\bP75a\\b|\\bA15\\b|\\bP76Ti\\b|\\bP81HD\\b|\\bA10\\b|\\bT760VE\\b|\\bT720HD\\b|\\bP76\\b|\\bP73\\b|\\bP71\\b|\\bP72\\b|\\bT720SE\\b|\\bC520Ti\\b|\\bT760\\b|\\bT720VE\\b|T720-3GE|T720-WiFi",OndaTablet:"\\b(V975i|Vi30|VX530|V701|Vi60|V701s|Vi50|V801s|V719|Vx610w|VX610W|V819i|Vi10|VX580W|Vi10|V711s|V813|V811|V820w|V820|Vi20|V711|VI30W|V712|V891w|V972|V819w|V820w|Vi60|V820w|V711|V813s|V801|V819|V975s|V801|V819|V819|V818|V811|V712|V975m|V101w|V961w|V812|V818|V971|V971s|V919|V989|V116w|V102w|V973|Vi40)\\b[\\s]+|V10 \\b4G\\b",JaytechTablet:"TPC-PA762",BlaupunktTablet:"Endeavour 800NG|Endeavour 1010",DigmaTablet:"\\b(iDx10|iDx9|iDx8|iDx7|iDxD7|iDxD8|iDsQ8|iDsQ7|iDsQ8|iDsD10|iDnD7|3TS804H|iDsQ11|iDj7|iDs10)\\b",EvolioTablet:"ARIA_Mini_wifi|Aria[ _]Mini|Evolio X10|Evolio X7|Evolio X8|\\bEvotab\\b|\\bNeura\\b",LavaTablet:"QPAD E704|\\bIvoryS\\b|E-TAB IVORY|\\bE-TAB\\b",AocTablet:"MW0811|MW0812|MW0922|MTK8382|MW1031|MW0831|MW0821|MW0931|MW0712",MpmanTablet:"MP11 OCTA|MP10 OCTA|MPQC1114|MPQC1004|MPQC994|MPQC974|MPQC973|MPQC804|MPQC784|MPQC780|\\bMPG7\\b|MPDCG75|MPDCG71|MPDC1006|MP101DC|MPDC9000|MPDC905|MPDC706HD|MPDC706|MPDC705|MPDC110|MPDC100|MPDC99|MPDC97|MPDC88|MPDC8|MPDC77|MP709|MID701|MID711|MID170|MPDC703|MPQC1010",CelkonTablet:"CT695|CT888|CT[\\s]?910|CT7 Tab|CT9 Tab|CT3 Tab|CT2 Tab|CT1 Tab|C820|C720|\\bCT-1\\b",WolderTablet:"miTab \\b(DIAMOND|SPACE|BROOKLYN|NEO|FLY|MANHATTAN|FUNK|EVOLUTION|SKY|GOCAR|IRON|GENIUS|POP|MINT|EPSILON|BROADWAY|JUMP|HOP|LEGEND|NEW AGE|LINE|ADVANCE|FEEL|FOLLOW|LIKE|LINK|LIVE|THINK|FREEDOM|CHICAGO|CLEVELAND|BALTIMORE-GH|IOWA|BOSTON|SEATTLE|PHOENIX|DALLAS|IN 101|MasterChef)\\b",MediacomTablet:"M-MPI10C3G|M-SP10EG|M-SP10EGP|M-SP10HXAH|M-SP7HXAH|M-SP10HXBH|M-SP8HXAH|M-SP8MXA",MiTablet:"\\bMI PAD\\b|\\bHM NOTE 1W\\b",NibiruTablet:"Nibiru M1|Nibiru Jupiter One",NexoTablet:"NEXO NOVA|NEXO 10|NEXO AVIO|NEXO FREE|NEXO GO|NEXO EVO|NEXO 3G|NEXO SMART|NEXO KIDDO|NEXO MOBI",LeaderTablet:"TBLT10Q|TBLT10I|TBL-10WDKB|TBL-10WDKBO2013|TBL-W230V2|TBL-W450|TBL-W500|SV572|TBLT7I|TBA-AC7-8G|TBLT79|TBL-8W16|TBL-10W32|TBL-10WKB|TBL-W100",UbislateTablet:"UbiSlate[\\s]?7C",PocketBookTablet:"Pocketbook",KocasoTablet:"\\b(TB-1207)\\b",HisenseTablet:"\\b(F5281|E2371)\\b",Hudl:"Hudl HT7S3|Hudl 2",TelstraTablet:"T-Hub2",GenericTablet:"Android.*\\b97D\\b|Tablet(?!.*PC)|BNTV250A|MID-WCDMA|LogicPD Zoom2|\\bA7EB\\b|CatNova8|A1_07|CT704|CT1002|\\bM721\\b|rk30sdk|\\bEVOTAB\\b|M758A|ET904|ALUMIUM10|Smartfren Tab|Endeavour 1010|Tablet-PC-4|Tagi Tab|\\bM6pro\\b|CT1020W|arc 10HD|\\bTP750\\b|\\bQTAQZ3\\b|WVT101|TM1088|KT107"},oss:{AndroidOS:"Android",BlackBerryOS:"blackberry|\\bBB10\\b|rim tablet os",PalmOS:"PalmOS|avantgo|blazer|elaine|hiptop|palm|plucker|xiino",SymbianOS:"Symbian|SymbOS|Series60|Series40|SYB-[0-9]+|\\bS60\\b",WindowsMobileOS:"Windows CE.*(PPC|Smartphone|Mobile|[0-9]{3}x[0-9]{3})|Windows Mobile|Windows Phone [0-9.]+|WCE;",WindowsPhoneOS:"Windows Phone 10.0|Windows Phone 8.1|Windows Phone 8.0|Windows Phone OS|XBLWP7|ZuneWP7|Windows NT 6.[23]; ARM;",iOS:"\\biPhone.*Mobile|\\biPod|\\biPad|AppleCoreMedia",iPadOS:"CPU OS 13",SailfishOS:"Sailfish",MeeGoOS:"MeeGo",MaemoOS:"Maemo",JavaOS:"J2ME/|\\bMIDP\\b|\\bCLDC\\b",webOS:"webOS|hpwOS",badaOS:"\\bBada\\b",BREWOS:"BREW"},uas:{Chrome:"\\bCrMo\\b|CriOS|Android.*Chrome/[.0-9]* (Mobile)?",Dolfin:"\\bDolfin\\b",Opera:"Opera.*Mini|Opera.*Mobi|Android.*Opera|Mobile.*OPR/[0-9.]+$|Coast/[0-9.]+",Skyfire:"Skyfire",Edge:"\\bEdgiOS\\b|Mobile Safari/[.0-9]* Edge",IE:"IEMobile|MSIEMobile",Firefox:"fennec|firefox.*maemo|(Mobile|Tablet).*Firefox|Firefox.*Mobile|FxiOS",Bolt:"bolt",TeaShark:"teashark",Blazer:"Blazer",Safari:"Version((?!\\bEdgiOS\\b).)*Mobile.*Safari|Safari.*Mobile|MobileSafari",WeChat:"\\bMicroMessenger\\b",UCBrowser:"UC.*Browser|UCWEB",baiduboxapp:"baiduboxapp",baidubrowser:"baidubrowser",DiigoBrowser:"DiigoBrowser",Mercury:"\\bMercury\\b",ObigoBrowser:"Obigo",NetFront:"NF-Browser",GenericBrowser:"NokiaBrowser|OviBrowser|OneBrowser|TwonkyBeamBrowser|SEMC.*Browser|FlyFlow|Minimo|NetFront|Novarra-Vision|MQQBrowser|MicroMessenger",PaleMoon:"Android.*PaleMoon|Mobile.*PaleMoon"},props:{Mobile:"Mobile/[VER]",Build:"Build/[VER]",Version:"Version/[VER]",VendorID:"VendorID/[VER]",iPad:"iPad.*CPU[a-z ]+[VER]",iPhone:"iPhone.*CPU[a-z ]+[VER]",iPod:"iPod.*CPU[a-z ]+[VER]",Kindle:"Kindle/[VER]",Chrome:["Chrome/[VER]","CriOS/[VER]","CrMo/[VER]"],Coast:["Coast/[VER]"],Dolfin:"Dolfin/[VER]",Firefox:["Firefox/[VER]","FxiOS/[VER]"],Fennec:"Fennec/[VER]",Edge:"Edge/[VER]",IE:["IEMobile/[VER];","IEMobile [VER]","MSIE [VER];","Trident/[0-9.]+;.*rv:[VER]"],NetFront:"NetFront/[VER]",NokiaBrowser:"NokiaBrowser/[VER]",Opera:[" OPR/[VER]","Opera Mini/[VER]","Version/[VER]"],"Opera Mini":"Opera Mini/[VER]","Opera Mobi":"Version/[VER]",UCBrowser:["UCWEB[VER]","UC.*Browser/[VER]"],MQQBrowser:"MQQBrowser/[VER]",MicroMessenger:"MicroMessenger/[VER]",baiduboxapp:"baiduboxapp/[VER]",baidubrowser:"baidubrowser/[VER]",SamsungBrowser:"SamsungBrowser/[VER]",Iron:"Iron/[VER]",Safari:["Version/[VER]","Safari/[VER]"],Skyfire:"Skyfire/[VER]",Tizen:"Tizen/[VER]",Webkit:"webkit[ /][VER]",PaleMoon:"PaleMoon/[VER]",SailfishBrowser:"SailfishBrowser/[VER]",Gecko:"Gecko/[VER]",Trident:"Trident/[VER]",Presto:"Presto/[VER]",Goanna:"Goanna/[VER]",iOS:" \\bi?OS\\b [VER][ ;]{1}",Android:"Android [VER]",Sailfish:"Sailfish [VER]",BlackBerry:["BlackBerry[\\w]+/[VER]","BlackBerry.*Version/[VER]","Version/[VER]"],BREW:"BREW [VER]",Java:"Java/[VER]","Windows Phone OS":["Windows Phone OS [VER]","Windows Phone [VER]"],"Windows Phone":"Windows Phone [VER]","Windows CE":"Windows CE/[VER]","Windows NT":"Windows NT [VER]",Symbian:["SymbianOS/[VER]","Symbian/[VER]"],webOS:["webOS/[VER]","hpwOS/[VER];"]},utils:{Bot:"Googlebot|facebookexternalhit|Google-AMPHTML|s~amp-validator|AdsBot-Google|Google Keyword Suggestion|Facebot|YandexBot|YandexMobileBot|bingbot|ia_archiver|AhrefsBot|Ezooms|GSLFbot|WBSearchBot|Twitterbot|TweetmemeBot|Twikle|PaperLiBot|Wotbox|UnwindFetchor|Exabot|MJ12bot|YandexImages|TurnitinBot|Pingdom|contentkingapp|AspiegelBot",MobileBot:"Googlebot-Mobile|AdsBot-Google-Mobile|YahooSeeker/M1A1-R2D2",DesktopMode:"WPDesktop",TV:"SonyDTV|HbbTV",WebKit:"(webkit)[ /]([\\w.]+)",Console:"\\b(Nintendo|Nintendo WiiU|Nintendo 3DS|Nintendo Switch|PLAYSTATION|Xbox)\\b",Watch:"SM-V700"}},g.detectMobileBrowsers={fullPattern:/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,
shortPattern:/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i,tabletPattern:/android|ipad|playbook|silk/i};var h,i=Object.prototype.hasOwnProperty;return g.FALLBACK_PHONE="UnknownPhone",g.FALLBACK_TABLET="UnknownTablet",g.FALLBACK_MOBILE="UnknownMobile",h="isArray"in Array?Array.isArray:function(a){return"[object Array]"===Object.prototype.toString.call(a)},function(){var a,b,c,e,f,j,k=g.mobileDetectRules;for(a in k.props)if(i.call(k.props,a)){for(b=k.props[a],h(b)||(b=[b]),f=b.length,e=0;e<f;++e)c=b[e],j=c.indexOf("[VER]"),j>=0&&(c=c.substring(0,j)+"([\\w._\\+]+)"+c.substring(j+5)),b[e]=new RegExp(c,"i");k.props[a]=b}d(k.oss),d(k.phones),d(k.tablets),d(k.uas),d(k.utils),k.oss0={WindowsPhoneOS:k.oss.WindowsPhoneOS,WindowsMobileOS:k.oss.WindowsMobileOS}}(),g.findMatch=function(a,b){for(var c in a)if(i.call(a,c)&&a[c].test(b))return c;return null},g.findMatches=function(a,b){var c=[];for(var d in a)i.call(a,d)&&a[d].test(b)&&c.push(d);return c},g.getVersionStr=function(a,b){var c,d,e,f,h=g.mobileDetectRules.props;if(i.call(h,a))for(c=h[a],e=c.length,d=0;d<e;++d)if(f=c[d].exec(b),null!==f)return f[1];return null},g.getVersion=function(a,b){var c=g.getVersionStr(a,b);return c?g.prepareVersionNo(c):NaN},g.prepareVersionNo=function(a){var b;return b=a.split(/[a-z._ \/\-]/i),1===b.length&&(a=b[0]),b.length>1&&(a=b[0]+".",b.shift(),a+=b.join("")),Number(a)},g.isMobileFallback=function(a){return g.detectMobileBrowsers.fullPattern.test(a)||g.detectMobileBrowsers.shortPattern.test(a.substr(0,4))},g.isTabletFallback=function(a){return g.detectMobileBrowsers.tabletPattern.test(a)},g.prepareDetectionCache=function(a,c,d){if(a.mobile===b){var e,h,i;return(h=g.findMatch(g.mobileDetectRules.tablets,c))?(a.mobile=a.tablet=h,void(a.phone=null)):(e=g.findMatch(g.mobileDetectRules.phones,c))?(a.mobile=a.phone=e,void(a.tablet=null)):void(g.isMobileFallback(c)?(i=f.isPhoneSized(d),i===b?(a.mobile=g.FALLBACK_MOBILE,a.tablet=a.phone=null):i?(a.mobile=a.phone=g.FALLBACK_PHONE,a.tablet=null):(a.mobile=a.tablet=g.FALLBACK_TABLET,a.phone=null)):g.isTabletFallback(c)?(a.mobile=a.tablet=g.FALLBACK_TABLET,a.phone=null):a.mobile=a.tablet=a.phone=null)}},g.mobileGrade=function(a){var b=null!==a.mobile();return a.os("iOS")&&a.version("iPad")>=4.3||a.os("iOS")&&a.version("iPhone")>=3.1||a.os("iOS")&&a.version("iPod")>=3.1||a.version("Android")>2.1&&a.is("Webkit")||a.version("Windows Phone OS")>=7||a.is("BlackBerry")&&a.version("BlackBerry")>=6||a.match("Playbook.*Tablet")||a.version("webOS")>=1.4&&a.match("Palm|Pre|Pixi")||a.match("hp.*TouchPad")||a.is("Firefox")&&a.version("Firefox")>=12||a.is("Chrome")&&a.is("AndroidOS")&&a.version("Android")>=4||a.is("Skyfire")&&a.version("Skyfire")>=4.1&&a.is("AndroidOS")&&a.version("Android")>=2.3||a.is("Opera")&&a.version("Opera Mobi")>11&&a.is("AndroidOS")||a.is("MeeGoOS")||a.is("Tizen")||a.is("Dolfin")&&a.version("Bada")>=2||(a.is("UC Browser")||a.is("Dolfin"))&&a.version("Android")>=2.3||a.match("Kindle Fire")||a.is("Kindle")&&a.version("Kindle")>=3||a.is("AndroidOS")&&a.is("NookTablet")||a.version("Chrome")>=11&&!b||a.version("Safari")>=5&&!b||a.version("Firefox")>=4&&!b||a.version("MSIE")>=7&&!b||a.version("Opera")>=10&&!b?"A":a.os("iOS")&&a.version("iPad")<4.3||a.os("iOS")&&a.version("iPhone")<3.1||a.os("iOS")&&a.version("iPod")<3.1||a.is("Blackberry")&&a.version("BlackBerry")>=5&&a.version("BlackBerry")<6||a.version("Opera Mini")>=5&&a.version("Opera Mini")<=6.5&&(a.version("Android")>=2.3||a.is("iOS"))||a.match("NokiaN8|NokiaC7|N97.*Series60|Symbian/3")||a.version("Opera Mobi")>=11&&a.is("SymbianOS")?"B":(a.version("BlackBerry")<5||a.match("MSIEMobile|Windows CE.*Mobile")||a.version("Windows Mobile")<=5.2,"C")},g.detectOS=function(a){return g.findMatch(g.mobileDetectRules.oss0,a)||g.findMatch(g.mobileDetectRules.oss,a)},g.getDeviceSmallerSide=function(){return window.screen.width<window.screen.height?window.screen.width:window.screen.height},f.prototype={constructor:f,mobile:function(){return g.prepareDetectionCache(this._cache,this.ua,this.maxPhoneWidth),this._cache.mobile},phone:function(){return g.prepareDetectionCache(this._cache,this.ua,this.maxPhoneWidth),this._cache.phone},tablet:function(){return g.prepareDetectionCache(this._cache,this.ua,this.maxPhoneWidth),this._cache.tablet},userAgent:function(){return this._cache.userAgent===b&&(this._cache.userAgent=g.findMatch(g.mobileDetectRules.uas,this.ua)),this._cache.userAgent},userAgents:function(){return this._cache.userAgents===b&&(this._cache.userAgents=g.findMatches(g.mobileDetectRules.uas,this.ua)),this._cache.userAgents},os:function(){return this._cache.os===b&&(this._cache.os=g.detectOS(this.ua)),this._cache.os},version:function(a){return g.getVersion(a,this.ua)},versionStr:function(a){return g.getVersionStr(a,this.ua)},is:function(b){return c(this.userAgents(),b)||a(b,this.os())||a(b,this.phone())||a(b,this.tablet())||c(g.findMatches(g.mobileDetectRules.utils,this.ua),b)},match:function(a){return a instanceof RegExp||(a=new RegExp(a,"i")),a.test(this.ua)},isPhoneSized:function(a){return f.isPhoneSized(a||this.maxPhoneWidth)},mobileGrade:function(){return this._cache.grade===b&&(this._cache.grade=g.mobileGrade(this)),this._cache.grade}},"undefined"!=typeof window&&window.screen?f.isPhoneSized=function(a){return a<0?b:g.getDeviceSmallerSide()<=a}:f.isPhoneSized=function(){},f._impl=g,f.version="1.4.5 2021-03-13",f})}(function(a){if("undefined"!=typeof module&&module.exports)return function(a){module.exports=a()};if("function"==typeof define&&define.amd)return define;if("undefined"!=typeof window)return function(a){window.MobileDetect=a()};throw new Error("unknown environment")}());var ai_lists=!0,ai_block_class_def="code-block";
if("undefined"!=typeof ai_lists){function X(b,e){for(var n=[];b=b.previousElementSibling;)("undefined"==typeof e||b.matches(e))&&n.push(b);return n}function fa(b,e){for(var n=[];b=b.nextElementSibling;)("undefined"==typeof e||b.matches(e))&&n.push(b);return n}var host_regexp=RegExp(":\\/\\/(.[^/:]+)","i");function ha(b){b=b.match(host_regexp);return null!=b&&1<b.length&&"string"===typeof b[1]&&0<b[1].length?b[1].toLowerCase():null}function Q(b){return b.includes(":")?(b=b.split(":"),1E3*(3600*parseInt(b[0])+
60*parseInt(b[1])+parseInt(b[2]))):null}function Y(b){try{var e=Date.parse(b);isNaN(e)&&(e=null)}catch(n){e=null}if(null==e&&b.includes(" ")){b=b.split(" ");try{e=Date.parse(b[0]),e+=Q(b[1]),isNaN(e)&&(e=null)}catch(n){e=null}}return e}function Z(){null==document.querySelector("#ai-iab-tcf-bar")&&null==document.querySelector(".ai-list-manual")||"function"!=typeof __tcfapi||"function"!=typeof ai_load_blocks||"undefined"!=typeof ai_iab_tcf_callback_installed||(__tcfapi("addEventListener",2,function(b,
e){e&&"useractioncomplete"===b.eventStatus&&(ai_tcData=b,ai_load_blocks(),b=document.querySelector("#ai-iab-tcf-status"),null!=b&&(b.textContent="IAB TCF 2.0 DATA LOADED"),b=document.querySelector("#ai-iab-tcf-bar"),null!=b&&(b.classList.remove("status-error"),b.classList.add("status-ok")))}),ai_iab_tcf_callback_installed=!0)}ai_process_lists=function(b){function e(a,c,k){if(0==a.length){if("!@!"==k)return!0;c!=k&&("true"==k.toLowerCase()?k=!0:"false"==k.toLowerCase()&&(k=!1));return c==k}if("object"!=
typeof c&&"array"!=typeof c)return!1;var l=a[0];a=a.slice(1);if("*"==l)for(let [,p]of Object.entries(c)){if(e(a,p,k))return!0}else if(l in c)return e(a,c[l],k);return!1}function n(a,c,k){if("object"!=typeof a||-1==c.indexOf("["))return!1;c=c.replace(/]| /gi,"").split("[");return e(c,a,k)}function z(){if("function"==typeof __tcfapi){var a=document.querySelector("#ai-iab-tcf-status"),c=document.querySelector("#ai-iab-tcf-bar");null!=a&&(a.textContent="IAB TCF 2.0 DETECTED");__tcfapi("getTCData",2,function(k,
l){l?(null!=c&&(c.classList.remove("status-error"),c.classList.add("status-ok")),"tcloaded"==k.eventStatus||"useractioncomplete"==k.eventStatus)?(ai_tcData=k,k.gdprApplies?null!=a&&(a.textContent="IAB TCF 2.0 DATA LOADED"):null!=a&&(a.textContent="IAB TCF 2.0 GDPR DOES NOT APPLY"),null!=c&&(c.classList.remove("status-error"),c.classList.add("status-ok")),setTimeout(function(){ai_process_lists()},10)):"cmpuishown"==k.eventStatus&&(ai_cmpuishown=!0,null!=a&&(a.textContent="IAB TCF 2.0 CMP UI SHOWN"),
null!=c&&(c.classList.remove("status-error"),c.classList.add("status-ok"))):(null!=a&&(a.textContent="IAB TCF 2.0 __tcfapi getTCData failed"),null!=c&&(c.classList.remove("status-ok"),c.classList.add("status-error")))})}}function C(a){"function"==typeof __tcfapi?(ai_tcfapi_found=!0,"undefined"==typeof ai_iab_tcf_callback_installed&&Z(),"undefined"==typeof ai_tcData_requested&&(ai_tcData_requested=!0,z(),cookies_need_tcData=!0)):a&&("undefined"==typeof ai_tcfapi_found&&(ai_tcfapi_found=!1,setTimeout(function(){ai_process_lists()},
10)),a=document.querySelector("#ai-iab-tcf-status"),null!=a&&(a.textContent="IAB TCF 2.0 MISSING: __tcfapi function not found"),a=document.querySelector("#ai-iab-tcf-bar"),null!=a&&(a.classList.remove("status-ok"),a.classList.add("status-error")))}if(null==b)b=document.querySelectorAll("div.ai-list-data, meta.ai-list-data");else{window.jQuery&&window.jQuery.fn&&b instanceof jQuery&&(b=Array.prototype.slice.call(b));var x=[];b.forEach((a,c)=>{a.matches(".ai-list-data")?x.push(a):(a=a.querySelectorAll(".ai-list-data"),
a.length&&a.forEach((k,l)=>{x.push(k)}))});b=x}if(b.length){b.forEach((a,c)=>{a.classList.remove("ai-list-data")});var L=ia(window.location.search);if(null!=L.referrer)var A=L.referrer;else A=document.referrer,""!=A&&(A=ha(A));var R=window.navigator.userAgent,S=R.toLowerCase(),aa=navigator.language,M=aa.toLowerCase();if("undefined"!==typeof MobileDetect)var ba=new MobileDetect(R);b.forEach((a,c)=>{var k=document.cookie.split(";");k.forEach(function(f,h){k[h]=f.trim()});c=a.closest("div."+ai_block_class_def);
var l=!0;if(a.hasAttribute("referer-list")){var p=a.getAttribute("referer-list");p=b64d(p).split(",");var v=a.getAttribute("referer-list-type"),E=!1;p.every((f,h)=>{f=f.trim();if(""==f)return!0;if("*"==f.charAt(0))if("*"==f.charAt(f.length-1)){if(f=f.substr(1,f.length-2),-1!=A.indexOf(f))return E=!0,!1}else{if(f=f.substr(1),A.substr(-f.length)==f)return E=!0,!1}else if("*"==f.charAt(f.length-1)){if(f=f.substr(0,f.length-1),0==A.indexOf(f))return E=!0,!1}else if("#"==f){if(""==A)return E=!0,!1}else if(f==
A)return E=!0,!1;return!0});var r=E;switch(v){case "B":r&&(l=!1);break;case "W":r||(l=!1)}}if(l&&a.hasAttribute("client-list")&&"undefined"!==typeof ba)switch(p=a.getAttribute("client-list"),p=b64d(p).split(","),v=a.getAttribute("client-list-type"),r=!1,p.every((f,h)=>{if(""==f.trim())return!0;f.split("&&").every((d,t)=>{t=!0;var w=!1;for(d=d.trim();"!!"==d.substring(0,2);)t=!t,d=d.substring(2);"language:"==d.substring(0,9)&&(w=!0,d=d.substring(9).toLowerCase());var q=!1;w?"*"==d.charAt(0)?"*"==d.charAt(d.length-
1)?(d=d.substr(1,d.length-2).toLowerCase(),-1!=M.indexOf(d)&&(q=!0)):(d=d.substr(1).toLowerCase(),M.substr(-d.length)==d&&(q=!0)):"*"==d.charAt(d.length-1)?(d=d.substr(0,d.length-1).toLowerCase(),0==M.indexOf(d)&&(q=!0)):d==M&&(q=!0):"*"==d.charAt(0)?"*"==d.charAt(d.length-1)?(d=d.substr(1,d.length-2).toLowerCase(),-1!=S.indexOf(d)&&(q=!0)):(d=d.substr(1).toLowerCase(),S.substr(-d.length)==d&&(q=!0)):"*"==d.charAt(d.length-1)?(d=d.substr(0,d.length-1).toLowerCase(),0==S.indexOf(d)&&(q=!0)):ba.is(d)&&
(q=!0);return(r=q?t:!t)?!0:!1});return r?!1:!0}),v){case "B":r&&(l=!1);break;case "W":r||(l=!1)}var N=p=!1;for(v=1;2>=v;v++)if(l){switch(v){case 1:var g=a.getAttribute("cookie-list");break;case 2:g=a.getAttribute("parameter-list")}if(null!=g){g=b64d(g);switch(v){case 1:var y=a.getAttribute("cookie-list-type");break;case 2:y=a.getAttribute("parameter-list-type")}g=g.replace("tcf-gdpr","tcf-v2[gdprApplies]=true");g=g.replace("tcf-no-gdpr","tcf-v2[gdprApplies]=false");g=g.replace("tcf-google","tcf-v2[vendor][consents][755]=true && tcf-v2[purpose][consents][1]=true");
g=g.replace("tcf-no-google","!!tcf-v2[vendor][consents][755]");g=g.replace("tcf-media.net","tcf-v2[vendor][consents][142]=true && tcf-v2[purpose][consents][1]=true");g=g.replace("tcf-no-media.net","!!tcf-v2[vendor][consents][142]");g=g.replace("tcf-amazon","tcf-v2[vendor][consents][793]=true && tcf-v2[purpose][consents][1]=true");g=g.replace("tcf-no-amazon","!!tcf-v2[vendor][consents][793]");g=g.replace("tcf-ezoic","tcf-v2[vendor][consents][347]=true && tcf-v2[purpose][consents][1]=true");g=g.replace("tcf-no-ezoic",
"!!tcf-v2[vendor][consents][347]");var F=g.split(","),ca=[];k.forEach(function(f){f=f.split("=");try{var h=JSON.parse(decodeURIComponent(f[1]))}catch(d){h=decodeURIComponent(f[1])}ca[f[0]]=h});r=!1;var I=a;F.every((f,h)=>{f.split("&&").every((d,t)=>{t=!0;for(d=d.trim();"!!"==d.substring(0,2);)t=!t,d=d.substring(2);var w=d,q="!@!",T="tcf-v2"==w&&"!@!"==q,B=-1!=d.indexOf("["),J=0==d.indexOf("tcf-v2")||0==d.indexOf("euconsent-v2");J=J&&(B||T);-1!=d.indexOf("=")&&(q=d.split("="),w=q[0],q=q[1],B=-1!=w.indexOf("["),
J=(J=0==w.indexOf("tcf-v2")||0==w.indexOf("euconsent-v2"))&&(B||T));if(J)document.querySelector("#ai-iab-tcf-status"),B=document.querySelector("#ai-iab-tcf-bar"),null!=B&&(B.style.display="block"),T&&"boolean"==typeof ai_tcfapi_found?r=ai_tcfapi_found?t:!t:"object"==typeof ai_tcData?(null!=B&&(B.classList.remove("status-error"),B.classList.add("status-ok")),w=w.replace(/]| /gi,"").split("["),w.shift(),r=(w=e(w,ai_tcData,q))?t:!t):"undefined"==typeof ai_tcfapi_found&&(I.classList.add("ai-list-data"),
N=!0,"function"==typeof __tcfapi?C(!1):"undefined"==typeof ai_tcData_retrying&&(ai_tcData_retrying=!0,setTimeout(function(){"function"==typeof __tcfapi?C(!1):setTimeout(function(){"function"==typeof __tcfapi?C(!1):setTimeout(function(){C(!0)},3E3)},1E3)},600)));else if(B)r=(w=n(ca,w,q))?t:!t;else{var U=!1;"!@!"==q?k.every(function(ja){return ja.split("=")[0]==d?(U=!0,!1):!0}):U=-1!=k.indexOf(d);r=U?t:!t}return r?!0:!1});return r?!1:!0});r&&(N=!1,I.classList.remove("ai-list-data"));switch(y){case "B":r&&
(l=!1);break;case "W":r||(l=!1)}}}a.classList.contains("ai-list-manual")&&(l?(I.classList.remove("ai-list-data"),I.classList.remove("ai-list-manual")):(p=!0,I.classList.add("ai-list-data")));(l||!p&&!N)&&a.hasAttribute("data-debug-info")&&(g=document.querySelector("."+a.dataset.debugInfo),null!=g&&(g=g.parentElement,null!=g&&g.classList.contains("ai-debug-info")&&g.remove()));y=X(a,".ai-debug-bar.ai-debug-lists");var ka=""==A?"#":A;0!=y.length&&y.forEach((f,h)=>{h=f.querySelector(".ai-debug-name.ai-list-info");
null!=h&&(h.textContent=ka,h.title=R+"\n"+aa);h=f.querySelector(".ai-debug-name.ai-list-status");null!=h&&(h.textContent=l?ai_front.visible:ai_front.hidden)});g=!1;if(l&&a.hasAttribute("scheduling-start")&&a.hasAttribute("scheduling-end")&&a.hasAttribute("scheduling-days")){var u=a.getAttribute("scheduling-start");v=a.getAttribute("scheduling-end");y=a.getAttribute("scheduling-days");g=!0;u=b64d(u);F=b64d(v);var V=parseInt(a.getAttribute("scheduling-fallback")),O=parseInt(a.getAttribute("gmt"));if(u.includes("-")||
F.includes("-"))P=Y(u)+O,K=Y(F)+O;else var P=Q(u),K=Q(F);P??=0;K??=0;var W=b64d(y).split(",");y=a.getAttribute("scheduling-type");var D=(new Date).getTime()+O;v=new Date(D);var G=v.getDay();0==G?G=6:G--;u.includes("-")||F.includes("-")||(u=(new Date(v.getFullYear(),v.getMonth(),v.getDate())).getTime()+O,D-=u,0>D&&(D+=864E5));scheduling_start_date_ok=D>=P;scheduling_end_date_ok=0==K||D<K;u=scheduling_start_date_ok&&scheduling_end_date_ok&&W.includes(G.toString());switch(y){case "B":u=!u}u||(l=!1);
var la=v.toISOString().split(".")[0].replace("T"," ");y=X(a,".ai-debug-bar.ai-debug-scheduling");0!=y.length&&y.forEach((f,h)=>{h=f.querySelector(".ai-debug-name.ai-scheduling-info");null!=h&&(h.textContent=la+" "+G+" current_time: "+Math.floor(D.toString()/1E3)+"  start_date:"+Math.floor(P/1E3).toString()+"=>"+scheduling_start_date_ok.toString()+" end_date:"+Math.floor(K/1E3).toString()+"=>"+scheduling_end_date_ok.toString()+" days:"+W.toString()+"=>"+W.includes(G.toString()).toString());h=f.querySelector(".ai-debug-name.ai-scheduling-status");
null!=h&&(h.textContent=l?ai_front.visible:ai_front.hidden);l||0==V||(f.classList.remove("ai-debug-scheduling"),f.classList.add("ai-debug-fallback"),h=f.querySelector(".ai-debug-name.ai-scheduling-status"),null!=h&&(h.textContent=ai_front.fallback+" = "+V))})}if(p||!l&&N)return!0;a.style.visibility="";a.style.position="";a.style.width="";a.style.height="";a.style.zIndex="";if(l){if(null!=c&&(c.style.visibility="",c.classList.contains("ai-remove-position")&&(c.style.position="")),a.hasAttribute("data-code")){p=
b64d(a.dataset.code);u=document.createRange();g=!0;try{H=u.createContextualFragment(p)}catch(f){g=!1}g&&(null!=a.closest("head")?(a.parentNode.insertBefore(H,a.nextSibling),a.remove()):a.append(H));da(a)}}else if(g&&!u&&0!=V){null!=c&&(c.style.visibility="",c.classList.contains("ai-remove-position")&&c.css({position:""}));p=fa(a,".ai-fallback");0!=p.length&&p.forEach((f,h)=>{f.classList.remove("ai-fallback")});if(a.hasAttribute("data-fallback-code")){p=b64d(a.dataset.fallbackCode);u=document.createRange();
g=!0;try{var H=u.createContextualFragment(p)}catch(f){g=!1}g&&a.append(H);da(a)}else a.style.display="none",null!=c&&null==c.querySelector(".ai-debug-block")&&c.hasAttribute("style")&&-1==c.getAttribute("style").indexOf("height:")&&(c.style.display="none");null!=c&&c.hasAttribute("data-ai")&&(c.getAttribute("data-ai"),a.hasAttribute("fallback-tracking")&&(H=a.getAttribute("fallback-tracking"),c.setAttribute("data-ai-"+a.getAttribute("fallback_level"),H)))}else a.style.display="none",null!=c&&(c.removeAttribute("data-ai"),
c.classList.remove("ai-track"),null!=c.querySelector(".ai-debug-block")?(c.style.visibility="",c.classList.remove("ai-close"),c.classList.contains("ai-remove-position")&&(c.style.position="")):c.hasAttribute("style")&&-1==c.getAttribute("style").indexOf("height:")&&(c.style.display="none"));a.setAttribute("data-code","");a.setAttribute("data-fallback-code","");null!=c&&c.classList.remove("ai-list-block")})}};function ea(b){b=`; ${document.cookie}`.split(`; ${b}=`);if(2===b.length)return b.pop().split(";").shift()}
function ma(b,e,n){ea(b)&&(document.cookie=b+"="+(e?";path="+e:"")+(n?";domain="+n:"")+";expires=Thu, 01 Jan 1970 00:00:01 GMT")}function m(b){ea(b)&&(ma(b,"/",window.location.hostname),document.cookie=b+"=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;")}(function(b){"complete"===document.readyState||"loading"!==document.readyState&&!document.documentElement.doScroll?b():document.addEventListener("DOMContentLoaded",b)})(function(){setTimeout(function(){ai_process_lists();setTimeout(function(){Z();
if("function"==typeof ai_load_blocks){document.addEventListener("cmplzEnableScripts",e);document.addEventListener("cmplz_event_marketing",e);function e(n){"cmplzEnableScripts"!=n.type&&"all"!==n.consentLevel||ai_load_blocks()}document.addEventListener("cmplz_enable_category",function(n){"marketing"===n.detail.category&&ai_load_blocks()})}},50);var b=document.querySelector(".ai-debug-page-type");null!=b&&b.addEventListener("dblclick",e=>{e=document.querySelector("#ai-iab-tcf-status");null!=e&&(e.textContent=
"CONSENT COOKIES");e=document.querySelector("#ai-iab-tcf-bar");null!=e&&(e.style.display="block")});b=document.querySelector("#ai-iab-tcf-bar");null!=b&&b.addEventListener("click",e=>{m("euconsent-v2");m("__lxG__consent__v2");m("__lxG__consent__v2_daisybit");m("__lxG__consent__v2_gdaisybit");m("CookieLawInfoConsent");m("cookielawinfo-checkbox-advertisement");m("cookielawinfo-checkbox-analytics");m("cookielawinfo-checkbox-necessary");m("complianz_policy_id");m("complianz_consent_status");m("cmplz_marketing");
m("cmplz_consent_status");m("cmplz_preferences");m("cmplz_statistics-anonymous");m("cmplz_choice");m("cmplz_banner-status");m("cmplz_functional");m("cmplz_policy_id");m("cmplz_statistics");m("moove_gdpr_popup");m("real_cookie_banner-blog:1-tcf");m("real_cookie_banner-blog:1");e=document.querySelector("#ai-iab-tcf-status");null!=e&&(e.textContent="CONSENT COOKIES DELETED")})},5)});function da(b){setTimeout(function(){"function"==typeof ai_process_rotations_in_element&&ai_process_rotations_in_element(b);
"function"==typeof ai_process_lists&&ai_process_lists();"function"==typeof ai_process_ip_addresses&&ai_process_ip_addresses();"function"==typeof ai_process_filter_hooks&&ai_process_filter_hooks();"function"==typeof ai_adb_process_blocks&&ai_adb_process_blocks(b);"function"==typeof ai_process_impressions&&1==ai_tracking_finished&&ai_process_impressions();"function"==typeof ai_install_click_trackers&&1==ai_tracking_finished&&ai_install_click_trackers();"function"==typeof ai_install_close_buttons&&ai_install_close_buttons(document)},
5)}function ia(b){var e=b?b.split("?")[1]:window.location.search.slice(1);b={};if(e){e=e.split("#")[0];e=e.split("&");for(var n=0;n<e.length;n++){var z=e[n].split("="),C=void 0,x=z[0].replace(/\[\d*\]/,function(L){C=L.slice(1,-1);return""});z="undefined"===typeof z[1]?"":z[1];x=x.toLowerCase();z=z.toLowerCase();b[x]?("string"===typeof b[x]&&(b[x]=[b[x]]),"undefined"===typeof C?b[x].push(z):b[x][C]=z):b[x]=z}}return b}};

ai_js_code = true;
</script>

<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"cb706f2046e8402caf3763cf2470a9c8","r":1}' crossorigin="anonymous"></script>
</body>

</html>


