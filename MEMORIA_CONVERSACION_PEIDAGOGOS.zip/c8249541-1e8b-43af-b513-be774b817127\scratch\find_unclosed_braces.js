const fs = require('fs');
const code = fs.readFileSync('d:/Peidagogos_Local/app.js', 'utf8');

const stack = [];
let inStr = null;
let inTemplate = false;
let inComment = false;
let inBlockComment = false;

for (let i = 0; i < code.length; i++) {
    const c = code[i];
    const next = code[i + 1];

    if (inComment) {
        if (c === '\n') inComment = false;
        continue;
    }
    if (inBlockComment) {
        if (c === '*' && next === '/') {
            inBlockComment = false;
            i++;
        }
        continue;
    }

    if (inStr) {
        if (c === '\\') {
            i++;
            continue;
        }
        if (c === inStr) {
            inStr = null;
        }
        continue;
    }

    if (inTemplate) {
        if (c === '\\') {
            i++;
            continue;
        }
        if (c === '`') {
            inTemplate = false;
        } else if (c === '$' && next === '{') {
            stack.push({ char: '`', index: i });
            i++;
            inTemplate = false; // inside ${...} expression
        }
        continue;
    }

    // Outside string / template
    if (c === '/' && next === '/') {
        inComment = true;
        i++;
        continue;
    }
    if (c === '/' && next === '*') {
        inBlockComment = true;
        i++;
        continue;
    }
    if (c === '"' || c === "'") {
        inStr = c;
        continue;
    }
    if (c === '`') {
        inTemplate = true;
        continue;
    }

    if (c === '{' || c === '(' || c === '[') {
        stack.push({ char: c, index: i });
    } else if (c === '}' || c === ')' || c === ']') {
        const top = stack.pop();
        if (!top) {
            console.log("Unmatched closing", c, "at index", i);
        } else {
            if (top.char === '`' && c === '}') {
                inTemplate = true; // resume template literal
            } else if ((c === '}' && top.char !== '{') || (c === ')' && top.char !== '(') || (c === ']' && top.char !== '[')) {
                console.log("Mismatched", top.char, "with", c, "at index", i);
            }
        }
    }
}

console.log("Remaining unclosed stack size:", stack.length);
if (stack.length > 0) {
    stack.slice(-5).forEach(item => {
        const linesUpTo = code.substring(0, item.index).split('\n');
        console.log("Unclosed", item.char, "at line", linesUpTo.length, "content:", linesUpTo[linesUpTo.length - 1].trim());
    });
}
