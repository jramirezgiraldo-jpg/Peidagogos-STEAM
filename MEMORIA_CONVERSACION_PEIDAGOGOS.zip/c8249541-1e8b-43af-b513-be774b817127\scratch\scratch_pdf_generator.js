const fs = require('fs');

function escapePdfText(text) {
    return text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function createPdf(filename, title, sections) {
    let objects = [];
    
    // 1: Catalog
    objects.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj');
    
    // 2: Pages
    objects.push('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj');
    
    // Build page stream text
    let streamLines = [];
    streamLines.push('BT');
    
    // Title
    streamLines.push('/F1 18 Tf');
    streamLines.push('40 780 Td');
    streamLines.push(`(${escapePdfText(title)}) Tj`);
    
    // Subtitle
    streamLines.push('/F2 10 Tf');
    streamLines.push('0 -22 Td');
    streamLines.push('(Direccion Nacional de Derecho de Autor - Republica de Colombia) Tj');
    streamLines.push('0 -15 Td');
    streamLines.push('(Obra: PEIDAGOGOS STEAM  |  Autor: Juan Felipe Ramirez Giraldo - CC 9770462  |  Ano: 2026) Tj');
    
    // Divider line
    streamLines.push('/F2 10 Tf');
    streamLines.push('0 -15 Td');
    streamLines.push('(-------------------------------------------------------------------------------------------------------------------------) Tj');
    
    let currentYOffset = -22;
    sections.forEach(sec => {
        streamLines.push('/F1 12 Tf');
        streamLines.push(`0 ${currentYOffset} Td`);
        streamLines.push(`(${escapePdfText(sec.header)}) Tj`);
        
        streamLines.push('/F2 9.5 Tf');
        sec.lines.forEach(line => {
            streamLines.push('0 -14 Td');
            streamLines.push(`(${escapePdfText(line)}) Tj`);
        });
        currentYOffset = -20;
    });
    
    streamLines.push('ET');
    
    const streamContent = streamLines.join('\n');
    const streamLength = Buffer.byteLength(streamContent);
    
    // 4: Contents Stream
    objects.push(`4 0 obj\n<< /Length ${streamLength} >>\nstream\n${streamContent}\nendstream\nendobj`);
    
    // 5: Font F1 (Helvetica Bold)
    objects.push('5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj');
    
    // 6: Font F2 (Helvetica)
    objects.push('6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj');
    
    // 3: Page
    objects.push('3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>\nendobj');
    
    // Compute xref
    let offset = 0;
    let xref = ['xref', '0 7', '0000000000 65535 f '];
    
    let pdfHeader = '%PDF-1.4\n';
    offset += Buffer.byteLength(pdfHeader);
    
    let body = '';
    const objMap = {
        1: objects[0],
        2: objects[1],
        3: objects[6],
        4: objects[2],
        5: objects[3],
        6: objects[4]
    };
    
    for (let i = 1; i <= 6; i++) {
        const objStr = objMap[i] + '\n';
        const strOffset = String(offset).padStart(10, '0');
        xref.push(`${strOffset} 00000 n `);
        body += objStr;
        offset += Buffer.byteLength(objStr);
    }
    
    const xrefContent = xref.join('\n') + '\n';
    const trailer = `trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n${offset}\n%%EOF\n`;
    
    const fullPdf = pdfHeader + body + xrefContent + trailer;
    fs.writeFileSync(filename, fullPdf, 'binary');
}

const sections = [
    {
        header: '1. OBJETO Y FINALIDAD DEL SOFTWARE',
        lines: [
            'PEIDAGOGOS STEAM es una plataforma integral EdTech para la ensenanza, gestion del aprendizaje adaptativo',
            'y evaluacion por competencias STEAM articulada con las mallas curriculares y Derechos Basicos de Aprendizaje (DBA)',
            'de Colombia. Incorpora motor pedagogico asistido por Inteligencia Artificial y mecanicas de gamificacion continua.'
        ]
    },
    {
        header: '2. ESPECIFICACION TECNICA Y ARQUITECTURA',
        lines: [
            '- Backend: Servidor RESTful Node.js / Express.js con control de sesiones, seguridad HTTP y persistencia JSON indexada.',
            '- Frontend: SPA responsiva en HTML5, CSS3 y JavaScript moderno con vistas adaptadas a movil, tablet y escritorio.',
            '- Motor IA: Asistente pedagogico server-side para generacion de guias didacticas contextualizadas y preguntas ICFES.',
            '- Seguridad: Encabezados de seguridad, trazabilidad de estudiantes y marcas de agua digitales de derechos de autor.',
            '- Alertas: Notificaciones transaccionales y de matricula automatizadas en tiempo real.'
        ]
    },
    {
        header: '3. MODULOS Y FUNCIONALIDADES PRINCIPALES',
        lines: [
            '- Modulo Aulas y Mallas DBA: Explorador interactivo de estandares curriculares por periodos y semanas academicas.',
            '- Modulo Guias de Aprendizaje Continuo: Generador y persistencia de guias interactivas por semana y estudiante.',
            '- Modulo Gamificacion (XP): Acumulacion de experiencia, rangos jerarquicos, logros, sanciones y Salon de la Fama.',
            '- Modulo Multirrol: Paneles para Docentes, Tutores Home School, Estudiantes de Validacion y Administrador General.',
            '- Modulo Proyector: Interfaz interactiva de alta resolucion para transmision en salas de clase y tableros digitales.'
        ]
    },
    {
        header: '4. ESTRUCTURA DEL CODIGO FUENTE (PAQUETE DE REGISTRO)',
        lines: [
            '- server.js (Servidor Backend y APIs) | app.js (Logica de Cliente y Gamificacion) | login.html (Interfaz SPA)',
            '- diagnostico_nocturno.js (Modulo de Evaluacion Diagnostica) | proyector.html (Panel de Proyeccion en Aula)'
        ]
    }
];

createPdf('d:\\Peidagogos_Local\\DESCRIPCION_TECNICA_PEIDAGOGOS_STEAM.pdf', 'MEMORIA TECNICA Y DESCRIPCION FUNCIONAL', sections);
console.log('PDF generado exitosamente!');
