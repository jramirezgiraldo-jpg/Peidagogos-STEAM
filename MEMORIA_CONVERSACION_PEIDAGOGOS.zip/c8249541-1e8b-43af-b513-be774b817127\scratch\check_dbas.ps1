$f1 = "C:\Users\Juan Felipe\Documents\DBA C naturales.pdf"
$f2 = "C:\Users\Juan Felipe\Documents\DBA C sociales.pdf"
$f3 = "C:\Users\Juan Felipe\Documents\DBA lenguaje.pdf"
$f4 = "C:\Users\Juan Felipe\Documents\DBA matematicas.pdf"

$list = @($f1, $f2, $f3, $f4)

foreach ($item in $list) {
    if (Test-Path -LiteralPath $item) {
        $fileInfo = Get-Item -LiteralPath $item
        $mb = [math]::Round($fileInfo.Length / 1MB, 2)
        Write-Host "FOUND: $item ($mb MB)"
    } else {
        Write-Host "NOT FOUND: $item"
    }
}
