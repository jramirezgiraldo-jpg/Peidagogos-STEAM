function PerteneceAlGrupo($est, $grupoName) {
    if (-not $est -or -not $grupoName) { return $false }
    $gEst = "$($est.grupo)".Trim()
    $graEst = "$($est.grado)".Trim()
    $target = "$grupoName".Trim()

    if ($gEst -eq $target -or $graEst -eq $target) { return $true }

    # Comparacion robusta para Ciclos (VI, IV, V, III, II, I)
    if ($target.ToLower().Contains('ciclo') -or $gEst.ToLower().Contains('ciclo') -or $graEst.ToLower().Contains('ciclo')) {
        $regexCiclo = 'ciclo\s*(VI|IV|V|III|II|I)\b'
        $targetMatch = [regex]::Match($target, $regexCiclo, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($targetMatch.Success) {
            $cTarget = $targetMatch.Groups[1].Value.ToUpper()
            $estMatch = [regex]::Match(($gEst + " " + $graEst), $regexCiclo, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if ($estMatch.Success -and $estMatch.Groups[1].Value.ToUpper() -eq $cTarget) {
                return $true
            }
        }
    }

    if ($target.StartsWith('RM-')) {
        $simpleTarget = $target.Replace('RM-', '').ToLower()
        if ($gEst.ToLower() -eq $target.ToLower() -or $gEst.ToLower() -eq $simpleTarget -or $graEst.ToLower() -eq $simpleTarget) {
            return $true
        }
    }

    if ($gEst.ToLower() -eq $target.ToLower()) { return $true }
    return $false
}

$users = Get-Content 'usuarios.json' | ConvertFrom-Json
$grupos = @(
    '6A', '6B', '7A', '7B', '7C', '8A', '8B', '9A', '10A', '10D', 'PENS',
    'Ciclo I (1°, 2°, 3°)', 'Ciclo II (4°, 5°)', 'Ciclo III (6°, 7°)', 'Ciclo IV (8°, 9°)', 'Ciclo V (10°)', 'Ciclo VI (11°)',
    'Ciclo I', 'Ciclo II', 'Ciclo III', 'Ciclo IV', 'Ciclo V', 'Ciclo VI',
    'HS-1', 'HS-2', 'HS-3', 'HS-4', 'HS-5', 'HS-6'
)

foreach ($g in $grupos) {
    $found = @()
    foreach ($u in $users) {
        if (PerteneceAlGrupo $u $g) {
            $found += $u
        }
    }
    if ($found.Count -gt 0) {
        Write-Host "Grupo [$g] -> $($found.Count) estudiantes:"
        foreach ($f in $found) {
            Write-Host "   - Doc: $($f.documento), Nombre: $($f.nombre) $($f.apellidos), Grado: $($f.grado), Grupo: $($f.grupo)"
        }
    }
}
