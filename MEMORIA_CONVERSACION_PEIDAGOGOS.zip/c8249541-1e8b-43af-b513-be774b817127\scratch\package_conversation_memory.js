const fs = require('fs');
const { execSync } = require('child_process');

const conversationId = 'c8249541-1e8b-43af-b513-be774b817127';
const brainPath = `C:/Users/Juan Felipe/.gemini/antigravity/brain/${conversationId}`;
const targetZip = `d:/Peidagogos_Local/MEMORIA_CONVERSACION_PEIDAGOGOS.zip`;

console.log('=== EMPAQUETANDO MEMORIA COMPLETA CON QUOTING CORRECTO ===');

if (fs.existsSync(brainPath)) {
    try {
        const cmd = `Compress-Archive -LiteralPath '${brainPath}' -DestinationPath '${targetZip}' -Force`;
        execSync(`powershell -Command "${cmd}"`);
        console.log('✅ Memoria completa empaquetada con éxito en:', targetZip);
    } catch(e) {
        console.error('Error al empaquetar:', e.message);
    }
} else {
    console.error('Carpeta brain no encontrada:', brainPath);
}
