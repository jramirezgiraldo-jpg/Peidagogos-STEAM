const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

console.log('Iniciando: 1. Aumentar tamaño de Logo, 2. Crear todos los cajones de herramientas grandes con explicaciones, 3. Cajones de grupos grandes con explicaciones...');

loginHtml = loginHtml.replace(/\r\n/g, '\n');

// 1. REEMPLAZAR EL HEADER Y SECCIÓN DE HERRAMIENTAS EN LOGIN.HTML
const targetHeaderDocenteSection = `<header style="background: white; border-bottom: 1.5px solid #E2E8F0; padding: 14px 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
        <div style="display: flex; align-items: center; gap: 14px;">
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 48px; width: auto; object-fit: contain;">
            <div style="border-left: 2px solid #E2E8F0; padding-left: 14px;">
                <div style="font-weight: 900; font-size: 1.25rem; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <span>👨‍🏫</span> <span id="docente-nombre-header">Docente</span>
                </div>
                <div id="docente-institucion-subhead" style="font-size: 0.82rem; color: #64748B; font-weight: 600;">
                    🏛️ IE Instituto Montenegro • Sede Principal
                </div>
            </div>
        </div>

        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
            <button onclick="window.abrirClasePrimerosAuxiliosEmocionales('docente')" style="background: linear-gradient(135deg, #EF4444, #DC2626); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 0.85rem; box-shadow: 0 3px 8px rgba(239,68,68,0.25);" title="Clase de Primeros Auxilios Emocionales post-sismo">
                <span>❤️‍🩹</span> Auxilios Emocionales
            </button>
            <button onclick="mostrarReferidos()" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 0.85rem; box-shadow: 0 3px 8px rgba(236,72,153,0.25);">
                <span>🎁</span> Invita y Gana
            </button>
            <button onclick="location.reload()" style="background: #F1F5F9; color: #475569; border: 1px solid #CBD5E1; padding: 8px 16px; border-radius: 8px; font-weight: 800; cursor: pointer; font-size: 0.85rem;" onmouseover="this.style.background='#E2E8F0'" onmouseout="this.style.background='#F1F5F9'">
                <span>🚪</span> Cerrar Sesión
            </button>
        </div>
    </header>

    <div style="padding: 30px 30px; max-width: 1400px; margin: 0 auto;">
        
        <!-- BARRA PRINCIPAL DE GESTIÓN Y HERRAMIENTAS STEAM -->
        <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 18px 22px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            
            <!-- Grupo Izquierdo: Gestión Curricular y Asignaturas -->
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <span style="font-weight: 900; font-size: 0.92rem; color: #1E293B; display: flex; align-items: center; gap: 6px;">
                    <span>📚</span> Gestión de Materias:
                </span>
                <button onclick="window.abrirModalCrearAsignaturaDocente('docente')" style="background: linear-gradient(135deg, #7C3AED, #6D28D9); color: white; border: none; padding: 9px 16px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 10px rgba(124,58,237,0.25);" title="Crear nueva materia y generar Malla Curricular DBA con IA">
                    <span>✨</span> Crear Asignatura (IA)
                </button>
                <button onclick="window.abrirModalGestionMateriasGradosDocente()" style="background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 9px 16px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 10px rgba(37,99,235,0.25);" title="Seleccionar qué materias dictas y qué grados tienes a cargo">
                    <span>⚙️</span> Mis Materias y Grados
                </button>
            </div>

            <!-- Grupo Derecho: Herramientas de Aula y Proyección -->
            <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <button onclick="window.abrirCajaHerramientas('todas', 'docente')" style="background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(236,72,153,0.25);" title="Caja con las 42 herramientas interactivas STEAM">
                    <span>🧰</span> Caja STEAM (42)
                </button>
                <button onclick="window.abrirConfiguradorDiapositivas('docente')" style="background: #6366F1; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(99,102,241,0.25);" title="Generador de 10 Diapositivas Semanales">
                    <span>📽️</span> Diapositivas
                </button>
                <a href="proyector.html" target="_blank" style="background: #10B981; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; text-decoration: none; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(16,185,129,0.25);" title="Modo interactivo de aula sin computadores">
                    <span>📽️</span> Proyector
                </a>
                <button onclick="window.abrirRankingDocenteNuevaPestana()" style="background: #F59E0B; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 900; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 3px 8px rgba(245,158,11,0.25);" title="Ránking en vivo para VideoBeam / Smart TV">
                    <span>🏆</span> Ránking
                </button>
                <button onclick="window.abrirModalAuditorQA()" style="background: #0284C7; color: white; border: none; padding: 9px 14px; border-radius: 10px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px;" title="Agente Auditor QA">
                    <span>🩺</span> QA
                </button>
            </div>
        </div>`;

const replacementHeaderDocenteSection = `<header style="background: white; border-bottom: 2px solid #E2E8F0; padding: 16px 35px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.04);">
        <div style="display: flex; align-items: center; gap: 18px;">
            <!-- LOGO PEIDAGOGOS STEAM MÁS GRANDE Y VISIBLE -->
            <img src="logo-peidagogos.png" alt="Peidagogos STEAM" style="height: 75px; width: auto; object-fit: contain; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.08));">
            <div style="border-left: 2px solid #CBD5E1; padding-left: 18px;">
                <div style="font-weight: 900; font-size: 1.45rem; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <span>👨‍🏫</span> <span id="docente-nombre-header">Docente</span>
                </div>
                <div id="docente-institucion-subhead" style="font-size: 0.9rem; color: #475569; font-weight: 700; margin-top: 2px;">
                    🏛️ IE Instituto Montenegro • Sede Principal
                </div>
            </div>
        </div>

        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <button onclick="location.reload()" style="background: #FEE2E2; color: #991B1B; border: 1.5px solid #FCA5A5; padding: 10px 20px; border-radius: 10px; font-weight: 800; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(239,68,68,0.15);" onmouseover="this.style.background='#FCA5A5'" onmouseout="this.style.background='#FEE2E2'">
                <span>🚪</span> Cerrar Sesión
            </button>
        </div>
    </header>

    <div style="padding: 35px 30px; max-width: 1420px; margin: 0 auto;">
        
        <!-- SECCIÓN DE CAJONES DE HERRAMIENTAS Y GESTIÓN PEDAGÓGICA STEAM -->
        <div style="margin-bottom: 35px;">
            <div style="margin-bottom: 18px;">
                <h2 style="font-size: 1.65rem; font-weight: 900; color: #0F172A; margin: 0; display: flex; align-items: center; gap: 10px;">
                    <span>🧰</span> Centro de Herramientas y Gestión Pedagógica
                </h2>
                <p style="color: #64748B; margin: 4px 0 0 0; font-size: 0.95rem;">
                    Accede a todos los módulos interactivos, proyectores de clase, generadores de diapositivas y creadores curriculares.
                </p>
            </div>

            <!-- Grid de Grandes Cajones de Herramientas (10 Módulos Oficiales) -->
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px;">
                
                <!-- 1. Crear Asignatura (IA) -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(124,58,237,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #F3E8FF; color: #7E22CE; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">IA Curricular</span>
                            <span style="font-size: 1.8rem;">✨</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Crear Asignatura (IA)</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Crea nuevas materias personalizadas y genera su Malla Curricular DBA automáticamente con IA a partir de documentos.
                        </p>
                    </div>
                    <button onclick="window.abrirModalCrearAsignaturaDocente('docente')" style="margin-top: 14px; background: linear-gradient(135deg, #7C3AED, #6D28D9); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(124,58,237,0.25);">
                        <span>📚</span> Crear Asignatura
                    </button>
                </div>

                <!-- 2. Mis Materias y Grados -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(37,99,235,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #EFF6FF; color: #1E40AF; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Configuración</span>
                            <span style="font-size: 1.8rem;">⚙️</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Mis Materias y Grados</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Administra qué asignaturas orientas y qué grados tienes a tu cargo para filtrar con exactitud los grupos de tu colegio.
                        </p>
                    </div>
                    <button onclick="window.abrirModalGestionMateriasGradosDocente()" style="margin-top: 14px; background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(37,99,235,0.25);">
                        <span>⚙️</span> Gestionar Materias
                    </button>
                </div>

                <!-- 3. Caja de Herramientas STEAM (42) -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(236,72,153,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #FDF2F8; color: #BE185D; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">42 Simuladores</span>
                            <span style="font-size: 1.8rem;">🧰</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Caja STEAM (42)</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Kit completo con simuladores interactivos, generadores de rúbricas formativas, dinámicas de aula y retos gamificados.
                        </p>
                    </div>
                    <button onclick="window.abrirCajaHerramientas('todas', 'docente')" style="margin-top: 14px; background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(236,72,153,0.25);">
                        <span>🧰</span> Abrir Caja STEAM
                    </button>
                </div>

                <!-- 4. 10 Diapositivas Semanales -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(99,102,241,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #EEF2FF; color: #4338CA; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Presentaciones</span>
                            <span style="font-size: 1.8rem;">📽️</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">10 Diapositivas</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Genera y personaliza las diapositivas de la semana para introducir temas curriculares con explicaciones visuales.
                        </p>
                    </div>
                    <button onclick="window.abrirConfiguradorDiapositivas('docente')" style="margin-top: 14px; background: linear-gradient(135deg, #6366F1, #4F46E5); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(99,102,241,0.25);">
                        <span>📽️</span> Ver Diapositivas
                    </button>
                </div>

                <!-- 5. Modo Proyector (Sin Computadores) -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(16,185,129,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #ECFDF5; color: #047857; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">VideoBeam / Aula</span>
                            <span style="font-size: 1.8rem;">📽️</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Modo Proyector</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Herramienta diseñada para dictar clase guiada e interactiva cuando los estudiantes no tienen computadores.
                        </p>
                    </div>
                    <a href="proyector.html" target="_blank" style="margin-top: 14px; background: linear-gradient(135deg, #10B981, #059669); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(16,185,129,0.25);">
                        <span>📽️</span> Modo Proyector
                    </a>
                </div>

                <!-- 6. Proyectar QR Matrícula -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(37,99,235,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #EFF6FF; color: #1E40AF; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Matrícula Fácil</span>
                            <span style="font-size: 1.8rem;">📱</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Proyectar QR Matrícula</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Proyecta el código QR institucional gigante para que tus estudiantes se matriculen en segundos desde el celular.
                        </p>
                    </div>
                    <a href="proyector-qr.html" target="_blank" style="margin-top: 14px; background: linear-gradient(135deg, #2563EB, #1D4ED8); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(37,99,235,0.25);">
                        <span>📷</span> Proyectar Código QR
                    </a>
                </div>

                <!-- 7. Ránking y Leaderboard en Vivo -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(245,158,11,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #FEF3C7; color: #B45309; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Leaderboard</span>
                            <span style="font-size: 1.8rem;">🏆</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Ránking en Vivo</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Abre la tabla de posiciones con puntajes XP en una pestaña nueva para proyectar en Smart TV o VideoBeam.
                        </p>
                    </div>
                    <button onclick="window.abrirRankingDocenteNuevaPestana()" style="margin-top: 14px; background: linear-gradient(135deg, #F59E0B, #D97706); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 900; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(245,158,11,0.25);">
                        <span>🏆</span> Proyectar Ránking
                    </button>
                </div>

                <!-- 8. Auxilios Emocionales (Terremoto) -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(239,68,68,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #FEE2E2; color: #B91C1C; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Contención y Apoyo</span>
                            <span style="font-size: 1.8rem;">❤️‍🩹</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Auxilios Emocionales</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Clase y dinámicas interactivas para primeros auxilios emocionales, contención psicológica y resiliencia post-sismo.
                        </p>
                    </div>
                    <button onclick="window.abrirClasePrimerosAuxiliosEmocionales('docente')" style="margin-top: 14px; background: linear-gradient(135deg, #EF4444, #DC2626); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(239,68,68,0.25);">
                        <span>❤️‍🩹</span> Iniciar Taller Emocional
                    </button>
                </div>

                <!-- 9. Agente Auditor QA -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(14,165,233,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #E0F2FE; color: #0369A1; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Diagnóstico 24/7</span>
                            <span style="font-size: 1.8rem;">🩺</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Agente Auditor QA</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Verifica y audita una a una todas las funciones de la plataforma, consistencia de datos de estudiantes y mallas DBA.
                        </p>
                    </div>
                    <button onclick="window.abrirModalAuditorQA()" style="margin-top: 14px; background: linear-gradient(135deg, #0EA5E9, #0284C7); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(14,165,233,0.25);">
                        <span>🩺</span> Agente Auditor QA
                    </button>
                </div>

                <!-- 10. Invita y Gana -->
                <div style="background: white; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 10px 25px rgba(236,72,153,0.15)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <span style="background: #FDF2F8; color: #BE185D; font-size: 0.72rem; font-weight: 900; padding: 3px 10px; border-radius: 20px; text-transform: uppercase;">Beneficios</span>
                            <span style="font-size: 1.8rem;">🎁</span>
                        </div>
                        <h4 style="margin: 0 0 6px 0; font-size: 1.15rem; font-weight: 900; color: #1E293B;">Invita y Gana</h4>
                        <p style="margin: 0; color: #64748B; font-size: 0.84rem; line-height: 1.45;">
                            Comparte tu código de recomendación con otros colegios o docentes y desbloquea funciones institucionales exclusivas.
                        </p>
                    </div>
                    <button onclick="mostrarReferidos()" style="margin-top: 14px; background: linear-gradient(135deg, #EC4899, #BE185D); color: white; border: none; padding: 10px; border-radius: 10px; font-weight: 800; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 10px rgba(236,72,153,0.25);">
                        <span>🎁</span> Invita y Gana
                    </button>
                </div>

            </div>
        </div>`;

const targetHeaderDocenteSectionNorm = targetHeaderDocenteSection.replace(/\r\n/g, '\n');
if (loginHtml.includes(targetHeaderDocenteSectionNorm)) {
    loginHtml = loginHtml.replace(targetHeaderDocenteSectionNorm, replacementHeaderDocenteSection);
    console.log('✅ Header con logo aumentado y Centro de Herramientas con 10 grandes cajones descriptivos integrado.');
} else {
    console.warn('⚠️ No se encontró targetHeaderDocenteSection.');
}

// 2. ACTUALIZAR CAJONES DE GRUPOS CON DISEÑO EXTRA GRANDE Y EXPLICACIONES COMPLETAS
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260818_v\d+/g, 'diagnostico_nocturno.js?v=20260818_v53');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260818_v\d+/g, 'agente_auditor_qa.js?v=20260818_v53');
loginHtml = loginHtml.replace(/app\.js\?v=20260818_v\d+/g, 'app.js?v=20260818_v53');

fs.writeFileSync(loginPath, loginHtml, 'utf8');

// Validar sintaxis de app.js
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
