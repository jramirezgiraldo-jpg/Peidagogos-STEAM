const fs = require('fs');
const vm = require('vm');

const loginPath = 'd:/Peidagogos_Local/login.html';
const appPath = 'd:/Peidagogos_Local/app.js';

let loginHtml = fs.readFileSync(loginPath, 'utf8');
let appJs = fs.readFileSync(appPath, 'utf8');

loginHtml = loginHtml.replace(/\r\n/g, '\n');
appJs = appJs.replace(/\r\n/g, '\n');

console.log('=== AUDITORÍA Y POTENCIACIÓN DE MOTORES EN TIEMPO REAL POR DEMANDA ===');

// 1. Verificar y potenciar el generador de Secuencias Didácticas Pro en tiempo real
// Asegurar que renderizarSecuenciaDidacticaTool permita personalizar modelos, horas, minutero e ingesta
const motorSecuenciaDidacticaRealtime = `
// ==========================================================================
// GENERADOR DINÁMICO DE SECUENCIAS DIDÁCTICAS PRO EN TIEMPO REAL
// ==========================================================================
window.renderizarSecuenciaDidacticaTool = function(stage, base) {
    const data = window.generarDatosPedagogicosDinamicos(base.materia, base.grado, base.concepto, base.dificultad);
    
    // Modelos Pedagógicos configurables
    const modelosPedagogicos = [
        { id: 'constructivismo', nombre: 'Constructivismo y Aprendizaje Significativo (Ausubel/Piaget)' },
        { id: 'abp', nombre: 'Aprendizaje Basado en Proyectos (ABP STEAM)' },
        { id: 'aula_invertida', nombre: 'Aula Invertida (Flipped Classroom)' },
        { id: 'epc', nombre: 'Enseñanza para la Comprensión (Harvard Project Zero)' },
        { id: 'socioformativo', nombre: 'Enfoque Socioformativo y Competencias para la Vida (Tobón)' },
        { id: 'pensamiento_critico', nombre: 'Pensamiento Crítico y Resolución de Problemas Complejos' },
        { id: 'steam_integrado', nombre: 'STEAM Integrado (Ciencia, Tecnología, Ingeniería, Arte, Matemáticas)' },
        { id: 'tradicional_activo', nombre: 'Pedagogía Dialogante y Activa' }
    ];

    const modeloSeleccionado = base.modelo || modelosPedagogicos[1].nombre;
    const horasSemanales = base.horas || 4;
    const minutosInicio = Math.round(horasSemanales * 60 * 0.20);
    const minutosDesarrollo = Math.round(horasSemanales * 60 * 0.60);
    const minutosCierre = Math.round(horasSemanales * 60 * 0.20);

    stage.innerHTML = \`
        <div style="flex: 1; padding: 24px; background: #FFFFFF; display: flex; flex-direction: column; gap: 20px; text-align: left; overflow-y: auto;">
            
            <!-- Encabezado de la Secuencia Didáctica Pro -->
            <div style="background: linear-gradient(135deg, #1E40AF, #3B82F6); border-radius: 18px; padding: 22px 26px; color: white; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px; box-shadow: 0 8px 25px rgba(37,99,235,0.25);">
                <div>
                    <span style="background: rgba(255,255,255,0.22); color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; text-transform: uppercase; font-weight: 900; letter-spacing: 0.5px;">
                        Planificación Oficial en Tiempo Real • Estándares MEN
                    </span>
                    <h2 style="margin: 8px 0 3px 0; font-size: 1.6rem; font-weight: 900; color: white;">
                        Secuencia Didáctica: \${data.tema}
                    </h2>
                    <div style="font-size: 0.92rem; opacity: 0.95; font-weight: 600;">
                        📚 \${base.materia} • 🎓 Grado \${base.grado}° • ⏱️ \${horasSemanales} Horas Semanales (\${horasSemanales * 60} min)
                    </div>
                </div>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="window.print()" style="background: white; color: #1E40AF; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 900; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                        <span>🖨️</span> Imprimir PDF
                    </button>
                </div>
            </div>

            <!-- Panel de Parámetros Dinámicos y Modelo Pedagógico -->
            <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 16px; padding: 18px 22px; display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 14px; align-items: center;">
                <div>
                    <label style="display: block; font-size: 0.8rem; font-weight: 800; color: #475569; margin-bottom: 4px; text-transform: uppercase;">Modelo Pedagógico:</label>
                    <div style="font-weight: 900; color: #1E293B; font-size: 0.95rem;">🎯 \${modeloSeleccionado}</div>
                </div>
                <div>
                    <label style="display: block; font-size: 0.8rem; font-weight: 800; color: #475569; margin-bottom: 4px; text-transform: uppercase;">Enfoque STEAM Integrado:</label>
                    <div style="font-weight: 900; color: #059669; font-size: 0.95rem;">🌿 Ciencia + Tecnología + Pensamiento Crítico</div>
                </div>
                <div>
                    <label style="display: block; font-size: 0.8rem; font-weight: 800; color: #475569; margin-bottom: 4px; text-transform: uppercase;">Pregunta Problematizadora:</label>
                    <div style="font-weight: 800; color: #7C3AED; font-size: 0.9rem;">¿Cómo influye \${data.tema} en la sostenibilidad de nuestro entorno?</div>
                </div>
            </div>

            <!-- Minutero Proporcional y Momentos de la Clase -->
            <div style="display: flex; flex-direction: column; gap: 16px;">
                <h3 style="margin: 0; font-size: 1.25rem; font-weight: 900; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <span>⏱️</span> Momentos Pedagógicos de la Clase (Minutero Proporcional Dinámico)
                </h3>

                <!-- Momento 1: Inicio / Exploración -->
                <div style="background: #EFF6FF; border: 2px solid #93C5FD; border-radius: 16px; padding: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="font-weight: 900; color: #1E40AF; font-size: 1.05rem;">1. Inicio / Exploración y Activación de Presaberes</span>
                        <span style="background: #DBEAFE; color: #1E40AF; padding: 4px 12px; border-radius: 20px; font-weight: 900; font-size: 0.82rem;">\${minutosInicio} Minutos (20%)</span>
                    </div>
                    <p style="margin: 0 0 10px 0; color: #334155; font-size: 0.9rem; line-height: 1.5;">
                        • <strong>Pregunta Detonante:</strong> \${data.debateDetonante || '¿Qué sabemos acerca de ' + data.tema + ' y cómo lo observamos en nuestro municipio?'}
                    </p>
                    <p style="margin: 0; color: #475569; font-size: 0.88rem; line-height: 1.45;">
                        • <strong>Dinámica:</strong> Lluvia de ideas digital en Pizarra STEAM y visualización del mentefacto conceptual base.
                    </p>
                </div>

                <!-- Momento 2: Desarrollo / Construcción del Conocimiento -->
                <div style="background: #F0FDF4; border: 2px solid #86EFAC; border-radius: 16px; padding: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="font-weight: 900; color: #166534; font-size: 1.05rem;">2. Desarrollo / Construcción Conceptual y Modelación</span>
                        <span style="background: #DCFCE7; color: #166534; padding: 4px 12px; border-radius: 20px; font-weight: 900; font-size: 0.82rem;">\${minutosDesarrollo} Minutos (60%)</span>
                    </div>
                    <p style="margin: 0 0 10px 0; color: #334155; font-size: 0.9rem; line-height: 1.5;">
                        • <strong>Actividad Central:</strong> Taller práctico y laboratorio virtual guiado sobre <em>\${data.tema}</em> con herramientas interactivas de la Caja STEAM.
                    </p>
                    <p style="margin: 0; color: #475569; font-size: 0.88rem; line-height: 1.45;">
                        • <strong>Trabajo Colaborativo:</strong> Equipos de 4 estudiantes analizando variables clave: \${data.palabras.slice(0, 5).join(', ')}.
                    </p>
                </div>

                <!-- Momento 3: Cierre / Evaluación Formativa y Transferencia -->
                <div style="background: #FAF5FF; border: 2px solid #D8B4FE; border-radius: 16px; padding: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="font-weight: 900; color: #6B21A8; font-size: 1.05rem;">3. Cierre / Evaluación Formativa y Transferencia</span>
                        <span style="background: #F3E8FF; color: #6B21A8; padding: 4px 12px; border-radius: 20px; font-weight: 900; font-size: 0.82rem;">\${minutosCierre} Minutos (20%)</span>
                    </div>
                    <p style="margin: 0 0 10px 0; color: #334155; font-size: 0.9rem; line-height: 1.5;">
                        • <strong>Socialización y Rúbrica:</strong> Presentación de conclusiones por equipos y autoevaluación formativa con Exit Tickets.
                    </p>
                    <p style="margin: 0; color: #475569; font-size: 0.88rem; line-height: 1.45;">
                        • <strong>Transferencia a la Vida Real:</strong> Formulación de una propuesta de aplicación de \${data.tema} para la comunidad educativa.
                    </p>
                </div>
            </div>

            <!-- Rúbrica de Evaluación Formativa Asociada -->
            <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 16px; padding: 20px;">
                <h4 style="margin: 0 0 12px 0; font-size: 1.15rem; font-weight: 900; color: #0F172A; display: flex; align-items: center; gap: 8px;">
                    <span>📊</span> Matriz de Desempeños Formativos (Escala Nacional MEN)
                </h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
                    <div style="background: #ECFDF5; border: 1px solid #A7F3D0; padding: 12px; border-radius: 10px;">
                        <span style="font-size: 0.75rem; font-weight: 900; color: #047857; text-transform: uppercase;">Superior (4.6 - 5.0)</span>
                        <p style="margin: 4px 0 0 0; font-size: 0.82rem; color: #065F46; line-height: 1.4;">Diseña, modela y argumenta soluciones innovadoras aplicando \${data.tema} en contextos complejos.</p>
                    </div>
                    <div style="background: #EFF6FF; border: 1px solid #BFDBFE; padding: 12px; border-radius: 10px;">
                        <span style="font-size: 0.75rem; font-weight: 900; color: #1E40AF; text-transform: uppercase;">Alto (4.0 - 4.5)</span>
                        <p style="margin: 4px 0 0 0; font-size: 0.82rem; color: #1E3A8A; line-height: 1.4;">Comprende y explica con claridad los principios y fórmulas asociadas a \${data.tema}.</p>
                    </div>
                    <div style="background: #FEF3C7; border: 1px solid #FDE68A; padding: 12px; border-radius: 10px;">
                        <span style="font-size: 0.75rem; font-weight: 900; color: #92400E; text-transform: uppercase;">Básico (3.0 - 3.9)</span>
                        <p style="margin: 4px 0 0 0; font-size: 0.82rem; color: #78350F; line-height: 1.4;">Identifica los conceptos básicos de \${data.tema} con apoyo del docente.</p>
                    </div>
                    <div style="background: #FEF2F2; border: 1px solid #FECACA; padding: 12px; border-radius: 10px;">
                        <span style="font-size: 0.75rem; font-weight: 900; color: #991B1B; text-transform: uppercase;">Bajo (1.0 - 2.9)</span>
                        <p style="margin: 4px 0 0 0; font-size: 0.82rem; color: #7F1D1D; line-height: 1.4;">Presenta dificultades en la apropiación de conceptos; requiere plan de mejoramiento.</p>
                    </div>
                </div>
            </div>

        </div>
    \`;
};
`;

// Reemplazar o actualizar renderizarSecuenciaDidacticaTool en app.js
if (appJs.includes('window.renderizarSecuenciaDidacticaTool = function')) {
    const sIdx = appJs.indexOf('window.renderizarSecuenciaDidacticaTool = function');
    const eIdx = appJs.indexOf('window.renderizarFichaLaboratorioTool = function', sIdx);
    if (sIdx !== -1 && eIdx !== -1) {
        appJs = appJs.slice(0, sIdx) + motorSecuenciaDidacticaRealtime + '\n\n' + appJs.slice(eIdx);
        console.log('✅ Motor de Secuencias Didácticas Pro en tiempo real actualizado.');
    }
} else {
    appJs += '\n' + motorSecuenciaDidacticaRealtime;
    console.log('✅ Motor de Secuencias Didácticas Pro inyectado en app.js');
}

// Actualizar versión de scripts a v63
loginHtml = loginHtml.replace(/diagnostico_nocturno\.js\?v=20260819_v\d+/g, 'diagnostico_nocturno.js?v=20260819_v63');
loginHtml = loginHtml.replace(/agente_auditor_qa\.js\?v=20260819_v\d+/g, 'agente_auditor_qa.js?v=20260819_v63');
loginHtml = loginHtml.replace(/app\.js\?v=20260819_v\d+/g, 'app.js?v=20260819_v63');

fs.writeFileSync(loginPath, loginHtml, 'utf8');
fs.writeFileSync(appPath, appJs, 'utf8');

// Validar sintaxis
try {
    new vm.Script(appJs);
    console.log('✨ app.js validado (0 errores).');
} catch(e) {
    console.error('Error app.js:', e);
}
